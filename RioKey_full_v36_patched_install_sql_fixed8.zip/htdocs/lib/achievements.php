<?php
function achievements_check(int $user_id, string $event, array $data = []): void {
  user_features_ensure_schema();
  badges_seed_defaults();

  try {
    if ($event === 'topup_approved') {
      $st = db()->prepare("SELECT COUNT(*) c FROM wallet_transactions WHERE user_id=? AND type='topup_approved'");
      $st->execute([$user_id]);
      $c = (int)($st->fetchColumn() ?: 0);
      if ($c >= 1) user_award_badge($user_id,'first_topup');
      return;
    }

    if ($event === 'purchase') {
      $st = db()->prepare("SELECT COUNT(*) c FROM shop_orders WHERE user_id=?");
      $st->execute([$user_id]);
      $c = (int)($st->fetchColumn() ?: 0);
      if ($c >= 1) user_award_badge($user_id,'first_purchase');
      if ($c >= 10) user_award_badge($user_id,'collector_10');
      return;
    }

    if ($event === 'coupon_redeem') {
      $st = db()->prepare("SELECT COUNT(*) c FROM coupon_redemptions WHERE user_id=?");
      $st->execute([$user_id]);
      $c = (int)($st->fetchColumn() ?: 0);
      if ($c >= 5) user_award_badge($user_id,'coupon_hunter_5');
      return;
    }

    if ($event === 'vip_active') {
      user_award_badge($user_id,'vip_member');
      return;
    }

    if ($event === 'checkin') {
      $streak = (int)($data['streak'] ?? 0);
      if ($streak >= 7) user_award_badge($user_id,'streak_7', ['streak'=>$streak]);
      return;
    }

    if ($event === 'community_post') {
      $st = db()->prepare("SELECT COUNT(*) c FROM community_posts WHERE user_id=?");
      $st->execute([$user_id]);
      $c = (int)($st->fetchColumn() ?: 0);
      if ($c >= 5) user_award_badge($user_id,'community_contributor');
      return;
    }
  } catch (Throwable $e) {}
}
