<?php

function rate_limit_exceeded(string $key, int $limit, int $window_sec): bool {
  $pdo = db();
  // table
  if (!db_has_table('rate_limits')) {
    try {
      $pdo->exec("CREATE TABLE rate_limits (
        k VARCHAR(120) PRIMARY KEY,
        cnt INT NOT NULL DEFAULT 0,
        reset_at DATETIME NOT NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
  }

  $now = time();
  $reset_at = date('Y-m-d H:i:s', $now + $window_sec);

  $pdo->beginTransaction();
  try {
    $st = $pdo->prepare("SELECT cnt, reset_at FROM rate_limits WHERE k=? FOR UPDATE");
    $st->execute([$key]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
      $pdo->prepare("INSERT INTO rate_limits(k,cnt,reset_at) VALUES(?,?,?)")->execute([$key,1,$reset_at]);
      $pdo->commit();
      return false;
    }

    $reset_ts = strtotime((string)$row['reset_at']);
    if (!$reset_ts || $reset_ts <= $now) {
      $pdo->prepare("UPDATE rate_limits SET cnt=1, reset_at=? WHERE k=?")->execute([$reset_at,$key]);
      $pdo->commit();
      return false;
    }

    $cnt = (int)$row['cnt'] + 1;
    if ($cnt > $limit) { $pdo->commit(); return true; }
    $pdo->prepare("UPDATE rate_limits SET cnt=? WHERE k=?")->execute([$cnt,$key]);
    $pdo->commit();
    return false;
  } catch (Throwable $e) {
    try { $pdo->rollBack(); } catch (Throwable $x) {}
    return false;
  }
}

function community_ensure_schema(): void {
  $pdo = db();

  // posts columns
  $cols = [
    'is_approved' => "ALTER TABLE community_posts ADD COLUMN is_approved TINYINT(1) NOT NULL DEFAULT 1",
    'is_locked'   => "ALTER TABLE community_posts ADD COLUMN is_locked TINYINT(1) NOT NULL DEFAULT 0",
    'updated_at'  => "ALTER TABLE community_posts ADD COLUMN updated_at DATETIME NULL",
  ];
  foreach($cols as $c=>$sql){
    if (!db_has_column('community_posts',$c)) { try { $pdo->exec($sql); } catch (Throwable $e) {} }
  }

  // comments columns
  if (!db_has_column('community_comments','is_approved')) {
    try { $pdo->exec("ALTER TABLE community_comments ADD COLUMN is_approved TINYINT(1) NOT NULL DEFAULT 1"); } catch (Throwable $e) {}
  }
  if (!db_has_column('community_comments','ip')) {
    try { $pdo->exec("ALTER TABLE community_comments ADD COLUMN ip VARCHAR(64) NULL"); } catch (Throwable $e) {}
  }
  if (!db_has_column('community_comments','ua')) {
    try { $pdo->exec("ALTER TABLE community_comments ADD COLUMN ua VARCHAR(255) NULL"); } catch (Throwable $e) {}
  }

  // edits history
  if (!db_has_table('community_edits')) {
    try {
      $pdo->exec("CREATE TABLE community_edits (
        id INT AUTO_INCREMENT PRIMARY KEY,
        post_id INT NOT NULL,
        editor_id INT NOT NULL,
        old_title VARCHAR(255) NULL,
        old_content MEDIUMTEXT NULL,
        note VARCHAR(255) NULL,
        created_at DATETIME NOT NULL,
        INDEX idx_post (post_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
  }

  // tickets
  if (!db_has_table('support_tickets')) {
    try {
      $pdo->exec("CREATE TABLE support_tickets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        type VARCHAR(40) NOT NULL,
        order_id INT NULL,
        key_id INT NULL,
        subject VARCHAR(255) NULL,
        content MEDIUMTEXT NOT NULL,
        status ENUM('open','in_progress','resolved','rejected') NOT NULL DEFAULT 'open',
        staff_note VARCHAR(255) NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NULL,
        INDEX idx_user (user_id),
        INDEX idx_status (status)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
  }
}

function user_is_muted(array $u): bool {
  $mu = $u['mute_until'] ?? null;
  if (!$mu) return false;
  $ts = strtotime((string)$mu);
  return $ts && time() < $ts;
}

function community_text_has_blocked_words(string $text): bool {
  $raw = (string)setting('community_blocked_words', '');
  if ($raw === '') return false;
  $hay = function_exists('mb_strtolower') ? mb_strtolower($text,'UTF-8') : strtolower($text);
  $kws = preg_split('/[\r\n,]+/', $raw);
  foreach($kws as $k){
    $k = trim(function_exists('mb_strtolower') ? mb_strtolower($k,'UTF-8') : strtolower($k));
    if ($k==='') continue;
    $pos = function_exists('mb_strpos') ? mb_strpos($hay,$k,0,'UTF-8') : strpos($hay,$k);
    if ($pos !== false) return true;
  }
  return false;
}

function community_should_review(array $u): bool {
  $days = (int)setting('community_review_days', 7);
  $created = $u['created_at'] ?? null;
  if (!$created) return true;
  $age = (int)floor((time() - strtotime((string)$created))/86400);
  if ($age < 0) $age = 0;
  return $age < $days;
}
