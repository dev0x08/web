<?php

function reviews_ensure_schema(): void {
  $pdo = db();
  if (!db_has_table('product_reviews')) {
    try {
      $pdo->exec("CREATE TABLE product_reviews (
        id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        user_id INT NOT NULL,
        rating TINYINT NOT NULL,
        content TEXT NULL,
        status ENUM('pending','approved','hidden') NOT NULL DEFAULT 'pending',
        created_at DATETIME NOT NULL,
        updated_at DATETIME NULL,
        UNIQUE KEY uq_user_product (user_id, product_id),
        INDEX idx_product (product_id),
        INDEX idx_status (status),
        INDEX idx_created (created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
  }
  try {
    if (!db_has_column('users','avatar_frame')) $pdo->exec("ALTER TABLE users ADD COLUMN avatar_frame VARCHAR(40) NULL");
  } catch (Throwable $e) {}
}

function review_star_row(int $rating): string {
  $rating = max(0, min(5, $rating));
  $html = '';
  for($i=1;$i<=5;$i++){
    $html .= $i <= $rating
      ? '<span class="text-orange-300">★</span>'
      : '<span class="text-slate-600">★</span>';
  }
  return $html;
}

function review_can_write(int $user_id, int $product_id): bool {
  if($user_id<=0 || $product_id<=0) return false;
  // must have purchased
  $st = db()->prepare("SELECT 1 FROM shop_orders WHERE user_id=? AND product_id=? LIMIT 1");
  $st->execute([$user_id,$product_id]);
  if(!$st->fetchColumn()) return false;
  return true;
}

function review_get_summary(int $product_id): array {
  reviews_ensure_schema();
  $st = db()->prepare("SELECT COUNT(*) c, AVG(rating) a FROM product_reviews WHERE product_id=? AND status='approved'");
  $st->execute([$product_id]);
  $row = $st->fetch(PDO::FETCH_ASSOC) ?: [];
  $cnt = (int)($row['c'] ?? 0);
  $avg = (float)($row['a'] ?? 0);
  return ['count'=>$cnt,'avg'=>$avg];
}

function review_list(int $product_id, int $limit=30): array {
  reviews_ensure_schema();
  $limit = max(1, min(100, $limit));
  $st = db()->prepare("SELECT r.*, u.username FROM product_reviews r
    JOIN users u ON u.id=r.user_id
    WHERE r.product_id=? AND r.status='approved'
    ORDER BY r.created_at DESC
    LIMIT $limit");
  $st->execute([$product_id]);
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function review_upsert(int $user_id, int $product_id, int $rating, string $content): array {
  reviews_ensure_schema();
  if(!review_can_write($user_id,$product_id)) return ['ok'=>false,'error'=>'Bạn cần mua sản phẩm trước khi đánh giá.'];
  $rating = max(1, min(5, $rating));
  $content = trim($content);
  if($content==='') $content = null;

  // auto approve (you can switch to pending if want)
  $status = (string)setting('reviews_auto_approve','1') === '1' ? 'approved' : 'pending';

  try {
    db()->prepare("INSERT INTO product_reviews(product_id,user_id,rating,content,status,created_at) VALUES(?,?,?,?,?,NOW())
      ON DUPLICATE KEY UPDATE rating=VALUES(rating), content=VALUES(content), status=VALUES(status), updated_at=NOW()")
      ->execute([$product_id,$user_id,$rating,$content,$status]);
    return ['ok'=>true,'status'=>$status];
  } catch (Throwable $e) {
    return ['ok'=>false,'error'=>$e->getMessage()];
  }
}

function admin_review_list(string $status='pending', int $limit=200): array {
  reviews_ensure_schema();
  $limit = max(1, min(500, $limit));
  $st = db()->prepare("SELECT r.*, p.title AS product_title, u.username
    FROM product_reviews r
    JOIN shop_products p ON p.id=r.product_id
    JOIN users u ON u.id=r.user_id
    WHERE r.status=?
    ORDER BY r.created_at DESC
    LIMIT $limit");
  $st->execute([$status]);
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function admin_review_set_status(int $id, string $status): void {
  $allow=['pending','approved','hidden'];
  if(!in_array($status,$allow,true)) $status='pending';
  db()->prepare("UPDATE product_reviews SET status=?, updated_at=NOW() WHERE id=?")->execute([$status,$id]);
}
