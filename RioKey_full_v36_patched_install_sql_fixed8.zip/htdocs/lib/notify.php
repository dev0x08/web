<?php
// Notification helpers (compatible with both schema variants)
//
// Supported minimal schema:
//   notifications(id,user_id,title,body,created_at)
//   notification_reads(user_id,notification_id,read_at)  [no auto id]
//
// Some older builds may add extra columns (link_url/audience/etc). We ignore them safely.

// NOTE: admin UI may call notify_create(user_id,title,body,audience,link_url,meta)
// so we accept extra params and safely ignore what schema doesn't support.
function notify_create(int $user_id, string $title, ?string $body, ?string $audience=null, ?string $link_url=null, $meta=null): void {
  $tbl='notifications';
  $note = (string)($body ?? '');
  if ($link_url) $note .= "\n".$link_url;

  db()->prepare("INSERT INTO {$tbl}(user_id,title,body,created_at) VALUES(?,?,?,NOW())")
    ->execute([$user_id,$title,$note]);
}

function notify_user(int $user_id, string $title, ?string $body, ?string $link_url=null): void {
  notify_create($user_id,$title,$body,null,$link_url);
}

// Broadcast: insert one notification per user (simple, safe)
function notify_all(string $title, ?string $body, ?string $link_url=null): void {
  $users = db()->query("SELECT id FROM users")->fetchAll(PDO::FETCH_ASSOC) ?: [];
  foreach($users as $u){
    notify_create((int)$u['id'], $title, $body, null, $link_url);
  }
}

function notify_unread_count(int $user_id): int {
  $sql = "SELECT COUNT(*) c
          FROM notifications n
          LEFT JOIN notification_reads r
            ON r.notification_id=n.id AND r.user_id=?
          WHERE n.user_id=? AND r.notification_id IS NULL";
  $st=db()->prepare($sql);
  $st->execute([$user_id,$user_id]);
  return (int)($st->fetchColumn() ?: 0);
}

function notify_list(int $user_id, int $limit=50): array {
  $sql = "SELECT n.*,
                 CASE WHEN r.notification_id IS NULL THEN 0 ELSE 1 END AS is_read
          FROM notifications n
          LEFT JOIN notification_reads r
            ON r.notification_id=n.id AND r.user_id=?
          WHERE n.user_id=?
          ORDER BY n.id DESC
          LIMIT ?";
  $st=db()->prepare($sql);
  $st->bindValue(1,$user_id,PDO::PARAM_INT);
  $st->bindValue(2,$user_id,PDO::PARAM_INT);
  $st->bindValue(3,$limit,PDO::PARAM_INT);
  $st->execute();
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function notify_mark_read(int $user_id, int $notification_id): void {
  db()->prepare("INSERT IGNORE INTO notification_reads(user_id,notification_id,read_at) VALUES(?,?,NOW())")
    ->execute([$user_id,$notification_id]);
}
