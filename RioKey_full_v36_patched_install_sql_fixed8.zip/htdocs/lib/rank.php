<?php
/**
 * Rank rules & progress
 * - Rules stored in `ranks` table.
 * - Progress is based on approved orders count (as requested).
 */

function ranks_all(): array {
  try {
    $st = db()->query("SELECT * FROM ranks ORDER BY require_orders ASC, id ASC");
    return $st->fetchAll() ?: [];
  } catch (Throwable $e) {
    return [];
  }
}

function user_approved_orders_count(int $user_id): int {
  // RioKey: rank dựa trên số đơn mua/đổi key đã giao
  try {
    $st = db()->prepare("SELECT COUNT(*) c FROM shop_orders WHERE user_id=? AND status='delivered'");
  } catch (Throwable $e) {
    // fallback (nếu chưa migrate schema)
    $st = db()->prepare("SELECT COUNT(*) c FROM orders WHERE user_id=? AND status='approved'");
  }
  $st->execute([$user_id]);
  return (int)($st->fetch()['c'] ?? 0);
}

function rank_for_orders(int $orders_ok, array $ranks): ?array {
  if (!$ranks) return null;
  $current = $ranks[0];
  foreach ($ranks as $r) {
    $req = (int)($r['require_orders'] ?? 0);
    if ($orders_ok >= $req) $current = $r;
  }
  return $current;
}

function rank_next(array $current, array $ranks): ?array {
  $curReq = (int)($current['require_orders'] ?? 0);
  foreach ($ranks as $r) {
    if ((int)($r['require_orders'] ?? 0) > $curReq) return $r;
  }
  return null;
}

function rank_progress_for_user(int $user_id): array {
  $ranks = ranks_all();
  $orders_ok = user_approved_orders_count($user_id);
  $current = rank_for_orders($orders_ok, $ranks) ?: ($ranks[0] ?? null);
  $next = $current ? rank_next($current, $ranks) : null;

  $need = $next ? (int)$next['require_orders'] : (int)($current['require_orders'] ?? 0);
  if ($need <= 0) $need = max(1, $orders_ok);

  $pct = (int)round(min(1, $orders_ok / max(1, $need)) * 100);

  return [
    'orders_ok' => $orders_ok,
    'current' => $current,
    'next' => $next,
    'need' => $need,
    'pct' => $pct
  ];
}
