<?php
// RioKey - Shop bán key/code game
// - Giữ UI hiện tại, chỉ thay logic Cashback/Referral -> Shop Key
// - Tách biệt khỏi các bảng cũ để an toàn

function shop_ensure_schema(): void {
  static $done = false;
  if ($done) return;
  $done = true;

  $pdo = db();

  // products
  $pdo->exec("CREATE TABLE IF NOT EXISTS shop_products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL,
    category VARCHAR(32) NOT NULL DEFAULT 'game_key',
    icon VARCHAR(80) NULL,
    image_url TEXT NULL,
    price_vnd INT NOT NULL DEFAULT 0,
    points_price INT NOT NULL DEFAULT 0,
    description TEXT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX(slug),
    INDEX(category),
    INDEX(is_active)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

  
  // product price overrides (rank/vip)
  if (!db_has_table('product_prices')) {
    try {
      $pdo->exec("CREATE TABLE product_prices (
        id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        audience_type ENUM('rank','vip') NOT NULL,
        audience_value VARCHAR(64) NULL,
        price_vnd INT NOT NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NULL,
        UNIQUE KEY uq_price (product_id, audience_type, audience_value),
        INDEX idx_prod (product_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
  }

// keys
  $pdo->exec("CREATE TABLE IF NOT EXISTS shop_keys (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    key_code TEXT NOT NULL,
    is_sold TINYINT(1) NOT NULL DEFAULT 0,
    sold_to INT NULL,
    sold_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX(product_id),
    INDEX(is_sold),
    INDEX(sold_to)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

  
  // upgrades: keys de-dup + activation
  try {
    if (!db_has_column('shop_keys','key_hash')) {
      $pdo->exec("ALTER TABLE shop_keys ADD COLUMN key_hash CHAR(64) NULL");
      $pdo->exec("CREATE INDEX idx_key_hash ON shop_keys(key_hash)");
      $pdo->exec("UPDATE shop_keys SET key_hash = SHA2(TRIM(key_code),256) WHERE key_hash IS NULL");
      $pdo->exec("CREATE UNIQUE INDEX uq_key_dedup ON shop_keys(product_id, key_hash)");
    }
  } catch (Throwable $e) {}

  try {
    if (!db_has_column('shop_keys','is_disabled')) {
      $pdo->exec("ALTER TABLE shop_keys ADD COLUMN is_disabled TINYINT(1) NOT NULL DEFAULT 0");
    }
    if (!db_has_column('shop_keys','is_activated')) {
      $pdo->exec("ALTER TABLE shop_keys ADD COLUMN is_activated TINYINT(1) NOT NULL DEFAULT 0");
    }
    if (!db_has_column('shop_keys','activated_at')) {
      $pdo->exec("ALTER TABLE shop_keys ADD COLUMN activated_at DATETIME NULL");
    }
  } catch (Throwable $e) {}
// orders
  $pdo->exec("CREATE TABLE IF NOT EXISTS shop_orders (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_code VARCHAR(60) NOT NULL,
    request_token VARCHAR(80) NULL,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    key_id BIGINT NOT NULL,
    pay_method ENUM('wallet','points') NOT NULL,
    amount_vnd INT NOT NULL DEFAULT 0,
    points INT NOT NULL DEFAULT 0,
    status ENUM('delivered','revoked') NOT NULL DEFAULT 'delivered',
    activated_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_order_code(order_code),
    UNIQUE KEY uq_request_token(request_token),
    UNIQUE KEY uq_key_id(key_id),
    INDEX(user_id),
    INDEX(product_id),
    INDEX(pay_method)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

  
  // user key inventory (for gifting / transfers)
  $pdo->exec("CREATE TABLE IF NOT EXISTS shop_user_keys (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    key_id BIGINT NOT NULL,
    order_id BIGINT NULL,
    activated_at DATETIME NULL,
    gift_link_id INT NULL,
    gifted_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_key_user(key_id),
    INDEX(user_id),
    INDEX(product_id),
    INDEX(order_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

  // backfill inventory from existing orders (idempotent)
  try {
    $pdo->exec("INSERT IGNORE INTO shop_user_keys(user_id,product_id,key_id,order_id,activated_at,created_at)
               SELECT o.user_id,o.product_id,o.key_id,o.id,o.activated_at,o.created_at
               FROM shop_orders o
               WHERE o.status='delivered'");
  } catch (Throwable $e) {}


// ---- schema upgrades for existing installs ----
  try {
    if (!db_has_column('shop_orders','activated_at')) $pdo->exec("ALTER TABLE shop_orders ADD COLUMN activated_at DATETIME NULL AFTER status");
  } catch (Throwable $e) {}


  try {
    if (!db_has_column('shop_products','category')) $pdo->exec("ALTER TABLE shop_products ADD COLUMN category VARCHAR(32) NOT NULL DEFAULT 'game_key' AFTER slug");
    if (!db_has_column('shop_products','icon')) $pdo->exec("ALTER TABLE shop_products ADD COLUMN icon VARCHAR(80) NULL AFTER category");
    if (!db_has_column('shop_products','image_url')) $pdo->exec("ALTER TABLE shop_products ADD COLUMN image_url TEXT NULL AFTER icon");
  } catch (Throwable $e) {}

  try {
    if (!db_has_column('shop_orders','request_token')) $pdo->exec("ALTER TABLE shop_orders ADD COLUMN request_token VARCHAR(80) NULL AFTER order_code");
  } catch (Throwable $e) {}
  try { $pdo->exec("ALTER TABLE shop_orders ADD UNIQUE KEY uq_request_token(request_token)"); } catch (Throwable $e) {}
  try { $pdo->exec("ALTER TABLE shop_orders ADD UNIQUE KEY uq_key_id(key_id)"); } catch (Throwable $e) {}

  // Seed demo data (only when empty)
  try { shop_seed_demo(); } catch (Throwable $e) {}
}

function shop_slug(string $s): string {
  $s = trim(mb_strtolower($s));
  $s = preg_replace('~[^\pL\pN]+~u', '-', $s);
  $s = trim($s, '-');
  return $s !== '' ? $s : substr(bin2hex(random_bytes(4)), 0, 8);
}


function shop_base_price_for_user(int $user_id, array $product): int {
  // Base price for display/purchase after applying overrides (rank/vip/flash)
  shop_ensure_schema();
  $base = (int)($product['price_vnd'] ?? 0);

  // VIP override
  try {
    if ($user_id > 0) {
      $vip = vip_get_user($user_id);
      if (!empty($vip) && !empty($vip['tier'])) {
        $tier = (string)$vip['tier'];
        $st = db()->prepare("SELECT price_vnd FROM product_prices WHERE product_id=? AND audience_type='vip' AND audience_value=? LIMIT 1");
        $st->execute([(int)$product['id'], $tier]);
        $v = $st->fetchColumn();
        if ($v !== false && $v !== null) $base = (int)$v;
      }
      // Rank override
      $rank = (string)(rank_name((int)$user_id) ?? '');
      if ($rank !== '') {
        $st = db()->prepare("SELECT price_vnd FROM product_prices WHERE product_id=? AND audience_type='rank' AND audience_value=? LIMIT 1");
        $st->execute([(int)$product['id'], $rank]);
        $v = $st->fetchColumn();
        if ($v !== false && $v !== null) $base = (int)$v;
      }
    }
  } catch (Throwable $e) {}

  // Flash sale override (lowest wins)
  try {
    $f = flash_price_for_product((int)$product['id']);
    if ($f !== null) $base = min($base, (int)$f);
  } catch (Throwable $e) {}

  return max(0, (int)$base);
}

function shop_final_price_for_user(int $user_id, array $product, int $flash_discount_pct=0): array {
  // Returns final price after VIP % discount + flash discount % (stacked, cap 80)
  shop_ensure_schema();
  $base = shop_base_price_for_user($user_id, $product);

  $vip_pct = 0;
  try { $vip_pct = vip_discount_pct($user_id); } catch (Throwable $e) { $vip_pct = 0; }

  // If there is an explicit override price in product_prices, base already reflects it.
  // Now apply % discounts (VIP tier discount + flash discount) on top of base.
  $ap = vip_apply_price((int)$base, (int)$vip_pct, (int)$flash_discount_pct);
  $price = (int)($ap['price'] ?? $base);
  $total_pct = (int)($ap['total'] ?? 0);

  return [
    'price' => max(0,$price),
    'vip'   => (int)($ap['vip'] ?? 0),
    'flash' => (int)($ap['flash'] ?? 0),
    'total' => (int)$total_pct,
  ];
}

function shop_products(bool $only_active=true, ?string $category=null): array {
  shop_ensure_schema();
  $where = $only_active ? "WHERE is_active=1" : "";
  if ($category !== null && $category !== '') {
    $where .= ($where ? ' AND ' : 'WHERE ') . "category=" . db()->quote($category);
  }
  $st = db()->query("SELECT * FROM shop_products {$where} ORDER BY id DESC");
  $items = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

  // attach stock
  $pdo = db();
  foreach ($items as &$p) {
    $st2 = $pdo->prepare("SELECT COUNT(*) c FROM shop_keys WHERE product_id=? AND is_sold=0");
    $st2->execute([(int)$p['id']]);
    $p['stock'] = (int)($st2->fetchColumn() ?: 0);
  }
  return $items;
}

function shop_get_product(int $product_id): ?array {
  shop_ensure_schema();
  $st = db()->prepare("SELECT * FROM shop_products WHERE id=? LIMIT 1");
  $st->execute([$product_id]);
  $p = $st->fetch(PDO::FETCH_ASSOC);
  return $p ?: null;
}

function shop_stock(int $product_id): int {
  shop_ensure_schema();
  $st = db()->prepare("SELECT COUNT(*) c FROM shop_keys WHERE product_id=? AND is_sold=0");
  $st->execute([$product_id]);
  return (int)($st->fetchColumn() ?: 0);
}

function shop_add_product(string $title, int $price_vnd, int $points_price, string $description='', int $is_active=1, string $category='game_key', ?string $icon=null, ?string $image_url=null): int {
  shop_ensure_schema();
  $slug = shop_slug($title);
  $st = db()->prepare("INSERT INTO shop_products(title,slug,category,icon,image_url,price_vnd,points_price,description,is_active,created_at) VALUES(?,?,?,?,?,?,?,?,?,NOW())");
  $st->execute([$title,$slug,$category,$icon,$image_url,$price_vnd,$points_price,$description,$is_active]);
  return (int)db()->lastInsertId();
}

function shop_import_keys(int $product_id, array $lines): int {
  shop_ensure_schema();
  $pdo = db();
  $cnt = 0;

  // vendor_id for marketplace mode (optional)
  $vendor_id = null;
  try {
    if (db_has_column('shop_products','vendor_id')) {
      $stV = $pdo->prepare("SELECT vendor_id FROM shop_products WHERE id=? LIMIT 1");
      $stV->execute([$product_id]);
      $vendor_id = $stV->fetchColumn();
      $vendor_id = ($vendor_id === false || $vendor_id === null || $vendor_id === '') ? null : (int)$vendor_id;
    }
  } catch (Throwable $e) { $vendor_id = null; }

  $hasVendor = db_has_column('shop_keys','vendor_id');

  // normalize + de-dup in file
  $seen = [];
  $norm = [];
  foreach ($lines as $ln) {
    $k = trim((string)$ln);
    if ($k === '') continue;
    $h = hash('sha256', $k);
    if (isset($seen[$h])) continue;
    $seen[$h] = 1;
    $norm[] = [$k, $h];
  }
  if (!$norm) return 0;

  $pdo->beginTransaction();
  try {
    $hasHash = db_has_column('shop_keys','key_hash');
    foreach ($norm as $row) {
      [$k,$h] = $row;
      if ($hasHash) {
        if ($hasVendor) {
          $st = $pdo->prepare("INSERT IGNORE INTO shop_keys(product_id,key_code,key_hash,is_sold,vendor_id,created_at) VALUES(?,?,?,?,?,NOW())");
          $st->execute([$product_id,$k,$h,0,$vendor_id]);
        } else {
          $st = $pdo->prepare("INSERT IGNORE INTO shop_keys(product_id,key_code,key_hash,is_sold,created_at) VALUES(?,?,?,?,NOW())");
          $st->execute([$product_id,$k,$h,0]);
        }
      } else {
        if ($hasVendor) {
          $st = $pdo->prepare("INSERT INTO shop_keys(product_id,key_code,is_sold,vendor_id,created_at) VALUES(?,?,0,?,NOW())");
          $st->execute([$product_id,$k,$vendor_id]);
        } else {
          $st = $pdo->prepare("INSERT INTO shop_keys(product_id,key_code,is_sold,created_at) VALUES(?,?,0,NOW())");
          $st->execute([$product_id,$k]);
        }
      }
      $cnt += (int)$st->rowCount();
    }
    $pdo->commit();
    return $cnt;
  } catch (Throwable $e) {
    try { $pdo->rollBack(); } catch (Throwable $x) {}
    return 0;
  }
}



function shop_make_order_code(): string {
  return 'RK' . strtoupper(substr(bin2hex(random_bytes(6)), 0, 10));
}

function shop_points_rate(string $key, float $default=0.0): float {
  $v = (string)setting($key, (string)$default);
  $v = str_replace(',', '.', $v);
  $f = (float)$v;
  if ($f < 0) $f = 0;
  if ($f > 100) $f = 100;
  return $f;
}

function shop_buy(int $user_id, int $product_id, string $request_token=''): array {

  $ip = client_ip();
  $limit = (int)setting('buy_req_limit', 20);
  $win = (int)setting('buy_req_window', 60);
  if ($limit > 0 && $win > 0 && rate_limit_exceeded('buyip:'.$ip, $limit, $win)) {
    ip_block($ip, 'Auto block: buy rate limit', (int)setting('buy_block_minutes', 5), null);
    security_log($user_id, 'buy_rate_limited', []);
    return ['ok'=>false,'error'=>'Bạn thao tác quá nhanh, vui lòng thử lại sau.'];
  }

  shop_ensure_schema();
  $pdo = db();
  $pdo->beginTransaction();
  try {
    if ($request_token === '') $request_token = 'rt_' . bin2hex(random_bytes(16));
    if (db_has_column('shop_orders','request_token')) {
      $st0 = $pdo->prepare("SELECT o.order_code, k.key_code FROM shop_orders o JOIN shop_keys k ON k.id=o.key_id WHERE o.request_token=? AND o.user_id=? LIMIT 1");
      $st0->execute([$request_token, $user_id]);
      if ($row0 = $st0->fetch(PDO::FETCH_ASSOC)) {
        $pdo->commit();
        return ['ok'=>true,'order_code'=>$row0['order_code'],'key'=>$row0['key_code']];
      }
    }

        $stP = $pdo->prepare("SELECT * FROM shop_products WHERE id=? AND is_active=1 FOR UPDATE");
    $stP->execute([$product_id]);
    $p = $stP->fetch(PDO::FETCH_ASSOC);
    if (!$p) throw new Exception('Sản phẩm không tồn tại');

    $base_price = shop_base_price_for_user($user_id, $p);
    if ($base_price <= 0) throw new Exception('Sản phẩm này không hỗ trợ mua bằng tiền');

    // Apply VIP + Flash Sale discounts (server-side) on base price
    $flashD = flash_active_discount($p['category'] ?? null);
    $ap = shop_final_price_for_user($user_id, $p, (int)$flashD);
    $price = (int)$ap['price'];

    // Vendor/CTV split (marketplace)
    $vendor_id = (int)($p['vendor_id'] ?? 0);
    $vendor_fee_pct = ($vendor_id > 0) ? vendor_fee_percent_for($vendor_id, $p) : 0.0;
    $vendor_fee = (int)floor($price * $vendor_fee_pct / 100.0);
    if ($vendor_fee < 0) $vendor_fee = 0;
    if ($vendor_fee > $price) $vendor_fee = $price;
    $vendor_net = (int)($price - $vendor_fee);



    // lock wallet
    $stW = $pdo->prepare("SELECT balance, processing FROM wallets WHERE user_id=? FOR UPDATE");
    $stW->execute([$user_id]);
    $w = $stW->fetch(PDO::FETCH_ASSOC);
    if (!$w) throw new Exception('Ví không tồn tại');
    if ((float)$w['balance'] < $price) throw new Exception('Số dư không đủ');

    // pick a key
    $stK = $pdo->prepare("SELECT * FROM shop_keys WHERE product_id=? AND is_sold=0 AND (is_disabled=0 OR is_disabled IS NULL) ORDER BY id ASC LIMIT 1 FOR UPDATE");
    $stK->execute([$product_id]);
    $k = $stK->fetch(PDO::FETCH_ASSOC);
    if (!$k) throw new Exception('Hết key');

    // debit wallet
    $newBalance = (float)$w['balance'] - $price;
    $pdo->prepare("UPDATE wallets SET balance=? WHERE user_id=?")->execute([$newBalance, $user_id]);
    $pdo->prepare("INSERT INTO wallet_transactions(user_id,type,ref_table,ref_id,amount,balance_after,note) VALUES(?,?,?,?,?,?,?)")
      ->execute([$user_id, 'shop_buy', 'shop_products', (int)$product_id, -$price, $newBalance, 'Mua key: '.($p['title'] ?? '')]);

    // mark key sold
    $pdo->prepare("UPDATE shop_keys SET is_sold=1, sold_to=?, sold_at=NOW() WHERE id=?")
      ->execute([$user_id, (int)$k['id']]);

    $orderCode = shop_make_order_code();
    $ip = client_ip();
    $ua = substr(client_ua(),0,255);
    $hasIP = db_has_column('shop_orders','ip');
    $hasUA = db_has_column('shop_orders','ua');

    if (db_has_column('shop_orders','request_token')) {
      $cols = "order_code,request_token,user_id,product_id,key_id,pay_method,amount_vnd,points,status,created_at";
      $ph   = "?,?,?,?,?,'wallet',?,0,'delivered',NOW()";
      $vals = [$orderCode,$request_token,$user_id,$product_id,(int)$k['id'],$price];

      if ($hasIP) { $cols .= ",ip"; $ph .= ",?"; $vals[] = $ip; }
      if ($hasUA) { $cols .= ",ua"; $ph .= ",?"; $vals[] = $ua; }

      $stO = $pdo->prepare("INSERT INTO shop_orders($cols) VALUES($ph)");
      $stO->execute($vals);
      $orderId = (int)$pdo->lastInsertId();
    } else {
      $cols = "order_code,user_id,product_id,key_id,pay_method,amount_vnd,points,status,created_at";
      $ph   = "?,?,?,?, 'wallet', ?,0,'delivered',NOW()";
      $ph   = "?,?,?,?, 'wallet', ?,0,'delivered',NOW()";
      $vals = [$orderCode,$user_id,$product_id,(int)$k['id'],$price];

      if ($hasIP) { $cols .= ",ip"; $ph .= ",?"; $vals[] = $ip; }
      if ($hasUA) { $cols .= ",ua"; $ph .= ",?"; $vals[] = $ua; }

      // fix placeholders spacing
      $ph = str_replace(" 'wallet'", "'wallet'", $ph);
      $stO = $pdo->prepare("INSERT INTO shop_orders($cols) VALUES($ph)");
      $stO->execute($vals);
      $orderId = (int)$pdo->lastInsertId();
    }


    // Credit vendor wallet for wallet purchases
    try {
      if ($vendor_id > 0 && db_has_column('shop_orders','vendor_id')) {
        // ensure vendor wallet row
        if (db_has_table('vendor_wallets')) {
          $pdo->prepare("INSERT IGNORE INTO vendor_wallets(vendor_id,balance,locked,total_withdrawn,updated_at) VALUES(?,0,0,0,NOW())")->execute([$vendor_id]);
          if ($vendor_net > 0) {
            $pdo->prepare("UPDATE vendor_wallets SET balance=balance+?, updated_at=NOW() WHERE vendor_id=?")->execute([$vendor_net, $vendor_id]);
            $pdo->prepare("INSERT INTO vendor_transactions(vendor_id,type,amount,ref_key,note,meta_json,created_at) VALUES(?,?,?,?,?,?,NOW())")
              ->execute([$vendor_id,'sale_credit',$vendor_net,'order:'.$orderCode,'Doanh thu từ đơn '.$orderCode, json_encode(['price'=>$price,'fee'=>$vendor_fee,'pct'=>$vendor_fee_pct], JSON_UNESCAPED_UNICODE)]);
          }
        }
        // attach vendor fields to order
        if (isset($orderId) && $orderId > 0) {
          $pdo->prepare("UPDATE shop_orders SET vendor_id=?, vendor_fee_vnd=?, vendor_net_vnd=? WHERE id=?")
            ->execute([$vendor_id, $vendor_fee, $vendor_net, $orderId]);
        }
      }
    } catch (Throwable $e) {}

    // Earn points by purchase (admin set %)
    $rate = shop_points_rate('points_rate_purchase', 0.0);
    $vipBonus = vip_points_bonus_pct($user_id);
    $earn = (int)floor($price * $rate * (100 + $vipBonus) / 10000.0);
    if ($earn > 0) {
      $stp = $pdo->prepare("SELECT id FROM point_transactions WHERE user_id=? AND type='purchase' AND ref_key=? LIMIT 1");
      $stp->execute([$user_id, 'purchase:'.$orderCode]);
      if (!$stp->fetch()) {
        $pdo->prepare("INSERT INTO point_transactions(user_id, points, type, ref_key, note, created_at) VALUES(?,?,?,?,?,NOW())")
        ->execute([$user_id, $earn, 'purchase', 'purchase:'.$orderCode, 'Tích điểm mua key ('.$rate.'%)']);
        $pdo->prepare("UPDATE users SET points = points + ? WHERE id=?")->execute([$earn, $user_id]);
      }
    }

    // Add to user key inventory (for gifting/transfers)
    try {
      $orderId = (int)$pdo->lastInsertId();
      $pdo->prepare("INSERT IGNORE INTO shop_user_keys(user_id,product_id,key_id,order_id,created_at) VALUES(?,?,?,?,NOW())")
        ->execute([$user_id,$product_id,(int)$k['id'],$orderId]);
    } catch (Throwable $e) {}

    $pdo->commit();

    try { notify_user($user_id, 'Mua key thành công', 'Key đã được thêm vào Kho key. Mã đơn: '.$orderCode); } catch (Throwable $e) {}

    return ['ok'=>true,'order_code'=>$orderCode,'key'=>$k['key_code']];
  } catch (Throwable $e) {
    $pdo->rollBack();
    return ['ok'=>false,'error'=>$e->getMessage()];
  }
}

function shop_redeem_points(int $user_id, int $product_id, string $request_token=''): array {
  shop_ensure_schema();
  $pdo = db();
  $pdo->beginTransaction();
  try {
    if ($request_token === '') $request_token = 'rt_' . bin2hex(random_bytes(16));
    if (db_has_column('shop_orders','request_token')) {
      $st0 = $pdo->prepare("SELECT o.order_code, k.key_code FROM shop_orders o JOIN shop_keys k ON k.id=o.key_id WHERE o.request_token=? AND o.user_id=? LIMIT 1");
      $st0->execute([$request_token, $user_id]);
      if ($row0 = $st0->fetch(PDO::FETCH_ASSOC)) {
        $pdo->commit();
        return ['ok'=>true,'order_code'=>$row0['order_code'],'key'=>$row0['key_code']];
      }
    }

        $stP = $pdo->prepare("SELECT * FROM shop_products WHERE id=? AND is_active=1 FOR UPDATE");
    $stP->execute([$product_id]);
    $p = $stP->fetch(PDO::FETCH_ASSOC);
    if (!$p) throw new Exception('Sản phẩm không tồn tại');

    $cost = (int)($p['points_price'] ?? 0);
    if ($cost <= 0) throw new Exception('Sản phẩm này không hỗ trợ đổi bằng điểm');

    // lock user
    $stU = $pdo->prepare("SELECT id, points FROM users WHERE id=? FOR UPDATE");
    $stU->execute([$user_id]);
    $u = $stU->fetch(PDO::FETCH_ASSOC);
    if (!$u) throw new Exception('User không tồn tại');
    if ((int)$u['points'] < $cost) throw new Exception('Bạn không đủ điểm');

    // pick a key
    $stK = $pdo->prepare("SELECT * FROM shop_keys WHERE product_id=? AND is_sold=0 AND (is_disabled=0 OR is_disabled IS NULL) ORDER BY id ASC LIMIT 1 FOR UPDATE");
    $stK->execute([$product_id]);
    $k = $stK->fetch(PDO::FETCH_ASSOC);
    if (!$k) throw new Exception('Hết key');

    // subtract points (ledger + update users.points)
    // points_add runs its own transaction normally, but we're already in a transaction.
    // So we do the inserts manually here to keep it atomic.
    $newPoints = (int)$u['points'] - $cost;
    $pdo->prepare("UPDATE users SET points=? WHERE id=?")->execute([$newPoints, $user_id]);
    $pdo->prepare("INSERT INTO point_transactions(user_id,points,type,ref_key,note,created_at) VALUES(?,?,?,?,?,NOW())")
      ->execute([$user_id, -$cost, 'redeem', 'redeem:shop:'.(int)$product_id.':'.(int)$k['id'], 'Đổi key: '.($p['title'] ?? '')]);

    // mark key sold
    $pdo->prepare("UPDATE shop_keys SET is_sold=1, sold_to=?, sold_at=NOW() WHERE id=?")
      ->execute([$user_id, (int)$k['id']]);

    $orderCode = shop_make_order_code();
    if (db_has_column('shop_orders','request_token')) {
      $pdo->prepare("INSERT INTO shop_orders(order_code,request_token,user_id,product_id,key_id,pay_method,amount_vnd,points,status,created_at) VALUES(?,?,?,?,?,'points', 0, ?, 'delivered', NOW())")
        ->execute([$orderCode,$request_token,$user_id,$product_id,(int)$k['id'],$cost]);
    } else {
      $pdo->prepare("INSERT INTO shop_orders(order_code,user_id,product_id,key_id,pay_method,amount_vnd,points,status,created_at) VALUES(?,?,?,?,'points', 0, ?, 'delivered', NOW())")
        ->execute([$orderCode,$user_id,$product_id,(int)$k['id'],$cost]);
    }

    // Add to user key inventory (for gifting/transfers)
    try {
      $orderId = (int)$pdo->lastInsertId();
      $pdo->prepare("INSERT IGNORE INTO shop_user_keys(user_id,product_id,key_id,order_id,created_at) VALUES(?,?,?,?,NOW())")
        ->execute([$user_id,$product_id,(int)$k['id'],$orderId]);
    } catch (Throwable $e) {}

    $pdo->commit();

    try { notify_user($user_id, 'Đổi key thành công', 'Key đã được thêm vào Kho key. Mã đơn: '.$orderCode); } catch (Throwable $e) {}

    return ['ok'=>true,'order_code'=>$orderCode,'key'=>$k['key_code']];
  } catch (Throwable $e) {
    $pdo->rollBack();
    return ['ok'=>false,'error'=>$e->getMessage()];
  }
}

function shop_user_orders(int $user_id, int $limit=50): array {
  shop_ensure_schema();
  $sql = "SELECT o.*, p.title AS product_title
          FROM shop_orders o
          JOIN shop_products p ON p.id=o.product_id
          WHERE o.user_id=?
          ORDER BY o.id DESC
          LIMIT ?";
  $st = db()->prepare($sql);
  $st->bindValue(1,$user_id,PDO::PARAM_INT);
  $st->bindValue(2,$limit,PDO::PARAM_INT);
  $st->execute();
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function shop_user_keys(int $user_id, int $limit=200): array {
  shop_ensure_schema();
  $sql = "SELECT o.id, o.created_at, o.order_code, o.pay_method, o.amount_vnd, o.points, o.activated_at,
                 p.title AS product_title,
                 k.key_code
          FROM shop_orders o
          JOIN shop_products p ON p.id=o.product_id
          JOIN shop_keys k ON k.id=o.key_id
          WHERE o.user_id=?
          ORDER BY o.id DESC
          LIMIT ?";
  $st = db()->prepare($sql);
  $st->bindValue(1,$user_id,PDO::PARAM_INT);
  $st->bindValue(2,$limit,PDO::PARAM_INT);
  $st->execute();
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function shop_admin_orders(int $limit=200): array {
  shop_ensure_schema();
  $sql = "SELECT o.*, p.title AS product_title, u.name AS user_name, u.username AS user_username
          FROM shop_orders o
          JOIN shop_products p ON p.id=o.product_id
          JOIN users u ON u.id=o.user_id
          ORDER BY o.id DESC
          LIMIT ?";
  $st = db()->prepare($sql);
  $st->bindValue(1,$limit,PDO::PARAM_INT);
  $st->execute();
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}



function shop_seed_demo(): void {
  static $seeded = false;
  if ($seeded) return;
  $seeded = true;

  $pdo = db();
  try {
    $c = (int)($pdo->query("SELECT COUNT(*) FROM shop_products")->fetchColumn() ?: 0);
    if ($c > 0) return;
  } catch (Throwable $e) { return; }

  $demo = [
    ['Key Steam Random', 'game_key', 'gamepad-2', 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1200&q=60', 19000, 0, 'Key random Steam giao tự động.'],
    ['Key Valorant (VN)', 'game_key', 'key-round', 'https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=1200&q=60', 39000, 0, 'Key/Code dùng cho Valorant.'],
    ['Giftcard Garena 50K', 'giftcard', 'credit-card', 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=1200&q=60', 52000, 450, 'Thẻ Garena 50K giao tự động.'],
    ['Giftcard Google Play 100K', 'giftcard', 'credit-card', 'https://images.unsplash.com/photo-1556742111-a301076d9d18?auto=format&fit=crop&w=1200&q=60', 102000, 900, 'Mã Google Play 100K.'],
    ['Tài khoản Netflix 1 tháng', 'account', 'user-round', 'https://images.unsplash.com/photo-1525182008055-f88b95ff7980?auto=format&fit=crop&w=1200&q=60', 59000, 0, 'Tài khoản/slot Netflix dùng 1 tháng.'],
  ];

  $pdo->beginTransaction();
  try {
    foreach ($demo as $d) {
      [$title,$cat,$icon,$img,$price,$points,$desc] = $d;
      $slug = shop_slug($title);
      $st = $pdo->prepare("INSERT INTO shop_products(title,slug,category,icon,image_url,price_vnd,points_price,description,is_active,created_at) VALUES(?,?,?,?,?,?,?,?,1,NOW())");
      $st->execute([$title,$slug,$cat,$icon,$img,(int)$price,(int)$points,$desc]);
      $pid = (int)$pdo->lastInsertId();

      // 10 demo keys per product
      $ins = $pdo->prepare("INSERT INTO shop_keys(product_id,key_code,is_sold,created_at) VALUES(?,?,0,NOW())");
      for ($i=1; $i<=10; $i++) {
        $k = strtoupper(substr(bin2hex(random_bytes(8)),0,16)) . '-' . strtoupper(substr(bin2hex(random_bytes(4)),0,8));
        $ins->execute([$pid, $k]);
      }
    }
    $pdo->commit();
  } catch (Throwable $e) {
    try { $pdo->rollBack(); } catch (Throwable $x) {}
  }
}

