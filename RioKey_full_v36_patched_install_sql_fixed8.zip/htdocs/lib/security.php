<?php

function security_ensure_schema(): void {
  $pdo = db();
  if (!db_has_table('security_logs')) {
    try {
      $pdo->exec("CREATE TABLE security_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NULL,
        type VARCHAR(40) NOT NULL,
        ip VARCHAR(64) NULL,
        ua VARCHAR(255) NULL,
        details MEDIUMTEXT NULL,
        created_at DATETIME NOT NULL,
        INDEX idx_user (user_id),
        INDEX idx_type (type),
        INDEX idx_ip (ip),
        INDEX idx_created (created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
  }
}

function security_log(?int $user_id, string $type, array $details = []): void {
  try {
    security_ensure_schema();
    $pdo = db();
    $pdo->prepare("INSERT INTO security_logs(user_id,type,ip,ua,details,created_at) VALUES(?,?,?,?,?,NOW())")
      ->execute([$user_id, $type, client_ip(), substr(client_ua(),0,255), json_encode($details, JSON_UNESCAPED_UNICODE)]);
  } catch (Throwable $e) {}
}


function risk_ensure_schema(): void {
  $pdo = db();

  if (!db_has_table('risk_flags')) {
    try {
      $pdo->exec("CREATE TABLE risk_flags (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NULL,
        ip VARCHAR(64) NULL,
        type VARCHAR(40) NOT NULL,
        score INT NOT NULL DEFAULT 1,
        reason VARCHAR(255) NULL,
        meta MEDIUMTEXT NULL,
        status ENUM('open','resolved') NOT NULL DEFAULT 'open',
        created_at DATETIME NOT NULL,
        updated_at DATETIME NULL,
        INDEX idx_user (user_id),
        INDEX idx_ip (ip),
        INDEX idx_type (type),
        INDEX idx_status (status)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
  }

  if (!db_has_table('ip_blocks')) {
    try {
      $pdo->exec("CREATE TABLE ip_blocks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        ip VARCHAR(64) NOT NULL,
        reason VARCHAR(255) NULL,
        hits INT NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL,
        expires_at DATETIME NULL,
        created_by INT NULL,
        UNIQUE KEY uq_ip (ip),
        INDEX idx_exp (expires_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
  }
}

function risk_flag(?int $user_id, ?string $ip, string $type, string $reason, array $meta = [], int $score_inc = 1): void {
  try {
    risk_ensure_schema();
    $pdo = db();
    $metaJson = json_encode($meta, JSON_UNESCAPED_UNICODE);
    // Merge into an open flag if exists
    $st = $pdo->prepare("SELECT id, score FROM risk_flags WHERE status='open' AND type=? AND ((user_id IS NOT NULL AND user_id=?) OR (ip IS NOT NULL AND ip=?)) ORDER BY id DESC LIMIT 1");
    $st->execute([$type, $user_id, $ip]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if ($row) {
      $pdo->prepare("UPDATE risk_flags SET score=score+?, reason=?, meta=?, updated_at=NOW() WHERE id=?")
        ->execute([$score_inc, $reason, $metaJson, (int)$row['id']]);
    } else {
      $pdo->prepare("INSERT INTO risk_flags(user_id,ip,type,score,reason,meta,status,created_at,updated_at) VALUES(?,?,?,?,?,?, 'open', NOW(), NOW())")
        ->execute([$user_id, $ip, $type, max(1,$score_inc), $reason, $metaJson]);
    }
  } catch (Throwable $e) {}
}

function ip_block(string $ip, string $reason, ?int $minutes = 10, ?int $by = null): void {
  try {
    risk_ensure_schema();
    $pdo = db();
    $exp = null;
    if ($minutes !== null && $minutes > 0) {
      $exp = date('Y-m-d H:i:s', time() + $minutes*60);
    }
    $pdo->prepare("INSERT INTO ip_blocks(ip,reason,hits,created_at,expires_at,created_by)
      VALUES(?,?,0,NOW(),?,?)
      ON DUPLICATE KEY UPDATE reason=VALUES(reason), expires_at=VALUES(expires_at), created_by=VALUES(created_by)")
      ->execute([$ip, $reason, $exp, $by]);
  } catch (Throwable $e) {}
}

function ip_unblock(string $ip): void {
  try {
    risk_ensure_schema();
    db()->prepare("DELETE FROM ip_blocks WHERE ip=?")->execute([$ip]);
  } catch (Throwable $e) {}
}

function ip_is_blocked(string $ip): bool {
  try {
    risk_ensure_schema();
    $st = db()->prepare("SELECT id, expires_at FROM ip_blocks WHERE ip=? LIMIT 1");
    $st->execute([$ip]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if (!$row) return false;
    $exp = $row['expires_at'] ?? null;
    if ($exp === null || $exp === '') return true;
    $ts = strtotime((string)$exp);
    if (!$ts) return true;
    if ($ts > time()) return true;
    // expired -> cleanup
    db()->prepare("DELETE FROM ip_blocks WHERE id=?")->execute([(int)$row['id']]);
    return false;
  } catch (Throwable $e) {
    return false;
  }
}

function security_auto_rules(?int $user_id, string $type, string $ip, array $details): void {
  // thresholds (settings)
  $redeemFailLimit = (int)setting('fraud_redeem_fail_limit', 5);     // per 30 minutes
  $redeemFailMin   = (int)setting('fraud_redeem_fail_window_min', 30);

  $ordersIpLimit   = (int)setting('fraud_orders_ip_limit', 12);     // per 60 minutes
  $ordersIpMin     = (int)setting('fraud_orders_ip_window_min', 60);

  $sharedIpUsers   = (int)setting('fraud_shared_ip_user_min', 4);   // accounts sharing same ip

  $autoBlockMin    = (int)setting('fraud_auto_ip_block_minutes', 10);

  try {
    // 1) redeem fail burst
    if ($type === 'coupon_redeem_fail' && $user_id) {
      $st = db()->prepare("SELECT COUNT(*) c FROM security_logs WHERE user_id=? AND type='coupon_redeem_fail' AND created_at >= DATE_SUB(NOW(), INTERVAL ? MINUTE)");
      $st->execute([(int)$user_id, $redeemFailMin]);
      $c = (int)($st->fetchColumn() ?: 0);
      if ($redeemFailLimit > 0 && $c >= $redeemFailLimit) {
        risk_flag((int)$user_id, $ip, 'redeem_fail_burst', "Redeem fail nhiều ({$c}/{$redeemFailMin}m)", ['count'=>$c,'window_min'=>$redeemFailMin], 2);
        // soft block IP if extreme
        if ($c >= $redeemFailLimit*2) ip_block($ip, "Auto block: redeem fail burst", $autoBlockMin, null);
      }
    }

    // 2) too many orders from same IP
    if ($type === 'purchase') {
      $st = db()->prepare("SELECT COUNT(*) c FROM shop_orders WHERE ip=? AND created_at >= DATE_SUB(NOW(), INTERVAL ? MINUTE)");
      $st->execute([$ip, $ordersIpMin]);
      $c = (int)($st->fetchColumn() ?: 0);
      if ($ordersIpLimit > 0 && $c >= $ordersIpLimit) {
        risk_flag($user_id, $ip, 'orders_ip_burst', "Mua quá nhiều theo IP ({$c}/{$ordersIpMin}m)", ['count'=>$c,'window_min'=>$ordersIpMin], 2);
        if ($c >= $ordersIpLimit*2) ip_block($ip, "Auto block: orders burst", $autoBlockMin, null);
      }
    }

    // 3) shared IP accounts
    if ($ip !== '' && db_has_column('users','last_ip')) {
      $st = db()->prepare("SELECT COUNT(*) c FROM users WHERE last_ip=?");
      $st->execute([$ip]);
      $uCnt = (int)($st->fetchColumn() ?: 0);
      if ($sharedIpUsers > 0 && $uCnt >= $sharedIpUsers) {
        risk_flag($user_id, $ip, 'shared_ip_many_users', "Nhiều account chung IP ({$uCnt})", ['users'=>$uCnt], 1);
      }
    }
  } catch (Throwable $e) {}
}

