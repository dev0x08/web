<?php
function level_ensure_schema(): void {
  $pdo = db();
  try {
    if (!db_has_column('users','xp')) $pdo->exec("ALTER TABLE users ADD COLUMN xp INT NOT NULL DEFAULT 0");
    if (!db_has_column('users','level')) $pdo->exec("ALTER TABLE users ADD COLUMN level INT NOT NULL DEFAULT 1");
  } catch (Throwable $e) {}
  if (!db_has_table('level_titles')) {
    try {
      $pdo->exec("CREATE TABLE level_titles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        level_required INT NOT NULL,
        title VARCHAR(60) NOT NULL,
        sort INT NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at DATETIME NOT NULL,
        UNIQUE KEY uq_level_title (level_required, title),
        INDEX idx_level (level_required),
        INDEX idx_active (is_active)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
  }
}
function level_seed_titles(): void {
  level_ensure_schema();
  $items = [
    [2,'Rookie',10],
    [5,'Key Scout',20],
    [10,'Key Hunter',30],
    [15,'Elite Trader',40],
    [20,'RioKey Legend',50],
  ];
  foreach($items as $it){
    try{
      db()->prepare("INSERT IGNORE INTO level_titles(level_required,title,sort,is_active,created_at) VALUES(?,?,?,?,NOW())")
        ->execute([(int)$it[0],(string)$it[1],(int)$it[2],1]);
    }catch(Throwable $e){}
  }
}
function level_req_for_next(int $level): int {
  if($level<1) $level=1;
  return 100 + ($level-1)*50;
}
function level_calc_from_xp(int $xp): array {
  $xp = max(0,$xp);
  $level = 1;
  $remain = $xp;
  while(true){
    $need = level_req_for_next($level);
    if($remain < $need) break;
    $remain -= $need;
    $level++;
    if($level>200) break;
  }
  $need = level_req_for_next($level);
  return ['level'=>$level,'cur'=>$remain,'need'=>$need,'xp_total'=>$xp];
}
function user_level_info(int $user_id): array {
  level_seed_titles();
  $st=db()->prepare("SELECT xp,level FROM users WHERE id=? LIMIT 1");
  $st->execute([$user_id]);
  $row=$st->fetch(PDO::FETCH_ASSOC) ?: ['xp'=>0,'level'=>1];
  $xp=(int)($row['xp'] ?? 0);
  return level_calc_from_xp($xp);
}
function user_add_xp(int $user_id, int $xp_add, string $reason=''): array {
  level_seed_titles();
  $xp_add = max(0,$xp_add);
  if($user_id<=0 || $xp_add<=0) return ['ok'=>false];
  $pdo = db();
  $pdo->beginTransaction();
  try{
    $st=$pdo->prepare("SELECT xp,level FROM users WHERE id=? FOR UPDATE");
    $st->execute([$user_id]);
    $row=$st->fetch(PDO::FETCH_ASSOC);
    if(!$row){ $pdo->rollBack(); return ['ok'=>false]; }
    $old_xp=(int)$row['xp'];
    $old_level=(int)$row['level'];
    $new_xp=$old_xp + $xp_add;
    $calc=level_calc_from_xp($new_xp);
    $new_level=(int)$calc['level'];
    $pdo->prepare("UPDATE users SET xp=?, level=? WHERE id=?")->execute([$new_xp,$new_level,$user_id]);
    $pdo->commit();
    if($new_level>$old_level){
      try{ notify_user($user_id,'Level Up!','Bạn đã lên cấp '.$new_level.' 🎉', route_url('profile')); }catch(Throwable $e){}
    }
    try{ audit_log($user_id,'xp_add','user',(string)$user_id,['xp_add'=>$xp_add,'reason'=>$reason,'new_xp'=>$new_xp,'new_level'=>$new_level]); } catch(Throwable $e){}
    return ['ok'=>true,'new_xp'=>$new_xp,'new_level'=>$new_level,'calc'=>$calc];
  }catch(Throwable $e){
    try{ $pdo->rollBack(); }catch(Throwable $e2){}
    return ['ok'=>false,'error'=>$e->getMessage()];
  }
}
function xp_from_amount_vnd(int $amount, string $type): int {
  $amount = max(0,(int)$amount);
  $per1000_topup = (int)setting('xp_per_1000_vnd_topup','1');
  $per1000_spend = (int)setting('xp_per_1000_vnd_spend','1');
  if($per1000_topup<0) $per1000_topup=0;
  if($per1000_spend<0) $per1000_spend=0;
  if($type==='topup') return (int)floor($amount/1000) * $per1000_topup;
  if($type==='spend') return (int)floor($amount/1000) * $per1000_spend;
  return 0;
}
function level_titles_available(int $user_id): array {
  level_seed_titles();
  $info = user_level_info($user_id);
  $lvl = (int)$info['level'];
  $st=db()->prepare("SELECT * FROM level_titles WHERE is_active=1 AND level_required<=? ORDER BY sort ASC, level_required ASC");
  $st->execute([$lvl]);
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}
