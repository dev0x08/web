<?php

function coupons_ensure_schema(): void {
  $pdo = db();

  if (!db_has_table('coupons')) {
    $pdo->exec("CREATE TABLE coupons (
      id INT AUTO_INCREMENT PRIMARY KEY,
      code VARCHAR(64) NOT NULL,
      reward_type ENUM('wallet','points') NOT NULL DEFAULT 'points',
      reward_amount INT NOT NULL DEFAULT 0,
      max_uses INT NULL,
      per_user_once TINYINT(1) NOT NULL DEFAULT 1,
      expires_at DATETIME NULL,
      is_active TINYINT(1) NOT NULL DEFAULT 1,
      note VARCHAR(255) NULL,
      created_by INT NULL,
      created_at DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE UNIQUE INDEX uq_coupons_code ON coupons(code)");
  } else {
    $cols = [
      'reward_type' => "ALTER TABLE coupons ADD COLUMN reward_type ENUM('wallet','points') NOT NULL DEFAULT 'points'",
      'reward_amount' => "ALTER TABLE coupons ADD COLUMN reward_amount INT NOT NULL DEFAULT 0",
      'max_uses' => "ALTER TABLE coupons ADD COLUMN max_uses INT NULL",
      'per_user_once' => "ALTER TABLE coupons ADD COLUMN per_user_once TINYINT(1) NOT NULL DEFAULT 1",
      'expires_at' => "ALTER TABLE coupons ADD COLUMN expires_at DATETIME NULL",
      'is_active' => "ALTER TABLE coupons ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1",
      'note' => "ALTER TABLE coupons ADD COLUMN note VARCHAR(255) NULL",
      'created_by' => "ALTER TABLE coupons ADD COLUMN created_by INT NULL",
      'created_at' => "ALTER TABLE coupons ADD COLUMN created_at DATETIME NOT NULL"
    ];
    foreach($cols as $c=>$sql){
      if (!db_has_column('coupons',$c)) { try { $pdo->exec($sql); } catch (Throwable $e) {} }
    }
    try { $pdo->exec("CREATE UNIQUE INDEX uq_coupons_code ON coupons(code)"); } catch (Throwable $e) {}
  }

  if (!db_has_table('coupon_redemptions')) {
    $pdo->exec("CREATE TABLE coupon_redemptions (
      id INT AUTO_INCREMENT PRIMARY KEY,
      coupon_id INT NOT NULL,
      user_id INT NOT NULL,
      reward_type ENUM('wallet','points') NOT NULL,
      reward_amount INT NOT NULL,
      created_at DATETIME NOT NULL,
      request_token VARCHAR(64) NULL,
      ip VARCHAR(64) NULL,
      ua VARCHAR(250) NULL,
      UNIQUE KEY uq_redemp_req (request_token),
      INDEX idx_coupon_user (coupon_id,user_id),
      CONSTRAINT fk_coupon_redemptions_coupon FOREIGN KEY (coupon_id) REFERENCES coupons(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  } else {
    if (!db_has_column('coupon_redemptions','request_token')) {
      try { $pdo->exec("ALTER TABLE coupon_redemptions ADD COLUMN request_token VARCHAR(64) NULL"); } catch (Throwable $e) {}
      try { $pdo->exec("ALTER TABLE coupon_redemptions ADD UNIQUE KEY uq_redemp_req (request_token)"); } catch (Throwable $e) {}
    }
  }

    if (!db_has_column('coupon_redemptions','ip')) { try { $pdo->exec("ALTER TABLE coupon_redemptions ADD COLUMN ip VARCHAR(64) NULL"); } catch (Throwable $e) {} }
    if (!db_has_column('coupon_redemptions','ua')) { try { $pdo->exec("ALTER TABLE coupon_redemptions ADD COLUMN ua VARCHAR(250) NULL"); } catch (Throwable $e) {} }

}

function coupon_normalize_code(string $code): string {
  $code = trim($code);
  $code = preg_replace('/\s+/', '', $code);
  return strtoupper($code);
}

function coupon_redeem(int $user_id, string $code, string $request_token=''): array {
  $ip = client_ip();
  $limit = (int)setting('redeem_req_limit', 10);
  $win = (int)setting('redeem_req_window', 60);
  if ($limit > 0 && $win > 0 && rate_limit_exceeded('redeemip:'.$ip, $limit, $win)) {
    ip_block($ip, 'Auto block: redeem rate limit', (int)setting('redeem_block_minutes', 5), null);
    security_log(null, 'redeem_rate_limited', []);
    return ['ok'=>false,'error'=>'Bạn thao tác quá nhanh, vui lòng thử lại sau.'];
  }


  coupons_ensure_schema();
  $pdo = db();

  $code = coupon_normalize_code($code);
  if ($code === '') return ['ok'=>false,'msg'=>'Vui lòng nhập mã.'];

  // Anti-fraud: limit redeem per IP per day
  $limit = (int)setting('fraud_ip_daily_redeem_limit', 15);
  if ($limit > 0) {
    try {
      $ip = client_ip();
      $stL = $pdo->prepare("SELECT COUNT(*) FROM coupon_redemptions WHERE ip=? AND DATE(created_at)=CURDATE()");
      $stL->execute([$ip]);
      $cnt = (int)($stL->fetchColumn() ?: 0);
      if ($cnt >= $limit) return ['ok'=>false,'msg'=>'Bạn thao tác quá nhiều hôm nay. Vui lòng thử lại sau.'];
    } catch (Throwable $e) {}
  }

  if ($request_token !== '' && db_has_column('coupon_redemptions','request_token')) {
    $st = $pdo->prepare("SELECT r.reward_type,r.reward_amount,c.code FROM coupon_redemptions r JOIN coupons c ON c.id=r.coupon_id WHERE r.request_token=? LIMIT 1");
    $st->execute([$request_token]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if ($row) {
      return ['ok'=>true,'msg'=>'Bạn đã nhập mã này trước đó: '.$row['code'].' (+'.$row['reward_amount'].' '.($row['reward_type']==='wallet'?'đ':'điểm').')'];
    }
  }

  $pdo->beginTransaction();
  try {
    $st = $pdo->prepare("SELECT * FROM coupons WHERE code=? LIMIT 1 FOR UPDATE");
    $st->execute([$code]);
    $c = $st->fetch(PDO::FETCH_ASSOC);
    if (!$c) { $pdo->rollBack(); return ['ok'=>false,'msg'=>'Mã không tồn tại.']; }

    if ((int)($c['is_active'] ?? 0) !== 1) { $pdo->rollBack(); return ['ok'=>false,'msg'=>'Mã đang tạm tắt.']; }

    if (!empty($c['expires_at'])) {
      $exp = strtotime((string)$c['expires_at']);
      if ($exp && time() > $exp) { $pdo->rollBack(); return ['ok'=>false,'msg'=>'Mã đã hết hạn.']; }
    }

    $coupon_id = (int)$c['id'];
    $perOnce = (int)($c['per_user_once'] ?? 1) === 1;

    if ($perOnce) {
      $st = $pdo->prepare("SELECT id FROM coupon_redemptions WHERE coupon_id=? AND user_id=? LIMIT 1");
      $st->execute([$coupon_id,$user_id]);
      if ($st->fetch()) { $pdo->rollBack(); return ['ok'=>false,'msg'=>'Bạn đã sử dụng mã này rồi.']; }
    }

    $max = $c['max_uses'];
    if ($max !== null && (int)$max > 0) {
      $st = $pdo->prepare("SELECT COUNT(*) FROM coupon_redemptions WHERE coupon_id=?");
      $st->execute([$coupon_id]);
      $used = (int)($st->fetchColumn() ?: 0);
      if ($used >= (int)$max) { $pdo->rollBack(); return ['ok'=>false,'msg'=>'Mã đã được sử dụng hết lượt.']; }
    }

    $rtype = (string)($c['reward_type'] ?? 'points');
    $amount = (int)($c['reward_amount'] ?? 0);
    if ($amount <= 0) { $pdo->rollBack(); return ['ok'=>false,'msg'=>'Mã không hợp lệ (thưởng = 0).']; }

    if ($rtype === 'wallet') wallet_add($user_id, $amount, 'coupon', 'coupon:'.$code);
    else points_add($user_id, $amount, 'coupon', 'coupon:'.$code);

    $st = $pdo->prepare("INSERT INTO coupon_redemptions(coupon_id,user_id,reward_type,reward_amount,created_at,request_token,ip,ua) VALUES(?,?,?,?,NOW(),?,?,?)");
    $st->execute([$coupon_id,$user_id,$rtype,$amount, $request_token!==''?$request_token:null, client_ip(), client_ua()]);

    $pdo->commit();

    notify_user($user_id, 'Đổi mã thành công', 'Bạn đã nhận +'.$amount.' '.($rtype==='wallet'?'đ vào ví':'điểm').' từ mã '.$code.'.');
    return ['ok'=>true,'msg'=>'Đổi mã thành công: +'.$amount.' '.($rtype==='wallet'?'đ':'điểm').''];
  } catch (Throwable $e) {
    try { $pdo->rollBack(); } catch (Throwable $x) {}
    return ['ok'=>false,'msg'=>'Có lỗi xảy ra, vui lòng thử lại.'];
  }
}
