<?php
function app_cfg(): array {
  static $cfg = null;
  if ($cfg === null) $cfg = require __DIR__ . '/../config.php';
  return $cfg;
}

function base_path(): string {
  $p = rtrim(app_cfg()['app']['base_path'] ?? '', '/');
  return $p === '' ? '' : $p;
}

function base_url(string $path=''): string {
  $path = '/' . ltrim($path, '/');
  return base_path() . $path;
}

function route_url(string $route='dashboard', array $query=[]): string {
  $route = trim($route, '/');
  // Prefer pretty URLs: /dashboard, /orders... (rewritten by .htaccess).
  $url = base_url($route === '' ? '/' : '/'.$route);
  if ($query) {
    $url .= (str_contains($url, '?') ? '&' : '?') . http_build_query($query);
  }
  return $url;
}

function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function redirect(string $to): void {
  if (!headers_sent()) {
    header('Location: '.$to);
    exit;
  }
  // Fallback (in case output already started)
  echo '<script>location.href='.json_encode($to).'</script>';
  echo '<noscript><meta http-equiv="refresh" content="0;url='.e($to).'"></noscript>';
  exit;
}

function flash_set(string $k, string $msg): void { $_SESSION['_flash'][$k] = $msg; }
function flash_get(string $k): ?string {
  if (!isset($_SESSION['_flash'][$k])) return null;
  $m = $_SESSION['_flash'][$k];
  unset($_SESSION['_flash'][$k]);
  return $m;
}

function format_vnd($n): string {
  $n = (float)$n;
  return number_format($n, 0, ',', '.') . ' đ';
}

// Alias for legacy templates
function money_vnd($amount): string { return format_vnd($amount); }


function time_ago_vn($time): string {
  $ts = is_numeric($time) ? (int)$time : strtotime((string)$time);
  if (!$ts) return '';
  $diff = time() - $ts;
  if ($diff < 0) $diff = 0;
  if ($diff < 60) return $diff . ' giây trước';
  $m = (int)floor($diff/60);
  if ($m < 60) return $m . ' phút trước';
  $h = (int)floor($m/60);
  if ($h < 24) return $h . ' giờ trước';
  $d = (int)floor($h/24);
  if ($d < 30) return $d . ' ngày trước';
  $mo = (int)floor($d/30);
  if ($mo < 12) return $mo . ' tháng trước';
  $y = (int)floor($mo/12);
  return $y . ' năm trước';
}


function lucide_icon(string $name, string $class='w-5 h-5'): string {
  // lucide web uses <i data-lucide="..."></i>
  return '<i data-lucide="'.e($name).'" class="'.e($class).'"></i>';
}

function is_active_route(string $cur, string $route): bool {
  return $cur === $route;
}


function request_route(string $default='dashboard'): string {
  $r = $_GET['route'] ?? '';
  if ($r !== '') return trim($r,'/');

  $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
  $bp = base_path();
  if ($bp && str_starts_with($uri, $bp)) $uri = substr($uri, strlen($bp));
  $uri = trim($uri, '/');
  if ($uri === '' || $uri === 'index.php') return $default;
  return $uri;
}

function nav_active(string $name, string $route): string {
  return $route === $name ? 'bg-orange-500/20 border border-orange-500/30 text-orange-200 shadow-[0_0_0_1px_rgba(251,146,60,.15)]' : 'hover:bg-slate-800/40 text-slate-200/80';
}


function admin_url(string $route='dashboard', array $params=[]): string {
  $path = '/admin/' . trim($route,'/');
  $url = base_url($path);
  if ($params) $url .= (str_contains($url,'?')?'&':'?') . http_build_query($params);
  return $url;
}


/** MOD approval limits **/
function can_approve_order_amount(float $amount): bool {
  $u = auth_user();
  if (!$u) return false;
  if (is_admin()) return true;
  if (!is_mod()) return false;
  $limit = (float)($u['mod_order_limit'] ?? 0);
  return $limit > 0 && $amount <= $limit;
}

function can_approve_topup_amount(float $amount): bool {
  $u = auth_user();
  if (!$u) return false;
  if (is_admin()) return true;
  if (!is_mod()) return false;
  $limit = (float)($u['mod_topup_limit'] ?? 0);
  return $limit > 0 && $amount <= $limit;
}

// DB schema helpers (safe on MariaDB/MySQL)
// db() is defined in lib/db.php and loaded after helpers in bootstrap.php.
function db_has_column(string $table, string $column): bool {
  try {
    $pdo = db();
    $st = $pdo->prepare(
      "SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS " .
      "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1"
    );
    $st->execute([$table, $column]);
    $val = $st->fetchColumn();
    $st->closeCursor();
    return (bool)$val;
  } catch (Throwable $e) {
    return false;
  }
}

function db_has_table(string $table): bool {
  try {
    $pdo = db();
    $st = $pdo->prepare(
      "SELECT 1 FROM INFORMATION_SCHEMA.TABLES " .
      "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1"
    );
    $st->execute([$table]);
    $val = $st->fetchColumn();
    $st->closeCursor();
    return (bool)$val;
  } catch (Throwable $e) {
    return false;
  }
}




function client_ip(): string {
  $ip = $_SERVER['REMOTE_ADDR'] ?? '';
  // basic support for proxy headers if present
  $xff = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '';
  if ($xff) {
    $parts = array_map('trim', explode(',', $xff));
    if (!empty($parts[0])) $ip = $parts[0];
  }
  return substr($ip, 0, 64);
}
function client_ua(): string {
  return substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 250);
}



function avatar_url(array $u): string {
  $fn = trim((string)($u['avatar'] ?? ''));
  if ($fn === '') return '';
  // served from /uploads/avatars/
  return base_url('uploads/avatars/' . $fn);
}

function ensure_upload_dirs(): void {
  $base = __DIR__ . '/../uploads';
  $dirs = [$base, $base.'/avatars'];
  foreach($dirs as $d){
    if(!is_dir($d)) { @mkdir($d, 0775, true); }
  }
}

