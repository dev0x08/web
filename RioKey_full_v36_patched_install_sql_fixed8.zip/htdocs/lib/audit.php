<?php
function audit_log(int $admin_id, string $action, string $target_type='', ?string $target_id=null, array $meta=[]): void {
  try {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 250);
    $st = db()->prepare("INSERT INTO admin_audit_logs(admin_id,action,target_type,target_id,meta_json,ip,ua,created_at) VALUES(?,?,?,?,?,?,?,NOW())");
    $st->execute([$admin_id,$action,$target_type,$target_id,json_encode($meta,JSON_UNESCAPED_UNICODE),$ip,$ua]);
  } catch (Throwable $e) { /* ignore */ }
}
