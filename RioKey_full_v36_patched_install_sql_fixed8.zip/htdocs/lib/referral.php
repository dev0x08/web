<?php
function referral_ensure_schema(): void {
  $pdo = db();
  if (!db_has_table('referral_rewards')) {
    $pdo->exec("CREATE TABLE referral_rewards(
      id INT AUTO_INCREMENT PRIMARY KEY,
      referrer_id INT NOT NULL,
      referred_id INT NOT NULL,
      reward_points INT NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL,
      UNIQUE KEY uq_referred (referred_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  }
  // ensure users.ref_code exists (legacy) and referred_by exists
  if (!db_has_column('users','ref_code')) {
    $pdo->exec("ALTER TABLE users ADD COLUMN ref_code VARCHAR(32) NULL");
  }
  if (!db_has_column('users','referred_by')) {
    $pdo->exec("ALTER TABLE users ADD COLUMN referred_by INT NULL");
  }
  if (!db_has_column('users','referred_at')) {
    $pdo->exec("ALTER TABLE users ADD COLUMN referred_at DATETIME NULL");
  }
}

function referral_code_for_user(int $user_id): string {
  referral_ensure_schema();
  $st = db()->prepare("SELECT ref_code FROM users WHERE id=?");
  $st->execute([$user_id]);
  $c = (string)($st->fetchColumn() ?: '');
  if ($c !== '') return $c;
  // generate
  $code = strtoupper(substr(bin2hex(random_bytes(6)),0,10));
  db()->prepare("UPDATE users SET ref_code=? WHERE id=?")->execute([$code,$user_id]);
  return $code;
}

function referral_set_referred_by_on_register(string $ref_code, array $newUserRow): ?int {
  referral_ensure_schema();
  $ref_code = strtoupper(trim($ref_code));
  if ($ref_code==='') return null;

  $new_id = (int)($newUserRow['id'] ?? 0);
  if ($new_id<=0) return null;

  $st = db()->prepare("SELECT id FROM users WHERE ref_code=? LIMIT 1");
  $st->execute([$ref_code]);
  $ref_id = (int)($st->fetchColumn() ?: 0);
  if ($ref_id<=0) return null;
  if ($ref_id === $new_id) return null;

  // anti-fraud: same ip on register
  if ((int)setting('referral_enabled', 1) !== 1) return null;

  db()->prepare("UPDATE users SET referred_by=?, referred_at=NOW() WHERE id=?")->execute([$ref_id,$new_id]);
  return $ref_id;
}

function referral_try_reward(int $referred_id, string $event, int $amount_vnd): void {
  referral_ensure_schema();
  if ((int)setting('referral_enabled', 1) !== 1) return;

  $st = db()->prepare("SELECT referred_by FROM users WHERE id=?");
  $st->execute([$referred_id]);
  $referrer_id = (int)($st->fetchColumn() ?: 0);
  if ($referrer_id<=0) return;

  // already rewarded?
  $st2 = db()->prepare("SELECT id FROM referral_rewards WHERE referred_id=? LIMIT 1");
  $st2->execute([$referred_id]);
  if ($st2->fetch()) return;

  $min = (int)setting('referral_min_amount_vnd', 50000);
  if ($amount_vnd < $min) return;

  $reward = (int)setting('referral_reward_points', 200);
  if ($reward<=0) return;

  // anti-fraud: same ip between accounts on reward
  // best effort, uses last login ip not stored. skip.

  db()->prepare("INSERT INTO referral_rewards(referrer_id,referred_id,reward_points,created_at) VALUES(?,?,?,NOW())")
    ->execute([$referrer_id,$referred_id,$reward]);

  points_add($referrer_id, $reward, 'referral', 'referral:'.$referred_id, 'Thưởng mời bạn bè');

  notify_user($referrer_id, 'Thưởng referral', 'Bạn nhận +'.$reward.' điểm vì bạn bè đã nạp/mua lần đầu.');
}
