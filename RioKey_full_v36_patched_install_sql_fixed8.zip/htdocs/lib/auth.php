<?php
function auth_user(): ?array {
  if (empty($_SESSION['uid'])) return null;
  $st = db()->prepare("SELECT * FROM users WHERE id=? LIMIT 1");
  $st->execute([$_SESSION['uid']]);
  $u = $st->fetch();
  if (!$u) return null;

  // Ensure wallet row exists (prevents 'Wallet not found' in wallet_apply)
  try {
    db()->prepare("INSERT IGNORE INTO wallets (user_id,balance,processing,total_withdrawn) VALUES (?,0,0,0)")->execute([(int)$u['id']]);
  } catch (Throwable $e) {}

  // normalize role
  $u['role'] = strtolower(trim((string)($u['role'] ?? '')));
  $map = ['administrator'=>'admin','superadmin'=>'admin','owner'=>'admin','moderator'=>'mod','ctv'=>'vendor','collaborator'=>'vendor','contributor'=>'vendor','vendor'=>'vendor'];
  if (isset($map[$u['role']])) $u['role'] = $map[$u['role']];
  // numeric roles (legacy)
  if ($u['role'] === '1') $u['role'] = 'admin';
  if ($u['role'] === '2') $u['role'] = 'mod';
  if ($u['role'] === '3') $u['role'] = 'vendor';

  // Backward compatibility: if is_admin=1 but role not set, treat as admin
  if (!isset($u['role']) || $u['role'] === null || $u['role'] === '') {
    $u['role'] = ((int)($u['is_admin'] ?? 0) === 1) ? 'admin' : 'user';
  } elseif ((int)($u['is_admin'] ?? 0) === 1) {
    $u['role'] = 'admin';
  }


  // Ban check
  try {
    if ((int)($u['is_banned'] ?? 0) === 1 || (string)($u['role'] ?? '') === 'banned') {
      // logout
      $_SESSION['user_id'] = null;
      unset($_SESSION['user_id']);
      flash_set('err','Tài khoản của bạn đã bị khoá. Liên hệ hỗ trợ nếu cần.');
      return null;
    }
  } catch (Throwable $e) {}

  // Track last seen + IP/UA (best-effort)
  try {
    if (db_has_column('users','last_seen_at')) {
      db()->prepare("UPDATE users SET last_seen_at=NOW() WHERE id=?")->execute([(int)$u['id']]);
    }
    if (db_has_column('users','last_ip')) {
      db()->prepare("UPDATE users SET last_ip=? WHERE id=?")->execute([client_ip(), (int)$u['id']]);
    }
    if (db_has_column('users','last_ua')) {
      db()->prepare("UPDATE users SET last_ua=? WHERE id=?")->execute([substr(client_ua(),0,255), (int)$u['id']]);
    }
  } catch (Throwable $e) {}

  return $u;
}

function require_auth(): void {
  if (!auth_user()) redirect(base_url('/auth/login.php'));
}

function is_admin(): bool {
  $u = auth_user();
  if (!$u) return false;
  if ((int)($u['is_admin'] ?? 0) === 1) return true;
  $role = strtolower(trim((string)($u['role'] ?? 'user')));
  return in_array($role, ['admin','superadmin','owner'], true);
}

function is_mod(): bool {
  $u = auth_user();
  if (!$u) return false;
  $role = strtolower(trim((string)($u['role'] ?? 'user')));
  return in_array($role, ['mod','admin','superadmin','owner'], true) || (int)($u['is_admin'] ?? 0) === 1;
}

function require_admin(): void {
  if (!is_admin()) redirect(base_url('/auth/login.php'));
}

function require_staff(): void {
  if (!is_mod()) redirect(base_url('/auth/login.php'));
}


function is_vendor(): bool {
  $u = auth_user();
  if (!$u) return false;
  if (is_admin()) return true; // admin tối cao
  $role = strtolower(trim((string)($u['role'] ?? 'user')));
  if ($role !== 'vendor') return false;
  if (db_has_column('users','vendor_active')) {
    try {
      if ((int)($u['vendor_active'] ?? 1) !== 1) return false;
    } catch (Throwable $e) {}
  }
  return true;
}

function require_vendor(): void {
  if (!auth_user()) redirect(base_url('/auth/login.php'));
  if (!is_vendor()) { http_response_code(404); include __DIR__ . '/../pages/404.php'; exit; }
}


function login_user_id(int $user_id): void {
  $_SESSION['uid'] = $user_id;
}

function logout(): void {
  unset($_SESSION['uid']);
}

/**
 * Authenticate user by email or username.
 * Returns true on success and sets session uid.
 */
function login(string $identity, string $password): bool {
  $identity = trim($identity);
  if ($identity === '' || $password === '') return false;

  $ip = client_ip();
  // login rate limit per IP
  $limit = (int)setting('login_req_limit', 12);     // attempts per window
  $win   = (int)setting('login_req_window', 60);    // seconds
  if ($limit > 0 && $win > 0 && rate_limit_exceeded('loginip:'.$ip, $limit, $win)) {
    // escalate if too many
    ip_block($ip, 'Auto block: login rate limit', (int)setting('login_block_minutes', 5), null);
    security_log(null, 'login_rate_limited', ['identity'=>$identity]);
    return false;
  }

  // Decide whether identity is an email or username
  $sql = (strpos($identity, '@') !== false)
    ? "SELECT id,password_hash FROM users WHERE email=? LIMIT 1"
    : "SELECT id,password_hash FROM users WHERE username=? LIMIT 1";

  try {
    $st = db()->prepare($sql);
    $st->execute([$identity]);
    $u = $st->fetch();
    if (!$u) {
      security_log(null, 'login_fail', ['identity'=>$identity,'reason'=>'not_found']);
      return false;
    }

    $uid = (int)($u['id'] ?? 0);
    if (!password_verify($password, (string)($u['password_hash'] ?? ''))) {
      security_log($uid ?: null, 'login_fail', ['identity'=>$identity,'reason'=>'bad_password']);
      return false;
    }

    login_user_id($uid);
    security_log($uid, 'login_success', []);
    return true;
  } catch (Throwable $e) {
    security_log(null, 'login_error', ['err'=>$e->getMessage()]);
    return false;
  }
}

