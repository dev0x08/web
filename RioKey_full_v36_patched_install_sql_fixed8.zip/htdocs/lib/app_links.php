<?php
function app_links_ensure_schema(): void {
  $pdo = db();
  if(!db_has_table('app_links')){
    try{
      $pdo->exec("CREATE TABLE app_links (
        id INT AUTO_INCREMENT PRIMARY KEY,
        token VARCHAR(80) NOT NULL,
        title VARCHAR(120) NOT NULL,
        platform VARCHAR(60) NULL,
        description TEXT NULL,
        cover_image TEXT NULL,
        images TEXT NULL,
        url TEXT NOT NULL,
        url_backup TEXT NULL,
        mode ENUM('once','forever') NOT NULL DEFAULT 'forever',
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        downloads INT NOT NULL DEFAULT 0,
        used_at DATETIME NULL,
        used_ip VARCHAR(45) NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NULL,
        UNIQUE KEY uq_token (token),
        INDEX idx_active (is_active),
        INDEX idx_mode (mode),
        INDEX idx_used (used_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }catch(Throwable $e){}
  } else {
    // light migrations
    try{
      if(!db_has_column('app_links','downloads')) $pdo->exec("ALTER TABLE app_links ADD COLUMN downloads INT NOT NULL DEFAULT 0");
      if(!db_has_column('app_links','platform')) $pdo->exec("ALTER TABLE app_links ADD COLUMN platform VARCHAR(60) NULL");
      if(!db_has_column('app_links','used_ip')) $pdo->exec("ALTER TABLE app_links ADD COLUMN used_ip VARCHAR(45) NULL");
      if(!db_has_column('app_links','description')) $pdo->exec("ALTER TABLE app_links ADD COLUMN description TEXT NULL");
      if(!db_has_column('app_links','cover_image')) $pdo->exec("ALTER TABLE app_links ADD COLUMN cover_image TEXT NULL");
      if(!db_has_column('app_links','images')) $pdo->exec("ALTER TABLE app_links ADD COLUMN images TEXT NULL");
      if(!db_has_column('app_links','url_backup')) $pdo->exec("ALTER TABLE app_links ADD COLUMN url_backup TEXT NULL");
    }catch(Throwable $e){}
  }
}
function app_link_token_new(): string { return bin2hex(random_bytes(24)); }

function app_links_admin_list(int $limit=300): array {
  app_links_ensure_schema();
  $limit = max(1, min(500, $limit));
  $st = db()->query("SELECT * FROM app_links ORDER BY id DESC LIMIT $limit");
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function app_links_active_list(): array {
  app_links_ensure_schema();
  $st = db()->query("SELECT * FROM app_links WHERE is_active=1 ORDER BY id DESC");
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function app_link_get(int $id){
  app_links_ensure_schema();
  $st=db()->prepare("SELECT * FROM app_links WHERE id=? LIMIT 1");
  $st->execute([$id]);
  $r=$st->fetch(PDO::FETCH_ASSOC);
  return $r ?: null;
}

function app_link_by_token(string $token){
  app_links_ensure_schema();
  $st=db()->prepare("SELECT * FROM app_links WHERE token=? LIMIT 1");
  $st->execute([$token]);
  $r=$st->fetch(PDO::FETCH_ASSOC);
  return $r ?: null;
}

function app_link_create(array $data): array {
  app_links_ensure_schema();
  $title = trim((string)($data['title'] ?? ''));
  $platform = trim((string)($data['platform'] ?? ''));
  $description = trim((string)($data['description'] ?? ''));
  $cover_image = trim((string)($data['cover_image'] ?? ''));
  $images = trim((string)($data['images'] ?? ''));
  $url = trim((string)($data['url'] ?? ''));
  $url_backup = trim((string)($data['url_backup'] ?? ''));
  $mode = (string)($data['mode'] ?? 'forever');
  $is_active = (int)($data['is_active'] ?? 1) ? 1 : 0;

  if($title==='') return ['ok'=>false,'error'=>'Thiếu tên app.'];
  if($url==='') return ['ok'=>false,'error'=>'Thiếu link tải.'];
  if(!in_array($mode,['once','forever'],true)) $mode='forever';

  $token = app_link_token_new();
  db()->prepare("INSERT INTO app_links(token,title,platform,description,cover_image,images,url,url_backup,mode,is_active,created_at,updated_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,NOW(),NOW())")
    ->execute([
      $token,
      $title,
      $platform!==''?$platform:null,
      $description!==''?$description:null,
      $cover_image!==''?$cover_image:null,
      $images!==''?$images:null,
      $url,
      $url_backup!==''?$url_backup:null,
      $mode,
      $is_active
    ]);

  $id=(int)db()->lastInsertId();
  try{ audit_log((int)auth_user()['id'],'app_link_create','app_link',(string)$id,['title'=>$title,'mode'=>$mode,'active'=>$is_active]); }catch(Throwable $e){}
  return ['ok'=>true,'id'=>$id,'token'=>$token];
}

function app_link_update(int $id, array $data): array {
  app_links_ensure_schema();
  $row = app_link_get($id);
  if(!$row) return ['ok'=>false,'error'=>'Không tồn tại.'];

  $title = trim((string)($data['title'] ?? $row['title']));
  $platform = trim((string)($data['platform'] ?? ($row['platform'] ?? '')));
  $description = trim((string)($data['description'] ?? ($row['description'] ?? '')));
  $cover_image = trim((string)($data['cover_image'] ?? ($row['cover_image'] ?? '')));
  $images = trim((string)($data['images'] ?? ($row['images'] ?? '')));
  $url = trim((string)($data['url'] ?? $row['url']));
  $url_backup = trim((string)($data['url_backup'] ?? ($row['url_backup'] ?? '')));
  $mode = (string)($data['mode'] ?? $row['mode']);
  $is_active = (int)($data['is_active'] ?? $row['is_active']) ? 1 : 0;

  if($title==='') return ['ok'=>false,'error'=>'Thiếu tên app.'];
  if($url==='') return ['ok'=>false,'error'=>'Thiếu link tải.'];
  if(!in_array($mode,['once','forever'],true)) $mode='forever';

  db()->prepare("UPDATE app_links
      SET title=?, platform=?, description=?, cover_image=?, images=?, url=?, url_backup=?, mode=?, is_active=?, updated_at=NOW()
      WHERE id=?")
    ->execute([
      $title,
      $platform!==''?$platform:null,
      $description!==''?$description:null,
      $cover_image!==''?$cover_image:null,
      $images!==''?$images:null,
      $url,
      $url_backup!==''?$url_backup:null,
      $mode,
      $is_active,
      $id
    ]);

  try{ audit_log((int)auth_user()['id'],'app_link_update','app_link',(string)$id,['mode'=>$mode,'active'=>$is_active]); }catch(Throwable $e){}
  return ['ok'=>true];
}

function app_link_delete(int $id): array {
  app_links_ensure_schema();
  $row = app_link_get($id);
  if(!$row) return ['ok'=>false,'error'=>'Không tồn tại.'];
  db()->prepare("DELETE FROM app_links WHERE id=?")->execute([$id]);
  try{ audit_log((int)auth_user()['id'],'app_link_delete','app_link',(string)$id,['title'=>$row['title'] ?? '']); }catch(Throwable $e){}
  return ['ok'=>true];
}

function app_link_regen_token(int $id): array {
  app_links_ensure_schema();
  $row = app_link_get($id);
  if(!$row) return ['ok'=>false,'error'=>'Không tồn tại.'];
  $token = app_link_token_new();
  db()->prepare("UPDATE app_links SET token=?, used_at=NULL, used_ip=NULL, updated_at=NOW() WHERE id=?")->execute([$token,$id]);
  try{ audit_log((int)auth_user()['id'],'app_link_regen','app_link',(string)$id,[]); }catch(Throwable $e){}
  return ['ok'=>true,'token'=>$token];
}

function app_link_reset_used(int $id): array {
  app_links_ensure_schema();
  $row = app_link_get($id);
  if(!$row) return ['ok'=>false,'error'=>'Không tồn tại.'];
  db()->prepare("UPDATE app_links SET used_at=NULL, used_ip=NULL, updated_at=NOW() WHERE id=?")->execute([$id]);
  try{ audit_log((int)auth_user()['id'],'app_link_reset','app_link',(string)$id,[]); }catch(Throwable $e){}
  return ['ok'=>true];
}

function app_link_track_download(string $token, string $ip=''): array {
  app_links_ensure_schema();
  $pdo=db();
  $pdo->beginTransaction();
  try{
    $st=$pdo->prepare("SELECT * FROM app_links WHERE token=? FOR UPDATE");
    $st->execute([$token]);
    $r=$st->fetch(PDO::FETCH_ASSOC);
    if(!$r) throw new Exception('Link không tồn tại.');
    if((int)$r['is_active']!==1) throw new Exception('Link đang tắt.');
    $mode=(string)$r['mode'];
    if($mode==='once' && !empty($r['used_at'])) throw new Exception('Link chỉ mở 1 lần và đã được sử dụng.');
    $pdo->prepare("UPDATE app_links SET downloads=downloads+1, used_at=IF(mode='once',NOW(),used_at), used_ip=IF(mode='once',?,used_ip), updated_at=NOW() WHERE id=?")
      ->execute([$ip,(int)$r['id']]);
    $pdo->commit();
    return ['ok'=>true,'row'=>$r];
  }catch(Throwable $e){
    try{ $pdo->rollBack(); }catch(Throwable $e2){}
    return ['ok'=>false,'error'=>$e->getMessage()];
  }
}

function app_link_resolve_url(array $row, string $src='primary'): string {
  $src = ($src==='backup') ? 'backup' : 'primary';
  $primary = trim((string)($row['url'] ?? ''));
  $backup = trim((string)($row['url_backup'] ?? ''));
  if($src==='backup') return $backup!=='' ? $backup : $primary;
  return $primary;
}
