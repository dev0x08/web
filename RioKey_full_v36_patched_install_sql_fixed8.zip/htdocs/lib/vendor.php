<?php
/**
 * Vendor/CTV engine for RioKey marketplace mode
 * - Adds vendor_id to products/keys/orders/app_links
 * - Credits vendor wallet on wallet purchases with fee split
 */

function vendor_ensure_schema(): void {
  $pdo = db();
  // user fields
  try {
    if (db_has_table('users')) {
      if (!db_has_column('users','vendor_fee_percent')) $pdo->exec("ALTER TABLE users ADD COLUMN vendor_fee_percent DECIMAL(6,2) NULL");
      if (!db_has_column('users','vendor_active')) $pdo->exec("ALTER TABLE users ADD COLUMN vendor_active TINYINT(1) NOT NULL DEFAULT 1");
      if (!db_has_column('users','vendor_payout_info')) $pdo->exec("ALTER TABLE users ADD COLUMN vendor_payout_info TEXT NULL");
    }
  } catch (Throwable $e) {}

  // shop tables (created by shop_ensure_schema)
  try {
    if (db_has_table('shop_products')) {
      if (!db_has_column('shop_products','vendor_id')) $pdo->exec("ALTER TABLE shop_products ADD COLUMN vendor_id INT NULL");
      if (!db_has_column('shop_products','vendor_fee_percent')) $pdo->exec("ALTER TABLE shop_products ADD COLUMN vendor_fee_percent DECIMAL(6,2) NULL");
      if (!db_has_column('shop_products','vendor_note')) $pdo->exec("ALTER TABLE shop_products ADD COLUMN vendor_note VARCHAR(190) NULL");
      try { $pdo->exec("CREATE INDEX idx_vendor ON shop_products(vendor_id)"); } catch(Throwable $e2){}
    }
    if (db_has_table('shop_keys')) {
      if (!db_has_column('shop_keys','vendor_id')) $pdo->exec("ALTER TABLE shop_keys ADD COLUMN vendor_id INT NULL");
      try { $pdo->exec("CREATE INDEX idx_vendor ON shop_keys(vendor_id)"); } catch(Throwable $e2){}
    }
    if (db_has_table('shop_orders')) {
      if (!db_has_column('shop_orders','vendor_id')) $pdo->exec("ALTER TABLE shop_orders ADD COLUMN vendor_id INT NULL");
      if (!db_has_column('shop_orders','vendor_fee_vnd')) $pdo->exec("ALTER TABLE shop_orders ADD COLUMN vendor_fee_vnd INT NOT NULL DEFAULT 0");
      if (!db_has_column('shop_orders','vendor_net_vnd')) $pdo->exec("ALTER TABLE shop_orders ADD COLUMN vendor_net_vnd INT NOT NULL DEFAULT 0");
      try { $pdo->exec("CREATE INDEX idx_vendor ON shop_orders(vendor_id)"); } catch(Throwable $e2){}
    }
    if (db_has_table('app_links')) {
      if (!db_has_column('app_links','vendor_id')) $pdo->exec("ALTER TABLE app_links ADD COLUMN vendor_id INT NULL");
      try { $pdo->exec("CREATE INDEX idx_vendor ON app_links(vendor_id)"); } catch(Throwable $e2){}
    }
  } catch (Throwable $e) {}

  // vendor wallets
  if (!db_has_table('vendor_wallets')) {
    try {
      $pdo->exec("CREATE TABLE vendor_wallets (
        vendor_id INT PRIMARY KEY,
        balance DECIMAL(14,2) NOT NULL DEFAULT 0,
        locked DECIMAL(14,2) NOT NULL DEFAULT 0,
        total_withdrawn DECIMAL(14,2) NOT NULL DEFAULT 0,
        updated_at DATETIME NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
  }
  if (!db_has_table('vendor_transactions')) {
    try {
      $pdo->exec("CREATE TABLE vendor_transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        vendor_id INT NOT NULL,
        type VARCHAR(40) NOT NULL,
        amount DECIMAL(14,2) NOT NULL,
        ref_key VARCHAR(120) NULL,
        note VARCHAR(190) NULL,
        meta_json TEXT NULL,
        created_at DATETIME NOT NULL,
        INDEX idx_vendor (vendor_id),
        INDEX idx_ref (ref_key),
        INDEX idx_type (type)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
  }
  if (!db_has_table('vendor_withdrawals')) {
    try {
      $pdo->exec("CREATE TABLE vendor_withdrawals (
        id INT AUTO_INCREMENT PRIMARY KEY,
        vendor_id INT NOT NULL,
        amount DECIMAL(14,2) NOT NULL,
        status ENUM('pending','approved','rejected','paid') NOT NULL DEFAULT 'pending',
        payout_note VARCHAR(190) NULL,
        created_at DATETIME NOT NULL,
        processed_by INT NULL,
        processed_at DATETIME NULL,
        INDEX idx_vendor (vendor_id),
        INDEX idx_status (status)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
  }
}

function vendor_fee_percent_for(int $vendor_id, array $product_row=[]): float {
  $p = null;
  if (isset($product_row['vendor_fee_percent']) && $product_row['vendor_fee_percent'] !== null && $product_row['vendor_fee_percent'] !== '') {
    $p = (float)$product_row['vendor_fee_percent'];
  }
  if ($p === null && $vendor_id > 0 && db_has_column('users','vendor_fee_percent')) {
    try {
      $st = db()->prepare("SELECT vendor_fee_percent FROM users WHERE id=? LIMIT 1");
      $st->execute([$vendor_id]);
      $p = $st->fetchColumn();
      $p = ($p === false || $p === null || $p === '') ? null : (float)$p;
    } catch (Throwable $e) {}
  }
  if ($p === null) {
    $p = (float)str_replace(',', '.', (string)setting('vendor_fee_percent_default','10'));
  }
  if ($p < 0) $p = 0;
  if ($p > 80) $p = 80;
  return $p;
}

function vendor_wallet_ensure(int $vendor_id): void {
  if ($vendor_id <= 0) return;
  try {
    db()->prepare("INSERT IGNORE INTO vendor_wallets(vendor_id,balance,locked,total_withdrawn,updated_at) VALUES(?,0,0,0,NOW())")
      ->execute([$vendor_id]);
  } catch (Throwable $e) {}
}

function vendor_wallet_get(int $vendor_id): array {
  vendor_wallet_ensure($vendor_id);
  $st = db()->prepare("SELECT * FROM vendor_wallets WHERE vendor_id=? LIMIT 1");
  $st->execute([$vendor_id]);
  $r = $st->fetch(PDO::FETCH_ASSOC);
  return $r ?: ['vendor_id'=>$vendor_id,'balance'=>0,'locked'=>0,'total_withdrawn'=>0];
}

function vendor_credit(int $vendor_id, float $amount, string $type, string $ref_key='', string $note='', array $meta=[]): void {
  if ($vendor_id <= 0 || $amount <= 0) return;
  vendor_wallet_ensure($vendor_id);
  $pdo = db();
  $pdo->beginTransaction();
  try {
    $st = $pdo->prepare("SELECT balance FROM vendor_wallets WHERE vendor_id=? FOR UPDATE");
    $st->execute([$vendor_id]);
    $bal = (float)($st->fetchColumn() ?: 0);
    $new = $bal + $amount;
    $pdo->prepare("UPDATE vendor_wallets SET balance=?, updated_at=NOW() WHERE vendor_id=?")->execute([$new, $vendor_id]);
    $pdo->prepare("INSERT INTO vendor_transactions(vendor_id,type,amount,ref_key,note,meta_json,created_at) VALUES(?,?,?,?,?,?,NOW())")
      ->execute([$vendor_id,$type,$amount,$ref_key,$note,$meta?json_encode($meta,JSON_UNESCAPED_UNICODE):null]);
    $pdo->commit();
  } catch (Throwable $e) {
    try { $pdo->rollBack(); } catch (Throwable $x) {}
  }
}

function vendor_debit(int $vendor_id, float $amount, string $type, string $ref_key='', string $note='', array $meta=[]): bool {
  if ($vendor_id <= 0 || $amount <= 0) return false;
  vendor_wallet_ensure($vendor_id);
  $pdo = db();
  $pdo->beginTransaction();
  try {
    $st = $pdo->prepare("SELECT balance FROM vendor_wallets WHERE vendor_id=? FOR UPDATE");
    $st->execute([$vendor_id]);
    $bal = (float)($st->fetchColumn() ?: 0);
    if ($bal < $amount) throw new Exception('Số dư CTV không đủ');
    $new = $bal - $amount;
    $pdo->prepare("UPDATE vendor_wallets SET balance=?, updated_at=NOW() WHERE vendor_id=?")->execute([$new, $vendor_id]);
    $pdo->prepare("INSERT INTO vendor_transactions(vendor_id,type,amount,ref_key,note,meta_json,created_at) VALUES(?,?,?,?,?,?,NOW())")
      ->execute([$vendor_id,$type,-$amount,$ref_key,$note,$meta?json_encode($meta,JSON_UNESCAPED_UNICODE):null]);
    $pdo->commit();
    return true;
  } catch (Throwable $e) {
    try { $pdo->rollBack(); } catch (Throwable $x) {}
    return false;
  }
}

function vendor_request_withdraw(int $vendor_id, float $amount): array {
  vendor_wallet_ensure($vendor_id);
  $amount = (float)$amount;
  if ($amount <= 0) return ['ok'=>false,'error'=>'Số tiền không hợp lệ.'];
  $min = (float)str_replace(',', '.', (string)setting('vendor_withdraw_min','50000'));
  if ($amount < $min) return ['ok'=>false,'error'=>'Rút tối thiểu '.money_vnd((int)$min).'.'];
  $pdo = db();
  $pdo->beginTransaction();
  try {
    $st = $pdo->prepare("SELECT balance FROM vendor_wallets WHERE vendor_id=? FOR UPDATE");
    $st->execute([$vendor_id]);
    $bal = (float)($st->fetchColumn() ?: 0);
    if ($bal < $amount) throw new Exception('Số dư không đủ.');
    $pdo->prepare("UPDATE vendor_wallets SET balance=balance-?, locked=locked+?, updated_at=NOW() WHERE vendor_id=?")
      ->execute([$amount,$amount,$vendor_id]);
    $pdo->prepare("INSERT INTO vendor_withdrawals(vendor_id,amount,status,created_at) VALUES(?,?,'pending',NOW())")
      ->execute([$vendor_id,$amount]);
    $wid = (int)$pdo->lastInsertId();
    $pdo->prepare("INSERT INTO vendor_transactions(vendor_id,type,amount,ref_key,note,meta_json,created_at) VALUES(?,?,?,?,?,?,NOW())")
      ->execute([$vendor_id,'withdraw_request',-$amount,'withdraw:'.$wid,'Yêu cầu rút tiền',null]);
    $pdo->commit();
    return ['ok'=>true,'id'=>$wid];
  } catch (Throwable $e) {
    try { $pdo->rollBack(); } catch (Throwable $x) {}
    return ['ok'=>false,'error'=>$e->getMessage()];
  }
}

function vendor_list_orders(int $vendor_id, int $limit=100): array {
  shop_ensure_schema(); vendor_ensure_schema();
  $limit = max(1, min(300, $limit));
  $st = db()->prepare("SELECT o.*, p.title AS product_title
    FROM shop_orders o JOIN shop_products p ON p.id=o.product_id
    WHERE o.vendor_id=? ORDER BY o.id DESC LIMIT $limit");
  $st->execute([$vendor_id]);
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}
