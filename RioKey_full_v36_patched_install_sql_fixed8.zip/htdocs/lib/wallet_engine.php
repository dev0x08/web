<?php
function wallet_get(int $uid): array {
  $st = db()->prepare("SELECT * FROM wallets WHERE user_id=? LIMIT 1");
  $st->execute([$uid]);
  $w = $st->fetch();
  return $w ?: ['balance'=>0,'processing'=>0,'total_withdrawn'=>0];
}

function wallet_apply(int $uid, string $type, float $amount, ?string $ref_table=null, ?int $ref_id=null, ?string $note=null): void {
   $pdo = db();
  $started = false;
  if(!$pdo->inTransaction()) { $pdo->beginTransaction(); $started = true; }
  try {
    $st = db()->prepare("SELECT balance, processing, total_withdrawn FROM wallets WHERE user_id=? FOR UPDATE");
    $st->execute([$uid]);
    $w = $st->fetch();
    if (!$w) throw new Exception("Wallet not found");

    $balance = (float)$w['balance'];
    $processing = (float)$w['processing'];

    if ($type === 'withdraw_create') {
      if ($amount <= 0) throw new Exception("Invalid amount");
      if ($amount > $balance) throw new Exception("Insufficient balance");
      db()->prepare("UPDATE wallets SET balance=balance-?, processing=processing+? WHERE user_id=?")->execute([$amount,$amount,$uid]);
      $newBalance = $balance - $amount;
    } elseif ($type === 'withdraw_paid') {
      db()->prepare("UPDATE wallets SET processing=GREATEST(processing-?,0), total_withdrawn=total_withdrawn+? WHERE user_id=?")
        ->execute([$amount,$amount,$uid]);
      $newBalance = $balance;
    } else {
      $newBalance = $balance + $amount;
      if ($newBalance < 0) throw new Exception("Balance would go negative");
      db()->prepare("UPDATE wallets SET balance=? WHERE user_id=?")->execute([$newBalance,$uid]);
    }

    db()->prepare("
      INSERT INTO wallet_transactions(user_id,type,ref_table,ref_id,amount,balance_after,note)
      VALUES (?,?,?,?,?,?,?)
    ")->execute([$uid,$type,$ref_table,$ref_id,$amount,$newBalance,$note]);

    if($started) $pdo->commit();
  } catch (Throwable $e) {
    if($started) $pdo->rollBack();
    throw $e;
  }
}


// Apply transaction once by checking existing wallet_transactions (simple idempotency)
function wallet_apply_once(int $uid, string $type, float $amount, ?string $ref_table=null, ?int $ref_id=null, ?string $note=null): bool {
  if ($ref_table && $ref_id) {
    $st = db()->prepare("SELECT id FROM wallet_transactions WHERE user_id=? AND type=? AND ref_table=? AND ref_id=? LIMIT 1");
    $st->execute([$uid,$type,$ref_table,$ref_id]);
    if ($st->fetch()) return false;
  }
  wallet_apply($uid,$type,$amount,$ref_table,$ref_id,$note);
  return true;
}


function wallet_balance(int $uid): float {
  $w = wallet_get($uid);
  return (float)($w['balance'] ?? 0);
}

function wallet_transactions(int $uid, int $limit=50): array {
  $limit = max(1, min(200, $limit));
  $st = db()->prepare("SELECT * FROM wallet_transactions WHERE user_id=? ORDER BY id DESC LIMIT $limit");
  $st->execute([$uid]);
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

// Convenience wrappers
function wallet_add(int $uid, float $amount, string $type='adjust', ?string $note=null): void {
  wallet_apply($uid, $type, abs($amount), null, null, $note);
}

function wallet_sub(int $uid, float $amount, string $type='spend', ?string $note=null): void {
  wallet_apply($uid, $type, -abs($amount), null, null, $note);
}
