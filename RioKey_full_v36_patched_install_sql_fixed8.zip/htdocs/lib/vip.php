<?php
function vip_ensure_schema(): void {
  $pdo = db();

  if (!db_has_table('vip_plans')) {
    $pdo->exec("CREATE TABLE vip_plans(
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(80) NOT NULL,
      price_vnd INT NOT NULL DEFAULT 0,
      duration_days INT NOT NULL DEFAULT 30,
      discount_pct INT NOT NULL DEFAULT 0,
      points_bonus_pct INT NOT NULL DEFAULT 0,
      is_active TINYINT(1) NOT NULL DEFAULT 1,
      created_at DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("INSERT INTO vip_plans(title,price_vnd,duration_days,discount_pct,points_bonus_pct,is_active,created_at)
      VALUES('VIP RioKey',99000,30,5,20,1,NOW())");
  }

  if (!db_has_table('user_vip')) {
    $pdo->exec("CREATE TABLE user_vip(
      user_id INT PRIMARY KEY,
      plan_id INT NOT NULL,
      expires_at DATETIME NOT NULL,
      updated_at DATETIME NOT NULL,
      CONSTRAINT fk_user_vip_plan FOREIGN KEY(plan_id) REFERENCES vip_plans(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  }
}

function vip_get_user(int $user_id): ?array {
  return vip_active($user_id);
}


function vip_active(int $user_id): ?array {
  vip_ensure_schema();
  $st = db()->prepare("SELECT uv.user_id,uv.plan_id,uv.expires_at,p.title,p.discount_pct,p.points_bonus_pct
    FROM user_vip uv JOIN vip_plans p ON p.id=uv.plan_id
    WHERE uv.user_id=? LIMIT 1");
  $st->execute([$user_id]);
  $r = $st->fetch(PDO::FETCH_ASSOC);
  if(!$r) return null;
  $exp = strtotime((string)$r['expires_at']);
  if(!$exp || $exp < time()) return null;
  if((int)($r['discount_pct'] ?? 0) < 0) $r['discount_pct'] = 0;
  if((int)($r['points_bonus_pct'] ?? 0) < 0) $r['points_bonus_pct'] = 0;
  return $r;
}

function vip_discount_pct(int $user_id): int {
  $v = vip_active($user_id);
  return $v ? (int)($v['discount_pct'] ?? 0) : 0;
}

function vip_points_bonus_pct(int $user_id): int {
  $v = vip_active($user_id);
  return $v ? (int)($v['points_bonus_pct'] ?? 0) : 0;
}

function vip_apply_price(int $base_price, int $vip_discount, int $flash_discount): array {
  $vip_discount = max(0, min(80, (int)$vip_discount));
  $flash_discount = max(0, min(80, (int)$flash_discount));
  // stack with cap
  $total = min(80, $vip_discount + $flash_discount);
  $final = (int)max(0, floor($base_price * (100 - $total) / 100));
  return ['price'=>$final, 'vip'=>$vip_discount, 'flash'=>$flash_discount, 'total'=>$total];
}

function vip_buy(int $user_id, int $plan_id, string $request_token=''): array {
  vip_ensure_schema();
  $pdo = db();
  $started = false;
  if (!$pdo->inTransaction()) { $pdo->beginTransaction(); $started = true; }
  try {
    if($request_token==='') $request_token = 'vip_' . bin2hex(random_bytes(12));
    // idempotent: if already logged with same token return ok
    if (db_has_table('vip_orders')) {
      $st0 = $pdo->prepare("SELECT id FROM vip_orders WHERE request_token=? AND user_id=? LIMIT 1");
      $st0->execute([$request_token,$user_id]);
      if ($st0->fetch()) { if ($started) $pdo->commit();
    return ['ok'=>true,'msg'=>'Đã xử lý giao dịch VIP trước đó.']; }
    }

    // lock plan
    $st = $pdo->prepare("SELECT * FROM vip_plans WHERE id=? AND is_active=1 FOR UPDATE");
    $st->execute([$plan_id]);
    $p = $st->fetch(PDO::FETCH_ASSOC);
    if(!$p) throw new Exception('Gói VIP không tồn tại');

    $price = (int)($p['price_vnd'] ?? 0);
    if($price<=0) throw new Exception('Gói VIP không hợp lệ');

    // lock wallet
    $stW = $pdo->prepare("SELECT balance FROM wallets WHERE user_id=? FOR UPDATE");
    $stW->execute([$user_id]);
    $w = $stW->fetch(PDO::FETCH_ASSOC);
    if(!$w) throw new Exception('Ví không tồn tại');
    if((float)$w['balance'] < $price) throw new Exception('Số dư không đủ để mua VIP');

    $newBalance = (float)$w['balance'] - $price;
    $pdo->prepare("UPDATE wallets SET balance=? WHERE user_id=?")->execute([$newBalance,$user_id]);
    $pdo->prepare("INSERT INTO wallet_transactions(user_id,type,ref_table,ref_id,amount,balance_after,note) VALUES(?,?,?,?,?,?,?)")
      ->execute([$user_id,'vip_buy','vip_plans',(int)$plan_id,-$price,$newBalance,'Mua VIP: '.($p['title'] ?? '')]);

    // extend vip
    $days = max(1, (int)($p['duration_days'] ?? 30));
    $now = time();
    $curExp = null;
    $stE = $pdo->prepare("SELECT expires_at FROM user_vip WHERE user_id=? FOR UPDATE");
    $stE->execute([$user_id]);
    if($row = $stE->fetch(PDO::FETCH_ASSOC)) $curExp = strtotime((string)$row['expires_at']);

    $base = ($curExp && $curExp > $now) ? $curExp : $now;
    $newExp = date('Y-m-d H:i:s', $base + $days*86400);

    if($curExp !== null){
      $pdo->prepare("UPDATE user_vip SET plan_id=?, expires_at=?, updated_at=NOW() WHERE user_id=?")
        ->execute([(int)$plan_id,$newExp,$user_id]);
    } else {
      $pdo->prepare("INSERT INTO user_vip(user_id,plan_id,expires_at,updated_at) VALUES(?,?,?,NOW())")
        ->execute([$user_id,(int)$plan_id,$newExp]);
    }

    // vip orders log (optional)
    if (!db_has_table('vip_orders')) {
      $pdo->exec("CREATE TABLE vip_orders(
        id INT AUTO_INCREMENT PRIMARY KEY,
        request_token VARCHAR(64) NULL,
        user_id INT NOT NULL,
        plan_id INT NOT NULL,
        amount_vnd INT NOT NULL,
        created_at DATETIME NOT NULL,
        UNIQUE KEY uq_vip_req(request_token)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
    $pdo->prepare("INSERT INTO vip_orders(request_token,user_id,plan_id,amount_vnd,created_at) VALUES(?,?,?,?,NOW())")
      ->execute([$request_token,$user_id,(int)$plan_id,$price]);

    $pdo->commit();
    notify_user($user_id,'Kích hoạt VIP','Bạn đã mua VIP thành công. Hạn VIP: '.$newExp);
    return ['ok'=>true,'msg'=>'Mua VIP thành công. Hạn: '.$newExp];
  } catch(Throwable $e){
    try{$pdo->rollBack();}catch(Throwable $x){}
    return ['ok'=>false,'msg'=>$e->getMessage()];
  }
}
