<?php
function flash_ensure_schema(): void {
  $pdo = db();
  if (!db_has_table('flash_sales')) {
    $pdo->exec("CREATE TABLE flash_sales(
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(120) NOT NULL,
      category VARCHAR(32) NULL,
      discount_pct INT NOT NULL DEFAULT 0,
      starts_at DATETIME NOT NULL,
      ends_at DATETIME NOT NULL,
      is_active TINYINT(1) NOT NULL DEFAULT 1,
      created_at DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  }
}
function flash_active_discount(?string $category): int {
  flash_ensure_schema();
  $cat = $category;
  $now = date('Y-m-d H:i:s');
  $st = db()->prepare("SELECT discount_pct FROM flash_sales
    WHERE is_active=1 AND starts_at<=? AND ends_at>=? AND (category IS NULL OR category='' OR category=?)
    ORDER BY discount_pct DESC, id DESC LIMIT 1");
  $st->execute([$now,$now,$cat]);
  $d = $st->fetchColumn();
  return (int)($d ?: 0);
}
function flash_active_sale(?string $category): ?array {
  flash_ensure_schema();
  $now = date('Y-m-d H:i:s');
  $st = db()->prepare("SELECT * FROM flash_sales
    WHERE is_active=1 AND starts_at<=? AND ends_at>=? AND (category IS NULL OR category='' OR category=?)
    ORDER BY discount_pct DESC, id DESC LIMIT 1");
  $st->execute([$now,$now,$category]);
  $r = $st->fetch(PDO::FETCH_ASSOC);
  return $r ?: null;
}
