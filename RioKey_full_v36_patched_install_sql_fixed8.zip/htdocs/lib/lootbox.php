<?php
function lootbox_ensure_schema(): void {
  // no new tables; uses spin_logs style
  if (!db_has_table('lootbox_logs')) {
    db()->exec("CREATE TABLE lootbox_logs(
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      tier VARCHAR(16) NOT NULL,
      product_id INT NOT NULL,
      key_id INT NOT NULL,
      pay_method ENUM('wallet','points') NOT NULL,
      amount_vnd INT NOT NULL DEFAULT 0,
      points INT NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL,
      ip VARCHAR(64) NULL,
      ua VARCHAR(250) NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    db()->exec("CREATE INDEX idx_loot_user ON lootbox_logs(user_id,id)");
  }
}

function lootbox_pick_tier(): string {
  // weights configurable
  $w_common = (int)setting('lootbox_w_common', 70);
  $w_rare   = (int)setting('lootbox_w_rare', 25);
  $w_epic   = (int)setting('lootbox_w_epic', 5);
  $w_common = max(0,$w_common); $w_rare=max(0,$w_rare); $w_epic=max(0,$w_epic);
  $sum = max(1, $w_common+$w_rare+$w_epic);
  $roll = random_int(1,$sum);
  if ($roll <= $w_common) return 'common';
  if ($roll <= $w_common+$w_rare) return 'rare';
  return 'epic';
}

function lootbox_category_for_tier(string $tier): string {
  if ($tier==='rare') return 'giftcard';
  if ($tier==='epic') return 'account';
  return 'game_key';
}

function lootbox_open(int $user_id, string $pay='points', string $request_token='', string $box_type='random'): array {
    vault_require_for_purchase($user_id);
lootbox_ensure_schema();
  shop_ensure_schema();
  $pdo = db();
  $started = false;
  if (!$pdo->inTransaction()) { $pdo->beginTransaction(); $started = true; }
  try {
    if ((int)setting('lootbox_enabled', 1) !== 1) throw new Exception('Lootbox đang tạm tắt.');

    // anti double-open (session lock)
    if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }
    $now = microtime(true);
    $lockUntil = (float)($_SESSION['lootbox_lock_until'] ?? 0);
    if ($lockUntil > $now) throw new Exception('Đang xử lý lượt mở trước đó, vui lòng chờ...');
    $_SESSION['lootbox_lock_until'] = $now + 3.5;

    if ($request_token==='') $request_token = 'lb_' . bin2hex(random_bytes(12));

    // request_token strict idempotency
    if ($request_token !== '' && db_has_column('shop_orders','request_token')) {
      $stX = $pdo->prepare("SELECT o.order_code,p.title,k.key_code FROM shop_orders o
        JOIN shop_products p ON p.id=o.product_id
        JOIN shop_keys k ON k.id=o.key_id
        WHERE o.user_id=? AND o.request_token=? LIMIT 1");
      $stX->execute([$user_id, $request_token]);
      $x = $stX->fetch(PDO::FETCH_ASSOC);
      if ($x) {
        if ($started) $pdo->commit();
        return ['ok'=>true,'tier'=>'cached','product'=>$x['title'] ?? '', 'key'=>$x['key_code'] ?? '', 'order_code'=>$x['order_code'] ?? ''];
      }
    }


    // idempotency: if token exists return last
    $st0 = $pdo->prepare("SELECT l.product_id,k.key_code FROM lootbox_logs l JOIN shop_keys k ON k.id=l.key_id WHERE l.user_id=? AND l.ua=? AND l.ip=? AND l.created_at >= (NOW() - INTERVAL 2 MINUTE) ORDER BY l.id DESC LIMIT 1");
    $st0->execute([$user_id, client_ua(), client_ip()]);
    // not strict idempotent but reduce double opens


    // box_type override
    $box_type = trim(strtolower($box_type));
    $allowedTypes = ['random','game_key','giftcard','account'];
    if (!in_array($box_type, $allowedTypes, true)) $box_type = 'random';

    if ($box_type !== 'random') {
      // map to category and tier for logs
      $cat = $box_type;
      $tier = ($box_type==='giftcard') ? 'rare' : (($box_type==='account') ? 'epic' : 'common');
    } else {
      $tier = lootbox_pick_tier();
      $cat = lootbox_category_for_tier($tier);
    }

    // pick a product with available keys in that category
    $stP = $pdo->prepare("SELECT p.* FROM shop_products p
      WHERE p.is_active=1 AND p.category=? AND EXISTS(SELECT 1 FROM shop_keys k WHERE k.product_id=p.id AND k.is_sold=0)
      ORDER BY p.price_vnd ASC, p.id ASC LIMIT 1 FOR UPDATE");
    $stP->execute([$cat]);
    $p = $stP->fetch(PDO::FETCH_ASSOC);
    if(!$p) throw new Exception('Kho lootbox đang hết hàng cho loại '.$cat.' (tier '.$tier.').');

    $product_id = (int)$p['id'];

    // pick key
    $stK = $pdo->prepare("SELECT * FROM shop_keys WHERE product_id=? AND is_sold=0 ORDER BY id ASC LIMIT 1 FOR UPDATE");
    $stK->execute([$product_id]);
    $k = $stK->fetch(PDO::FETCH_ASSOC);
    if(!$k) throw new Exception('Hết key');

    $amount_vnd = 0;
    $points = 0;

    if ($pay==='wallet') {
      $price = (int)setting('lootbox_price_vnd', 20000);
      if ($price<=0) throw new Exception('Lootbox không hỗ trợ mua bằng tiền');
      // lock wallet
      $stW = $pdo->prepare("SELECT balance FROM wallets WHERE user_id=? FOR UPDATE");
      $stW->execute([$user_id]);
      $w = $stW->fetch(PDO::FETCH_ASSOC);
      if(!$w) throw new Exception('Ví không tồn tại');
      if((float)$w['balance'] < $price) throw new Exception('Số dư không đủ');

      $newBal = (float)$w['balance'] - $price;
      $pdo->prepare("UPDATE wallets SET balance=? WHERE user_id=?")->execute([$newBal,$user_id]);
      $pdo->prepare("INSERT INTO wallet_transactions(user_id,type,ref_table,ref_id,amount,balance_after,note) VALUES(?,?,?,?,?,?,?)")
        ->execute([$user_id,'lootbox','lootbox_logs',0,-$price,$newBal,'Mở lootbox ('.$tier.')']);

      $amount_vnd = $price;
    } else {
      $cost = (int)setting('lootbox_price_points', 200);
      if ($cost<=0) throw new Exception('Lootbox không hỗ trợ mua bằng điểm');
      $stU = $pdo->prepare("SELECT points FROM users WHERE id=? FOR UPDATE");
      $stU->execute([$user_id]);
      $u = $stU->fetch(PDO::FETCH_ASSOC);
      if(!$u) throw new Exception('User không tồn tại');
      if((int)$u['points'] < $cost) throw new Exception('Bạn không đủ điểm');

      $pdo->prepare("UPDATE users SET points=points-? WHERE id=?")->execute([$cost,$user_id]);
      $pdo->prepare("INSERT INTO point_transactions(user_id,points,type,ref_key,note,created_at) VALUES(?,?,?,?,?,NOW())")
        ->execute([$user_id, -$cost, 'lootbox', 'lootbox:'.date('Ymd').':'.bin2hex(random_bytes(8)), 'Mở lootbox ('.$tier.')']);

      $points = $cost;
    }

    // deliver: mark key sold and create shop_order record for history
    $pdo->prepare("UPDATE shop_keys SET is_sold=1, sold_to=?, sold_at=NOW() WHERE id=?")
      ->execute([$user_id, (int)$k['id']]);

    $orderCode = 'LB'.date('ymd').strtoupper(substr(bin2hex(random_bytes(3)),0,6));
    $cols = "order_code,user_id,product_id,key_id,pay_method,amount_vnd,points,status,created_at";
    $vals = [$orderCode,$user_id,$product_id,(int)$k['id'],$pay==='wallet'?'wallet':'points',$amount_vnd,$points,'delivered'];
    if (db_has_column('shop_orders','request_token')) {
      $cols = "order_code,request_token,user_id,product_id,key_id,pay_method,amount_vnd,points,status,created_at";
      $vals = [$orderCode,$request_token,$user_id,$product_id,(int)$k['id'],$pay==='wallet'?'wallet':'points',$amount_vnd,$points,'delivered'];
    }
    $place = implode(',', array_fill(0,count($vals),'?'));
    $pdo->prepare("INSERT INTO shop_orders($cols) VALUES($place,NOW())")->execute($vals);

    $pdo->prepare("INSERT INTO lootbox_logs(user_id,tier,product_id,key_id,pay_method,amount_vnd,points,created_at,ip,ua) VALUES(?,?,?,?,?,?,?,?,?,?)")
      ->execute([$user_id,$tier,$product_id,(int)$k['id'],$pay==='wallet'?'wallet':'points',$amount_vnd,$points,date('Y-m-d H:i:s'),client_ip(),client_ua()]);

    if ($started) $pdo->commit();
    return ['ok'=>true,'tier'=>$tier,'product'=>$p['title'] ?? '', 'key'=>$k['key_code'] ?? '', 'order_code'=>$orderCode];
  } catch(Throwable $e){
    try{$pdo->rollBack();}catch(Throwable $x){}
    return ['ok'=>false,'msg'=>$e->getMessage()];
  }
}
