<?php
// Vault PIN requirement for purchases + (optional) future key reveal
require_once __DIR__ . '/helpers.php';

function vault_ensure_schema(PDO $pdo): void {
  // users.vault_pin_hash, users.vault_pin_set_at
  if (!db_has_column('users','vault_pin_hash')) {
    try { $pdo->exec("ALTER TABLE users ADD COLUMN vault_pin_hash VARCHAR(255) NULL"); } catch (Throwable $e) {}
  }
  if (!db_has_column('users','vault_pin_set_at')) {
    try { $pdo->exec("ALTER TABLE users ADD COLUMN vault_pin_set_at DATETIME NULL"); } catch (Throwable $e) {}
  }
  // settings toggle
  if (!db_has_table('settings')) return;
  try {
    $st = $pdo->prepare("SELECT v FROM settings WHERE k=? LIMIT 1");
    $st->execute(['vault_required']);
    if (!$st->fetchColumn()) {
      $pdo->prepare("INSERT INTO settings (k,v) VALUES (?,?)")->execute(['vault_required','1']);
    }
  } catch (Throwable $e) {}
}

function vault_required(): bool {
  // default ON
  $v = setting('vault_required', '1');
  return (int)$v === 1;
}

function vault_is_set(int $uid): bool {
  $pdo = db();
  $st = $pdo->prepare("SELECT vault_pin_hash FROM users WHERE id=? LIMIT 1");
  $st->execute([$uid]);
  $h = $st->fetchColumn();
  return $h && is_string($h) && strlen($h) > 10;
}

function vault_require_for_purchase(int $uid): void {
  if (!vault_required()) return;
  if (!vault_is_set($uid)) {
    throw new Exception('Bạn cần cập nhật PIN Vault trước khi mua key. Vào Trang cá nhân > Vault để thiết lập.');
  }
}

function vault_set_pin(int $uid, string $pin): array {
  $pin = trim($pin);
  if (!preg_match('/^[0-9]{4,8}$/', $pin)) {
    return ['ok'=>false,'error'=>'PIN phải là 4-8 chữ số.'];
  }
  $hash = password_hash($pin, PASSWORD_BCRYPT);
  $pdo = db();
  $st = $pdo->prepare("UPDATE users SET vault_pin_hash=?, vault_pin_set_at=NOW() WHERE id=?");
  $st->execute([$hash,$uid]);
  return ['ok'=>true];
}

function vault_verify_pin(int $uid, string $pin): bool {
  $pin = trim($pin);
  $pdo = db();
  $st = $pdo->prepare("SELECT vault_pin_hash FROM users WHERE id=? LIMIT 1");
  $st->execute([$uid]);
  $h = $st->fetchColumn();
  if(!$h) return false;
  return password_verify($pin, $h);
}
