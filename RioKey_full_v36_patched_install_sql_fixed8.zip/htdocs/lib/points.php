<?php
// Points ledger helpers (all point changes MUST go through points_add)

function points_balance(int $user_id): int {
  $st = db()->prepare("SELECT points FROM users WHERE id=?");
  $st->execute([$user_id]);
  return (int)($st->fetch()['points'] ?? 0);
}

/**
 * Add/subtract points with idempotency via ref_key.
 * - $type: checkin|mission|redeem|admin_adjust|...
 * - $ref_key: unique key per user+type to prevent double credit (e.g., 'checkin:2026-01-24', 'redeem:123')
 */
function points_add(int $user_id, int $points, string $type, ?string $ref_key=null, ?string $note=null): bool {
  if ($points === 0) return false;

  $pdo = db();
  $started = false;
  if(!$pdo->inTransaction()) { $pdo->beginTransaction(); $started=true; }
  try {
    if ($ref_key !== null) {
      $st0 = $pdo->prepare("SELECT id FROM point_transactions WHERE user_id=? AND type=? AND ref_key=? LIMIT 1");
      $st0->execute([$user_id,$type,$ref_key]);
      if ($st0->fetch()) { if($started) $pdo->commit(); return false; }
    }

    $st = $pdo->prepare("INSERT INTO point_transactions(user_id, points, type, ref_key, note, created_at) VALUES(?,?,?,?,?,NOW())");
    $st->execute([$user_id, $points, $type, $ref_key, $note]);

    $st2 = $pdo->prepare("UPDATE users SET points = points + ? WHERE id=?");
    $st2->execute([$points, $user_id]);

    if($started) $pdo->commit();
    return true;
  } catch (Throwable $e) {
    if($started) $pdo->rollBack();
    throw $e;
  }
}

function points_recent(int $user_id, int $limit=30): array {
  $st = db()->prepare("SELECT * FROM point_transactions WHERE user_id=? ORDER BY id DESC LIMIT ?");
  $st->bindValue(1, $user_id, PDO::PARAM_INT);
  $st->bindValue(2, $limit, PDO::PARAM_INT);
  $st->execute();
  return $st->fetchAll() ?: [];
}
