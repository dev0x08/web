<?php
function setting_get(string $key, $default=null) {
  try {
    $st = db()->prepare("SELECT v FROM settings WHERE k=? LIMIT 1");
    $st->execute([$key]);
    $row = $st->fetch();
    if (!$row) return $default;
    $v = $row['v'];
    if (in_array($key, ['captcha_enabled','popup_enabled','captcha_login_enabled','maintenance_enabled','google_login_enabled','ref_event_enabled','comment_spam_enabled','topup_enabled','preview_enabled','wishlist_enabled','lootbox_enabled','spin_enabled','vip_enabled','gifts_enabled','community_enabled','app_enabled'], true)) return (int)$v === 1;
    return $v;
  } catch (Throwable $e) {
    return $default;
  }
}

function setting_set(string $key, $value): void {
  $v = is_bool($value) ? ($value ? '1' : '0') : (string)$value;
  db()->prepare("INSERT INTO settings (k,v) VALUES (?,?) ON DUPLICATE KEY UPDATE v=VALUES(v)")
    ->execute([$key,$v]);
}

function setting(string $key, $default=null) { return setting_get($key,$default); }


function feature_enabled(string $key, bool $default=true): bool {
  $v = setting_get($key, $default ? '1' : '0');
  if (is_bool($v)) return $v;
  return (int)$v === 1;
}
