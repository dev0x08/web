<?php
function spin_ensure_schema(): void {
  $pdo = db();
  if (!db_has_table('spin_logs')) {
    $pdo->exec("CREATE TABLE spin_logs(
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      reward_type ENUM('points','coupon') NOT NULL DEFAULT 'points',
      reward_value VARCHAR(120) NOT NULL,
      is_free TINYINT(1) NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL,
      ip VARCHAR(64) NULL,
      ua VARCHAR(250) NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE INDEX idx_spin_user ON spin_logs(user_id,id)");
  }
}

function spin_can_free(int $user_id): bool {
  spin_ensure_schema();
  $st = db()->prepare("SELECT created_at FROM spin_logs WHERE user_id=? AND is_free=1 ORDER BY id DESC LIMIT 1");
  $st->execute([$user_id]);
  $t = $st->fetchColumn();
  if(!$t) return true;
  return date('Y-m-d') !== date('Y-m-d', strtotime((string)$t));
}

function spin_rewards_list(): array {
  // [type,value,weight]
  return [
    ['points', 10, 30],
    ['points', 20, 25],
    ['points', 50, 20],
    ['points', 100, 15],
    ['points', 200, 7],
    ['points', 500, 3],
  ];
}

function spin_pick_reward(): array {
  // [type,value,weight]
  $rewards = spin_rewards_list();
  $sum = 0;
  foreach($rewards as $r) $sum += (int)$r[2];
  $roll = random_int(1, max(1,$sum));
  $acc = 0;
  foreach($rewards as $i=>$r){
    $acc += (int)$r[2];
    if($roll <= $acc) return ['type'=>$r[0],'value'=>(int)$r[1],'idx'=>(int)$i];
  }
  return ['type'=>'points','value'=>10,'idx'=>0];
}

function spin_do(int $user_id, bool $free=false): array {
  spin_ensure_schema();
  $pdo = db();
  $started = false;
  if (!$pdo->inTransaction()) { $pdo->beginTransaction(); $started = true; }
  try {
    if ((int)setting('spin_enabled', 0) !== 1) throw new Exception('Vòng quay đang tạm tắt.');

    $price = (int)setting('spin_price_points', 50);
    if ($price < 0) $price = 0;

    if ($free) {
      if (!spin_can_free($user_id)) throw new Exception('Hôm nay bạn đã quay miễn phí rồi.');
    } else {
      // deduct points
      $stU = $pdo->prepare("SELECT points FROM users WHERE id=? FOR UPDATE");
      $stU->execute([$user_id]);
      $u = $stU->fetch(PDO::FETCH_ASSOC);
      if(!$u) throw new Exception('User không tồn tại');
      if((int)$u['points'] < $price) throw new Exception('Bạn không đủ điểm để quay.');
      $pdo->prepare("UPDATE users SET points=points-? WHERE id=?")->execute([$price,$user_id]);
      $pdo->prepare("INSERT INTO point_transactions(user_id,points,type,ref_key,note,created_at) VALUES(?,?,?,?,?,NOW())")
        ->execute([$user_id, -$price, 'spin', 'spin:pay:'.bin2hex(random_bytes(8)), 'Quay vòng quay']);
    }

    $pick = spin_pick_reward();
    $rtype = (string)$pick['type'];
    $val = (int)$pick['value'];

    if ($rtype === 'points') {
      points_add($user_id, $val, 'spin_reward', 'spin_reward:'.date('Ymd').':'.bin2hex(random_bytes(8)), 'Thưởng vòng quay');
      $reward_value = (string)$val;
      $msg = 'Bạn nhận được +' . $val . ' điểm!';
    } else {
      $reward_value = 'COUPON';
      $msg = 'Bạn nhận được 1 coupon!';
    }

    $pdo->prepare("INSERT INTO spin_logs(user_id,reward_type,reward_value,is_free,created_at,ip,ua) VALUES(?,?,?,?,NOW(),?,?)")
      ->execute([$user_id,$rtype,$reward_value,$free?1:0,client_ip(),client_ua()]);

    if ($started) $pdo->commit();
    return ['ok'=>true,'type'=>$rtype,'value'=>$val,'msg'=>$msg];
  } catch(Throwable $e){
    try{$pdo->rollBack();}catch(Throwable $x){}
    return ['ok'=>false,'msg'=>$e->getMessage()];
  }
}
