<?php
function user_features_ensure_schema(): void {
  $pdo = db();
  if (!db_has_table('badges')) {
    try {
      $pdo->exec("CREATE TABLE badges (
        id INT AUTO_INCREMENT PRIMARY KEY,
        code VARCHAR(60) NOT NULL,
        name VARCHAR(120) NOT NULL,
        icon VARCHAR(60) NOT NULL DEFAULT 'award',
        rarity ENUM('common','rare','epic','legend') NOT NULL DEFAULT 'common',
        description VARCHAR(255) NULL,
        title VARCHAR(60) NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        sort INT NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL,
        UNIQUE KEY uq_code (code),
        INDEX idx_active (is_active),
        INDEX idx_sort (sort)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
  }

  if (!db_has_table('user_badges')) {
    try {
      $pdo->exec("CREATE TABLE user_badges (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        badge_id INT NOT NULL,
        earned_at DATETIME NOT NULL,
        meta MEDIUMTEXT NULL,
        UNIQUE KEY uq_user_badge (user_id, badge_id),
        INDEX idx_user (user_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
  }

  if (!db_has_table('user_wishlist')) {
    try {
      $pdo->exec("CREATE TABLE user_wishlist (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        product_id INT NOT NULL,
        created_at DATETIME NOT NULL,
        UNIQUE KEY uq_wish (user_id, product_id),
        INDEX idx_user (user_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
  }

  try {
    if (!db_has_column('users','featured_badge_id')) $pdo->exec("ALTER TABLE users ADD COLUMN featured_badge_id INT NULL");
    if (!db_has_column('users','display_title')) $pdo->exec("ALTER TABLE users ADD COLUMN display_title VARCHAR(60) NULL");
    if (!db_has_column('users','profile_cover')) $pdo->exec("ALTER TABLE users ADD COLUMN profile_cover VARCHAR(40) NULL");
    if (!db_has_column('users','avatar')) $pdo->exec("ALTER TABLE users ADD COLUMN avatar VARCHAR(255) NULL");
    if (!db_has_column('users','vault_pin_hash')) $pdo->exec("ALTER TABLE users ADD COLUMN vault_pin_hash VARCHAR(255) NULL");
  } catch (Throwable $e) {}
}

function badges_seed_defaults(): void {
  user_features_ensure_schema();
  $items = [
    ['first_topup','First Topup','sparkles','common','Nạp tiền lần đầu.','Topup Starter',10],
    ['first_purchase','First Purchase','shopping-bag','common','Mua key lần đầu.','Key Hunter',20],
    ['collector_10','Collector','boxes','rare','Mua 10 đơn hàng.','Collector',30],
    ['coupon_hunter_5','Coupon Hunter','ticket','rare','Redeem 5 coupon.','Coupon Master',40],
    ['streak_7','7-Day Streak','flame','epic','Điểm danh liên tục 7 ngày.','Streak Lord',50],
    ['vip_member','VIP Member','crown','epic','Kích hoạt VIP.','VIP',60],
    ['community_contributor','Contributor','message-circle','rare','Đăng 5 bài trong cộng đồng.','Contributor',70],
  ];
  foreach($items as $it){
    try {
      db()->prepare("INSERT IGNORE INTO badges(code,name,icon,rarity,description,title,sort,created_at) VALUES(?,?,?,?,?,?,?,NOW())")
        ->execute([$it[0],$it[1],$it[2],$it[3],$it[4],$it[5],(int)$it[6]]);
    } catch (Throwable $e) {}
  }
}

function badge_by_code(string $code) {
  badges_seed_defaults();
  $st = db()->prepare("SELECT * FROM badges WHERE code=? AND is_active=1 LIMIT 1");
  $st->execute([$code]);
  return $st->fetch(PDO::FETCH_ASSOC);
}

function user_has_badge(int $user_id, int $badge_id): bool {
  $st = db()->prepare("SELECT 1 FROM user_badges WHERE user_id=? AND badge_id=? LIMIT 1");
  $st->execute([$user_id,$badge_id]);
  return (bool)$st->fetchColumn();
}

function user_award_badge(int $user_id, string $badge_code, array $meta = []): bool {
  $b = badge_by_code($badge_code);
  if (!$b) return false;
  $bid = (int)($b['id'] ?? 0);
  if ($bid<=0) return false;
  if (user_has_badge($user_id, $bid)) return false;

  try {
    db()->prepare("INSERT INTO user_badges(user_id,badge_id,earned_at,meta) VALUES(?,?,NOW(),?)")
      ->execute([$user_id,$bid,json_encode($meta,JSON_UNESCAPED_UNICODE)]);
    notify_user($user_id, 'Bạn nhận được badge mới!', $b['name'].' — '.$b['description'], route_url('badges'));
    return true;
  } catch (Throwable $e) {
    return false;
  }
}

function user_badges(int $user_id): array {
  badges_seed_defaults();
  $st = db()->prepare("SELECT ub.earned_at, b.* FROM user_badges ub JOIN badges b ON b.id=ub.badge_id WHERE ub.user_id=? ORDER BY b.sort ASC, ub.earned_at DESC");
  $st->execute([$user_id]);
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

function wishlist_ids(int $user_id): array {
  if ($user_id<=0) return [];
  $st = db()->prepare("SELECT product_id FROM user_wishlist WHERE user_id=?");
  $st->execute([$user_id]);
  return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN) ?: []);
}

function wishlist_toggle(int $user_id, int $product_id): bool {
  user_features_ensure_schema();
  if ($user_id<=0 || $product_id<=0) return false;
  $st = db()->prepare("SELECT 1 FROM user_wishlist WHERE user_id=? AND product_id=? LIMIT 1");
  $st->execute([$user_id,$product_id]);
  if ($st->fetchColumn()) {
    db()->prepare("DELETE FROM user_wishlist WHERE user_id=? AND product_id=?")->execute([$user_id,$product_id]);
    return false;
  }
  db()->prepare("INSERT IGNORE INTO user_wishlist(user_id,product_id,created_at) VALUES(?,?,NOW())")->execute([$user_id,$product_id]);
  return true;
}

function wishlist_items(int $user_id): array {
  shop_ensure_schema();
  user_features_ensure_schema();
  $st = db()->prepare("SELECT p.*, w.created_at AS wished_at
    FROM user_wishlist w JOIN shop_products p ON p.id=w.product_id
    WHERE w.user_id=? ORDER BY w.id DESC");
  $st->execute([$user_id]);
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}
