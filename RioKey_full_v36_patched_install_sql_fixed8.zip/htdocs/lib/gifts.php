<?php
function gifts_ensure_schema(): void {
  try{ shop_ensure_schema(); }catch(Throwable $e){}

  $pdo=db();
  if(!db_has_table('gift_links')){
    try{
      $pdo->exec("CREATE TABLE gift_links (
        id INT AUTO_INCREMENT PRIMARY KEY,
        token VARCHAR(80) NOT NULL,
        from_user_id INT NOT NULL,
        user_key_id INT NOT NULL,
        status ENUM('active','claimed','revoked','expired') NOT NULL DEFAULT 'active',
        expires_at DATETIME NULL,
        claimed_by_user_id INT NULL,
        claimed_at DATETIME NULL,
        created_at DATETIME NOT NULL,
        UNIQUE KEY uq_token (token),
        UNIQUE KEY uq_key (user_key_id),
        INDEX idx_from (from_user_id),
        INDEX idx_status (status)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }catch(Throwable $e){}
  }
  try{
    if(!db_has_column('shop_user_keys','gift_link_id')) $pdo->exec("ALTER TABLE shop_user_keys ADD COLUMN gift_link_id INT NULL");
    if(!db_has_column('shop_user_keys','gifted_at')) $pdo->exec("ALTER TABLE shop_user_keys ADD COLUMN gifted_at DATETIME NULL");
  }catch(Throwable $e){}
}
function gift_token_new(): string { return bin2hex(random_bytes(24)); }
function gift_create(int $from_user_id, int $user_key_id): array {
  gifts_ensure_schema();
  if($from_user_id<=0 || $user_key_id<=0) return ['ok'=>false,'error'=>'Thiếu dữ liệu.'];
  $pdo=db(); $pdo->beginTransaction();
  try{
    $st=$pdo->prepare("SELECT * FROM shop_user_keys WHERE id=? FOR UPDATE");
    $st->execute([$user_key_id]);
    $k=$st->fetch(PDO::FETCH_ASSOC);
    if(!$k) throw new Exception('Key không tồn tại.');
    if((int)$k['user_id'] !== $from_user_id) throw new Exception('Bạn không sở hữu key này.');
    if(!empty($k['gift_link_id'])) throw new Exception('Key này đã có gift link.');
    if(!empty($k['activated_at'])) throw new Exception('Key đã kích hoạt, không thể tặng.');
    $token=gift_token_new();
    $days=(int)setting('gift_expires_days','7'); if($days<1) $days=7; if($days>30) $days=30;
    $pdo->prepare("INSERT INTO gift_links(token,from_user_id,user_key_id,status,expires_at,created_at) VALUES(?,?,?,?,DATE_ADD(NOW(), INTERVAL ? DAY),NOW())")
      ->execute([$token,$from_user_id,$user_key_id,'active',$days]);
    $gid=(int)$pdo->lastInsertId();
    $pdo->prepare("UPDATE shop_user_keys SET gift_link_id=?, gifted_at=NOW() WHERE id=?")->execute([$gid,$user_key_id]);
    $pdo->commit();
    return ['ok'=>true,'token'=>$token,'gift_id'=>$gid,'expires_days'=>$days];
  }catch(Throwable $e){
    try{ $pdo->rollBack(); }catch(Throwable $e2){}
    return ['ok'=>false,'error'=>$e->getMessage()];
  }
}
function gift_revoke(int $from_user_id, int $gift_id): array {
  gifts_ensure_schema();
  $pdo=db(); $pdo->beginTransaction();
  try{
    $st=$pdo->prepare("SELECT * FROM gift_links WHERE id=? FOR UPDATE");
    $st->execute([$gift_id]);
    $g=$st->fetch(PDO::FETCH_ASSOC);
    if(!$g) throw new Exception('Gift không tồn tại.');
    if((int)$g['from_user_id'] !== $from_user_id) throw new Exception('Không có quyền.');
    if((string)$g['status'] !== 'active') throw new Exception('Gift không còn active.');
    $pdo->prepare("UPDATE gift_links SET status='revoked' WHERE id=?")->execute([$gift_id]);
    $pdo->prepare("UPDATE shop_user_keys SET gift_link_id=NULL, gifted_at=NULL WHERE id=?")->execute([(int)$g['user_key_id']]);
    $pdo->commit();
    return ['ok'=>true];
  }catch(Throwable $e){
    try{ $pdo->rollBack(); }catch(Throwable $e2){}
    return ['ok'=>false,'error'=>$e->getMessage()];
  }
}
function gift_by_token(string $token){
  gifts_ensure_schema();
  $st=db()->prepare("SELECT * FROM gift_links WHERE token=? LIMIT 1");
  $st->execute([$token]);
  $g=$st->fetch(PDO::FETCH_ASSOC);
  if(!$g) return null;
  if((string)$g['status']==='active' && !empty($g['expires_at'])){
    $st2=db()->prepare("SELECT (expires_at < NOW()) FROM gift_links WHERE id=?");
    $st2->execute([(int)$g['id']]);
    if((int)($st2->fetchColumn() ?: 0)===1){
      db()->prepare("UPDATE gift_links SET status='expired' WHERE id=?")->execute([(int)$g['id']]);
      $g['status']='expired';
    }
  }
  return $g;
}
function gift_claim(string $token, int $to_user_id): array {
  gifts_ensure_schema();
  if($to_user_id<=0) return ['ok'=>false,'error'=>'Bạn cần đăng nhập.'];
  $pdo=db(); $pdo->beginTransaction();
  try{
    $st=$pdo->prepare("SELECT * FROM gift_links WHERE token=? FOR UPDATE");
    $st->execute([$token]);
    $g=$st->fetch(PDO::FETCH_ASSOC);
    if(!$g) throw new Exception('Link không tồn tại.');
    if((string)$g['status'] !== 'active') throw new Exception('Link không còn hiệu lực.');
    if(!empty($g['expires_at'])){
      $st2=$pdo->prepare("SELECT (expires_at < NOW()) FROM gift_links WHERE id=?");
      $st2->execute([(int)$g['id']]);
      if((int)($st2->fetchColumn() ?: 0)===1) throw new Exception('Link đã hết hạn.');
    }
    $key_id=(int)$g['user_key_id'];
    $st=$pdo->prepare("SELECT * FROM shop_user_keys WHERE id=? FOR UPDATE");
    $st->execute([$key_id]);
    $k=$st->fetch(PDO::FETCH_ASSOC);
    if(!$k) throw new Exception('Key không tồn tại.');
    if(!empty($k['activated_at'])) throw new Exception('Key đã kích hoạt.');
    if((int)$k['gift_link_id'] !== (int)$g['id']) throw new Exception('Key không khớp gift link.');
    $pdo->prepare("UPDATE shop_user_keys SET user_id=?, gift_link_id=NULL, gifted_at=NULL WHERE id=?")
      ->execute([$to_user_id,$key_id]);
    $pdo->prepare("UPDATE gift_links SET status='claimed', claimed_by_user_id=?, claimed_at=NOW() WHERE id=?")
      ->execute([$to_user_id,(int)$g['id']]);
    $pdo->commit();
    try{ notify_user((int)$g['from_user_id'],'Gift đã được nhận','Key bạn tặng đã được người nhận lấy.', route_url('my_keys')); }catch(Throwable $e){}
    try{ notify_user($to_user_id,'Bạn đã nhận quà!','Key đã được chuyển vào Kho key của bạn.', route_url('my_keys')); }catch(Throwable $e){}
    return ['ok'=>true];
  }catch(Throwable $e){
    try{ $pdo->rollBack(); }catch(Throwable $e2){}
    return ['ok'=>false,'error'=>$e->getMessage()];
  }
}
function gifts_outgoing(int $user_id, int $limit=100): array {
  gifts_ensure_schema();
  $limit=max(1,min(200,$limit));
  $st=db()->prepare("SELECT g.*, p.title AS product_title FROM gift_links g
    JOIN shop_user_keys k ON k.id=g.user_key_id
    JOIN shop_products p ON p.id=k.product_id
    WHERE g.from_user_id=? ORDER BY g.id DESC LIMIT $limit");
  $st->execute([$user_id]);
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}
