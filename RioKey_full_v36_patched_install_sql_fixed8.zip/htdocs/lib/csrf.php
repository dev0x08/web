<?php
function csrf_token(): string {
  if (session_status() === PHP_SESSION_NONE) session_start();
  if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(16));
  return $_SESSION['_csrf'];
}
function csrf_check(): void {
  if (session_status() === PHP_SESSION_NONE) session_start();
  $t = $_POST['_csrf'] ?? '';
  if (!$t || !hash_equals($_SESSION['_csrf'] ?? '', $t)) {
    http_response_code(403);
    die('CSRF invalid');
  }
}


function csrf_field(): string {
  $t = csrf_token();
  return '<input type="hidden" name="_csrf" value="'.htmlspecialchars($t, ENT_QUOTES, 'UTF-8').'">';
}

function csrf_require(): void {
  if ($_SERVER['REQUEST_METHOD'] === 'POST') csrf_check();
}
