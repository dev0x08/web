<?php
function showcase_ensure_schema(): void {
  $pdo=db();
  if(!db_has_table('user_showcase')){
    try{
      $pdo->exec("CREATE TABLE user_showcase (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        product_id INT NOT NULL,
        sort INT NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL,
        UNIQUE KEY uq_user_product (user_id, product_id),
        INDEX idx_user (user_id),
        INDEX idx_sort (sort)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }catch(Throwable $e){}
  }
}
function showcase_list(int $user_id): array {
  showcase_ensure_schema();
  $st=db()->prepare("SELECT s.*, p.title, p.category
    FROM user_showcase s JOIN shop_products p ON p.id=s.product_id
    WHERE s.user_id=? ORDER BY s.sort ASC, s.id ASC LIMIT 6");
  $st->execute([$user_id]);
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}
function showcase_count(int $user_id): int {
  showcase_ensure_schema();
  $st=db()->prepare("SELECT COUNT(*) FROM user_showcase WHERE user_id=?");
  $st->execute([$user_id]);
  return (int)($st->fetchColumn() ?: 0);
}
function showcase_toggle(int $user_id, int $product_id): array {
  showcase_ensure_schema();
  if($user_id<=0 || $product_id<=0) return ['ok'=>false];
  $ok=false;
  $st=db()->prepare("SELECT 1 FROM shop_orders WHERE user_id=? AND product_id=? LIMIT 1");
  $st->execute([$user_id,$product_id]);
  if($st->fetchColumn()) $ok=true;
  if(!$ok){
    $st=db()->prepare("SELECT 1 FROM user_wishlist WHERE user_id=? AND product_id=? LIMIT 1");
    $st->execute([$user_id,$product_id]);
    if($st->fetchColumn()) $ok=true;
  }
  if(!$ok) return ['ok'=>false,'error'=>'Chỉ pin sản phẩm đã mua hoặc đang wishlist.'];
  $st=db()->prepare("SELECT id FROM user_showcase WHERE user_id=? AND product_id=? LIMIT 1");
  $st->execute([$user_id,$product_id]);
  $id=(int)($st->fetchColumn() ?: 0);
  if($id>0){
    db()->prepare("DELETE FROM user_showcase WHERE id=?")->execute([$id]);
    return ['ok'=>true,'pinned'=>false];
  }
  if(showcase_count($user_id)>=6) return ['ok'=>false,'error'=>'Bộ sưu tập tối đa 6 sản phẩm.'];
  $sort = showcase_count($user_id)+1;
  db()->prepare("INSERT IGNORE INTO user_showcase(user_id,product_id,sort,created_at) VALUES(?,?,?,NOW())")
    ->execute([$user_id,$product_id,$sort]);
  return ['ok'=>true,'pinned'=>true];
}
