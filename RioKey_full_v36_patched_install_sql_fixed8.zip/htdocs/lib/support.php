<?php
// Support / Tickets (thread + attachments)
function support_ensure_schema(): void {
  $pdo = db();
  if(!db_has_table('support_tickets')){
    try{
      $pdo->exec("CREATE TABLE support_tickets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        type VARCHAR(30) NOT NULL DEFAULT 'general',
        order_id INT NULL,
        subject VARCHAR(200) NULL,
        status ENUM('open','pending','resolved','closed') NOT NULL DEFAULT 'open',
        staff_note TEXT NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NULL,
        INDEX idx_user (user_id),
        INDEX idx_status (status),
        INDEX idx_order (order_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch(Throwable $e){}
  }
  if(!db_has_table('support_messages')){
    try{
      $pdo->exec("CREATE TABLE support_messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        ticket_id INT NOT NULL,
        sender_type ENUM('user','staff','system') NOT NULL DEFAULT 'user',
        sender_id INT NULL,
        content TEXT NOT NULL,
        attachments JSON NULL,
        created_at DATETIME NOT NULL,
        INDEX idx_ticket (ticket_id),
        INDEX idx_sender (sender_type, sender_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch(Throwable $e){}
  }
  try{
    if(!db_has_column('support_tickets','last_message_at')) $pdo->exec("ALTER TABLE support_tickets ADD COLUMN last_message_at DATETIME NULL");
    if(!db_has_column('support_tickets','updated_at')) $pdo->exec("ALTER TABLE support_tickets ADD COLUMN updated_at DATETIME NULL");
  } catch(Throwable $e){}
}
function support_ticket_create(int $user_id, string $type, ?int $order_id, string $subject, string $content, array $attachments=[]): int {
  support_ensure_schema();
  $pdo=db(); $pdo->beginTransaction();
  try{
    $pdo->prepare("INSERT INTO support_tickets(user_id,type,order_id,subject,status,created_at,last_message_at,updated_at) VALUES(?,?,?,?, 'open', NOW(), NOW(), NOW())")
      ->execute([$user_id,$type, ($order_id&&$order_id>0?$order_id:null), ($subject!==''?$subject:null)]);
    $tid=(int)$pdo->lastInsertId();
    $pdo->prepare("INSERT INTO support_messages(ticket_id,sender_type,sender_id,content,attachments,created_at) VALUES(?,?,?,?,?,NOW())")
      ->execute([$tid,'user',$user_id,$content, ($attachments?json_encode($attachments,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE):null)]);
    $pdo->commit();
    return $tid;
  }catch(Throwable $e){
    try{$pdo->rollBack();}catch(Throwable $e2){}
    throw $e;
  }
}
function support_ticket_add_message(int $ticket_id, string $sender_type, ?int $sender_id, string $content, array $attachments=[]): void {
  support_ensure_schema();
  $pdo=db(); $pdo->beginTransaction();
  try{
    $pdo->prepare("INSERT INTO support_messages(ticket_id,sender_type,sender_id,content,attachments,created_at) VALUES(?,?,?,?,?,NOW())")
      ->execute([$ticket_id,$sender_type,$sender_id,$content, ($attachments?json_encode($attachments,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE):null)]);
    $pdo->prepare("UPDATE support_tickets SET last_message_at=NOW(), updated_at=NOW(), status=IF(status='closed','closed', IF(?, 'pending', status)) WHERE id=?")
      ->execute([$sender_type==='user'?1:0,$ticket_id]);
    $pdo->commit();
  }catch(Throwable $e){
    try{$pdo->rollBack();}catch(Throwable $e2){}
    throw $e;
  }
}
function support_ticket_get(int $ticket_id){
  support_ensure_schema();
  $st=db()->prepare("SELECT * FROM support_tickets WHERE id=? LIMIT 1");
  $st->execute([$ticket_id]);
  return $st->fetch(PDO::FETCH_ASSOC) ?: null;
}
function support_ticket_messages(int $ticket_id): array {
  support_ensure_schema();
  $st=db()->prepare("SELECT * FROM support_messages WHERE ticket_id=? ORDER BY id ASC");
  $st->execute([$ticket_id]);
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}
function support_user_tickets(int $user_id, int $limit=100): array {
  support_ensure_schema();
  $limit=max(1,min(200,$limit));
  $st=db()->prepare("SELECT * FROM support_tickets WHERE user_id=? ORDER BY COALESCE(last_message_at, created_at) DESC, id DESC LIMIT $limit");
  $st->execute([$user_id]);
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}
function support_admin_tickets(string $status='all', int $limit=200): array {
  support_ensure_schema();
  $limit=max(1,min(500,$limit));
  if($status==='all'){
    $st=db()->prepare("SELECT t.*, u.username FROM support_tickets t JOIN users u ON u.id=t.user_id ORDER BY COALESCE(t.last_message_at, t.created_at) DESC, t.id DESC LIMIT $limit");
    $st->execute();
  } else {
    $st=db()->prepare("SELECT t.*, u.username FROM support_tickets t JOIN users u ON u.id=t.user_id WHERE t.status=? ORDER BY COALESCE(t.last_message_at, t.created_at) DESC, t.id DESC LIMIT $limit");
    $st->execute([$status]);
  }
  return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}
function support_ticket_set_status(int $ticket_id, string $status, string $staff_note=''): void {
  support_ensure_schema();
  $allowed=['open','pending','resolved','closed'];
  if(!in_array($status,$allowed,true)) $status='open';
  db()->prepare("UPDATE support_tickets SET status=?, staff_note=?, updated_at=NOW() WHERE id=?")->execute([$status, ($staff_note!==''?$staff_note:null), $ticket_id]);
}
function support_ticket_dir(int $ticket_id): string {
  $base = __DIR__ . '/../uploads/tickets/' . (int)$ticket_id;
  if(!is_dir($base)) @mkdir($base, 0755, true);
  return $base;
}
function support_handle_uploads(int $ticket_id, string $field='files', int $max_files=6): array {
  support_ensure_schema();
  if(empty($_FILES[$field]) || !is_array($_FILES[$field]['name'])) return [];
  $names=$_FILES[$field]['name'];
  $tmp=$_FILES[$field]['tmp_name'];
  $err=$_FILES[$field]['error'];
  $size=$_FILES[$field]['size'];
  $out=[];
  $max_files=max(1,min(12,$max_files));
  $dir = support_ticket_dir($ticket_id);
  for($i=0;$i<count($names) && $i<$max_files;$i++){
    if(($err[$i] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) continue;
    $s=(int)($size[$i] ?? 0);
    if($s<=0 || $s> (int)setting('upload_max_mb', 5)*1024*1024) continue;
    $orig = (string)$names[$i];
    $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
    $allow=['png','jpg','jpeg','webp','gif'];
    if(!in_array($ext,$allow,true)) continue;
    $safe = bin2hex(random_bytes(10)).'.'.$ext;
    $dest = $dir.'/'.$safe;
    if(@move_uploaded_file($tmp[$i], $dest)){
      $out[] = 'uploads/tickets/'.(int)$ticket_id.'/'.$safe;
    }
  }
  return $out;
}