-- RioKey full clean DB v35 (MariaDB compatible)

DROP DATABASE IF EXISTS riokey;

CREATE DATABASE riokey CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE riokey;

SET NAMES utf8mb4;

SET FOREIGN_KEY_CHECKS=0;

-- Base schema

CREATE TABLE `admin_audit_logs` (
  `id` bigint(20) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `action` varchar(80) NOT NULL,
  `target_type` varchar(40) NOT NULL DEFAULT '',
  `target_id` varchar(80) DEFAULT NULL,
  `meta_json` text DEFAULT NULL,
  `ip` varchar(60) DEFAULT NULL,
  `ua` varchar(250) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_audit_logs` (`id`, `admin_id`, `action`, `target_type`, `target_id`, `meta_json`, `ip`, `ua`, `created_at`) VALUES
(1, 4, 'topup_create', 'topup', 'TP8GKPSDDN', '{\"amount\":50000}', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36', '2026-01-25 07:52:51');

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `content` varchar(255) NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `banners` (
  `id` int(11) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `link_url` varchar(255) DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `checkins` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `checkin_date` date NOT NULL,
  `streak_count` int(11) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `checkin_rewards` (
  `id` int(11) NOT NULL,
  `day_index` int(11) NOT NULL,
  `points` int(11) NOT NULL,
  `day_no` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `checkin_rewards` (`id`, `day_index`, `points`, `day_no`) VALUES
(1, 1, 5, 1),
(2, 2, 8, 1),
(3, 3, 10, 1),
(4, 4, 12, 1),
(5, 5, 15, 1),
(6, 6, 20, 1),
(7, 7, 25, 1);

CREATE TABLE `community_comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `is_approved` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `community_links` (
  `id` int(11) NOT NULL,
  `title` varchar(80) NOT NULL,
  `url` varchar(255) NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `community_posts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(140) NOT NULL,
  `content` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `community_post_tags` (
  `post_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `community_tags` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `slug` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `title` varchar(80) NOT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `missions` (
  `id` int(11) NOT NULL,
  `title` varchar(120) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `points` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `mission_claims` (
  `id` bigint(20) NOT NULL,
  `mission_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `claimed_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `notifications` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(180) NOT NULL,
  `body` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `notification_reads` (
  `user_id` int(11) NOT NULL,
  `notification_id` bigint(20) NOT NULL,
  `read_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `orders` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_code` varchar(60) NOT NULL,
  `title` varchar(255) NOT NULL,
  `cashback_amount` decimal(14,2) NOT NULL DEFAULT 0.00,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `order_date` date NOT NULL DEFAULT curdate(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `point_transactions` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `points` int(11) NOT NULL,
  `type` varchar(40) NOT NULL,
  `ref_key` varchar(120) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `popups` (
  `id` int(11) NOT NULL,
  `title` varchar(120) NOT NULL,
  `content` text NOT NULL,
  `button_text` varchar(80) DEFAULT NULL,
  `button_url` varchar(255) DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `ranks` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `rate_normal` int(11) NOT NULL DEFAULT 0,
  `rate_promo` int(11) NOT NULL DEFAULT 0,
  `require_orders` int(11) NOT NULL DEFAULT 0,
  `condition_text` varchar(255) DEFAULT NULL,
  `icon` varchar(60) NOT NULL DEFAULT 'badge-check'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `ranks` (`id`, `name`, `slug`, `rate_normal`, `rate_promo`, `require_orders`, `condition_text`, `icon`) VALUES
(1, 'ĐỒNG', 'dong', 60, 70, 0, 'Hạng mặc định khi đăng ký', 'badge-check'),
(2, 'VÀNG', 'vang', 70, 80, 10, '10 đơn hàng thành công', 'zap'),
(3, 'KIM CƯƠNG', 'kim-cuong', 80, 90, 50, '50 đơn hàng thành công', 'gem');

CREATE TABLE `referrals` (
  `id` bigint(20) NOT NULL,
  `referrer_id` int(11) NOT NULL,
  `referee_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `rewards` (
  `id` int(11) NOT NULL,
  `title` varchar(120) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `points_cost` int(11) NOT NULL DEFAULT 0,
  `stock` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `sort` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `reward_redemptions` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `reward_id` int(11) NOT NULL,
  `points_cost` int(11) NOT NULL,
  `status` enum('pending','approved','rejected','paid') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `settings` (
  `k` varchar(80) NOT NULL,
  `v` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `settings` (`k`, `v`) VALUES
('bank_account_name', ''),
('bank_account_no', ''),
('bank_id', ''),
('captcha_enabled', '1'),
('captcha_login_enabled', '0'),
('comment_spam_enabled', '1'),
('comment_spam_keywords', ''),
('google_login_enabled', '0'),
('maintenance_enabled', '0'),
('popup_enabled', '1'),
('ref_event_enabled', '0'),
('topup_enabled', '1'),
('topup_min_amount', '10000'),
('topup_prefix', 'NAP'),
('vietqr_template', 'compact2');

CREATE TABLE `topup_requests` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `code` varchar(30) NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `pay_note` varchar(80) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `admin_note` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `approved_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `topup_requests` (`id`, `user_id`, `code`, `amount`, `pay_note`, `status`, `admin_note`, `created_at`, `approved_at`) VALUES
(1, 4, 'TP8GKPSDDN', 50000.00, 'NAP TP8GKPSDDN', 'pending', NULL, '2026-01-25 07:52:51', NULL);

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `username` varchar(60) DEFAULT NULL,
  `email` varchar(190) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `avatar_url` varchar(255) DEFAULT NULL,
  `bank_name` varchar(80) DEFAULT NULL,
  `bank_owner` varchar(120) DEFAULT NULL,
  `bank_account` varchar(60) DEFAULT NULL,
  `ref_code` varchar(20) NOT NULL,
  `referred_by` int(11) DEFAULT NULL,
  `referred_at` datetime DEFAULT NULL,
  `google_id` varchar(120) DEFAULT NULL,
  `is_admin` tinyint(4) NOT NULL DEFAULT 0,
  `role` enum('user','mod','admin') NOT NULL DEFAULT 'user',
  `mod_order_limit` int(11) NOT NULL DEFAULT 0,
  `mod_topup_limit` int(11) NOT NULL DEFAULT 0,
  `points` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` (`id`, `name`, `username`, `email`, `password_hash`, `phone`, `avatar_url`, `bank_name`, `bank_owner`, `bank_account`, `ref_code`, `referred_by`, `referred_at`, `google_id`, `is_admin`, `role`, `mod_order_limit`, `mod_topup_limit`, `points`, `created_at`) VALUES
(1, 'Admin', 'admin', 'admin@test.com', '$2y$10$F7cjdp3lwaS7ZTh4f8gnXeNop8CbySGMs2zrZhcsItchtoP//Xyq2', '0900000001', NULL, NULL, NULL, NULL, 'ADMIN01', NULL, NULL, NULL, 1, 'admin', 0, 0, 0, '2026-01-25 07:24:27'),
(2, 'Moderator', 'mod', 'mod@test.com', '$2y$10$nqIj.7T/lto5uHVHkCI7YulwElwxOgzpHua.ph6vbzfwXT1IeHIDm', '0900000002', NULL, NULL, NULL, NULL, 'MOD0002', NULL, NULL, NULL, 0, 'mod', 200000, 500000, 0, '2026-01-25 07:24:27'),
(3, 'User Test', 'user1', 'user@test.com', '$2y$10$oJyNctIqTE.ssEG8uyMqnO6d/oazFMxTB3Gj63NT6Mmzr0GGEpfs2', '0900000003', NULL, NULL, NULL, NULL, 'USR0003', NULL, NULL, NULL, 0, 'user', 0, 0, 0, '2026-01-25 07:24:27'),
(4, 'Nguyen The Anh', NULL, 'nta.anh1995@gmail.com', '$2y$10$g3cRehd59H0.V8AFPOQGvuuVwPi4apQKL0l9Nl8nipYXF9SL72Apa', '0969226075', NULL, NULL, NULL, NULL, 'f12164cdff', NULL, '2026-01-25 07:28:35', NULL, 0, 'user', 0, 0, 0, '2026-01-25 07:28:35');

CREATE TABLE `wallets` (
  `user_id` int(11) NOT NULL,
  `balance` decimal(14,2) NOT NULL DEFAULT 0.00,
  `processing` decimal(14,2) NOT NULL DEFAULT 0.00,
  `total_withdrawn` decimal(14,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `wallets` (`user_id`, `balance`, `processing`, `total_withdrawn`) VALUES
(1, 0.00, 0.00, 0.00),
(2, 0.00, 0.00, 0.00),
(3, 0.00, 0.00, 0.00),
(4, 0.00, 0.00, 0.00);

CREATE TABLE `wallet_transactions` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(40) NOT NULL,
  `ref_table` varchar(40) DEFAULT NULL,
  `ref_id` bigint(20) DEFAULT NULL,
  `amount` decimal(14,2) NOT NULL,
  `balance_after` decimal(14,2) NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `withdraw_requests` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(14,2) NOT NULL,
  `status` enum('pending','approved','rejected','paid') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `admin_audit_logs` ADD PRIMARY KEY (`id`);
-- Safe alter add index: admin_audit_logs.idx_admin_time
SET @sql_safe_add_idx_1 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'admin_audit_logs'
        AND INDEX_NAME = 'idx_admin_time'
    ),
    'DO 1;',
    'ALTER TABLE `admin_audit_logs` ADD KEY `idx_admin_time` (`admin_id`,`id`);'
  )
);
PREPARE st_safe_add_idx_1 FROM @sql_safe_add_idx_1;
EXECUTE st_safe_add_idx_1;
DEALLOCATE PREPARE st_safe_add_idx_1;
ALTER TABLE `announcements` ADD PRIMARY KEY (`id`);

ALTER TABLE `banners` ADD PRIMARY KEY (`id`);

ALTER TABLE `checkins` ADD PRIMARY KEY (`id`);
-- Safe alter add index: checkins.uniq_user_date
SET @sql_alter_add_idx_1 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'checkins'
        AND INDEX_NAME = 'uniq_user_date'
    ),
    'DO 1;',
    'ALTER TABLE `checkins` ADD UNIQUE KEY `uniq_user_date` (`user_id`,`checkin_date`);'
  )
);
PREPARE st_alter_add_idx_1 FROM @sql_alter_add_idx_1;
EXECUTE st_alter_add_idx_1;
DEALLOCATE PREPARE st_alter_add_idx_1;
-- Safe alter add index: checkins.idx_user
SET @sql_safe_add_idx_2 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'checkins'
        AND INDEX_NAME = 'idx_user'
    ),
    'DO 1;',
    'ALTER TABLE `checkins` ADD KEY `idx_user` (`user_id`);'
  )
);
PREPARE st_safe_add_idx_2 FROM @sql_safe_add_idx_2;
EXECUTE st_safe_add_idx_2;
DEALLOCATE PREPARE st_safe_add_idx_2;
ALTER TABLE `checkin_rewards` ADD PRIMARY KEY (`id`);
-- Safe alter add index: checkin_rewards.uniq_day
SET @sql_safe_add_idx_3 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'checkin_rewards'
        AND INDEX_NAME = 'uniq_day'
    ),
    'DO 1;',
    'ALTER TABLE `checkin_rewards` ADD UNIQUE KEY `uniq_day` (`day_index`);'
  )
);
PREPARE st_safe_add_idx_3 FROM @sql_safe_add_idx_3;
EXECUTE st_safe_add_idx_3;
DEALLOCATE PREPARE st_safe_add_idx_3;
ALTER TABLE `community_comments` ADD PRIMARY KEY (`id`);
-- Safe alter add index: community_comments.idx_post
SET @sql_alter_add_idx_2 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'community_comments'
        AND INDEX_NAME = 'idx_post'
    ),
    'DO 1;',
    'ALTER TABLE `community_comments` ADD KEY `idx_post` (`post_id`);'
  )
);
PREPARE st_alter_add_idx_2 FROM @sql_alter_add_idx_2;
EXECUTE st_alter_add_idx_2;
DEALLOCATE PREPARE st_alter_add_idx_2;
-- Safe alter add index: community_comments.idx_user
SET @sql_safe_add_idx_4 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'community_comments'
        AND INDEX_NAME = 'idx_user'
    ),
    'DO 1;',
    'ALTER TABLE `community_comments` ADD KEY `idx_user` (`user_id`);'
  )
);
PREPARE st_safe_add_idx_4 FROM @sql_safe_add_idx_4;
EXECUTE st_safe_add_idx_4;
DEALLOCATE PREPARE st_safe_add_idx_4;
ALTER TABLE `community_links` ADD PRIMARY KEY (`id`);

ALTER TABLE `community_posts` ADD PRIMARY KEY (`id`);
-- Safe alter add index: community_posts.idx_user_time
SET @sql_safe_add_idx_5 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'community_posts'
        AND INDEX_NAME = 'idx_user_time'
    ),
    'DO 1;',
    'ALTER TABLE `community_posts` ADD KEY `idx_user_time` (`user_id`,`id`);'
  )
);
PREPARE st_safe_add_idx_5 FROM @sql_safe_add_idx_5;
EXECUTE st_safe_add_idx_5;
DEALLOCATE PREPARE st_safe_add_idx_5;
ALTER TABLE `community_post_tags` ADD PRIMARY KEY (`post_id`,`tag_id`);
-- Safe alter add index: community_post_tags.idx_tag
SET @sql_safe_add_idx_6 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'community_post_tags'
        AND INDEX_NAME = 'idx_tag'
    ),
    'DO 1;',
    'ALTER TABLE `community_post_tags` ADD KEY `idx_tag` (`tag_id`);'
  )
);
PREPARE st_safe_add_idx_6 FROM @sql_safe_add_idx_6;
EXECUTE st_safe_add_idx_6;
DEALLOCATE PREPARE st_safe_add_idx_6;
ALTER TABLE `community_tags` ADD PRIMARY KEY (`id`);
-- Safe alter add index: community_tags.uniq_slug
SET @sql_safe_add_idx_7 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'community_tags'
        AND INDEX_NAME = 'uniq_slug'
    ),
    'DO 1;',
    'ALTER TABLE `community_tags` ADD UNIQUE KEY `uniq_slug` (`slug`);'
  )
);
PREPARE st_safe_add_idx_7 FROM @sql_safe_add_idx_7;
EXECUTE st_safe_add_idx_7;
DEALLOCATE PREPARE st_safe_add_idx_7;
ALTER TABLE `contacts` ADD PRIMARY KEY (`id`);

ALTER TABLE `missions` ADD PRIMARY KEY (`id`);

ALTER TABLE `mission_claims` ADD PRIMARY KEY (`id`);
-- Safe alter add index: mission_claims.uniq_mission_user
SET @sql_alter_add_idx_3 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'mission_claims'
        AND INDEX_NAME = 'uniq_mission_user'
    ),
    'DO 1;',
    'ALTER TABLE `mission_claims` ADD UNIQUE KEY `uniq_mission_user` (`mission_id`,`user_id`);'
  )
);
PREPARE st_alter_add_idx_3 FROM @sql_alter_add_idx_3;
EXECUTE st_alter_add_idx_3;
DEALLOCATE PREPARE st_alter_add_idx_3;
-- Safe alter add index: mission_claims.idx_user
SET @sql_safe_add_idx_8 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'mission_claims'
        AND INDEX_NAME = 'idx_user'
    ),
    'DO 1;',
    'ALTER TABLE `mission_claims` ADD KEY `idx_user` (`user_id`);'
  )
);
PREPARE st_safe_add_idx_8 FROM @sql_safe_add_idx_8;
EXECUTE st_safe_add_idx_8;
DEALLOCATE PREPARE st_safe_add_idx_8;
ALTER TABLE `notifications` ADD PRIMARY KEY (`id`);
-- Safe alter add index: notifications.idx_user_time
SET @sql_safe_add_idx_9 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'notifications'
        AND INDEX_NAME = 'idx_user_time'
    ),
    'DO 1;',
    'ALTER TABLE `notifications` ADD KEY `idx_user_time` (`user_id`,`id`);'
  )
);
PREPARE st_safe_add_idx_9 FROM @sql_safe_add_idx_9;
EXECUTE st_safe_add_idx_9;
DEALLOCATE PREPARE st_safe_add_idx_9;
ALTER TABLE `notification_reads` ADD PRIMARY KEY (`user_id`,`notification_id`);
-- Safe alter add index: notification_reads.idx_n
SET @sql_safe_add_idx_10 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'notification_reads'
        AND INDEX_NAME = 'idx_n'
    ),
    'DO 1;',
    'ALTER TABLE `notification_reads` ADD KEY `idx_n` (`notification_id`);'
  )
);
PREPARE st_safe_add_idx_10 FROM @sql_safe_add_idx_10;
EXECUTE st_safe_add_idx_10;
DEALLOCATE PREPARE st_safe_add_idx_10;
ALTER TABLE `orders` ADD PRIMARY KEY (`id`);
-- Safe alter add index: orders.uniq_order_code
SET @sql_alter_add_idx_4 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'orders'
        AND INDEX_NAME = 'uniq_order_code'
    ),
    'DO 1;',
    'ALTER TABLE `orders` ADD UNIQUE KEY `uniq_order_code` (`order_code`);'
  )
);
PREPARE st_alter_add_idx_4 FROM @sql_alter_add_idx_4;
EXECUTE st_alter_add_idx_4;
DEALLOCATE PREPARE st_alter_add_idx_4;
-- Safe alter add index: orders.idx_user_time
SET @sql_safe_add_idx_11 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'orders'
        AND INDEX_NAME = 'idx_user_time'
    ),
    'DO 1;',
    'ALTER TABLE `orders` ADD KEY `idx_user_time` (`user_id`,`id`);'
  )
);
PREPARE st_safe_add_idx_11 FROM @sql_safe_add_idx_11;
EXECUTE st_safe_add_idx_11;
DEALLOCATE PREPARE st_safe_add_idx_11;
ALTER TABLE `point_transactions` ADD PRIMARY KEY (`id`);
-- Safe alter add index: point_transactions.uniq_user_type_ref
SET @sql_alter_add_idx_5 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'point_transactions'
        AND INDEX_NAME = 'uniq_user_type_ref'
    ),
    'DO 1;',
    'ALTER TABLE `point_transactions` ADD UNIQUE KEY `uniq_user_type_ref` (`user_id`,`type`,`ref_key`);'
  )
);
PREPARE st_alter_add_idx_5 FROM @sql_alter_add_idx_5;
EXECUTE st_alter_add_idx_5;
DEALLOCATE PREPARE st_alter_add_idx_5;
-- Safe alter add index: point_transactions.idx_user
SET @sql_safe_add_idx_12 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'point_transactions'
        AND INDEX_NAME = 'idx_user'
    ),
    'DO 1;',
    'ALTER TABLE `point_transactions` ADD KEY `idx_user` (`user_id`);'
  )
);
PREPARE st_safe_add_idx_12 FROM @sql_safe_add_idx_12;
EXECUTE st_safe_add_idx_12;
DEALLOCATE PREPARE st_safe_add_idx_12;
ALTER TABLE `popups` ADD PRIMARY KEY (`id`);

ALTER TABLE `ranks` ADD PRIMARY KEY (`id`);
-- Safe alter add index: ranks.uniq_slug
SET @sql_safe_add_idx_13 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'ranks'
        AND INDEX_NAME = 'uniq_slug'
    ),
    'DO 1;',
    'ALTER TABLE `ranks` ADD UNIQUE KEY `uniq_slug` (`slug`);'
  )
);
PREPARE st_safe_add_idx_13 FROM @sql_safe_add_idx_13;
EXECUTE st_safe_add_idx_13;
DEALLOCATE PREPARE st_safe_add_idx_13;
ALTER TABLE `referrals` ADD PRIMARY KEY (`id`);
-- Safe alter add index: referrals.uniq_pair
SET @sql_alter_add_idx_6 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'referrals'
        AND INDEX_NAME = 'uniq_pair'
    ),
    'DO 1;',
    'ALTER TABLE `referrals` ADD UNIQUE KEY `uniq_pair` (`referrer_id`,`referee_id`);'
  )
);
PREPARE st_alter_add_idx_6 FROM @sql_alter_add_idx_6;
EXECUTE st_alter_add_idx_6;
DEALLOCATE PREPARE st_alter_add_idx_6;-- Safe alter add index: referrals.idx_referrer
SET @sql_alter_add_idx_7 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'referrals'
        AND INDEX_NAME = 'idx_referrer'
    ),
    'DO 1;',
    'ALTER TABLE `referrals` ADD KEY `idx_referrer` (`referrer_id`);'
  )
);
PREPARE st_alter_add_idx_7 FROM @sql_alter_add_idx_7;
EXECUTE st_alter_add_idx_7;
DEALLOCATE PREPARE st_alter_add_idx_7;
-- Safe alter add index: referrals.idx_referee
SET @sql_safe_add_idx_14 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'referrals'
        AND INDEX_NAME = 'idx_referee'
    ),
    'DO 1;',
    'ALTER TABLE `referrals` ADD KEY `idx_referee` (`referee_id`);'
  )
);
PREPARE st_safe_add_idx_14 FROM @sql_safe_add_idx_14;
EXECUTE st_safe_add_idx_14;
DEALLOCATE PREPARE st_safe_add_idx_14;
ALTER TABLE `rewards` ADD PRIMARY KEY (`id`);

ALTER TABLE `reward_redemptions` ADD PRIMARY KEY (`id`);
-- Safe alter add index: reward_redemptions.idx_user_time
SET @sql_alter_add_idx_8 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'reward_redemptions'
        AND INDEX_NAME = 'idx_user_time'
    ),
    'DO 1;',
    'ALTER TABLE `reward_redemptions` ADD KEY `idx_user_time` (`user_id`,`id`);'
  )
);
PREPARE st_alter_add_idx_8 FROM @sql_alter_add_idx_8;
EXECUTE st_alter_add_idx_8;
DEALLOCATE PREPARE st_alter_add_idx_8;
-- Safe alter add index: reward_redemptions.fk_rr_r
SET @sql_safe_add_idx_15 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'reward_redemptions'
        AND INDEX_NAME = 'fk_rr_r'
    ),
    'DO 1;',
    'ALTER TABLE `reward_redemptions` ADD KEY `fk_rr_r` (`reward_id`);'
  )
);
PREPARE st_safe_add_idx_15 FROM @sql_safe_add_idx_15;
EXECUTE st_safe_add_idx_15;
DEALLOCATE PREPARE st_safe_add_idx_15;
ALTER TABLE `settings` ADD PRIMARY KEY (`k`);

ALTER TABLE `topup_requests` ADD PRIMARY KEY (`id`);
-- Safe alter add index: topup_requests.uniq_code
SET @sql_alter_add_idx_9 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'topup_requests'
        AND INDEX_NAME = 'uniq_code'
    ),
    'DO 1;',
    'ALTER TABLE `topup_requests` ADD UNIQUE KEY `uniq_code` (`code`);'
  )
);
PREPARE st_alter_add_idx_9 FROM @sql_alter_add_idx_9;
EXECUTE st_alter_add_idx_9;
DEALLOCATE PREPARE st_alter_add_idx_9;
-- Safe alter add index: topup_requests.idx_user_time
SET @sql_safe_add_idx_16 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'topup_requests'
        AND INDEX_NAME = 'idx_user_time'
    ),
    'DO 1;',
    'ALTER TABLE `topup_requests` ADD KEY `idx_user_time` (`user_id`,`id`);'
  )
);
PREPARE st_safe_add_idx_16 FROM @sql_safe_add_idx_16;
EXECUTE st_safe_add_idx_16;
DEALLOCATE PREPARE st_safe_add_idx_16;
ALTER TABLE `users` ADD PRIMARY KEY (`id`);
-- Safe alter add index: users.uniq_email
SET @sql_alter_add_idx_10 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND INDEX_NAME = 'uniq_email'
    ),
    'DO 1;',
    'ALTER TABLE `users` ADD UNIQUE KEY `uniq_email` (`email`);'
  )
);
PREPARE st_alter_add_idx_10 FROM @sql_alter_add_idx_10;
EXECUTE st_alter_add_idx_10;
DEALLOCATE PREPARE st_alter_add_idx_10;-- Safe alter add index: users.uniq_ref_code
SET @sql_alter_add_idx_11 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND INDEX_NAME = 'uniq_ref_code'
    ),
    'DO 1;',
    'ALTER TABLE `users` ADD UNIQUE KEY `uniq_ref_code` (`ref_code`);'
  )
);
PREPARE st_alter_add_idx_11 FROM @sql_alter_add_idx_11;
EXECUTE st_alter_add_idx_11;
DEALLOCATE PREPARE st_alter_add_idx_11;-- Safe alter add index: users.uniq_google_id
SET @sql_alter_add_idx_12 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND INDEX_NAME = 'uniq_google_id'
    ),
    'DO 1;',
    'ALTER TABLE `users` ADD UNIQUE KEY `uniq_google_id` (`google_id`);'
  )
);
PREPARE st_alter_add_idx_12 FROM @sql_alter_add_idx_12;
EXECUTE st_alter_add_idx_12;
DEALLOCATE PREPARE st_alter_add_idx_12;-- Safe alter add index: users.uniq_username
SET @sql_alter_add_idx_13 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND INDEX_NAME = 'uniq_username'
    ),
    'DO 1;',
    'ALTER TABLE `users` ADD UNIQUE KEY `uniq_username` (`username`);'
  )
);
PREPARE st_alter_add_idx_13 FROM @sql_alter_add_idx_13;
EXECUTE st_alter_add_idx_13;
DEALLOCATE PREPARE st_alter_add_idx_13;
-- Safe alter add index: users.idx_referred_by
SET @sql_safe_add_idx_17 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND INDEX_NAME = 'idx_referred_by'
    ),
    'DO 1;',
    'ALTER TABLE `users` ADD KEY `idx_referred_by` (`referred_by`);'
  )
);
PREPARE st_safe_add_idx_17 FROM @sql_safe_add_idx_17;
EXECUTE st_safe_add_idx_17;
DEALLOCATE PREPARE st_safe_add_idx_17;
ALTER TABLE `wallets` ADD PRIMARY KEY (`user_id`);

ALTER TABLE `wallet_transactions` ADD PRIMARY KEY (`id`);
-- Safe alter add index: wallet_transactions.idx_user_time
SET @sql_alter_add_idx_14 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'wallet_transactions'
        AND INDEX_NAME = 'idx_user_time'
    ),
    'DO 1;',
    'ALTER TABLE `wallet_transactions` ADD KEY `idx_user_time` (`user_id`,`id`);'
  )
);
PREPARE st_alter_add_idx_14 FROM @sql_alter_add_idx_14;
EXECUTE st_alter_add_idx_14;
DEALLOCATE PREPARE st_alter_add_idx_14;
-- Safe alter add index: wallet_transactions.idx_ref
SET @sql_safe_add_idx_18 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'wallet_transactions'
        AND INDEX_NAME = 'idx_ref'
    ),
    'DO 1;',
    'ALTER TABLE `wallet_transactions` ADD KEY `idx_ref` (`ref_table`,`ref_id`);'
  )
);
PREPARE st_safe_add_idx_18 FROM @sql_safe_add_idx_18;
EXECUTE st_safe_add_idx_18;
DEALLOCATE PREPARE st_safe_add_idx_18;
ALTER TABLE `withdraw_requests` ADD PRIMARY KEY (`id`);
-- Safe alter add index: withdraw_requests.idx_user_time
SET @sql_safe_add_idx_19 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'withdraw_requests'
        AND INDEX_NAME = 'idx_user_time'
    ),
    'DO 1;',
    'ALTER TABLE `withdraw_requests` ADD KEY `idx_user_time` (`user_id`,`id`);'
  )
);
PREPARE st_safe_add_idx_19 FROM @sql_safe_add_idx_19;
EXECUTE st_safe_add_idx_19;
DEALLOCATE PREPARE st_safe_add_idx_19;
ALTER TABLE `admin_audit_logs`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `banners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `checkins`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

ALTER TABLE `checkin_rewards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

ALTER TABLE `community_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `community_links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `community_posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `community_tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `missions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `mission_claims`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

ALTER TABLE `notifications`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

ALTER TABLE `orders`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

ALTER TABLE `point_transactions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

ALTER TABLE `popups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `ranks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `referrals`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

ALTER TABLE `rewards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `reward_redemptions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

ALTER TABLE `topup_requests`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

ALTER TABLE `wallet_transactions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

ALTER TABLE `withdraw_requests`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

ALTER TABLE `admin_audit_logs` ADD CONSTRAINT `fk_audit_user` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

ALTER TABLE `checkins` ADD CONSTRAINT `fk_chk_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

ALTER TABLE `community_comments` ADD CONSTRAINT `fk_cc_p` FOREIGN KEY (`post_id`) REFERENCES `community_posts` (`id`) ON DELETE CASCADE;

ALTER TABLE `community_comments` ADD CONSTRAINT `fk_cc_u` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

ALTER TABLE `community_posts` ADD CONSTRAINT `fk_cp_u` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

ALTER TABLE `community_post_tags` ADD CONSTRAINT `fk_cpt_p` FOREIGN KEY (`post_id`) REFERENCES `community_posts` (`id`) ON DELETE CASCADE;

ALTER TABLE `community_post_tags` ADD CONSTRAINT `fk_cpt_t` FOREIGN KEY (`tag_id`) REFERENCES `community_tags` (`id`) ON DELETE CASCADE;

ALTER TABLE `mission_claims` ADD CONSTRAINT `fk_mc_m` FOREIGN KEY (`mission_id`) REFERENCES `missions` (`id`) ON DELETE CASCADE;

ALTER TABLE `mission_claims` ADD CONSTRAINT `fk_mc_u` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

ALTER TABLE `notifications` ADD CONSTRAINT `fk_n_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

ALTER TABLE `notification_reads` ADD CONSTRAINT `fk_nr_n` FOREIGN KEY (`notification_id`) REFERENCES `notifications` (`id`) ON DELETE CASCADE;

ALTER TABLE `notification_reads` ADD CONSTRAINT `fk_nr_u` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

ALTER TABLE `orders` ADD CONSTRAINT `fk_order_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

ALTER TABLE `point_transactions` ADD CONSTRAINT `fk_pt_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

ALTER TABLE `referrals` ADD CONSTRAINT `fk_referee` FOREIGN KEY (`referee_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

ALTER TABLE `referrals` ADD CONSTRAINT `fk_referrer` FOREIGN KEY (`referrer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

ALTER TABLE `reward_redemptions` ADD CONSTRAINT `fk_rr_r` FOREIGN KEY (`reward_id`) REFERENCES `rewards` (`id`) ON DELETE CASCADE;

ALTER TABLE `reward_redemptions` ADD CONSTRAINT `fk_rr_u` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

ALTER TABLE `topup_requests` ADD CONSTRAINT `fk_topup_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

ALTER TABLE `users` ADD CONSTRAINT `fk_referred_by` FOREIGN KEY (`referred_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

ALTER TABLE `wallets` ADD CONSTRAINT `fk_wallet_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

ALTER TABLE `wallet_transactions` ADD CONSTRAINT `fk_wt_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

ALTER TABLE `withdraw_requests` ADD CONSTRAINT `fk_wd_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

-- Feature tables (CREATE first)

CREATE TABLE IF NOT EXISTS shop_products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL,
    category VARCHAR(32) NOT NULL DEFAULT 'game_key',
    icon VARCHAR(80) NULL,
    image_url TEXT NULL,
    price_vnd INT NOT NULL DEFAULT 0,
    points_price INT NOT NULL DEFAULT 0,
    description TEXT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX(slug),
    INDEX(category),
    INDEX(is_active)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS product_prices (
        id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        audience_type ENUM('rank','vip') NOT NULL,
        audience_value VARCHAR(64) NULL,
        price_vnd INT NOT NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NULL,
        UNIQUE KEY uq_price (product_id, audience_type, audience_value),
        INDEX idx_prod (product_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS shop_keys (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    key_code TEXT NOT NULL,
    is_sold TINYINT(1) NOT NULL DEFAULT 0,
    sold_to INT NULL,
    sold_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX(product_id),
    INDEX(is_sold),
    INDEX(sold_to)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS shop_orders (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_code VARCHAR(60) NOT NULL,
    request_token VARCHAR(80) NULL,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    key_id BIGINT NOT NULL,
    pay_method ENUM('wallet','points') NOT NULL,
    amount_vnd INT NOT NULL DEFAULT 0,
    points INT NOT NULL DEFAULT 0,
    status ENUM('delivered','revoked') NOT NULL DEFAULT 'delivered',
    activated_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_order_code(order_code),
    UNIQUE KEY uq_request_token(request_token),
    UNIQUE KEY uq_key_id(key_id),
    INDEX(user_id),
    INDEX(product_id),
    INDEX(pay_method)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS shop_user_keys (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    key_id BIGINT NOT NULL,
    order_id BIGINT NULL,
    activated_at DATETIME NULL,
    gift_link_id INT NULL,
    gifted_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_key_user(key_id),
    INDEX(user_id),
    INDEX(product_id),
    INDEX(order_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS coupons (
      id INT AUTO_INCREMENT PRIMARY KEY,
      code VARCHAR(64) NOT NULL,
      reward_type ENUM('wallet','points') NOT NULL DEFAULT 'points',
      reward_amount INT NOT NULL DEFAULT 0,
      max_uses INT NULL,
      per_user_once TINYINT(1) NOT NULL DEFAULT 1,
      expires_at DATETIME NULL,
      is_active TINYINT(1) NOT NULL DEFAULT 1,
      note VARCHAR(255) NULL,
      created_by INT NULL,
      created_at DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS coupon_redemptions (
      id INT AUTO_INCREMENT PRIMARY KEY,
      coupon_id INT NOT NULL,
      user_id INT NOT NULL,
      reward_type ENUM('wallet','points') NOT NULL,
      reward_amount INT NOT NULL,
      created_at DATETIME NOT NULL,
      request_token VARCHAR(64) NULL,
      ip VARCHAR(64) NULL,
      ua VARCHAR(250) NULL,
      UNIQUE KEY uq_redemp_req (request_token),
      INDEX idx_coupon_user (coupon_id,user_id),
      CONSTRAINT fk_coupon_redemptions_coupon FOREIGN KEY (coupon_id) REFERENCES coupons(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS vip_plans(
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(80) NOT NULL,
      price_vnd INT NOT NULL DEFAULT 0,
      duration_days INT NOT NULL DEFAULT 30,
      discount_pct INT NOT NULL DEFAULT 0,
      points_bonus_pct INT NOT NULL DEFAULT 0,
      is_active TINYINT(1) NOT NULL DEFAULT 1,
      created_at DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_vip(
      user_id INT PRIMARY KEY,
      plan_id INT NOT NULL,
      expires_at DATETIME NOT NULL,
      updated_at DATETIME NOT NULL,
      CONSTRAINT fk_user_vip_plan FOREIGN KEY(plan_id) REFERENCES vip_plans(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS vip_orders(
        id INT AUTO_INCREMENT PRIMARY KEY,
        request_token VARCHAR(64) NULL,
        user_id INT NOT NULL,
        plan_id INT NOT NULL,
        amount_vnd INT NOT NULL,
        created_at DATETIME NOT NULL,
        UNIQUE KEY uq_vip_req(request_token)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS flash_sales(
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(120) NOT NULL,
      category VARCHAR(32) NULL,
      discount_pct INT NOT NULL DEFAULT 0,
      starts_at DATETIME NOT NULL,
      ends_at DATETIME NOT NULL,
      is_active TINYINT(1) NOT NULL DEFAULT 1,
      created_at DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS spin_logs(
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      reward_type ENUM('points','coupon') NOT NULL DEFAULT 'points',
      reward_value VARCHAR(120) NOT NULL,
      is_free TINYINT(1) NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL,
      ip VARCHAR(64) NULL,
      ua VARCHAR(250) NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS lootbox_logs(
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      tier VARCHAR(16) NOT NULL,
      product_id INT NOT NULL,
      key_id INT NOT NULL,
      pay_method ENUM('wallet','points') NOT NULL,
      amount_vnd INT NOT NULL DEFAULT 0,
      points INT NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL,
      ip VARCHAR(64) NULL,
      ua VARCHAR(250) NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS referral_rewards(
      id INT AUTO_INCREMENT PRIMARY KEY,
      referrer_id INT NOT NULL,
      referred_id INT NOT NULL,
      reward_points INT NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL,
      UNIQUE KEY uq_referred (referred_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS rate_limits (
        k VARCHAR(120) PRIMARY KEY,
        cnt INT NOT NULL DEFAULT 0,
        reset_at DATETIME NOT NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS community_edits (
        id INT AUTO_INCREMENT PRIMARY KEY,
        post_id INT NOT NULL,
        editor_id INT NOT NULL,
        old_title VARCHAR(255) NULL,
        old_content MEDIUMTEXT NULL,
        note VARCHAR(255) NULL,
        created_at DATETIME NOT NULL,
        INDEX idx_post (post_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS support_tickets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        type VARCHAR(40) NOT NULL,
        order_id INT NULL,
        key_id INT NULL,
        subject VARCHAR(255) NULL,
        content MEDIUMTEXT NOT NULL,
        status ENUM('open','in_progress','resolved','rejected') NOT NULL DEFAULT 'open',
        staff_note VARCHAR(255) NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NULL,
        INDEX idx_user (user_id),
        INDEX idx_status (status)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS security_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NULL,
        type VARCHAR(40) NOT NULL,
        ip VARCHAR(64) NULL,
        ua VARCHAR(255) NULL,
        details MEDIUMTEXT NULL,
        created_at DATETIME NOT NULL,
        INDEX idx_user (user_id),
        INDEX idx_type (type),
        INDEX idx_ip (ip),
        INDEX idx_created (created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS risk_flags (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NULL,
        ip VARCHAR(64) NULL,
        type VARCHAR(40) NOT NULL,
        score INT NOT NULL DEFAULT 1,
        reason VARCHAR(255) NULL,
        meta MEDIUMTEXT NULL,
        status ENUM('open','resolved') NOT NULL DEFAULT 'open',
        created_at DATETIME NOT NULL,
        updated_at DATETIME NULL,
        INDEX idx_user (user_id),
        INDEX idx_ip (ip),
        INDEX idx_type (type),
        INDEX idx_status (status)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ip_blocks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        ip VARCHAR(64) NOT NULL,
        reason VARCHAR(255) NULL,
        hits INT NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL,
        expires_at DATETIME NULL,
        created_by INT NULL,
        UNIQUE KEY uq_ip (ip),
        INDEX idx_exp (expires_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS badges (
        id INT AUTO_INCREMENT PRIMARY KEY,
        code VARCHAR(60) NOT NULL,
        name VARCHAR(120) NOT NULL,
        icon VARCHAR(60) NOT NULL DEFAULT 'award',
        rarity ENUM('common','rare','epic','legend') NOT NULL DEFAULT 'common',
        description VARCHAR(255) NULL,
        title VARCHAR(60) NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        sort INT NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL,
        UNIQUE KEY uq_code (code),
        INDEX idx_active (is_active),
        INDEX idx_sort (sort)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_badges (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        badge_id INT NOT NULL,
        earned_at DATETIME NOT NULL,
        meta MEDIUMTEXT NULL,
        UNIQUE KEY uq_user_badge (user_id, badge_id),
        INDEX idx_user (user_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_wishlist (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        product_id INT NOT NULL,
        created_at DATETIME NOT NULL,
        UNIQUE KEY uq_wish (user_id, product_id),
        INDEX idx_user (user_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS product_reviews (
        id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        user_id INT NOT NULL,
        rating TINYINT NOT NULL,
        content TEXT NULL,
        status ENUM('pending','approved','hidden') NOT NULL DEFAULT 'pending',
        created_at DATETIME NOT NULL,
        updated_at DATETIME NULL,
        UNIQUE KEY uq_user_product (user_id, product_id),
        INDEX idx_product (product_id),
        INDEX idx_status (status),
        INDEX idx_created (created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS level_titles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        level_required INT NOT NULL,
        title VARCHAR(60) NOT NULL,
        sort INT NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at DATETIME NOT NULL,
        UNIQUE KEY uq_level_title (level_required, title),
        INDEX idx_level (level_required),
        INDEX idx_active (is_active)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_showcase (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        product_id INT NOT NULL,
        sort INT NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL,
        UNIQUE KEY uq_user_product (user_id, product_id),
        INDEX idx_user (user_id),
        INDEX idx_sort (sort)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS gift_links (
        id INT AUTO_INCREMENT PRIMARY KEY,
        token VARCHAR(80) NOT NULL,
        from_user_id INT NOT NULL,
        user_key_id INT NOT NULL,
        status ENUM('active','claimed','revoked','expired') NOT NULL DEFAULT 'active',
        expires_at DATETIME NULL,
        claimed_by_user_id INT NULL,
        claimed_at DATETIME NULL,
        created_at DATETIME NOT NULL,
        UNIQUE KEY uq_token (token),
        UNIQUE KEY uq_key (user_key_id),
        INDEX idx_from (from_user_id),
        INDEX idx_status (status)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS app_links (
        id INT AUTO_INCREMENT PRIMARY KEY,
        token VARCHAR(80) NOT NULL,
        title VARCHAR(120) NOT NULL,
        platform VARCHAR(60) NULL,
        description TEXT NULL,
        cover_image TEXT NULL,
        images TEXT NULL,
        url TEXT NOT NULL,
        url_backup TEXT NULL,
        mode ENUM('once','forever') NOT NULL DEFAULT 'forever',
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        downloads INT NOT NULL DEFAULT 0,
        used_at DATETIME NULL,
        used_ip VARCHAR(45) NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NULL,
        UNIQUE KEY uq_token (token),
        INDEX idx_active (is_active),
        INDEX idx_mode (mode),
        INDEX idx_used (used_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS support_tickets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        type VARCHAR(30) NOT NULL DEFAULT 'general',
        order_id INT NULL,
        subject VARCHAR(200) NULL,
        status ENUM('open','pending','resolved','closed') NOT NULL DEFAULT 'open',
        staff_note TEXT NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NULL,
        INDEX idx_user (user_id),
        INDEX idx_status (status),
        INDEX idx_order (order_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS support_messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        ticket_id INT NOT NULL,
        sender_type ENUM('user','staff','system') NOT NULL DEFAULT 'user',
        sender_id INT NULL,
        content TEXT NOT NULL,
        attachments JSON NULL,
        created_at DATETIME NOT NULL,
        INDEX idx_ticket (ticket_id),
        INDEX idx_sender (sender_type, sender_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS vendor_wallets (
        vendor_id INT PRIMARY KEY,
        balance DECIMAL(14,2) NOT NULL DEFAULT 0,
        locked DECIMAL(14,2) NOT NULL DEFAULT 0,
        total_withdrawn DECIMAL(14,2) NOT NULL DEFAULT 0,
        updated_at DATETIME NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS vendor_transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        vendor_id INT NOT NULL,
        type VARCHAR(40) NOT NULL,
        amount DECIMAL(14,2) NOT NULL,
        ref_key VARCHAR(120) NULL,
        note VARCHAR(190) NULL,
        meta_json TEXT NULL,
        created_at DATETIME NOT NULL,
        INDEX idx_vendor (vendor_id),
        INDEX idx_ref (ref_key),
        INDEX idx_type (type)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS vendor_withdrawals (
        id INT AUTO_INCREMENT PRIMARY KEY,
        vendor_id INT NOT NULL,
        amount DECIMAL(14,2) NOT NULL,
        status ENUM('pending','approved','rejected','paid') NOT NULL DEFAULT 'pending',
        payout_note VARCHAR(190) NULL,
        created_at DATETIME NOT NULL,
        processed_by INT NULL,
        processed_at DATETIME NULL,
        INDEX idx_vendor (vendor_id),
        INDEX idx_status (status)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Indexes (safe)

-- Ensure vendor_id columns exist before creating vendor indexes
SET @t := 'shop_products';

SET @sql_v1 := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=@t),
    IF(
      EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=@t AND COLUMN_NAME='vendor_id'),
      'DO 1;',
      CONCAT('ALTER TABLE ', @t, ' ADD COLUMN vendor_id INT NULL;')
    ),
    'DO 1;'
  )
);

PREPARE st_v1 FROM @sql_v1;

EXECUTE st_v1;

DEALLOCATE PREPARE st_v1;

SET @t := 'shop_keys';

SET @sql_v2 := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=@t),
    IF(
      EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=@t AND COLUMN_NAME='vendor_id'),
      'DO 1;',
      CONCAT('ALTER TABLE ', @t, ' ADD COLUMN vendor_id INT NULL;')
    ),
    'DO 1;'
  )
);

PREPARE st_v2 FROM @sql_v2;

EXECUTE st_v2;

DEALLOCATE PREPARE st_v2;

SET @t := 'shop_orders';

SET @sql_v3 := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=@t),
    IF(
      EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=@t AND COLUMN_NAME='vendor_id'),
      'DO 1;',
      CONCAT('ALTER TABLE ', @t, ' ADD COLUMN vendor_id INT NULL;')
    ),
    'DO 1;'
  )
);

PREPARE st_v3 FROM @sql_v3;

EXECUTE st_v3;

DEALLOCATE PREPARE st_v3;

SET @t := 'app_links';

SET @sql_v4 := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=@t),
    IF(
      EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=@t AND COLUMN_NAME='vendor_id'),
      'DO 1;',
      CONCAT('ALTER TABLE ', @t, ' ADD COLUMN vendor_id INT NULL;')
    ),
    'DO 1;'
  )
);

PREPARE st_v4 FROM @sql_v4;

EXECUTE st_v4;

DEALLOCATE PREPARE st_v4;

-- Ensure column exists before creating indexes on it
SET @sql_col_key_hash := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_keys'
        AND COLUMN_NAME = 'key_hash'
    ),
    'DO 1;',
    'ALTER TABLE shop_keys ADD COLUMN key_hash CHAR(64) NULL AFTER key_code;'
  )
);

PREPARE st_col_key_hash FROM @sql_col_key_hash;

EXECUTE st_col_key_hash;

DEALLOCATE PREPARE st_col_key_hash;

-- Backfill hash for existing rows (safe if table empty)
UPDATE shop_keys
SET key_hash = SHA2(TRIM(key_code), 256)
WHERE key_hash IS NULL;

SET @sql_1 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_keys'
        AND INDEX_NAME = 'idx_key_hash'
    ),
    'DO 1;',
    'CREATE INDEX idx_key_hash ON shop_keys(key_hash);'
  )
);

PREPARE st_1 FROM @sql_1;

EXECUTE st_1;

DEALLOCATE PREPARE st_1;

SET @sql_2 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_keys'
        AND INDEX_NAME = 'uq_key_dedup'
    ),
    'DO 1;',
    'CREATE UNIQUE INDEX uq_key_dedup ON shop_keys(product_id, key_hash);'
  )
);

PREPARE st_2 FROM @sql_2;

EXECUTE st_2;

DEALLOCATE PREPARE st_2;

SET @sql_3 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'coupons'
        AND INDEX_NAME = 'uq_coupons_code'
    ),
    'DO 1;',
    'CREATE UNIQUE INDEX uq_coupons_code ON coupons(code);'
  )
);

PREPARE st_3 FROM @sql_3;

EXECUTE st_3;

DEALLOCATE PREPARE st_3;

SET @sql_4 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'spin_logs'
        AND INDEX_NAME = 'idx_spin_user'
    ),
    'DO 1;',
    'CREATE INDEX idx_spin_user ON spin_logs(user_id,id);'
  )
);

PREPARE st_4 FROM @sql_4;

EXECUTE st_4;

DEALLOCATE PREPARE st_4;

SET @sql_5 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'lootbox_logs'
        AND INDEX_NAME = 'idx_loot_user'
    ),
    'DO 1;',
    'CREATE INDEX idx_loot_user ON lootbox_logs(user_id,id);'
  )
);

PREPARE st_5 FROM @sql_5;

EXECUTE st_5;

DEALLOCATE PREPARE st_5;

SET @sql_6 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_products'
        AND INDEX_NAME = 'idx_vendor'
    ),
    'DO 1;',
    'CREATE INDEX idx_vendor ON shop_products(vendor_id);'
  )
);

PREPARE st_6 FROM @sql_6;

EXECUTE st_6;

DEALLOCATE PREPARE st_6;

SET @sql_7 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_keys'
        AND INDEX_NAME = 'idx_vendor'
    ),
    'DO 1;',
    'CREATE INDEX idx_vendor ON shop_keys(vendor_id);'
  )
);

PREPARE st_7 FROM @sql_7;

EXECUTE st_7;

DEALLOCATE PREPARE st_7;

SET @sql_8 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_orders'
        AND INDEX_NAME = 'idx_vendor'
    ),
    'DO 1;',
    'CREATE INDEX idx_vendor ON shop_orders(vendor_id);'
  )
);

PREPARE st_8 FROM @sql_8;

EXECUTE st_8;

DEALLOCATE PREPARE st_8;

SET @sql_9 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'app_links'
        AND INDEX_NAME = 'idx_vendor'
    ),
    'DO 1;',
    'CREATE INDEX idx_vendor ON app_links(vendor_id);'
  )
);

PREPARE st_9 FROM @sql_9;

EXECUTE st_9;

DEALLOCATE PREPARE st_9;

-- Alters (may already exist)

ALTER TABLE shop_products ADD COLUMN low_stock_threshold INT NOT NULL DEFAULT 10;

-- Safe add column: shop_products.low_stock_threshold
SET @sql_addcol_1 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_products'
        AND COLUMN_NAME = 'low_stock_threshold'
    ),
    'DO 1;',
    'ALTER TABLE shop_products ADD COLUMN low_stock_threshold INT NOT NULL DEFAULT 0;;'
  )
);
PREPARE st_addcol_1 FROM @sql_addcol_1;
EXECUTE st_addcol_1;
DEALLOCATE PREPARE st_addcol_1;

-- Safe add column: withdraw_requests.status
SET @sql_addcol_2 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'withdraw_requests'
        AND COLUMN_NAME = 'status'
    ),
    'DO 1;',
    "ALTER TABLE withdraw_requests ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'approved';;"
  )
);
PREPARE st_addcol_2 FROM @sql_addcol_2;
EXECUTE st_addcol_2;
DEALLOCATE PREPARE st_addcol_2;

-- Safe add column: withdraw_requests.evidence
SET @sql_addcol_3 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'withdraw_requests'
        AND COLUMN_NAME = 'evidence'
    ),
    'DO 1;',
    'ALTER TABLE withdraw_requests ADD COLUMN evidence TEXT NULL;;'
  )
);
PREPARE st_addcol_3 FROM @sql_addcol_3;
EXECUTE st_addcol_3;
DEALLOCATE PREPARE st_addcol_3;

-- Safe add column: withdraw_requests.reviewed_by
SET @sql_addcol_4 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'withdraw_requests'
        AND COLUMN_NAME = 'reviewed_by'
    ),
    'DO 1;',
    'ALTER TABLE withdraw_requests ADD COLUMN reviewed_by INT NULL;;'
  )
);
PREPARE st_addcol_4 FROM @sql_addcol_4;
EXECUTE st_addcol_4;
DEALLOCATE PREPARE st_addcol_4;

-- Safe add column: withdraw_requests.reviewed_at
SET @sql_addcol_5 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'withdraw_requests'
        AND COLUMN_NAME = 'reviewed_at'
    ),
    'DO 1;',
    'ALTER TABLE withdraw_requests ADD COLUMN reviewed_at DATETIME NULL;;'
  )
);
PREPARE st_addcol_5 FROM @sql_addcol_5;
EXECUTE st_addcol_5;
DEALLOCATE PREPARE st_addcol_5;

-- Safe add column: shop_keys.key_hash
SET @sql_addcol_6 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_keys'
        AND COLUMN_NAME = 'key_hash'
    ),
    'DO 1;',
    'ALTER TABLE shop_keys ADD COLUMN key_hash CHAR(64) NULL;;'
  )
);
PREPARE st_addcol_6 FROM @sql_addcol_6;
EXECUTE st_addcol_6;
DEALLOCATE PREPARE st_addcol_6;

-- Safe add column: shop_keys.is_disabled
SET @sql_addcol_7 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_keys'
        AND COLUMN_NAME = 'is_disabled'
    ),
    'DO 1;',
    'ALTER TABLE shop_keys ADD COLUMN is_disabled TINYINT(1) NOT NULL DEFAULT 0;;'
  )
);
PREPARE st_addcol_7 FROM @sql_addcol_7;
EXECUTE st_addcol_7;
DEALLOCATE PREPARE st_addcol_7;

-- Safe add column: shop_keys.is_activated
SET @sql_addcol_8 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_keys'
        AND COLUMN_NAME = 'is_activated'
    ),
    'DO 1;',
    'ALTER TABLE shop_keys ADD COLUMN is_activated TINYINT(1) NOT NULL DEFAULT 0;;'
  )
);
PREPARE st_addcol_8 FROM @sql_addcol_8;
EXECUTE st_addcol_8;
DEALLOCATE PREPARE st_addcol_8;

-- Safe add column: shop_keys.activated_at
SET @sql_addcol_9 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_keys'
        AND COLUMN_NAME = 'activated_at'
    ),
    'DO 1;',
    'ALTER TABLE shop_keys ADD COLUMN activated_at DATETIME NULL;;'
  )
);
PREPARE st_addcol_9 FROM @sql_addcol_9;
EXECUTE st_addcol_9;
DEALLOCATE PREPARE st_addcol_9;

-- Safe add column: shop_orders.activated_at
SET @sql_addcol_10 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_orders'
        AND COLUMN_NAME = 'activated_at'
    ),
    'DO 1;',
    'ALTER TABLE shop_orders ADD COLUMN activated_at DATETIME NULL AFTER status;;'
  )
);
PREPARE st_addcol_10 FROM @sql_addcol_10;
EXECUTE st_addcol_10;
DEALLOCATE PREPARE st_addcol_10;

-- Safe add column: shop_products.category
SET @sql_addcol_11 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_products'
        AND COLUMN_NAME = 'category'
    ),
    'DO 1;',
    "ALTER TABLE shop_products ADD COLUMN category VARCHAR(32) NOT NULL DEFAULT 'game_key' AFTER slug;;"
  )
);
PREPARE st_addcol_11 FROM @sql_addcol_11;
EXECUTE st_addcol_11;
DEALLOCATE PREPARE st_addcol_11;

-- Safe add column: shop_products.icon
SET @sql_addcol_12 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_products'
        AND COLUMN_NAME = 'icon'
    ),
    'DO 1;',
    'ALTER TABLE shop_products ADD COLUMN icon VARCHAR(80) NULL AFTER category;;'
  )
);
PREPARE st_addcol_12 FROM @sql_addcol_12;
EXECUTE st_addcol_12;
DEALLOCATE PREPARE st_addcol_12;

-- Safe add column: shop_products.image_url
SET @sql_addcol_13 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_products'
        AND COLUMN_NAME = 'image_url'
    ),
    'DO 1;',
    'ALTER TABLE shop_products ADD COLUMN image_url TEXT NULL AFTER icon;;'
  )
);
PREPARE st_addcol_13 FROM @sql_addcol_13;
EXECUTE st_addcol_13;
DEALLOCATE PREPARE st_addcol_13;

-- Safe add column: shop_orders.request_token
SET @sql_addcol_14 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_orders'
        AND COLUMN_NAME = 'request_token'
    ),
    'DO 1;',
    'ALTER TABLE shop_orders ADD COLUMN request_token VARCHAR(80) NULL AFTER order_code;;'
  )
);
PREPARE st_addcol_14 FROM @sql_addcol_14;
EXECUTE st_addcol_14;
DEALLOCATE PREPARE st_addcol_14;
-- Safe alter add index: shop_orders.uq_request_token
SET @sql_safe_add_idx_20 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_orders'
        AND INDEX_NAME = 'uq_request_token'
    ),
    'DO 1;',
    'ALTER TABLE `shop_orders` ADD UNIQUE KEY `uq_request_token` (request_token);'
  )
);
PREPARE st_safe_add_idx_20 FROM @sql_safe_add_idx_20;
EXECUTE st_safe_add_idx_20;
DEALLOCATE PREPARE st_safe_add_idx_20;-- Safe alter add index: shop_orders.uq_key_id
SET @sql_safe_add_idx_21 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_orders'
        AND INDEX_NAME = 'uq_key_id'
    ),
    'DO 1;',
    'ALTER TABLE `shop_orders` ADD UNIQUE KEY `uq_key_id` (key_id);'
  )
);
PREPARE st_safe_add_idx_21 FROM @sql_safe_add_idx_21;
EXECUTE st_safe_add_idx_21;
DEALLOCATE PREPARE st_safe_add_idx_21;
-- Safe add column: coupon_redemptions.request_token
SET @sql_addcol_15 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'coupon_redemptions'
        AND COLUMN_NAME = 'request_token'
    ),
    'DO 1;',
    'ALTER TABLE coupon_redemptions ADD COLUMN request_token VARCHAR(64) NULL;;'
  )
);
PREPARE st_addcol_15 FROM @sql_addcol_15;
EXECUTE st_addcol_15;
DEALLOCATE PREPARE st_addcol_15;
-- Safe alter add index: coupon_redemptions.uq_redemp_req
SET @sql_safe_add_idx_22 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'coupon_redemptions'
        AND INDEX_NAME = 'uq_redemp_req'
    ),
    'DO 1;',
    'ALTER TABLE `coupon_redemptions` ADD UNIQUE KEY `uq_redemp_req` (request_token);'
  )
);
PREPARE st_safe_add_idx_22 FROM @sql_safe_add_idx_22;
EXECUTE st_safe_add_idx_22;
DEALLOCATE PREPARE st_safe_add_idx_22;
-- Safe add column: coupon_redemptions.ip
SET @sql_addcol_16 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'coupon_redemptions'
        AND COLUMN_NAME = 'ip'
    ),
    'DO 1;',
    'ALTER TABLE coupon_redemptions ADD COLUMN ip VARCHAR(64) NULL;;'
  )
);
PREPARE st_addcol_16 FROM @sql_addcol_16;
EXECUTE st_addcol_16;
DEALLOCATE PREPARE st_addcol_16;

-- Safe add column: coupon_redemptions.ua
SET @sql_addcol_17 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'coupon_redemptions'
        AND COLUMN_NAME = 'ua'
    ),
    'DO 1;',
    'ALTER TABLE coupon_redemptions ADD COLUMN ua VARCHAR(250) NULL;;'
  )
);
PREPARE st_addcol_17 FROM @sql_addcol_17;
EXECUTE st_addcol_17;
DEALLOCATE PREPARE st_addcol_17;

-- Safe add column: users.ref_code
SET @sql_addcol_18 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND COLUMN_NAME = 'ref_code'
    ),
    'DO 1;',
    'ALTER TABLE users ADD COLUMN ref_code VARCHAR(32) NULL;;'
  )
);
PREPARE st_addcol_18 FROM @sql_addcol_18;
EXECUTE st_addcol_18;
DEALLOCATE PREPARE st_addcol_18;

-- Safe add column: users.referred_by
SET @sql_addcol_19 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND COLUMN_NAME = 'referred_by'
    ),
    'DO 1;',
    'ALTER TABLE users ADD COLUMN referred_by INT NULL;;'
  )
);
PREPARE st_addcol_19 FROM @sql_addcol_19;
EXECUTE st_addcol_19;
DEALLOCATE PREPARE st_addcol_19;

-- Safe add column: users.referred_at
SET @sql_addcol_20 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND COLUMN_NAME = 'referred_at'
    ),
    'DO 1;',
    'ALTER TABLE users ADD COLUMN referred_at DATETIME NULL;;'
  )
);
PREPARE st_addcol_20 FROM @sql_addcol_20;
EXECUTE st_addcol_20;
DEALLOCATE PREPARE st_addcol_20;

-- Safe add column: community_comments.is_approved
SET @sql_addcol_21 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'community_comments'
        AND COLUMN_NAME = 'is_approved'
    ),
    'DO 1;',
    'ALTER TABLE community_comments ADD COLUMN is_approved TINYINT(1) NOT NULL DEFAULT 1;;'
  )
);
PREPARE st_addcol_21 FROM @sql_addcol_21;
EXECUTE st_addcol_21;
DEALLOCATE PREPARE st_addcol_21;

-- Safe add column: community_comments.ip
SET @sql_addcol_22 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'community_comments'
        AND COLUMN_NAME = 'ip'
    ),
    'DO 1;',
    'ALTER TABLE community_comments ADD COLUMN ip VARCHAR(64) NULL;;'
  )
);
PREPARE st_addcol_22 FROM @sql_addcol_22;
EXECUTE st_addcol_22;
DEALLOCATE PREPARE st_addcol_22;

-- Safe add column: community_comments.ua
SET @sql_addcol_23 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'community_comments'
        AND COLUMN_NAME = 'ua'
    ),
    'DO 1;',
    'ALTER TABLE community_comments ADD COLUMN ua VARCHAR(255) NULL;;'
  )
);
PREPARE st_addcol_23 FROM @sql_addcol_23;
EXECUTE st_addcol_23;
DEALLOCATE PREPARE st_addcol_23;

-- Safe add column: users.featured_badge_id
SET @sql_addcol_24 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND COLUMN_NAME = 'featured_badge_id'
    ),
    'DO 1;',
    'ALTER TABLE users ADD COLUMN featured_badge_id INT NULL;;'
  )
);
PREPARE st_addcol_24 FROM @sql_addcol_24;
EXECUTE st_addcol_24;
DEALLOCATE PREPARE st_addcol_24;

-- Safe add column: users.display_title
SET @sql_addcol_25 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND COLUMN_NAME = 'display_title'
    ),
    'DO 1;',
    'ALTER TABLE users ADD COLUMN display_title VARCHAR(60) NULL;;'
  )
);
PREPARE st_addcol_25 FROM @sql_addcol_25;
EXECUTE st_addcol_25;
DEALLOCATE PREPARE st_addcol_25;

-- Safe add column: users.profile_cover
SET @sql_addcol_26 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND COLUMN_NAME = 'profile_cover'
    ),
    'DO 1;',
    'ALTER TABLE users ADD COLUMN profile_cover VARCHAR(40) NULL;;'
  )
);
PREPARE st_addcol_26 FROM @sql_addcol_26;
EXECUTE st_addcol_26;
DEALLOCATE PREPARE st_addcol_26;

-- Safe add column: users.avatar
SET @sql_addcol_27 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND COLUMN_NAME = 'avatar'
    ),
    'DO 1;',
    'ALTER TABLE users ADD COLUMN avatar VARCHAR(255) NULL;;'
  )
);
PREPARE st_addcol_27 FROM @sql_addcol_27;
EXECUTE st_addcol_27;
DEALLOCATE PREPARE st_addcol_27;

-- Safe add column: users.vault_pin_hash
SET @sql_addcol_28 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND COLUMN_NAME = 'vault_pin_hash'
    ),
    'DO 1;',
    'ALTER TABLE users ADD COLUMN vault_pin_hash VARCHAR(255) NULL;;'
  )
);
PREPARE st_addcol_28 FROM @sql_addcol_28;
EXECUTE st_addcol_28;
DEALLOCATE PREPARE st_addcol_28;

-- Safe add column: users.avatar_frame
SET @sql_addcol_29 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND COLUMN_NAME = 'avatar_frame'
    ),
    'DO 1;',
    'ALTER TABLE users ADD COLUMN avatar_frame VARCHAR(40) NULL;;'
  )
);
PREPARE st_addcol_29 FROM @sql_addcol_29;
EXECUTE st_addcol_29;
DEALLOCATE PREPARE st_addcol_29;

-- Safe add column: users.xp
SET @sql_addcol_30 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND COLUMN_NAME = 'xp'
    ),
    'DO 1;',
    'ALTER TABLE users ADD COLUMN xp INT NOT NULL DEFAULT 0;;'
  )
);
PREPARE st_addcol_30 FROM @sql_addcol_30;
EXECUTE st_addcol_30;
DEALLOCATE PREPARE st_addcol_30;

-- Safe add column: users.level
SET @sql_addcol_31 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND COLUMN_NAME = 'level'
    ),
    'DO 1;',
    'ALTER TABLE users ADD COLUMN level INT NOT NULL DEFAULT 1;;'
  )
);
PREPARE st_addcol_31 FROM @sql_addcol_31;
EXECUTE st_addcol_31;
DEALLOCATE PREPARE st_addcol_31;

-- Safe add column: shop_user_keys.gift_link_id
SET @sql_addcol_32 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_user_keys'
        AND COLUMN_NAME = 'gift_link_id'
    ),
    'DO 1;',
    'ALTER TABLE shop_user_keys ADD COLUMN gift_link_id INT NULL;;'
  )
);
PREPARE st_addcol_32 FROM @sql_addcol_32;
EXECUTE st_addcol_32;
DEALLOCATE PREPARE st_addcol_32;

-- Safe add column: shop_user_keys.gifted_at
SET @sql_addcol_33 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_user_keys'
        AND COLUMN_NAME = 'gifted_at'
    ),
    'DO 1;',
    'ALTER TABLE shop_user_keys ADD COLUMN gifted_at DATETIME NULL;;'
  )
);
PREPARE st_addcol_33 FROM @sql_addcol_33;
EXECUTE st_addcol_33;
DEALLOCATE PREPARE st_addcol_33;

-- Safe add column: app_links.downloads
SET @sql_addcol_34 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'app_links'
        AND COLUMN_NAME = 'downloads'
    ),
    'DO 1;',
    'ALTER TABLE app_links ADD COLUMN downloads INT NOT NULL DEFAULT 0;;'
  )
);
PREPARE st_addcol_34 FROM @sql_addcol_34;
EXECUTE st_addcol_34;
DEALLOCATE PREPARE st_addcol_34;

-- Safe add column: app_links.platform
SET @sql_addcol_35 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'app_links'
        AND COLUMN_NAME = 'platform'
    ),
    'DO 1;',
    'ALTER TABLE app_links ADD COLUMN platform VARCHAR(60) NULL;;'
  )
);
PREPARE st_addcol_35 FROM @sql_addcol_35;
EXECUTE st_addcol_35;
DEALLOCATE PREPARE st_addcol_35;

-- Safe add column: app_links.used_ip
SET @sql_addcol_36 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'app_links'
        AND COLUMN_NAME = 'used_ip'
    ),
    'DO 1;',
    'ALTER TABLE app_links ADD COLUMN used_ip VARCHAR(45) NULL;;'
  )
);
PREPARE st_addcol_36 FROM @sql_addcol_36;
EXECUTE st_addcol_36;
DEALLOCATE PREPARE st_addcol_36;

-- Safe add column: app_links.description
SET @sql_addcol_37 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'app_links'
        AND COLUMN_NAME = 'description'
    ),
    'DO 1;',
    'ALTER TABLE app_links ADD COLUMN description TEXT NULL;;'
  )
);
PREPARE st_addcol_37 FROM @sql_addcol_37;
EXECUTE st_addcol_37;
DEALLOCATE PREPARE st_addcol_37;

-- Safe add column: app_links.cover_image
SET @sql_addcol_38 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'app_links'
        AND COLUMN_NAME = 'cover_image'
    ),
    'DO 1;',
    'ALTER TABLE app_links ADD COLUMN cover_image TEXT NULL;;'
  )
);
PREPARE st_addcol_38 FROM @sql_addcol_38;
EXECUTE st_addcol_38;
DEALLOCATE PREPARE st_addcol_38;

-- Safe add column: app_links.images
SET @sql_addcol_39 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'app_links'
        AND COLUMN_NAME = 'images'
    ),
    'DO 1;',
    'ALTER TABLE app_links ADD COLUMN images TEXT NULL;;'
  )
);
PREPARE st_addcol_39 FROM @sql_addcol_39;
EXECUTE st_addcol_39;
DEALLOCATE PREPARE st_addcol_39;

-- Safe add column: app_links.url_backup
SET @sql_addcol_40 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'app_links'
        AND COLUMN_NAME = 'url_backup'
    ),
    'DO 1;',
    'ALTER TABLE app_links ADD COLUMN url_backup TEXT NULL;;'
  )
);
PREPARE st_addcol_40 FROM @sql_addcol_40;
EXECUTE st_addcol_40;
DEALLOCATE PREPARE st_addcol_40;

-- Safe add column: support_tickets.last_message_at
SET @sql_addcol_41 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'support_tickets'
        AND COLUMN_NAME = 'last_message_at'
    ),
    'DO 1;',
    'ALTER TABLE support_tickets ADD COLUMN last_message_at DATETIME NULL;;'
  )
);
PREPARE st_addcol_41 FROM @sql_addcol_41;
EXECUTE st_addcol_41;
DEALLOCATE PREPARE st_addcol_41;

-- Safe add column: support_tickets.updated_at
SET @sql_addcol_42 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'support_tickets'
        AND COLUMN_NAME = 'updated_at'
    ),
    'DO 1;',
    'ALTER TABLE support_tickets ADD COLUMN updated_at DATETIME NULL;;'
  )
);
PREPARE st_addcol_42 FROM @sql_addcol_42;
EXECUTE st_addcol_42;
DEALLOCATE PREPARE st_addcol_42;

-- Safe add column: users.vendor_fee_percent
SET @sql_addcol_43 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND COLUMN_NAME = 'vendor_fee_percent'
    ),
    'DO 1;',
    'ALTER TABLE users ADD COLUMN vendor_fee_percent DECIMAL(6,2) NULL;;'
  )
);
PREPARE st_addcol_43 FROM @sql_addcol_43;
EXECUTE st_addcol_43;
DEALLOCATE PREPARE st_addcol_43;

-- Safe add column: users.vendor_active
SET @sql_addcol_44 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND COLUMN_NAME = 'vendor_active'
    ),
    'DO 1;',
    'ALTER TABLE users ADD COLUMN vendor_active TINYINT(1) NOT NULL DEFAULT 1;;'
  )
);
PREPARE st_addcol_44 FROM @sql_addcol_44;
EXECUTE st_addcol_44;
DEALLOCATE PREPARE st_addcol_44;

-- Safe add column: users.vendor_payout_info
SET @sql_addcol_45 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND COLUMN_NAME = 'vendor_payout_info'
    ),
    'DO 1;',
    'ALTER TABLE users ADD COLUMN vendor_payout_info TEXT NULL;;'
  )
);
PREPARE st_addcol_45 FROM @sql_addcol_45;
EXECUTE st_addcol_45;
DEALLOCATE PREPARE st_addcol_45;

-- Safe add column: shop_products.vendor_id
SET @sql_addcol_46 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_products'
        AND COLUMN_NAME = 'vendor_id'
    ),
    'DO 1;',
    'ALTER TABLE shop_products ADD COLUMN vendor_id INT NULL;;'
  )
);
PREPARE st_addcol_46 FROM @sql_addcol_46;
EXECUTE st_addcol_46;
DEALLOCATE PREPARE st_addcol_46;

-- Safe add column: shop_products.vendor_fee_percent
SET @sql_addcol_47 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_products'
        AND COLUMN_NAME = 'vendor_fee_percent'
    ),
    'DO 1;',
    'ALTER TABLE shop_products ADD COLUMN vendor_fee_percent DECIMAL(6,2) NULL;;'
  )
);
PREPARE st_addcol_47 FROM @sql_addcol_47;
EXECUTE st_addcol_47;
DEALLOCATE PREPARE st_addcol_47;

-- Safe add column: shop_products.vendor_note
SET @sql_addcol_48 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_products'
        AND COLUMN_NAME = 'vendor_note'
    ),
    'DO 1;',
    'ALTER TABLE shop_products ADD COLUMN vendor_note VARCHAR(190) NULL;;'
  )
);
PREPARE st_addcol_48 FROM @sql_addcol_48;
EXECUTE st_addcol_48;
DEALLOCATE PREPARE st_addcol_48;

-- Safe add column: shop_keys.vendor_id
SET @sql_addcol_49 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_keys'
        AND COLUMN_NAME = 'vendor_id'
    ),
    'DO 1;',
    'ALTER TABLE shop_keys ADD COLUMN vendor_id INT NULL;;'
  )
);
PREPARE st_addcol_49 FROM @sql_addcol_49;
EXECUTE st_addcol_49;
DEALLOCATE PREPARE st_addcol_49;

-- Safe add column: shop_orders.vendor_id
SET @sql_addcol_50 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_orders'
        AND COLUMN_NAME = 'vendor_id'
    ),
    'DO 1;',
    'ALTER TABLE shop_orders ADD COLUMN vendor_id INT NULL;;'
  )
);
PREPARE st_addcol_50 FROM @sql_addcol_50;
EXECUTE st_addcol_50;
DEALLOCATE PREPARE st_addcol_50;

-- Safe add column: shop_orders.vendor_fee_vnd
SET @sql_addcol_51 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_orders'
        AND COLUMN_NAME = 'vendor_fee_vnd'
    ),
    'DO 1;',
    'ALTER TABLE shop_orders ADD COLUMN vendor_fee_vnd INT NOT NULL DEFAULT 0;;'
  )
);
PREPARE st_addcol_51 FROM @sql_addcol_51;
EXECUTE st_addcol_51;
DEALLOCATE PREPARE st_addcol_51;

-- Safe add column: shop_orders.vendor_net_vnd
SET @sql_addcol_52 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_orders'
        AND COLUMN_NAME = 'vendor_net_vnd'
    ),
    'DO 1;',
    'ALTER TABLE shop_orders ADD COLUMN vendor_net_vnd INT NOT NULL DEFAULT 0;;'
  )
);
PREPARE st_addcol_52 FROM @sql_addcol_52;
EXECUTE st_addcol_52;
DEALLOCATE PREPARE st_addcol_52;

-- Safe add column: app_links.vendor_id
SET @sql_addcol_53 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'app_links'
        AND COLUMN_NAME = 'vendor_id'
    ),
    'DO 1;',
    'ALTER TABLE app_links ADD COLUMN vendor_id INT NULL;;'
  )
);
PREPARE st_addcol_53 FROM @sql_addcol_53;
EXECUTE st_addcol_53;
DEALLOCATE PREPARE st_addcol_53;

-- Safe add column: mission_claims.status
SET @sql_addcol_54 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'mission_claims'
        AND COLUMN_NAME = 'status'
    ),
    'DO 1;',
    "ALTER TABLE mission_claims ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'approved';;"
  )
);
PREPARE st_addcol_54 FROM @sql_addcol_54;
EXECUTE st_addcol_54;
DEALLOCATE PREPARE st_addcol_54;

-- Safe add column: mission_claims.evidence
SET @sql_addcol_55 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'mission_claims'
        AND COLUMN_NAME = 'evidence'
    ),
    'DO 1;',
    'ALTER TABLE mission_claims ADD COLUMN evidence TEXT NULL;;'
  )
);
PREPARE st_addcol_55 FROM @sql_addcol_55;
EXECUTE st_addcol_55;
DEALLOCATE PREPARE st_addcol_55;

-- Safe add column: mission_claims.reviewed_by
SET @sql_addcol_56 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'mission_claims'
        AND COLUMN_NAME = 'reviewed_by'
    ),
    'DO 1;',
    'ALTER TABLE mission_claims ADD COLUMN reviewed_by INT NULL;;'
  )
);
PREPARE st_addcol_56 FROM @sql_addcol_56;
EXECUTE st_addcol_56;
DEALLOCATE PREPARE st_addcol_56;

-- Safe add column: mission_claims.reviewed_at
SET @sql_addcol_57 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'mission_claims'
        AND COLUMN_NAME = 'reviewed_at'
    ),
    'DO 1;',
    'ALTER TABLE mission_claims ADD COLUMN reviewed_at DATETIME NULL;;'
  )
);
PREPARE st_addcol_57 FROM @sql_addcol_57;
EXECUTE st_addcol_57;
DEALLOCATE PREPARE st_addcol_57;
-- Ensure mission_claims.claim_date exists before creating uq_user_mission_day
SET @sql_col_claim_date := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'mission_claims'
        AND COLUMN_NAME = 'claim_date'
    ),
    'DO 1;',
    'ALTER TABLE `mission_claims` ADD COLUMN `claim_date` DATE NULL;'
  )
);
PREPARE st_col_claim_date FROM @sql_col_claim_date;
EXECUTE st_col_claim_date;
DEALLOCATE PREPARE st_col_claim_date;

-- Safe alter add index: mission_claims.uq_user_mission_day
SET @sql_safe_add_idx_23 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'mission_claims'
        AND INDEX_NAME = 'uq_user_mission_day'
    ),
    'DO 1;',
    'ALTER TABLE `mission_claims` ADD UNIQUE KEY `uq_user_mission_day` (user_id, mission_id, claim_date);'
  )
);
PREPARE st_safe_add_idx_23 FROM @sql_safe_add_idx_23;
EXECUTE st_safe_add_idx_23;
DEALLOCATE PREPARE st_safe_add_idx_23;-- Safe alter add index: mission_claims.uq_user_mission
SET @sql_safe_add_idx_24 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'mission_claims'
        AND INDEX_NAME = 'uq_user_mission'
    ),
    'DO 1;',
    'ALTER TABLE `mission_claims` ADD UNIQUE KEY `uq_user_mission` (user_id, mission_id);'
  )
);
PREPARE st_safe_add_idx_24 FROM @sql_safe_add_idx_24;
EXECUTE st_safe_add_idx_24;
DEALLOCATE PREPARE st_safe_add_idx_24;
-- Seed data

INSERT INTO vip_plans(title,price_vnd,duration_days,discount_pct,points_bonus_pct,is_active,created_at)
      VALUES('VIP RioKey',99000,30,5,20,1,NOW());

-- Vendor/CTV patch

ALTER TABLE users ADD COLUMN vendor_fee_percent DECIMAL(6,2) NULL;

-- Safe add column: users.vendor_active
SET @sql_addcol_58 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND COLUMN_NAME = 'vendor_active'
    ),
    'DO 1;',
    'ALTER TABLE users ADD COLUMN vendor_active TINYINT(1) NOT NULL DEFAULT 1;;'
  )
);
PREPARE st_addcol_58 FROM @sql_addcol_58;
EXECUTE st_addcol_58;
DEALLOCATE PREPARE st_addcol_58;

-- Safe add column: users.vendor_payout_info
SET @sql_addcol_59 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'users'
        AND COLUMN_NAME = 'vendor_payout_info'
    ),
    'DO 1;',
    'ALTER TABLE users ADD COLUMN vendor_payout_info TEXT NULL;;'
  )
);
PREPARE st_addcol_59 FROM @sql_addcol_59;
EXECUTE st_addcol_59;
DEALLOCATE PREPARE st_addcol_59;

-- Safe add column: shop_products.vendor_id
SET @sql_addcol_60 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_products'
        AND COLUMN_NAME = 'vendor_id'
    ),
    'DO 1;',
    'ALTER TABLE shop_products ADD COLUMN vendor_id INT NULL;;'
  )
);
PREPARE st_addcol_60 FROM @sql_addcol_60;
EXECUTE st_addcol_60;
DEALLOCATE PREPARE st_addcol_60;

-- Safe add column: shop_products.vendor_fee_percent
SET @sql_addcol_61 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_products'
        AND COLUMN_NAME = 'vendor_fee_percent'
    ),
    'DO 1;',
    'ALTER TABLE shop_products ADD COLUMN vendor_fee_percent DECIMAL(6,2) NULL;;'
  )
);
PREPARE st_addcol_61 FROM @sql_addcol_61;
EXECUTE st_addcol_61;
DEALLOCATE PREPARE st_addcol_61;

-- Safe add column: shop_products.vendor_note
SET @sql_addcol_62 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_products'
        AND COLUMN_NAME = 'vendor_note'
    ),
    'DO 1;',
    'ALTER TABLE shop_products ADD COLUMN vendor_note VARCHAR(190) NULL;;'
  )
);
PREPARE st_addcol_62 FROM @sql_addcol_62;
EXECUTE st_addcol_62;
DEALLOCATE PREPARE st_addcol_62;
-- Safe create index: shop_products.idx_vendor
SET @sql_create_idx_1 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_products'
        AND INDEX_NAME = 'idx_vendor'
    ),
    'DO 1;',
    'CREATE INDEX `idx_vendor` ON `shop_products` (vendor_id);'
  )
);
PREPARE st_create_idx_1 FROM @sql_create_idx_1;
EXECUTE st_create_idx_1;
DEALLOCATE PREPARE st_create_idx_1;
-- Safe add column: shop_keys.vendor_id
SET @sql_addcol_63 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_keys'
        AND COLUMN_NAME = 'vendor_id'
    ),
    'DO 1;',
    'ALTER TABLE shop_keys ADD COLUMN vendor_id INT NULL;;'
  )
);
PREPARE st_addcol_63 FROM @sql_addcol_63;
EXECUTE st_addcol_63;
DEALLOCATE PREPARE st_addcol_63;
-- Safe create index: shop_keys.idx_vendor
SET @sql_create_idx_2 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_keys'
        AND INDEX_NAME = 'idx_vendor'
    ),
    'DO 1;',
    'CREATE INDEX `idx_vendor` ON `shop_keys` (vendor_id);'
  )
);
PREPARE st_create_idx_2 FROM @sql_create_idx_2;
EXECUTE st_create_idx_2;
DEALLOCATE PREPARE st_create_idx_2;
-- Safe add column: shop_orders.vendor_id
SET @sql_addcol_64 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_orders'
        AND COLUMN_NAME = 'vendor_id'
    ),
    'DO 1;',
    'ALTER TABLE shop_orders ADD COLUMN vendor_id INT NULL;;'
  )
);
PREPARE st_addcol_64 FROM @sql_addcol_64;
EXECUTE st_addcol_64;
DEALLOCATE PREPARE st_addcol_64;

-- Safe add column: shop_orders.vendor_fee_vnd
SET @sql_addcol_65 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_orders'
        AND COLUMN_NAME = 'vendor_fee_vnd'
    ),
    'DO 1;',
    'ALTER TABLE shop_orders ADD COLUMN vendor_fee_vnd INT NOT NULL DEFAULT 0;;'
  )
);
PREPARE st_addcol_65 FROM @sql_addcol_65;
EXECUTE st_addcol_65;
DEALLOCATE PREPARE st_addcol_65;

-- Safe add column: shop_orders.vendor_net_vnd
SET @sql_addcol_66 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_orders'
        AND COLUMN_NAME = 'vendor_net_vnd'
    ),
    'DO 1;',
    'ALTER TABLE shop_orders ADD COLUMN vendor_net_vnd INT NOT NULL DEFAULT 0;;'
  )
);
PREPARE st_addcol_66 FROM @sql_addcol_66;
EXECUTE st_addcol_66;
DEALLOCATE PREPARE st_addcol_66;
-- Safe create index: shop_orders.idx_vendor
SET @sql_create_idx_3 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'shop_orders'
        AND INDEX_NAME = 'idx_vendor'
    ),
    'DO 1;',
    'CREATE INDEX `idx_vendor` ON `shop_orders` (vendor_id);'
  )
);
PREPARE st_create_idx_3 FROM @sql_create_idx_3;
EXECUTE st_create_idx_3;
DEALLOCATE PREPARE st_create_idx_3;
-- Safe add column: app_links.vendor_id
SET @sql_addcol_67 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'app_links'
        AND COLUMN_NAME = 'vendor_id'
    ),
    'DO 1;',
    'ALTER TABLE app_links ADD COLUMN vendor_id INT NULL;;'
  )
);
PREPARE st_addcol_67 FROM @sql_addcol_67;
EXECUTE st_addcol_67;
DEALLOCATE PREPARE st_addcol_67;
-- Safe create index: app_links.idx_vendor
SET @sql_create_idx_4 := (
  SELECT IF(
    EXISTS(
      SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'app_links'
        AND INDEX_NAME = 'idx_vendor'
    ),
    'DO 1;',
    'CREATE INDEX `idx_vendor` ON `app_links` (vendor_id);'
  )
);
PREPARE st_create_idx_4 FROM @sql_create_idx_4;
EXECUTE st_create_idx_4;
DEALLOCATE PREPARE st_create_idx_4;
CREATE TABLE vendor_wallets (
  vendor_id INT PRIMARY KEY,
  balance DECIMAL(14,2) NOT NULL DEFAULT 0,
  locked DECIMAL(14,2) NOT NULL DEFAULT 0,
  total_withdrawn DECIMAL(14,2) NOT NULL DEFAULT 0,
  updated_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE vendor_transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  vendor_id INT NOT NULL,
  type VARCHAR(40) NOT NULL,
  amount DECIMAL(14,2) NOT NULL,
  ref_key VARCHAR(120) NULL,
  note VARCHAR(190) NULL,
  meta_json TEXT NULL,
  created_at DATETIME NOT NULL,
  INDEX idx_vendor (vendor_id),
  INDEX idx_ref (ref_key),
  INDEX idx_type (type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE vendor_withdrawals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  vendor_id INT NOT NULL,
  amount DECIMAL(14,2) NOT NULL,
  status ENUM('pending','approved','rejected','paid') NOT NULL DEFAULT 'pending',
  payout_note VARCHAR(190) NULL,
  created_at DATETIME NOT NULL,
  processed_by INT NULL,
  processed_at DATETIME NULL,
  INDEX idx_vendor (vendor_id),
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS=1;

-- Extra columns/settings for latest features
SET @db := DATABASE();

-- ensure settings table
SET @sql := (SELECT IF(
  EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=@db AND TABLE_NAME='settings'),
  'SELECT "OK";',
  'CREATE TABLE settings (k VARCHAR(64) PRIMARY KEY, v TEXT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
));

PREPARE st_settbl FROM @sql;

EXECUTE st_settbl;

DEALLOCATE PREPARE st_settbl;

INSERT INTO settings (k,v) VALUES ('vault_required','1') ON DUPLICATE KEY UPDATE v=VALUES(v);

INSERT INTO settings (k,v) VALUES ('vault_ok_minutes','10') ON DUPLICATE KEY UPDATE v=VALUES(v);

-- users role enum add vendor
SET @sql := (SELECT IF(
  EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='users' AND COLUMN_NAME='role'),
  'ALTER TABLE users MODIFY role ENUM(''user'',''mod'',''admin'',''vendor'') NOT NULL DEFAULT ''user''',
  'SELECT "OK";'
));

PREPARE st_role FROM @sql;

EXECUTE st_role;

DEALLOCATE PREPARE st_role;

-- users vendor fee percent
SET @sql := (SELECT IF(
  EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='users' AND COLUMN_NAME='vendor_fee_percent'),
  'SELECT "OK";',
  'ALTER TABLE users ADD COLUMN vendor_fee_percent DECIMAL(6,2) NULL'
));

PREPARE st_vfee FROM @sql;

EXECUTE st_vfee;

DEALLOCATE PREPARE st_vfee;

-- users vault columns
SET @sql := (SELECT IF(
  EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='users' AND COLUMN_NAME='vault_pin_hash'),
  'SELECT "OK";',
  'ALTER TABLE users ADD COLUMN vault_pin_hash VARCHAR(255) NULL'
));

PREPARE st_vph FROM @sql;

EXECUTE st_vph;

DEALLOCATE PREPARE st_vph;

SET @sql := (SELECT IF(
  EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='users' AND COLUMN_NAME='vault_pin_set_at'),
  'SELECT "OK";',
  'ALTER TABLE users ADD COLUMN vault_pin_set_at DATETIME NULL'
));

PREPARE st_vps FROM @sql;

EXECUTE st_vps;

DEALLOCATE PREPARE st_vps;

-- shop_keys.key_hash + index
SET @sql := (SELECT IF(
  EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='shop_keys' AND COLUMN_NAME='key_hash'),
  'SELECT "OK";',
  'ALTER TABLE shop_keys ADD COLUMN key_hash CHAR(64) NULL'
));

PREPARE st_kh FROM @sql;

EXECUTE st_kh;

DEALLOCATE PREPARE st_kh;

UPDATE shop_keys SET key_hash = SHA2(key_code,256) WHERE key_hash IS NULL;

SET @sql := (SELECT IF(
  EXISTS(SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='shop_keys' AND INDEX_NAME='idx_key_hash'),
  'SELECT "OK";',
  'CREATE INDEX idx_key_hash ON shop_keys(key_hash)'
));

PREPARE st_khi FROM @sql;

EXECUTE st_khi;

DEALLOCATE PREPARE st_khi;

-- shop_products.low_stock_threshold
SET @sql := (SELECT IF(
  EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='shop_products' AND COLUMN_NAME='low_stock_threshold'),
  'SELECT "OK";',
  'ALTER TABLE shop_products ADD COLUMN low_stock_threshold INT NOT NULL DEFAULT 10'
));

PREPARE st_lst FROM @sql;

EXECUTE st_lst;

DEALLOCATE PREPARE st_lst;

-- Seed accounts for testing
DELETE FROM users;

INSERT INTO users (id,name,username,email,password_hash,ref_code,is_admin,role,points,created_at)
VALUES
(1,'Admin','admin','admin@test.com','$2y$10$oY2KcyGAfyMxP8QiXR2/ze.9QgyHfL7DuT.gjz55E/9N6o8Mut5FS','ADMINREF',1,'admin',500000,NOW()),
(2,'Mod','mod','mod@test.com','$2y$10$oY2KcyGAfyMxP8QiXR2/ze.9QgyHfL7DuT.gjz55E/9N6o8Mut5FS','MODREF',0,'mod',500000,NOW()),
(3,'User','user','user@test.com','$2y$10$oY2KcyGAfyMxP8QiXR2/ze.9QgyHfL7DuT.gjz55E/9N6o8Mut5FS','USERREF',0,'user',500000,NOW());

SET @sql := (SELECT IF(
  EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='wallets'),
  'DELETE FROM wallets; INSERT INTO wallets (user_id,balance_vnd,updated_at) VALUES (1,500000,NOW()),(2,500000,NOW()),(3,500000,NOW());',
  'SELECT "OK";'
));

PREPARE st_w FROM @sql;

EXECUTE st_w;

DEALLOCATE PREPARE st_w;

-- Seed products/keys/redeems for test when tables exist
SET @has_sp := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='shop_products');

SET @has_sk := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='shop_keys');

SET @has_rd := (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='redeem_codes');

SET @sql := IF(@has_sp>0,
  'DELETE FROM shop_products;
   INSERT INTO shop_products (id,category,slug,title,price_points,price_vnd,stock_mode,is_active,created_at) VALUES
   (101,''game_key'',''game-key-test'',''Game Key Test'',1200,20000,''keys'',1,NOW()),
   (102,''giftcard'',''giftcard-test'',''Giftcard Test'',2200,40000,''keys'',1,NOW()),
   (103,''account'',''account-test'',''Account Test'',3200,60000,''keys'',1,NOW());',
  'SELECT "OK";'
);

PREPARE st_sp FROM @sql;

EXECUTE st_sp;

DEALLOCATE PREPARE st_sp;

SET @sql := IF(@has_sk>0,
  'DELETE FROM shop_keys;
   INSERT INTO shop_keys (product_id,key_code,is_sold,created_at,key_hash) VALUES
   (101,CONCAT(''GK-'',SUBSTR(SHA2(RAND(),256),1,16)),0,NOW(),SHA2(CONCAT(''GK-'',SUBSTR(SHA2(RAND(),256),1,16)),256)),
   (101,CONCAT(''GK-'',SUBSTR(SHA2(RAND(),256),1,16)),0,NOW(),SHA2(CONCAT(''GK-'',SUBSTR(SHA2(RAND(),256),1,16)),256)),
   (101,CONCAT(''GK-'',SUBSTR(SHA2(RAND(),256),1,16)),0,NOW(),SHA2(CONCAT(''GK-'',SUBSTR(SHA2(RAND(),256),1,16)),256)),
   (101,CONCAT(''GK-'',SUBSTR(SHA2(RAND(),256),1,16)),0,NOW(),SHA2(CONCAT(''GK-'',SUBSTR(SHA2(RAND(),256),1,16)),256)),
   (101,CONCAT(''GK-'',SUBSTR(SHA2(RAND(),256),1,16)),0,NOW(),SHA2(CONCAT(''GK-'',SUBSTR(SHA2(RAND(),256),1,16)),256)),
   (102,CONCAT(''GC-'',SUBSTR(SHA2(RAND(),256),1,16)),0,NOW(),SHA2(CONCAT(''GC-'',SUBSTR(SHA2(RAND(),256),1,16)),256)),
   (102,CONCAT(''GC-'',SUBSTR(SHA2(RAND(),256),1,16)),0,NOW(),SHA2(CONCAT(''GC-'',SUBSTR(SHA2(RAND(),256),1,16)),256)),
   (102,CONCAT(''GC-'',SUBSTR(SHA2(RAND(),256),1,16)),0,NOW(),SHA2(CONCAT(''GC-'',SUBSTR(SHA2(RAND(),256),1,16)),256)),
   (102,CONCAT(''GC-'',SUBSTR(SHA2(RAND(),256),1,16)),0,NOW(),SHA2(CONCAT(''GC-'',SUBSTR(SHA2(RAND(),256),1,16)),256)),
   (102,CONCAT(''GC-'',SUBSTR(SHA2(RAND(),256),1,16)),0,NOW(),SHA2(CONCAT(''GC-'',SUBSTR(SHA2(RAND(),256),1,16)),256)),
   (103,CONCAT(''AC-'',SUBSTR(SHA2(RAND(),256),1,16)),0,NOW(),SHA2(CONCAT(''AC-'',SUBSTR(SHA2(RAND(),256),1,16)),256)),
   (103,CONCAT(''AC-'',SUBSTR(SHA2(RAND(),256),1,16)),0,NOW(),SHA2(CONCAT(''AC-'',SUBSTR(SHA2(RAND(),256),1,16)),256)),
   (103,CONCAT(''AC-'',SUBSTR(SHA2(RAND(),256),1,16)),0,NOW(),SHA2(CONCAT(''AC-'',SUBSTR(SHA2(RAND(),256),1,16)),256)),
   (103,CONCAT(''AC-'',SUBSTR(SHA2(RAND(),256),1,16)),0,NOW(),SHA2(CONCAT(''AC-'',SUBSTR(SHA2(RAND(),256),1,16)),256)),
   (103,CONCAT(''AC-'',SUBSTR(SHA2(RAND(),256),1,16)),0,NOW(),SHA2(CONCAT(''AC-'',SUBSTR(SHA2(RAND(),256),1,16)),256));',
  'SELECT "OK";'
);

PREPARE st_sk FROM @sql;

EXECUTE st_sk;

DEALLOCATE PREPARE st_sk;

SET @sql := IF(@has_rd>0,
  'DELETE FROM redeem_codes;
   INSERT INTO redeem_codes (code,reward_type,reward_value,max_uses,per_user_once,expires_at,created_at) VALUES
   (CONCAT(''TEST'',SUBSTR(SHA2(RAND(),256),1,6)),''wallet'',50000,50,1,DATE_ADD(NOW(),INTERVAL 30 DAY),NOW()),
   (CONCAT(''TEST'',SUBSTR(SHA2(RAND(),256),1,6)),''wallet'',50000,50,1,DATE_ADD(NOW(),INTERVAL 30 DAY),NOW()),
   (CONCAT(''TEST'',SUBSTR(SHA2(RAND(),256),1,6)),''wallet'',50000,50,1,DATE_ADD(NOW(),INTERVAL 30 DAY),NOW()),
   (CONCAT(''TEST'',SUBSTR(SHA2(RAND(),256),1,6)),''points'',5000,50,1,DATE_ADD(NOW(),INTERVAL 30 DAY),NOW()),
   (CONCAT(''TEST'',SUBSTR(SHA2(RAND(),256),1,6)),''points'',5000,50,1,DATE_ADD(NOW(),INTERVAL 30 DAY),NOW()),
   (CONCAT(''TEST'',SUBSTR(SHA2(RAND(),256),1,6)),''points'',5000,50,1,DATE_ADD(NOW(),INTERVAL 30 DAY),NOW()),
   (CONCAT(''TEST'',SUBSTR(SHA2(RAND(),256),1,6)),''wallet'',100000,20,1,DATE_ADD(NOW(),INTERVAL 30 DAY),NOW()),
   (CONCAT(''TEST'',SUBSTR(SHA2(RAND(),256),1,6)),''wallet'',100000,20,1,DATE_ADD(NOW(),INTERVAL 30 DAY),NOW()),
   (CONCAT(''TEST'',SUBSTR(SHA2(RAND(),256),1,6)),''points'',12000,20,1,DATE_ADD(NOW(),INTERVAL 30 DAY),NOW()),
   (CONCAT(''TEST'',SUBSTR(SHA2(RAND(),256),1,6)),''points'',12000,20,1,DATE_ADD(NOW(),INTERVAL 30 DAY),NOW());',
  'SELECT "OK";'
);

PREPARE st_rd FROM @sql;

EXECUTE st_rd;

DEALLOCATE PREPARE st_rd;
