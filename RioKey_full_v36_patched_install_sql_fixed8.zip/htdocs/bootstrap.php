<?php
// Start output buffering early so redirects (header()) still work even if a page echoes before calling redirect().
// This also fixes "headers already sent" warnings in development.
if (!ob_get_level()) ob_start();

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/lib/helpers.php';
ensure_upload_dirs();

require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/lib/auth.php';
require_once __DIR__ . '/lib/csrf.php';
require_once __DIR__ . '/lib/settings.php';
require_once __DIR__ . '/lib/points.php';
require_once __DIR__ . '/lib/notify.php';
require_once __DIR__ . '/lib/vault.php';
require_once __DIR__ . '/lib/audit.php';
require_once __DIR__ . '/lib/rank.php';
require_once __DIR__ . '/lib/wallet_engine.php';
require_once __DIR__ . '/lib/shop.php';
require_once __DIR__ . '/lib/vendor.php';
require_once __DIR__ . '/lib/vip.php';
require_once __DIR__ . '/lib/flash.php';
require_once __DIR__ . '/lib/lootbox.php';
require_once __DIR__ . '/lib/spin.php';
require_once __DIR__ . '/lib/referral.php';
require_once __DIR__ . '/lib/coupons.php';
require_once __DIR__ . '/lib/community_forum.php';
require_once __DIR__ . '/lib/support.php';
require_once __DIR__ . '/lib/security.php';
require_once __DIR__ . '/lib/user_features.php';
require_once __DIR__ . '/lib/achievements.php';
require_once __DIR__ . '/lib/reviews.php';
require_once __DIR__ . '/lib/level_engine.php';
require_once __DIR__ . '/lib/showcase.php';
require_once __DIR__ . '/lib/gifts.php';
require_once __DIR__ . '/lib/app_links.php';

// IP block + anti-spam request rate limit
try {
  $ip = client_ip();
  if ($ip && ip_is_blocked($ip)) {
    http_response_code(429);
    echo "<!doctype html><html><head><meta charset='utf-8'><title>Too Many Requests</title></head><body style='background:#0b1220;color:#e2e8f0;font-family:system-ui;padding:32px'><h2>RioKey</h2><p>IP của bạn đang bị hạn chế tạm thời. Vui lòng thử lại sau.</p></body></html>";
    exit;
  }

  // global rate limit per IP (basic anti-DDOS/spam)
  $limit = (int)setting('ip_req_limit', 240);     // requests / window
  $win   = (int)setting('ip_req_window', 60);     // seconds
  if ($limit > 0 && $win > 0) {
    if (rate_limit_exceeded('reqip:'.$ip, $limit, $win)) {
      ip_block($ip, 'Auto block: request rate limit', (int)setting('ip_req_block_minutes', 5), null);
      http_response_code(429);
      echo "<!doctype html><html><head><meta charset='utf-8'><title>Too Many Requests</title></head><body style='background:#0b1220;color:#e2e8f0;font-family:system-ui;padding:32px'><h2>RioKey</h2><p>Bạn thao tác quá nhanh. Vui lòng thử lại sau.</p></body></html>";
      exit;
    }
  }
} catch (Throwable $e) {}


// RioKey schema upgrades (best-effort)
try {
  $pdo = db();
// vault schema
vault_ensure_schema($pdo);
  // users moderation fields
  $ucols = [
    'last_seen_at' => "ALTER TABLE users ADD COLUMN last_seen_at DATETIME NULL",
    'last_ip'      => "ALTER TABLE users ADD COLUMN last_ip VARCHAR(64) NULL",
    'last_ua'      => "ALTER TABLE users ADD COLUMN last_ua VARCHAR(255) NULL",
    'warnings'     => "ALTER TABLE users ADD COLUMN warnings INT NOT NULL DEFAULT 0",
    'mute_until'   => "ALTER TABLE users ADD COLUMN mute_until DATETIME NULL",
    'is_banned'    => "ALTER TABLE users ADD COLUMN is_banned TINYINT(1) NOT NULL DEFAULT 0",
    'ban_reason'   => "ALTER TABLE users ADD COLUMN ban_reason VARCHAR(255) NULL",
  ];
  foreach($ucols as $c=>$sql){ if(!db_has_column('users',$c)) { try { $pdo->exec($sql); } catch(Throwable $e) {} } }
  // shop inventory threshold
  if(!db_has_column('shop_products','low_stock_threshold')) { try { $pdo->exec("ALTER TABLE shop_products ADD COLUMN low_stock_threshold INT NOT NULL DEFAULT 10"); } catch(Throwable $e) {} }
  // shop orders ip/ua
  $ocols = [
    'ip' => "ALTER TABLE shop_orders ADD COLUMN ip VARCHAR(64) NULL",
    'ua' => "ALTER TABLE shop_orders ADD COLUMN ua VARCHAR(255) NULL",
  ];
  foreach($ocols as $c=>$sql){ if(!db_has_column('shop_orders',$c)) { try { $pdo->exec($sql); } catch(Throwable $e) {} } }
  // coupon redemptions ip/ua
  $rcols = [
    'ip' => "ALTER TABLE coupon_redemptions ADD COLUMN ip VARCHAR(64) NULL",
    'ua' => "ALTER TABLE coupon_redemptions ADD COLUMN ua VARCHAR(255) NULL",
  ];
  foreach($rcols as $c=>$sql){ if(db_has_table('coupon_redemptions') && !db_has_column('coupon_redemptions',$c)) { try { $pdo->exec($sql); } catch(Throwable $e) {} } }
  community_ensure_schema();
  security_ensure_schema();
  user_features_ensure_schema();
  badges_seed_defaults();
  reviews_ensure_schema();
  level_seed_titles();
  showcase_ensure_schema();
  gifts_ensure_schema();
  vendor_ensure_schema();
  support_ensure_schema();
  app_links_ensure_schema();
} catch(Throwable $e) {}

// Maintenance gate
try {
  $path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';
  $on = (int)setting('maintenance_enabled', 0);
  if ($on===1) {
    $isBypass = ($path === '/maintenance' || $path === '/maintenance-off' || str_starts_with($path, '/admin'));
    if (!$isBypass && !is_admin()) {
      header('Location: ' . base_url('/maintenance'));
      exit;
    }
  }
} catch (Throwable $e) {}
