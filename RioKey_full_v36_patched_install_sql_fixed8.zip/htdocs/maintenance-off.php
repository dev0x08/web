<?php
require_once __DIR__ . '/bootstrap.php';

$token = trim($_GET['token'] ?? '');
$real = (string)setting_get('maintenance_token', 'change_me');

if ($token !== '' && hash_equals($real, $token)) {
  setting_set('maintenance_enabled', false);
  // redirect home
  if (auth_user()) redirect(base_url('/dashboard'));
  redirect(base_url('/auth/login.php'));
}

http_response_code(403);
$title = "Không hợp lệ";
include __DIR__ . '/inc/head.php';
?>
<div class="min-h-screen grid place-items-center px-4">
  <div class="w-full max-w-lg card p-7 text-center">
    <div class="mx-auto w-14 h-14 rounded-2xl bg-rose-500/10 border border-rose-500/20 grid place-items-center">
      <?= lucide_icon('shield-alert','w-7 h-7 text-rose-300') ?>
    </div>
    <div class="text-2xl font-black mt-4">Link không hợp lệ</div>
    <div class="text-slate-400 mt-2">Token sai hoặc đã bị thay đổi.</div>
  </div>
</div>
<?php include __DIR__ . '/inc/foot.php'; ?>
