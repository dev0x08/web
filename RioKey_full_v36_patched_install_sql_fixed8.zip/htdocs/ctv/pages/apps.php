<?php
$u = auth_user();
$vid = (int)$u['id'];
vendor_ensure_schema();
app_links_ensure_schema();

$pdo = db();
$msg=''; $err='';
$action = $_POST['action'] ?? '';

if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_verify();
  try {
    if ($action==='create') {
      $title = trim((string)($_POST['title'] ?? ''));
      $platform = trim((string)($_POST['platform'] ?? ''));
      $description = trim((string)($_POST['description'] ?? ''));
      $cover_image = trim((string)($_POST['cover_image'] ?? ''));
      $images = trim((string)($_POST['images'] ?? ''));
      $url = trim((string)($_POST['url'] ?? ''));
      $url_backup = trim((string)($_POST['url_backup'] ?? ''));
      $mode = (string)($_POST['mode'] ?? 'forever');
      $is_active = (int)($_POST['is_active'] ?? 1) ? 1 : 0;

      if ($title==='') throw new Exception('Thiếu tên app.');
      if ($url==='') throw new Exception('Thiếu link tải.');
      if (!in_array($mode,['once','forever'],true)) $mode='forever';
      $token = app_link_token_new();

      $pdo->prepare("INSERT INTO app_links(vendor_id,token,title,platform,description,cover_image,images,url,url_backup,mode,is_active,created_at,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())")
        ->execute([$vid,$token,$title,$platform!==''?$platform:null,$description!==''?$description:null,$cover_image!==''?$cover_image:null,$images!==''?$images:null,$url,$url_backup!==''?$url_backup:null,$mode,$is_active]);

      $msg='Đã tạo link app.';
    }

    if ($action==='update') {
      $id=(int)($_POST['id'] ?? 0);
      $st=$pdo->prepare("SELECT * FROM app_links WHERE id=? AND vendor_id=? LIMIT 1");
      $st->execute([$id,$vid]);
      $row=$st->fetch(PDO::FETCH_ASSOC);
      if(!$row) throw new Exception('Không tồn tại.');

      $title = trim((string)($_POST['title'] ?? $row['title']));
      $platform = trim((string)($_POST['platform'] ?? ($row['platform'] ?? '')));
      $description = trim((string)($_POST['description'] ?? ($row['description'] ?? '')));
      $cover_image = trim((string)($_POST['cover_image'] ?? ($row['cover_image'] ?? '')));
      $images = trim((string)($_POST['images'] ?? ($row['images'] ?? '')));
      $url = trim((string)($_POST['url'] ?? $row['url']));
      $url_backup = trim((string)($_POST['url_backup'] ?? ($row['url_backup'] ?? '')));
      $mode = (string)($_POST['mode'] ?? $row['mode']);
      $is_active = (int)($_POST['is_active'] ?? $row['is_active']) ? 1 : 0;

      if($title==='') throw new Exception('Thiếu tên app.');
      if($url==='') throw new Exception('Thiếu link tải.');
      if(!in_array($mode,['once','forever'],true)) $mode='forever';

      $pdo->prepare("UPDATE app_links SET title=?,platform=?,description=?,cover_image=?,images=?,url=?,url_backup=?,mode=?,is_active=?,updated_at=NOW()
        WHERE id=? AND vendor_id=?")
        ->execute([$title,$platform!==''?$platform:null,$description!==''?$description:null,$cover_image!==''?$cover_image:null,$images!==''?$images:null,$url,$url_backup!==''?$url_backup:null,$mode,$is_active,$id,$vid]);

      $msg='Đã cập nhật.';
    }

    if ($action==='delete') {
      $id=(int)($_POST['id'] ?? 0);
      $pdo->prepare("DELETE FROM app_links WHERE id=? AND vendor_id=?")->execute([$id,$vid]);
      $msg='Đã xoá.';
    }
    if ($action==='regen') {
      $id=(int)($_POST['id'] ?? 0);
      $st=$pdo->prepare("SELECT id FROM app_links WHERE id=? AND vendor_id=? LIMIT 1");
      $st->execute([$id,$vid]);
      if(!$st->fetch()) throw new Exception('Không tồn tại.');
      $token=app_link_token_new();
      $pdo->prepare("UPDATE app_links SET token=?, used_at=NULL, used_ip=NULL, updated_at=NOW() WHERE id=? AND vendor_id=?")->execute([$token,$id,$vid]);
      $msg='Đã tạo token mới.';
    }
  } catch(Throwable $e) { $err=$e->getMessage(); }
}

$list=[];
$st=$pdo->prepare("SELECT * FROM app_links WHERE vendor_id=? ORDER BY id DESC LIMIT 200");
$st->execute([$vid]);
$list=$st->fetchAll(PDO::FETCH_ASSOC) ?: [];

$edit_id=(int)($_GET['edit'] ?? 0);
$edit=null;
foreach($list as $it){ if((int)$it['id']===$edit_id){ $edit=$it; break; } }
?>

<div class="flex items-center justify-between gap-3">
  <h1 class="text-xl font-extrabold">Apps của tôi</h1>
  <a class="btn btn-ghost" href="<?= e(base_url('/app')) ?>"><?= lucide_icon('external-link') ?> Xem trang tải app</a>
</div>

<?php if($msg): ?><div class="alert success mt-4"><?= e($msg) ?></div><?php endif; ?>
<?php if($err): ?><div class="alert error mt-4"><?= e($err) ?></div><?php endif; ?>

<div class="grid lg:grid-cols-2 gap-4 mt-4">
  <div class="card p-6">
    <h2 class="text-lg font-extrabold"><?= $edit?'Sửa':'Tạo' ?> link app</h2>
    <form class="mt-4 grid gap-3" method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="<?= $edit?'update':'create' ?>">
      <?php if($edit): ?><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><?php endif; ?>

      <div>
        <label class="label">Tên app</label>
        <input class="input" name="title" value="<?= e((string)($edit['title'] ?? '')) ?>" required>
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="label">Platform</label>
          <input class="input" name="platform" value="<?= e((string)($edit['platform'] ?? '')) ?>" placeholder="Android / iOS / Windows ...">
        </div>
        <div>
          <label class="label">Chế độ link</label>
          <?php $mode=(string)($edit['mode'] ?? 'forever'); ?>
          <select class="select" name="mode">
            <option value="forever" <?= $mode==='forever'?'selected':'' ?>>Vĩnh viễn</option>
            <option value="once" <?= $mode==='once'?'selected':'' ?>>Chỉ 1 lần</option>
          </select>
        </div>
      </div>

      <div>
        <label class="label">Mô tả</label>
        <textarea class="textarea" rows="4" name="description"><?= e((string)($edit['description'] ?? '')) ?></textarea>
      </div>

      <div>
        <label class="label">Cover image (URL)</label>
        <input class="input" name="cover_image" value="<?= e((string)($edit['cover_image'] ?? '')) ?>">
      </div>

      <div>
        <label class="label">Ảnh mô tả (nhiều URL, cách nhau bằng dấu phẩy)</label>
        <textarea class="textarea" rows="2" name="images"><?= e((string)($edit['images'] ?? '')) ?></textarea>
      </div>

      <div>
        <label class="label">Link tải chính</label>
        <input class="input" name="url" value="<?= e((string)($edit['url'] ?? '')) ?>" required>
      </div>
      <div>
        <label class="label">Link dự phòng (ẩn nếu không nhập)</label>
        <input class="input" name="url_backup" value="<?= e((string)($edit['url_backup'] ?? '')) ?>">
      </div>

      <div>
        <label class="label">Trạng thái</label>
        <?php $ac=(int)($edit['is_active'] ?? 1); ?>
        <select class="select" name="is_active">
          <option value="1" <?= $ac===1?'selected':'' ?>>Bật</option>
          <option value="0" <?= $ac===0?'selected':'' ?>>Tắt</option>
        </select>
      </div>

      <div class="flex gap-2">
        <button class="btn btn-primary" type="submit"><?= $edit?'Lưu':'Tạo' ?></button>
        <?php if($edit): ?><a class="btn btn-ghost" href="<?= e(base_url('/ctv/index.php?route=apps')) ?>">Huỷ</a><?php endif; ?>
      </div>
    </form>
  </div>

  <div class="card p-6">
    <h2 class="text-lg font-extrabold">Danh sách</h2>
    <div class="overflow-x-auto mt-4">
      <table class="table">
        <thead><tr><th>ID</th><th>Tên</th><th>Mode</th><th>Token</th><th></th></tr></thead>
        <tbody>
        <?php foreach($list as $it): ?>
          <tr>
            <td class="text-slate-500"><?= (int)$it['id'] ?></td>
            <td>
              <div class="font-semibold"><?= e($it['title']) ?></div>
              <div class="text-xs text-slate-500"><?= e($it['platform'] ?? '') ?> • <?= ((int)$it['is_active']===1)?'Bật':'Tắt' ?></div>
            </td>
            <td><?= e($it['mode']) ?></td>
            <td class="font-mono text-xs"><?= e(substr((string)$it['token'],0,14)).'…' ?></td>
            <td class="text-right">
              <a class="btn btn-ghost btn-sm" href="<?= e(base_url('/ctv/index.php?route=apps&edit='.(int)$it['id'])) ?>">Sửa</a>
              <form method="post" class="inline" onsubmit="return confirm('Regenerate token? Link cũ sẽ đổi.');">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="regen">
                <input type="hidden" name="id" value="<?= (int)$it['id'] ?>">
                <button class="btn btn-ghost btn-sm" type="submit">Regen</button>
              </form>
              <form method="post" class="inline" onsubmit="return confirm('Xoá link này?');">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$it['id'] ?>">
                <button class="btn btn-ghost btn-sm text-red-400" type="submit">Xoá</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if(!$list): ?><tr><td colspan="5" class="text-slate-500">Chưa có link app.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
