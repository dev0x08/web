<div class="card p-6">
  <h2 class="text-xl font-extrabold">404</h2>
  <p class="text-slate-400 mt-2">Không tìm thấy trang.</p>
</div>