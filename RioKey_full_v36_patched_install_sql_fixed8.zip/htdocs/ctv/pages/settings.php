<?php
$u=auth_user();
$vid=(int)$u['id'];
vendor_ensure_schema();
$pdo=db();

$msg=''; $err='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_verify();
  try {
    $payout = trim((string)($_POST['vendor_payout_info'] ?? ''));
    if (strlen($payout) > 2000) throw new Exception('Thông tin quá dài.');
    if (db_has_column('users','vendor_payout_info')) {
      $pdo->prepare("UPDATE users SET vendor_payout_info=? WHERE id=?")->execute([$payout!==''?$payout:null,$vid]);
      $msg='Đã lưu thông tin thanh toán.';
    } else {
      throw new Exception('DB chưa hỗ trợ vendor_payout_info.');
    }
  } catch(Throwable $e){ $err=$e->getMessage(); }
}

$st=$pdo->prepare("SELECT vendor_fee_percent,vendor_active,vendor_payout_info FROM users WHERE id=? LIMIT 1");
$st->execute([$vid]);
$row=$st->fetch(PDO::FETCH_ASSOC) ?: [];
$fee = $row['vendor_fee_percent'] ?? null;
$active = (int)($row['vendor_active'] ?? 1);
$payout = (string)($row['vendor_payout_info'] ?? '');
$defaultFee = setting('vendor_fee_percent_default','10');
?>

<div class="flex items-center justify-between gap-3">
  <h1 class="text-xl font-extrabold">Cài đặt CTV</h1>
</div>

<?php if($msg): ?><div class="alert success mt-4"><?= e($msg) ?></div><?php endif; ?>
<?php if($err): ?><div class="alert error mt-4"><?= e($err) ?></div><?php endif; ?>

<div class="grid lg:grid-cols-2 gap-4 mt-4">
  <div class="card p-6">
    <h2 class="text-lg font-extrabold">Thông tin tài khoản</h2>
    <div class="mt-3 text-sm text-slate-500">
      Trạng thái: <b class="text-white"><?= $active===1?'Đang hoạt động':'Bị tắt' ?></b><br>
      % chiết khấu theo tài khoản: <b class="text-white"><?= $fee===null||$fee===''?'(không set)':e($fee.'%') ?></b><br>
      % mặc định hệ thống: <b class="text-white"><?= e($defaultFee) ?>%</b>
    </div>
    <div class="text-xs text-slate-500 mt-3">
      Lưu ý: % thực tế có thể bị override theo từng sản phẩm (nếu bạn set ở sản phẩm).
    </div>
  </div>

  <div class="card p-6">
    <h2 class="text-lg font-extrabold">Thông tin nhận tiền</h2>
    <form method="post" class="mt-4 grid gap-3">
      <?= csrf_field() ?>
      <div>
        <label class="label">Thông tin chuyển khoản</label>
        <textarea class="textarea" name="vendor_payout_info" rows="6" placeholder="VD: Ngân hàng, Số tài khoản, Chủ tài khoản, Ghi chú..." ><?= e($payout) ?></textarea>
        <div class="text-xs text-slate-500 mt-1">Admin sẽ dùng thông tin này để trả tiền khi bạn yêu cầu rút.</div>
      </div>
      <button class="btn btn-primary" type="submit"><?= lucide_icon('save') ?> Lưu</button>
    </form>
  </div>
</div>
