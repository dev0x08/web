<?php
$u = auth_user();
$vid = (int)$u['id'];
vendor_ensure_schema(); shop_ensure_schema(); app_links_ensure_schema();
$vw = vendor_wallet_get($vid);

// stats
$pdo = db();
$products = 0; $apps = 0; $stock = 0; $orders = 0; $gross = 0; $fee = 0; $net = 0; $pending_w = 0;

try {
  $products = (int)$pdo->query("SELECT COUNT(*) FROM shop_products WHERE vendor_id={$vid}")->fetchColumn();
} catch(Throwable $e){}
try {
  $apps = (int)$pdo->query("SELECT COUNT(*) FROM app_links WHERE vendor_id={$vid}")->fetchColumn();
} catch(Throwable $e){}
try {
  $stock = (int)$pdo->query("SELECT COUNT(*) FROM shop_keys WHERE vendor_id={$vid} AND is_sold=0")->fetchColumn();
} catch(Throwable $e){}
try {
  $st = $pdo->prepare("SELECT COUNT(*) c, COALESCE(SUM(amount_vnd),0) g, COALESCE(SUM(vendor_fee_vnd),0) f, COALESCE(SUM(vendor_net_vnd),0) n
    FROM shop_orders WHERE vendor_id=? AND pay_method='wallet'");
  $st->execute([$vid]);
  $r = $st->fetch(PDO::FETCH_ASSOC) ?: [];
  $orders = (int)($r['c'] ?? 0);
  $gross = (int)($r['g'] ?? 0);
  $fee = (int)($r['f'] ?? 0);
  $net = (int)($r['n'] ?? 0);
} catch(Throwable $e){}
try {
  $st = $pdo->prepare("SELECT COUNT(*) FROM vendor_withdrawals WHERE vendor_id=? AND status='pending'");
  $st->execute([$vid]);
  $pending_w = (int)$st->fetchColumn();
} catch(Throwable $e){}

$recent = vendor_list_orders($vid, 10);
?>

<div class="grid lg:grid-cols-4 gap-4">
  <div class="card p-5">
    <div class="text-xs text-slate-500">Số dư khả dụng</div>
    <div class="text-2xl font-extrabold mt-1"><?= e(money_vnd((int)$vw['balance'])) ?></div>
    <div class="text-xs text-slate-500 mt-1">Locked: <?= e(money_vnd((int)$vw['locked'])) ?></div>
  </div>
  <div class="card p-5">
    <div class="text-xs text-slate-500">Sản phẩm</div>
    <div class="text-2xl font-extrabold mt-1"><?= (int)$products ?></div>
    <div class="text-xs text-slate-500 mt-1">Tồn key: <?= (int)$stock ?></div>
  </div>
  <div class="card p-5">
    <div class="text-xs text-slate-500">Doanh thu (wallet)</div>
    <div class="text-2xl font-extrabold mt-1"><?= e(money_vnd($gross)) ?></div>
    <div class="text-xs text-slate-500 mt-1">Phí: <?= e(money_vnd($fee)) ?> • Nhận: <?= e(money_vnd($net)) ?></div>
  </div>
  <div class="card p-5">
    <div class="text-xs text-slate-500">Yêu cầu rút (pending)</div>
    <div class="text-2xl font-extrabold mt-1"><?= (int)$pending_w ?></div>
    <div class="text-xs text-slate-500 mt-1">Apps: <?= (int)$apps ?></div>
  </div>
</div>

<div class="card p-6 mt-4">
  <div class="flex items-center justify-between gap-3">
    <h2 class="text-lg font-extrabold">Đơn hàng gần đây</h2>
    <a class="btn btn-ghost" href="<?= e(base_url('/ctv/index.php?route=orders')) ?>">Xem tất cả</a>
  </div>

  <div class="overflow-x-auto mt-4">
    <table class="table">
      <thead>
        <tr>
          <th>Mã</th><th>Sản phẩm</th><th>Giá</th><th>Phí</th><th>CTV nhận</th><th>Thời gian</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($recent as $o): ?>
        <tr>
          <td class="font-mono text-xs"><?= e($o['order_code'] ?? '') ?></td>
          <td><?= e($o['product_title'] ?? '') ?></td>
          <td><?= e(money_vnd((int)($o['amount_vnd'] ?? 0))) ?></td>
          <td><?= e(money_vnd((int)($o['vendor_fee_vnd'] ?? 0))) ?></td>
          <td><?= e(money_vnd((int)($o['vendor_net_vnd'] ?? 0))) ?></td>
          <td class="text-slate-500 text-sm"><?= e($o['created_at'] ?? '') ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$recent): ?>
        <tr><td colspan="6" class="text-slate-500">Chưa có đơn nào.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
