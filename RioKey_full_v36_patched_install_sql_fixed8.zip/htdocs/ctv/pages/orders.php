<?php
$u=auth_user();
$vid=(int)$u['id'];
vendor_ensure_schema();
shop_ensure_schema();

$orders = vendor_list_orders($vid, 200);
?>
<div class="flex items-center justify-between gap-3">
  <h1 class="text-xl font-extrabold">Đơn hàng (CTV)</h1>
</div>

<div class="card p-6 mt-4">
  <div class="overflow-x-auto">
    <table class="table">
      <thead>
        <tr>
          <th>Mã</th><th>Sản phẩm</th><th>User</th><th>Giá</th><th>Phí</th><th>CTV nhận</th><th>Thời gian</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach($orders as $o): ?>
        <tr>
          <td class="font-mono text-xs"><?= e($o['order_code'] ?? '') ?></td>
          <td><?= e($o['product_title'] ?? '') ?></td>
          <td class="text-slate-500">#<?= (int)($o['user_id'] ?? 0) ?></td>
          <td><?= e(money_vnd((int)($o['amount_vnd'] ?? 0))) ?></td>
          <td><?= e(money_vnd((int)($o['vendor_fee_vnd'] ?? 0))) ?></td>
          <td><?= e(money_vnd((int)($o['vendor_net_vnd'] ?? 0))) ?></td>
          <td class="text-slate-500 text-sm"><?= e($o['created_at'] ?? '') ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if(!$orders): ?>
        <tr><td colspan="7" class="text-slate-500">Chưa có đơn.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
