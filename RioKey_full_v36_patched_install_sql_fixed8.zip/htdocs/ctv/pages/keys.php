<?php
$u = auth_user();
$vid = (int)$u['id'];
vendor_ensure_schema();
shop_ensure_schema();

$pdo = db();
$msg = '';
$err = '';

$pid = (int)($_GET['product_id'] ?? 0);

// Load products
$products = [];
$stP = $pdo->prepare("SELECT id,title,category,is_active FROM shop_products WHERE vendor_id=? ORDER BY id DESC");
$stP->execute([$vid]);
$products = $stP->fetchAll(PDO::FETCH_ASSOC) ?: [];
if ($pid === 0 && $products) $pid = (int)$products[0]['id'];

$action = $_POST['action'] ?? '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_verify();
  try {
    if ($action === 'import') {
      $product_id = (int)($_POST['product_id'] ?? 0);
      $st = $pdo->prepare("SELECT id FROM shop_products WHERE id=? AND vendor_id=? LIMIT 1");
      $st->execute([$product_id,$vid]);
      if (!$st->fetch()) throw new Exception('Sản phẩm không hợp lệ.');

      $text = (string)($_POST['keys'] ?? '');
      $lines = preg_split('/\r\n|\r|\n/', $text);
      $cnt = shop_import_keys($product_id, $lines);
      if ($cnt <= 0) throw new Exception('Không thêm được key (có thể trùng hoặc rỗng).');
      $msg = "Đã thêm $cnt key.";
      $pid = $product_id;
    }

    if ($action === 'disable_key') {
      $kid = (int)($_POST['key_id'] ?? 0);
      if (!db_has_column('shop_keys','is_disabled')) throw new Exception('Bản DB chưa hỗ trợ is_disabled.');
      // ensure key belongs to vendor (by product vendor_id)
      $st = $pdo->prepare("SELECT k.id FROM shop_keys k JOIN shop_products p ON p.id=k.product_id WHERE k.id=? AND p.vendor_id=? LIMIT 1");
      $st->execute([$kid,$vid]);
      if (!$st->fetch()) throw new Exception('Key không hợp lệ.');
      $pdo->prepare("UPDATE shop_keys SET is_disabled=1 WHERE id=?")->execute([$kid]);
      $msg = 'Đã khoá key.';
    }
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

// List keys of selected product
$keys = [];
if ($pid > 0) {
  $st = $pdo->prepare("SELECT k.* FROM shop_keys k WHERE k.product_id=? ORDER BY k.id DESC LIMIT 200");
  $st->execute([$pid]);
  $keys = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}
?>

<div class="flex items-center justify-between gap-3">
  <h1 class="text-xl font-extrabold">Kho key (CTV)</h1>
  <a class="btn btn-ghost" href="<?= e(base_url('/ctv/index.php?route=products')) ?>"><?= lucide_icon('package') ?> Quản lý sản phẩm</a>
</div>

<?php if ($msg): ?><div class="alert success mt-4"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert error mt-4"><?= e($err) ?></div><?php endif; ?>

<div class="grid lg:grid-cols-2 gap-4 mt-4">
  <div class="card p-6">
    <h2 class="text-lg font-extrabold">Nhập key</h2>
    <form class="mt-4 grid gap-3" method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="import">
      <div>
        <label class="label">Chọn sản phẩm</label>
        <select class="select" name="product_id" onchange="location.href='<?= e(base_url('/ctv/index.php?route=keys&product_id=')) ?>'+this.value">
          <?php foreach ($products as $p): ?>
            <option value="<?= (int)$p['id'] ?>" <?= ((int)$p['id']===$pid)?'selected':'' ?>>#<?= (int)$p['id'] ?> — <?= e($p['title']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="label">Danh sách key (mỗi dòng 1 key)</label>
        <textarea class="textarea font-mono" rows="10" name="keys" placeholder="AAAA-BBBB-CCCC&#10;...." required></textarea>
        <div class="text-xs text-slate-500 mt-1">Hệ thống tự chống trùng theo SHA256, và giao key theo thứ tự.</div>
      </div>
      <button class="btn btn-primary" type="submit">Nhập key</button>
    </form>
  </div>

  <div class="card p-6">
    <div class="flex items-center justify-between gap-2">
      <h2 class="text-lg font-extrabold">Danh sách key (200 gần nhất)</h2>
      <div class="text-xs text-slate-500">Ẩn key trên UI user, chỉ lộ ở Kho key user.</div>
    </div>
    <div class="overflow-x-auto mt-4">
      <table class="table">
        <thead>
          <tr><th>ID</th><th>Trạng thái</th><th>Key</th><th></th></tr>
        </thead>
        <tbody>
        <?php foreach ($keys as $k): ?>
          <tr>
            <td class="text-slate-500"><?= (int)$k['id'] ?></td>
            <td>
              <?php if ((int)$k['is_sold']===1): ?>
                <span class="badge">Đã bán</span>
              <?php else: ?>
                <span class="badge green">Chưa bán</span>
              <?php endif; ?>
              <?php if (isset($k['is_disabled']) && (int)$k['is_disabled']===1): ?>
                <span class="badge red ml-1">Khoá</span>
              <?php endif; ?>
            </td>
            <td class="font-mono text-xs truncate max-w-[260px]"><?= e(substr((string)$k['key_code'],0,38)) ?><?= strlen((string)$k['key_code'])>38?'…':'' ?></td>
            <td class="text-right">
              <?php if ((int)$k['is_sold']===0 && (!isset($k['is_disabled']) || (int)$k['is_disabled']===0)): ?>
                <form method="post" class="inline" onsubmit="return confirm('Khoá key này?');">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="disable_key">
                  <input type="hidden" name="key_id" value="<?= (int)$k['id'] ?>">
                  <button class="btn btn-ghost btn-sm text-amber-300" type="submit">Khoá</button>
                </form>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$keys): ?>
          <tr><td colspan="4" class="text-slate-500">Chưa có key.</td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
