<?php
$u=auth_user();
$vid=(int)$u['id'];
vendor_ensure_schema();
$pdo=db();

$msg=''; $err='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_verify();
  try {
    $amount = (float)str_replace(',','.', (string)($_POST['amount'] ?? '0'));
    $res = vendor_request_withdraw($vid, $amount);
    if (!$res['ok']) throw new Exception($res['error'] ?? 'Không rút được.');
    $msg='Đã gửi yêu cầu rút tiền. ID #'.(int)$res['id'];
  } catch(Throwable $e){ $err=$e->getMessage(); }
}

$vw = vendor_wallet_get($vid);
$list=[];
try{
  $st=$pdo->prepare("SELECT * FROM vendor_withdrawals WHERE vendor_id=? ORDER BY id DESC LIMIT 200");
  $st->execute([$vid]);
  $list=$st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}catch(Throwable $e){}
?>

<div class="flex items-center justify-between gap-3">
  <h1 class="text-xl font-extrabold">Rút tiền</h1>
</div>

<?php if($msg): ?><div class="alert success mt-4"><?= e($msg) ?></div><?php endif; ?>
<?php if($err): ?><div class="alert error mt-4"><?= e($err) ?></div><?php endif; ?>

<div class="grid lg:grid-cols-2 gap-4 mt-4">
  <div class="card p-6">
    <h2 class="text-lg font-extrabold">Tạo yêu cầu rút</h2>
    <div class="mt-2 text-sm text-slate-500">Khả dụng: <b class="text-white"><?= e(money_vnd((int)$vw['balance'])) ?></b> • Locked: <?= e(money_vnd((int)$vw['locked'])) ?></div>
    <form method="post" class="mt-4 grid gap-3">
      <?= csrf_field() ?>
      <div>
        <label class="label">Số tiền muốn rút (VNĐ)</label>
        <input class="input" name="amount" type="number" min="0" step="1000" required>
        <div class="text-xs text-slate-500 mt-1">Tối thiểu: <?= e(money_vnd((int)setting('vendor_withdraw_min', 50000))) ?></div>
      </div>
      <button class="btn btn-primary" type="submit"><?= lucide_icon('send') ?> Gửi yêu cầu</button>
    </form>
    <div class="text-xs text-slate-500 mt-3">
      Lưu ý: Yêu cầu sẽ chuyển sang trạng thái <b>pending</b>. Admin sẽ xử lý chuyển khoản theo quy trình nội bộ.
    </div>
  </div>

  <div class="card p-6">
    <h2 class="text-lg font-extrabold">Lịch sử yêu cầu</h2>
    <div class="overflow-x-auto mt-4">
      <table class="table">
        <thead><tr><th>ID</th><th>Số tiền</th><th>Trạng thái</th><th>Thời gian</th></tr></thead>
        <tbody>
        <?php foreach($list as $w): ?>
          <tr>
            <td class="text-slate-500">#<?= (int)$w['id'] ?></td>
            <td><?= e(money_vnd((int)$w['amount'])) ?></td>
            <td><span class="badge"><?= e($w['status']) ?></span></td>
            <td class="text-slate-500 text-sm"><?= e($w['created_at']) ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if(!$list): ?><tr><td colspan="4" class="text-slate-500">Chưa có yêu cầu.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
