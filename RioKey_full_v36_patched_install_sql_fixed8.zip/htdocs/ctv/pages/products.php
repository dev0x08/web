<?php
$u = auth_user();
$vid = (int)$u['id'];
vendor_ensure_schema();
shop_ensure_schema();

$pdo = db();
$msg = '';
$err = '';

$action = $_POST['action'] ?? '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_verify();
  try {
    if ($action === 'create') {
      $title = trim((string)($_POST['title'] ?? ''));
      $category = trim((string)($_POST['category'] ?? 'game_key'));
      $icon = trim((string)($_POST['icon'] ?? ''));
      $image_url = trim((string)($_POST['image_url'] ?? ''));
      $price_vnd = (int)($_POST['price_vnd'] ?? 0);
      $points_price = (int)($_POST['points_price'] ?? 0);
      $vendor_fee_percent = trim((string)($_POST['vendor_fee_percent'] ?? ''));
      $description = trim((string)($_POST['description'] ?? ''));
      $is_active = (int)($_POST['is_active'] ?? 1) ? 1 : 0;

      if ($title === '') throw new Exception('Thiếu tên sản phẩm');
      if (!in_array($category, ['game_key','giftcard','account'], true)) $category = 'game_key';
      $slug = slug($title);

      $st = $pdo->prepare("INSERT INTO shop_products(title,slug,category,icon,image_url,price_vnd,points_price,description,is_active,vendor_id,vendor_fee_percent,created_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,NOW())");
      $st->execute([
        $title,$slug,$category,
        $icon!==''?$icon:null,
        $image_url!==''?$image_url:null,
        $price_vnd,$points_price,
        $description!==''?$description:null,
        $is_active,
        $vid,
        ($vendor_fee_percent!==''? (float)str_replace(',','.', $vendor_fee_percent) : null),
      ]);
      $msg = 'Đã tạo sản phẩm.';
    }

    if ($action === 'update') {
      $id = (int)($_POST['id'] ?? 0);
      $st0 = $pdo->prepare("SELECT * FROM shop_products WHERE id=? AND vendor_id=? LIMIT 1");
      $st0->execute([$id,$vid]);
      $row = $st0->fetch(PDO::FETCH_ASSOC);
      if (!$row) throw new Exception('Không tìm thấy sản phẩm.');

      $title = trim((string)($_POST['title'] ?? $row['title']));
      $category = trim((string)($_POST['category'] ?? $row['category']));
      $icon = trim((string)($_POST['icon'] ?? ($row['icon'] ?? '')));
      $image_url = trim((string)($_POST['image_url'] ?? ($row['image_url'] ?? '')));
      $price_vnd = (int)($_POST['price_vnd'] ?? $row['price_vnd']);
      $points_price = (int)($_POST['points_price'] ?? $row['points_price']);
      $vendor_fee_percent = trim((string)($_POST['vendor_fee_percent'] ?? ($row['vendor_fee_percent'] ?? '')));
      $description = trim((string)($_POST['description'] ?? ($row['description'] ?? '')));
      $is_active = (int)($_POST['is_active'] ?? $row['is_active']) ? 1 : 0;

      if ($title === '') throw new Exception('Thiếu tên sản phẩm');
      if (!in_array($category, ['game_key','giftcard','account'], true)) $category = 'game_key';
      $slug = slug($title);

      $pdo->prepare("UPDATE shop_products SET title=?, slug=?, category=?, icon=?, image_url=?, price_vnd=?, points_price=?, description=?, is_active=?, vendor_fee_percent=? WHERE id=? AND vendor_id=?")
        ->execute([
          $title,$slug,$category,
          $icon!==''?$icon:null,
          $image_url!==''?$image_url:null,
          $price_vnd,$points_price,
          $description!==''?$description:null,
          $is_active,
          ($vendor_fee_percent!==''? (float)str_replace(',','.', $vendor_fee_percent) : null),
          $id,$vid
        ]);
      $msg = 'Đã cập nhật.';
    }

    if ($action === 'delete') {
      $id = (int)($_POST['id'] ?? 0);
      $pdo->prepare("DELETE FROM shop_products WHERE id=? AND vendor_id=?")->execute([$id,$vid]);
      $msg = 'Đã xoá.';
    }
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$items = [];
try {
  $st = $pdo->prepare("SELECT p.*,
    (SELECT COUNT(*) FROM shop_keys k WHERE k.product_id=p.id AND k.is_sold=0) AS stock
    FROM shop_products p WHERE p.vendor_id=? ORDER BY p.id DESC");
  $st->execute([$vid]);
  $items = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

$edit_id = (int)($_GET['edit'] ?? 0);
$edit = null;
if ($edit_id) {
  foreach ($items as $it) if ((int)$it['id'] === $edit_id) { $edit = $it; break; }
}
?>

<div class="flex items-center justify-between gap-3">
  <h1 class="text-xl font-extrabold">Sản phẩm của tôi</h1>
  <a class="btn btn-ghost" href="<?= e(base_url('/ctv/index.php?route=keys')) ?>"><?= lucide_icon('key') ?> Quản lý key</a>
</div>

<?php if ($msg): ?><div class="alert success mt-4"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert error mt-4"><?= e($err) ?></div><?php endif; ?>

<div class="grid lg:grid-cols-2 gap-4 mt-4">
  <div class="card p-6">
    <h2 class="text-lg font-extrabold"><?= $edit ? 'Sửa sản phẩm' : 'Tạo sản phẩm' ?></h2>
    <form class="mt-4 grid gap-3" method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="<?= $edit ? 'update' : 'create' ?>">
      <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><?php endif; ?>

      <div>
        <label class="label">Tên sản phẩm</label>
        <input class="input" name="title" value="<?= e($edit['title'] ?? '') ?>" required>
      </div>

      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="label">Chuyên mục</label>
          <select class="select" name="category">
            <?php $cat = (string)($edit['category'] ?? 'game_key'); ?>
            <option value="game_key" <?= $cat==='game_key'?'selected':'' ?>>Key game</option>
            <option value="giftcard" <?= $cat==='giftcard'?'selected':'' ?>>Giftcard</option>
            <option value="account" <?= $cat==='account'?'selected':'' ?>>Tài khoản</option>
          </select>
        </div>
        <div>
          <label class="label">Active</label>
          <?php $ac = (int)($edit['is_active'] ?? 1); ?>
          <select class="select" name="is_active">
            <option value="1" <?= $ac===1?'selected':'' ?>>Bật</option>
            <option value="0" <?= $ac===0?'selected':'' ?>>Tắt</option>
          </select>
        </div>
      </div>

      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="label">Giá VNĐ</label>
          <input class="input" name="price_vnd" type="number" min="0" value="<?= e((string)($edit['price_vnd'] ?? 0)) ?>">
        </div>
        <div>
          <label class="label">Giá điểm</label>
          <input class="input" name="points_price" type="number" min="0" value="<?= e((string)($edit['points_price'] ?? 0)) ?>">
        </div>
      </div>

      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="label">Icon (lucide name)</label>
          <input class="input" name="icon" value="<?= e((string)($edit['icon'] ?? '')) ?>" placeholder="key / gamepad-2 / gift ...">
        </div>
        <div>
          <label class="label">Ảnh (URL)</label>
          <input class="input" name="image_url" value="<?= e((string)($edit['image_url'] ?? '')) ?>" placeholder="https://...">
        </div>
      </div>

      <div>
        <label class="label">Chiết khấu % (tuỳ chọn)</label>
        <input class="input" name="vendor_fee_percent" value="<?= e((string)($edit['vendor_fee_percent'] ?? '')) ?>" placeholder="vd: 10">
        <div class="text-xs text-slate-500 mt-1">Để trống = dùng % mặc định (Admin setting) hoặc % theo tài khoản CTV.</div>
      </div>

      <div>
        <label class="label">Mô tả</label>
        <textarea class="textarea" name="description" rows="5"><?= e((string)($edit['description'] ?? '')) ?></textarea>
      </div>

      <div class="flex gap-2">
        <button class="btn btn-primary" type="submit"><?= $edit ? 'Lưu' : 'Tạo' ?></button>
        <?php if ($edit): ?>
          <a class="btn btn-ghost" href="<?= e(base_url('/ctv/index.php?route=products')) ?>">Huỷ</a>
        <?php endif; ?>
      </div>
    </form>
  </div>

  <div class="card p-6">
    <h2 class="text-lg font-extrabold">Danh sách</h2>
    <div class="overflow-x-auto mt-4">
      <table class="table">
        <thead>
          <tr><th>ID</th><th>Tên</th><th>Giá</th><th>Tồn</th><th></th></tr>
        </thead>
        <tbody>
        <?php foreach ($items as $it): ?>
          <tr>
            <td class="text-slate-500"><?= (int)$it['id'] ?></td>
            <td>
              <div class="font-semibold"><?= e($it['title']) ?></div>
              <div class="text-xs text-slate-500"><?= e($it['category']) ?> • <?= ((int)$it['is_active']===1)?'Bật':'Tắt' ?></div>
            </td>
            <td>
              <div><?= e(money_vnd((int)$it['price_vnd'])) ?></div>
              <div class="text-xs text-slate-500"><?= (int)$it['points_price'] ?> điểm</div>
            </td>
            <td class="font-semibold"><?= (int)($it['stock'] ?? 0) ?></td>
            <td class="text-right">
              <a class="btn btn-ghost btn-sm" href="<?= e(base_url('/ctv/index.php?route=products&edit='.(int)$it['id'])) ?>">Sửa</a>
              <form method="post" class="inline" onsubmit="return confirm('Xoá sản phẩm này?');">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$it['id'] ?>">
                <button class="btn btn-ghost btn-sm text-red-400" type="submit">Xoá</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$items): ?>
          <tr><td colspan="5" class="text-slate-500">Chưa có sản phẩm. Tạo bên trái.</td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
