<?php
$u = auth_user();
$route = request_route('dashboard');
$route = explode('/', $route)[0];
$vw = vendor_wallet_get((int)$u['id']);
?>
<!-- Mobile overlay -->
<div x-show="sidebarOpen" x-transition.opacity class="fixed inset-0 z-40 bg-black/60 lg:hidden" @click="sidebarOpen=false"></div>

<!-- Sidebar -->
<aside class="fixed z-50 inset-y-0 left-0 w-[280px] bg-[#0b1220] border-r border-white/10
             transform transition lg:translate-x-0 lg:z-auto lg:block"
      :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'">
  <div class="h-16 px-4 flex items-center justify-between border-b border-white/10">
    <div class="font-extrabold text-lg">RioKey</div>
    <button class="lg:hidden btn btn-ghost" type="button" @click="sidebarOpen=false"><?= lucide_icon('x') ?></button>
  </div>

  <div class="p-4">
    <div class="p-4 rounded-2xl bg-white/5 border border-white/10">
      <div class="text-xs text-slate-500">Số dư CTV</div>
      <div class="text-2xl font-extrabold mt-1"><?= e(money_vnd((int)$vw['balance'])) ?></div>
      <div class="text-xs text-slate-500 mt-2">Locked: <?= e(money_vnd((int)$vw['locked'])) ?></div>
    </div>

    <nav class="mt-4 grid gap-1">
      <a @click="sidebarOpen=false" class="nav-item <?= ($route==='dashboard')?'active':'' ?>" href="<?= e(base_url('/ctv/index.php?route=dashboard')) ?>">
        <?= lucide_icon('layout-dashboard') ?><span>Dashboard</span>
      </a>
      <a @click="sidebarOpen=false" class="nav-item <?= ($route==='products')?'active':'' ?>" href="<?= e(base_url('/ctv/index.php?route=products')) ?>">
        <?= lucide_icon('package') ?><span>Sản phẩm</span>
      </a>
      <a @click="sidebarOpen=false" class="nav-item <?= ($route==='keys')?'active':'' ?>" href="<?= e(base_url('/ctv/index.php?route=keys')) ?>">
        <?= lucide_icon('key') ?><span>Kho key</span>
      </a>
      <a @click="sidebarOpen=false" class="nav-item <?= ($route==='apps')?'active':'' ?>" href="<?= e(base_url('/ctv/index.php?route=apps')) ?>">
        <?= lucide_icon('smartphone') ?><span>Apps</span>
      </a>
      <a @click="sidebarOpen=false" class="nav-item <?= ($route==='orders')?'active':'' ?>" href="<?= e(base_url('/ctv/index.php?route=orders')) ?>">
        <?= lucide_icon('receipt') ?><span>Đơn hàng</span>
      </a>
      <a @click="sidebarOpen=false" class="nav-item <?= ($route==='withdrawals')?'active':'' ?>" href="<?= e(base_url('/ctv/index.php?route=withdrawals')) ?>">
        <?= lucide_icon('wallet') ?><span>Rút tiền</span>
      </a>
      <a @click="sidebarOpen=false" class="nav-item <?= ($route==='settings')?'active':'' ?>" href="<?= e(base_url('/ctv/index.php?route=settings')) ?>">
        <?= lucide_icon('settings') ?><span>Cài đặt</span>
      </a>
    </nav>

    <?php if (is_admin()): ?>
      <div class="mt-4 pt-4 border-t border-white/10">
        <a class="nav-item" href="<?= e(base_url('/admin/')) ?>">
          <?= lucide_icon('shield') ?><span>Admin Panel</span>
        </a>
      </div>
    <?php endif; ?>
  </div>
</aside>
