<?php $u = auth_user(); ?>
<header class="sticky top-0 z-20 bg-[#0b1220]/80 backdrop-blur border-b border-white/10">
  <div class="px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-3">
    <div class="flex items-center gap-3">
      <button class="lg:hidden btn btn-ghost" type="button" @click="sidebarOpen=true">
        <?= lucide_icon('menu') ?>
      </button>
      <div>
        <div class="font-extrabold">RioKey — CTV</div>
        <div class="text-xs text-slate-500">Quản lý sản phẩm & doanh thu của bạn</div>
      </div>
    </div>

    <div class="flex items-center gap-2">
      <a class="btn btn-ghost" href="<?= e(base_url('/')) ?>" title="Về trang user">
        <?= lucide_icon('home') ?>
        <span class="hidden sm:inline">Trang user</span>
      </a>
      <a class="btn btn-ghost" href="<?= e(base_url('/ctv/index.php?route=logout')) ?>">
        <?= lucide_icon('log-out') ?>
        <span class="hidden sm:inline">Đăng xuất</span>
      </a>
    </div>
  </div>
</header>
