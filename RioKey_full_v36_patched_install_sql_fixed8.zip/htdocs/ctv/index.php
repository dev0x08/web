<?php
// Installer guard
if (!file_exists(__DIR__ . '/../config.php')) {
  header('Location: ' . rtrim(dirname($_SERVER['SCRIPT_NAME']),'/') . '/..install/');
  exit;
}
if (is_dir(__DIR__ . '/../install') && file_exists(__DIR__ . '/../install' . '/installed.lock')) {
  http_response_code(500);
  echo '<!doctype html><meta charset="utf-8"><title>Security</title><style>body{font-family:system-ui;background:#0b0b10;color:#fff;display:grid;place-items:center;min-height:100vh;margin:0} .box{max-width:720px;padding:28px;border:1px solid rgba(255,255,255,.12);border-radius:18px;background:rgba(255,255,255,.04)} a{color:#fb923c}</style><div class="box"><h2>⚠️ Vui lòng xoá thư mục <code>install</code></h2><p>Bạn đã cài đặt xong. Để bảo mật, hãy xoá thư mục <code>/install</code> khỏi hosting rồi refresh lại.</p></div>';
  exit;
}
?>
require_once __DIR__ . '/../bootstrap.php';
require_vendor();

// hide user bottom nav in ctv area
$IS_ADMIN_AREA = true;

$route = request_route('dashboard');
$route = explode('/', $route)[0];

$allowed_vendor = ['dashboard','products','keys','apps','orders','withdrawals','settings','logout','404'];
if (!in_array($route, $allowed_vendor, true)) {
  $route = '404';
  http_response_code(404);
}

$titleMap = [
  'dashboard' => 'CTV Dashboard',
  'products'  => 'Sản phẩm của tôi',
  'keys'      => 'Kho key (CTV)',
  'apps'      => 'App của tôi',
  'orders'    => 'Đơn hàng',
  'withdrawals' => 'Rút tiền',
  'settings'  => 'Cài đặt',
  '404'       => 'Not Found',
];
$title = $titleMap[$route] ?? 'CTV';

?>
<?php include __DIR__ . '/../inc/head.php'; ?>
<div x-data="{ sidebarOpen:false }">
  <div class="min-h-screen lg:flex">
    <?php include __DIR__ . '/sidebar.php'; ?>
    <div class="flex-1 lg:pl-[280px]">
      <?php include __DIR__ . '/topbar.php'; ?>
      <main class="px-4 sm:px-6 lg:px-8 py-6 pb-10">
        <?php include __DIR__ . "/pages/{$route}.php"; ?>
      </main>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../inc/foot.php'; ?>
