<?php
require_once __DIR__ . '/bootstrap.php';

// If maintenance is off, go home
if (!setting_get('maintenance_enabled', false)) {
  if (auth_user()) redirect(base_url('/dashboard'));
  redirect(base_url('/auth/login.php'));
}

$title = "Bảo trì";
include __DIR__ . '/inc/head.php';
?>
<div class="min-h-screen grid place-items-center px-4">
  <div class="w-full max-w-lg card p-7 text-center">
    <div class="mx-auto w-14 h-14 rounded-2xl bg-orange-500/10 border border-orange-500/20 grid place-items-center">
      <?= lucide_icon('construction','w-7 h-7 text-orange-300') ?>
    </div>
    <div class="text-2xl font-black mt-4">Website đang bảo trì</div>
    <div class="text-slate-400 mt-2 leading-relaxed">
      Hệ thống đang được nâng cấp. Vui lòng quay lại sau.
    </div>
    <div class="mt-6 text-xs text-slate-500">Nếu bạn là Admin, truy cập /admin/dashboard để vào quản trị.</div>
  </div>
</div>
<?php include __DIR__ . '/inc/foot.php'; ?>
