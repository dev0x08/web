<?php
// Installer guard
if (!file_exists(__DIR__ . '/config.php')) {
  header('Location: ' . rtrim(dirname($_SERVER['SCRIPT_NAME']),'/') . '/install/');
  exit;
}
if (is_dir(__DIR__ . '/install') && file_exists(__DIR__ . '/install/installed.lock')) {
  http_response_code(500);
  echo '<!doctype html><meta charset="utf-8"><title>Security</title><style>body{font-family:system-ui;background:#0b0b10;color:#fff;display:grid;place-items:center;min-height:100vh;margin:0} .box{max-width:720px;padding:28px;border:1px solid rgba(255,255,255,.12);border-radius:18px;background:rgba(255,255,255,.04)} a{color:#fb923c}</style><div class="box"><h2>⚠️ Vui lòng xoá thư mục <code>install</code></h2><p>Bạn đã cài đặt xong. Để bảo mật, hãy xoá thư mục <code>/install</code> khỏi hosting rồi refresh lại.</p><p>Nếu bạn chưa xoá được: dùng File Manager/FTP để xoá.</p></div>';
  exit;
}
?>
require_once __DIR__ . '/bootstrap.php';
require_auth();

$route = request_route('dashboard');
// Routes for RioKey (shop key/code game).
$allowed = ['go','dashboard','shop','orders','my_keys','wallet','topup','redeem','vip','lootbox','spin','profile','badges','wishlist','product','showcase','gifts','gift','app','app_download','notifications','missions','rewards','community','guide','referral','help','support','pricing','activity_feed','404','ticket','ticket_view'];
$route = explode('/', $route)[0];
// Backward compatible redirect for old links.
if ($route === 'cashback') redirect(route_url('shop'));
if (!in_array($route, $allowed, true)) {
  $route = '404';
  http_response_code(404);
}


// Feature gate: if disabled, hide from sidebar and block direct access
$gate = [
  'wishlist' => 'wishlist_enabled',
  'lootbox'  => 'lootbox_enabled',
  'spin'     => 'spin_enabled',
  'vip'      => 'vip_enabled',
  'gifts'    => 'gifts_enabled',
  'gift'     => 'gifts_enabled',
  'community'=> 'community_enabled',
  'app'      => 'app_enabled',
  'app_download' => 'app_enabled',
];
if (isset($gate[$route]) && !feature_enabled($gate[$route], true)) {
  $route = '404';
  http_response_code(404);
}

$titleMap = [
  'dashboard' => 'Tổng quan',
  'shop' => 'Shop Key',
  'wallet' => 'Tài chính',
  'topup' => 'Nạp tiền',
  'orders' => 'Lịch sử',
  'my_keys' => 'Kho key',
  'redeem' => 'Nhập mã',
  'support' => 'Hỗ trợ',
  'profile' => 'Hồ sơ',
  'notifications' => 'Thông báo',
  'app' => 'Tải App',
  'app_download' => 'Tải App',
    'missions' => 'Nhiệm vụ',
  'rewards' => 'Đổi điểm lấy key',
  'guide' => 'Hướng dẫn',
  'help' => 'Trợ giúp',
  '404' => 'Không tìm thấy',
];
$title = $titleMap[$route] ?? 'RioKey';

?>
<?php include __DIR__ . '/inc/head.php'; ?>
<div x-data="{ sidebarOpen:false }">

<div class="min-h-screen lg:flex">
  <?php include __DIR__ . '/inc/sidebar.php'; ?>

  <div class="flex-1 lg:pl-[280px]">
    <?php include __DIR__ . '/inc/navbar.php'; ?>

    <main class="px-4 sm:px-6 lg:px-8 py-6 pb-28 lg:pb-10">
      <?php include __DIR__ . "/pages/{$route}.php"; ?>
    </main>
  </div>
</div>

</div>
<?php include __DIR__ . '/inc/foot.php'; ?>
