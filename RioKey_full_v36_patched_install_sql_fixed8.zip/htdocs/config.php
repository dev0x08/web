<?php
return [
  'app' => [
    'name' => 'RioKey',
    // Nếu bạn đặt dự án trong subfolder, set base_path = '/ten-folder'
    'base_path' => '',
  ],
  'db' => [
    'host' => '127.0.0.1',
    'name' => 'caffiliate_php',
    'user' => 'root',
    'pass' => '',
    'charset' => 'utf8mb4',
  ],
];
