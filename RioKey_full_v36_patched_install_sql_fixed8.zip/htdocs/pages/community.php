<?php
$u = auth_user();
$lockedUntil = (string)setting('community_locked_until','');
$communityLocked = ($lockedUntil!=='' && strtotime($lockedUntil) > time());

require_auth();
$uid = (int)($u['id'] ?? 0);
community_ensure_schema();

$post_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;


// RioKey community gate
$community_enabled = (int)setting('community_enabled', 1) === 1;
$min_days = (int)setting('community_min_days', 30);
$min_topup = (int)setting('community_min_topup', 0);

$user_created_at = $u['created_at'] ?? null;
$age_days = 0;
if ($user_created_at) {
  $age_days = (int)floor((time() - strtotime((string)$user_created_at)) / 86400);
  if ($age_days < 0) $age_days = 0;
}

$total_topup = 0;
try {
  $stt = db()->prepare("SELECT COALESCE(SUM(amount),0) FROM wallet_transactions WHERE user_id=? AND (type='topup' OR type='topup_approved' OR ref LIKE 'topup:%')");
  $stt->execute([$uid]);
  $total_topup = (int)($stt->fetchColumn() ?: 0);
} catch (Throwable $e) { $total_topup = 0; }

$community_ok = ($age_days >= $min_days) || ($total_topup >= $min_topup);
$muted = user_is_muted($u);

$hasActive = db_has_column('community_posts', 'is_active');
$hasPinned = db_has_column('community_posts', 'is_pinned');
$hasExcerpt = db_has_column('community_posts', 'excerpt');
$hasApproved = db_has_column('community_posts','is_approved');
$approvedCond = ($hasApproved && !is_mod()) ? " AND is_approved=1" : "";
$commentCond = (!is_mod() && db_has_column('community_comments','is_approved')) ? " AND c.is_approved=1" : "";

$activeCond = $hasActive ? "is_active=1" : "1=1";
$orderCond  = $hasPinned ? "is_pinned DESC, id DESC" : "id DESC";

// Handle create post
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_post'])) {
  csrf_require();
  if (!$community_enabled || !$community_ok) { flash_set('err','Bạn chưa đủ điều kiện.'); redirect(route_url('community')); }
  if ($muted) { flash_set('err','Tài khoản của bạn đang bị hạn chế bình luận/đăng bài.'); redirect(route_url('community')); }

  // rate limit
  $limit = (int)setting('community_post_rate_limit', 3);
  $win   = (int)setting('community_post_rate_window', 300);
  if ($limit > 0 && rate_limit_exceeded('cpost:'.$uid, $limit, $win)) {
    security_log($uid,'community_rate_limit',['action'=>'post']);
    flash_set('err','Bạn thao tác quá nhanh, vui lòng thử lại sau.');
    redirect(route_url('community'));
  }

  $title = trim((string)($_POST['title'] ?? ''));
  $content2 = trim((string)($_POST['content'] ?? ''));
  if ($title !== '' && $content2 !== '') {
    $hasUserId = db_has_column('community_posts','user_id');
    $hasActiveCol = db_has_column('community_posts','is_active');
    $hasExcerptCol = db_has_column('community_posts','excerpt');
    $hasApprovedCol = db_has_column('community_posts','is_approved');

    $excerpt2 = '';
    if ($hasExcerptCol) {
      $raw = $content2;
      $excerpt2 = function_exists('mb_substr') ? mb_substr($raw,0,160,'UTF-8') : substr($raw,0,160);
      if (strlen($raw) > 160) $excerpt2 .= '...';
    }

    $approved = 1;
    if ($hasApprovedCol) {
      // review if user new OR contains blocked words
      if (community_should_review($u) || community_text_has_blocked_words($title.' '.$content2)) { $approved = 0; security_log($uid,'community_post_review',[]); }
    }

    $cols = ['title','content','created_at'];
    $vals = [$title,$content2,date('Y-m-d H:i:s')];

    if ($hasExcerptCol) { $cols[]='excerpt'; $vals[]=$excerpt2; }
    if ($hasActiveCol) { $cols[]='is_active'; $vals[]=1; }
    if ($hasApprovedCol) { $cols[]='is_approved'; $vals[]=$approved; }
    if ($hasUserId) { $cols[]='user_id'; $vals[]=$uid; }

    $place = implode(',', array_fill(0,count($cols),'?'));
    db()->prepare("INSERT INTO community_posts(".implode(',',$cols).") VALUES({$place})")->execute($vals);
    $newId = (int)db()->lastInsertId();

    if ($hasApprovedCol && $approved===0) {
      flash_set('ok','Bài viết đã gửi và đang chờ duyệt.');
      redirect(route_url('community'));
    }

    redirect(route_url('community',['id'=>$newId]));
  }

  flash_set('err','Vui lòng nhập tiêu đề và nội dung.');
  redirect(route_url('community'));
}

// Handle comment submit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment_post_id'])) {
  csrf_require();
  $pid = (int)($_POST['comment_post_id'] ?? 0);
  $content = trim($_POST['content'] ?? '');

  if ($pid > 0 && $content !== '') {
    if (!$community_enabled || !$community_ok) { flash_set('err','Bạn chưa đủ điều kiện.'); redirect(route_url('community',['id'=>$pid])); }
    if ($muted) { flash_set('err','Tài khoản của bạn đang bị hạn chế bình luận/đăng bài.'); redirect(route_url('community',['id'=>$pid])); }

    // post lock
    if (db_has_column('community_posts','is_locked')) {
      $stL = db()->prepare("SELECT is_locked FROM community_posts WHERE id=? LIMIT 1");
      $stL->execute([$pid]);
      $rowL = $stL->fetch(PDO::FETCH_ASSOC);
      if ($rowL && (int)$rowL['is_locked']===1) {
        flash_set('err','Chủ đề này đã bị khoá bình luận.');
        redirect(route_url('community',['id'=>$pid]));
      }
    }

    // rate limit
    $limit = (int)setting('community_comment_rate_limit', 10);
    $win   = (int)setting('community_comment_rate_window', 300);
    if ($limit > 0 && rate_limit_exceeded('cmt:'.$uid, $limit, $win)) {
      security_log($uid,'community_rate_limit',['action'=>'comment']);
    flash_set('err','Bạn bình luận quá nhanh, vui lòng thử lại sau.');
      redirect(route_url('community',['id'=>$pid]));
    }

    $enabled = (int)setting('comment_spam_enabled', 1) === 1;
    $kw_raw = (string)setting('comment_spam_keywords', '');
    $is_spam = false;

    if ($enabled && $kw_raw !== '') {
      $hay = function_exists('mb_strtolower') ? mb_strtolower($content, 'UTF-8') : strtolower($content);
      $kws = preg_split('/[\r\n,]+/', $kw_raw);
      foreach ($kws as $k) {
        $k = trim(function_exists('mb_strtolower') ? mb_strtolower($k, 'UTF-8') : strtolower($k));
        if ($k === '') continue;
        $pos = function_exists('mb_strpos') ? mb_strpos($hay, $k, 0, 'UTF-8') : strpos($hay, $k);
        if ($pos !== false) { $is_spam = true; break; }
      }
    }

    // extra blocked words (auto review)
    if (community_text_has_blocked_words($content)) { $is_spam = true; security_log($uid,'community_blocked_words',[]); }

    $approved = $is_spam ? 0 : 1;

    $cols = "post_id,user_id,content,is_approved,created_at";
    $ph   = "?,?,?,?,NOW()";
    $vals = [$pid, $uid, $content, $approved];

    if (db_has_column('community_comments','ip')) { $cols .= ",ip"; $ph .= ",?"; $vals[] = client_ip(); }
    if (db_has_column('community_comments','ua')) { $cols .= ",ua"; $ph .= ",?"; $vals[] = substr(client_ua(),0,255); }

    $st = db()->prepare("INSERT INTO community_comments($cols) VALUES($ph)");
    $st->execute($vals);

    if ($approved===0) flash_set('ok','Bình luận đã gửi và đang chờ duyệt.');
  }

  redirect(route_url('community', ['id' => $pid]));
}

// Load single post
$post = null;
if ($post_id > 0) {
  $sql = "SELECT * FROM community_posts WHERE id=? AND {$activeCond}{$approvedCond} LIMIT 1";
  $st = db()->prepare($sql);
  $st->execute([$post_id]);
  $post = $st->fetch(PDO::FETCH_ASSOC);
  if (!$post) { http_response_code(404); $post_id = 0; }
}

// List posts
$posts = [];
$tags  = [];
if ($post_id <= 0) {
  $tag = trim($_GET['tag'] ?? '');
  if ($tag !== '') {
    $sql = "SELECT p.*
            FROM community_posts p
            JOIN community_post_tags pt ON pt.post_id=p.id
            JOIN community_tags t ON t.id=pt.tag_id
            WHERE p.{$activeCond} AND t.slug=?
            ORDER BY p." . ($hasPinned ? "is_pinned DESC, " : "") . "p.id DESC";
    $st = db()->prepare($sql);
    $st->execute([$tag]);
  } else {
    $sql = "SELECT * FROM community_posts WHERE {$activeCond}{$approvedCond} ORDER BY {$orderCond} LIMIT 30";
    $st = db()->query($sql);
  }
  $posts = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
  $tags = db()->query("SELECT * FROM community_tags ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
}
?>

<?php if($post_id<=0): ?>
<div class="flex items-center justify-between gap-3">
  <div>
    <div class="text-2xl font-extrabold">Community</div>
    <div class="text-sm text-slate-400 mt-1">Tin tức • hướng dẫn • chia sẻ kinh nghiệm</div>
  </div>
</div>

<div class="mt-4 flex flex-wrap gap-2">
  <a class="px-3 py-1.5 rounded-full text-xs border border-white/10 hover:bg-white/5 <?= empty($_GET['tag'])?'bg-white/5':'' ?>"
     href="<?= e(route_url('community')) ?>">Tất cả</a>
  <?php foreach($tags as $t): ?>
    <a class="px-3 py-1.5 rounded-full text-xs border border-white/10 hover:bg-white/5 <?= (($_GET['tag']??'')===$t['slug'])?'bg-white/5':'' ?>"
       href="<?= e(route_url('community',['tag'=>$t['slug']])) ?>">#<?= e($t['name']) ?></a>
  <?php endforeach; ?>
</div>


<?php if(!$community_enabled): ?>
  <div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200">
    Community đang tạm tắt. Vui lòng quay lại sau.
  </div>
<?php else: ?>
  <?php if($m=flash_get('ok')): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($m) ?></div><?php endif; ?>
<?php if($m=flash_get('err')): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($m) ?></div><?php endif; ?>

<div class="mt-4 card p-5">
    <div class="flex items-center justify-between gap-3">
      <div>
        <div class="text-lg font-extrabold">Thảo luận cộng đồng</div>
        <div class="text-sm text-slate-400 mt-1">Tạo chủ đề + bình luận theo kiểu forum.</div>
      </div>
      <?= lucide_icon('messages-square','w-5 h-5 text-orange-300') ?>
    </div>

    <?php if($community_ok): ?>
      <form method="post" class="mt-4 space-y-3" data-once="1">
        <?= csrf_field() ?>
        <input type="hidden" name="create_post" value="1">
        <input class="input" name="title" placeholder="Tiêu đề chủ đề...">
        <textarea class="input min-h-[120px]" name="content" placeholder="Nội dung..."></textarea>
        <button class="btn" type="submit">Đăng bài</button>
      </form>
    <?php else: ?>
      <div class="mt-4 text-sm text-slate-300">
        Bạn chưa đủ điều kiện để đăng bài/bình luận.
        <div class="text-xs text-slate-500 mt-2">
          Điều kiện: tài khoản ≥ <b><?= (int)$min_days ?></b> ngày hoặc tổng nạp ≥ <b><?= format_vnd((int)$min_topup) ?></b>.
          Hiện tại: <b><?= (int)$age_days ?></b> ngày • tổng nạp <b><?= format_vnd((int)$total_topup) ?></b>.
        </div>
      </div>
    <?php endif; ?>
  </div>
<?php endif; ?>


<div class="mt-6 space-y-3">
  <?php if(!$posts): ?>
    <div class="text-slate-400">Chưa có bài viết.</div>
  <?php else: foreach($posts as $p): ?>
    <?php
      $pinned = $hasPinned ? ((int)($p['is_pinned'] ?? 0) === 1) : false;
      if ($hasExcerpt) $excerpt = (string)($p['excerpt'] ?? '');
      else {
        $raw = (string)($p['content'] ?? '');
        $excerpt = function_exists('mb_substr') ? mb_substr($raw, 0, 140, 'UTF-8') : substr($raw, 0, 140);
        if (strlen($raw) > 140) $excerpt .= '...';
      }
    ?>
    <a href="<?= e(route_url('community',['id'=>$p['id']])) ?>" class="block card p-5 hover:bg-white/5 transition">
      <div class="flex items-start gap-3">
        <div class="mt-0.5"><?= lucide_icon($pinned ? 'pin' : 'message-square','w-5 h-5') ?></div>
        <div class="min-w-0 flex-1">
          <div class="flex items-center gap-2">
            <div class="font-extrabold truncate"><?= e($p['title'] ?? '') ?></div>
            <?php if($pinned): ?>
              <span class="px-2 py-0.5 rounded-full text-[11px] bg-orange-500/20 text-orange-200 border border-orange-500/20">PIN</span>
            <?php endif; ?>
          </div>
          <div class="text-sm text-slate-400 mt-1 line-clamp-2"><?= e($excerpt) ?></div>
          <div class="text-xs text-slate-500 mt-2"><?= e($p['created_at'] ?? '') ?></div>
        </div>
        <div class="opacity-70"><?= lucide_icon('chevron-right','w-5 h-5') ?></div>
      </div>
    </a>
  <?php endforeach; endif; ?>
</div>

<?php else: ?>
<a href="<?= e(route_url('community')) ?>" class="inline-flex items-center gap-2 text-sm text-slate-300 hover:text-white">
  <?= lucide_icon('arrow-left','w-4 h-4') ?> Quay lại
</a>

<div class="mt-4 card p-6">
  <div class="text-2xl font-extrabold"><?= e($post['title'] ?? '') ?></div>
  <div class="text-xs text-slate-500 mt-2"><?= e($post['created_at'] ?? '') ?></div>
  <div class="mt-4 text-slate-200 leading-relaxed whitespace-pre-line"><?= e($post['content'] ?? '') ?></div>

<?php
// Tags for this post
$st = db()->prepare("SELECT t.id,t.slug,t.name FROM community_tags t JOIN community_post_tags pt ON pt.tag_id=t.id WHERE pt.post_id=?");
$st->execute([$post_id]);
$postTags = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

// Related posts by tags (fallback: newest posts)
$related = [];
if ($postTags) {
  $sql = "SELECT p.*, COUNT(*) AS match_cnt
          FROM community_posts p
          JOIN community_post_tags pt ON pt.post_id=p.id
          WHERE p.{$activeCond} AND p.id<>?
            AND pt.tag_id IN (SELECT tag_id FROM community_post_tags WHERE post_id=?)
          GROUP BY p.id
          ORDER BY match_cnt DESC" . ($hasPinned ? ", p.is_pinned DESC" : "") . ", p.id DESC
          LIMIT 6";
  $st = db()->prepare($sql);
  $st->execute([$post_id,$post_id]);
  $related = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}
if (!$related) {
  $sql = "SELECT * FROM community_posts WHERE {$activeCond}{$approvedCond} AND id<>? ORDER BY {$orderCond} LIMIT 6";
  $st = db()->prepare($sql);
  $st->execute([$post_id]);
  $related = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}
?>

<?php if($related): ?>
  <div class="mt-6">
    <div class="flex items-center justify-between">
      <div class="text-lg font-extrabold">Bài liên quan</div>
      <?php if($postTags): ?>
        <div class="hidden sm:flex gap-2 flex-wrap">
          <?php foreach($postTags as $t): ?>
            <a href="<?= e(route_url('community',['tag'=>$t['slug']])) ?>" class="px-3 py-1 rounded-full text-xs bg-white/5 border border-white/10 text-slate-200 hover:bg-white/10">#<?= e($t['name']) ?></a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
    <div class="mt-3 grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
      <?php foreach($related as $r): ?>
        <a class="p-4 rounded-2xl bg-black/25 border border-white/10 hover:bg-black/35 transition block" href="<?= e(route_url('community',['id'=>$r['id']])) ?>">
          <div class="font-extrabold text-slate-100 line-clamp-2"><?= e($r['title'] ?? '') ?></div>
          <div class="text-xs text-slate-500 mt-2"><?= e($r['created_at'] ?? '') ?></div>
          <?php
            if ($hasExcerpt) $ex = (string)($r['excerpt'] ?? '');
            else {
              $raw = (string)($r['content'] ?? '');
              $ex = function_exists('mb_substr') ? mb_substr($raw, 0, 100, 'UTF-8') : substr($raw, 0, 100);
              if (strlen($raw) > 100) $ex .= '...';
            }
          ?>
          <?php if($ex): ?><div class="text-sm text-slate-300 mt-2 line-clamp-2"><?= e($ex) ?></div><?php endif; ?>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
<?php endif; ?>

</div>

<?php
$st=db()->prepare("SELECT c.*, u.username, u.name FROM community_comments c JOIN users u ON u.id=c.user_id WHERE c.post_id=?{$commentCond} ORDER BY c.id DESC LIMIT 50");
$st->execute([$post_id]);
$comments=$st->fetchAll(PDO::FETCH_ASSOC) ?: [];
?>
<div class="mt-6 card p-6">
  <div class="text-lg font-extrabold">Bình luận</div>
  <?php if($community_enabled && $community_ok): ?>
  <form method="post" class="mt-4 space-y-3" data-once="1">
    <?= csrf_field() ?>
    <input type="hidden" name="comment_post_id" value="<?= (int)$post_id ?>">
    <textarea name="content" rows="3" class="input w-full" placeholder="Viết bình luận..."></textarea>
    <button class="btn" type="submit">Gửi bình luận</button>
    </form>
<?php else: ?>
  <div class="mt-4 text-sm text-slate-300">
    Bạn chưa đủ điều kiện để bình luận hoặc community đang tắt.
    <div class="text-xs text-slate-500 mt-2">Điều kiện: tài khoản ≥ <b><?= (int)$min_days ?></b> ngày hoặc tổng nạp ≥ <b><?= format_vnd((int)$min_topup) ?></b>.</div>
  </div>
<?php endif; ?>

  <div class="mt-6 space-y-3">
    <?php if(!$comments): ?><div class="text-slate-500 text-sm">Chưa có bình luận.</div><?php endif; ?>
    <?php foreach($comments as $c): ?>
      <div class="rounded-2xl border border-white/10 bg-white/5 p-4">
        <div class="flex items-center justify-between gap-3">
          <div class="font-bold"><?= e($c['username'] ?: ($c['name'] ?? 'User')) ?></div>
          <div class="text-xs text-slate-500"><?= e($c['created_at'] ?? '') ?></div>
        </div>
        <div class="mt-2 text-slate-200 whitespace-pre-line"><?= e($c['content'] ?? '') ?></div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>
