<?php
$u = auth_user();
$uid = (int)($u['id'] ?? 0);
$vip = $uid? vip_get_user($uid): null;
$rank = $uid? rank_name($uid): null;
?>
<div class="max-w-4xl">
  <div class="text-2xl font-extrabold">Bảng giá & Ưu đãi</div>
  <div class="text-sm text-slate-400 mt-2">Giá hiển thị có thể khác nhau theo Rank/VIP/Flash sale.</div>

  <div class="mt-6 grid md:grid-cols-2 gap-4">
    <div class="card p-5">
      <div class="font-extrabold">Tài khoản của bạn</div>
      <div class="mt-3 text-sm text-slate-300">
        <div>Rank: <b><?= e((string)($rank ?? 'Chưa có')) ?></b></div>
        <div class="mt-1">VIP: <b><?= e((string)($vip['tier'] ?? 'Chưa có')) ?></b></div>
      </div>
      <div class="text-xs text-slate-500 mt-3">Admin có thể cấu hình giá theo Rank/VIP ở Admin → Pricing.</div>
    </div>

    <div class="card p-5">
      <div class="font-extrabold">Flash sale</div>
      <div class="text-sm text-slate-400 mt-2">Khi có Flash sale, giá sẽ tự giảm và có countdown ở Shop.</div>
      <a class="btn btn-ghost mt-4" href="<?= e(route_url('shop')) ?>">Xem shop</a>
    </div>
  </div>
</div>
