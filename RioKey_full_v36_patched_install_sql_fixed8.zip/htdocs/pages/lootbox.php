<?php
$u = auth_user(); require_auth();
$uid = (int)($u['id'] ?? 0);
lootbox_ensure_schema();
$w = wallet_get($uid);
$balance = (float)($w['balance'] ?? 0);
$pts = (int)($u['points'] ?? 0);

$rt = 'lb_' . bin2hex(random_bytes(16));
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['open_lootbox'])) {
  csrf_require();
  $pay = (string)($_POST['pay'] ?? 'points');
  $res = lootbox_open($uid, $pay, (string)($_POST['request_token'] ?? ''), (string)($_POST['box_type'] ?? 'random'));
  if (isset($_POST['ajax'])) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok'=>($res['ok']??false),'msg'=>($res['msg']??($res['error']??'')),'tier'=>($res['tier']??''),'product'=>($res['product']??''),'key'=>($res['key']??''),'order_code'=>($res['order_code']??'')], JSON_UNESCAPED_UNICODE);
    exit;
  }
  if ($res['ok'] ?? false) {
    flash_set('ok', 'Mở lootbox thành công! Tier: '.($res['tier'] ?? '').' • Sản phẩm: '.($res['product'] ?? '').'. Key đã vào Kho key.');
    redirect(route_url('my_keys'));
  } else {
    flash_set('error', (string)($res['msg'] ?? 'Có lỗi'));
    redirect(route_url('lootbox'));
  }
}

$enabled = (int)setting('lootbox_enabled',1)===1;
$pPts = (int)setting('lootbox_price_points',200);
$pVnd = (int)setting('lootbox_price_vnd',20000);
?>
<div class="max-w-4xl mx-auto">
  <div class="text-center">
    <h1 class="text-3xl sm:text-4xl font-black tracking-tight">Lootbox <span class="text-orange-400">Săn key</span></h1>
    <p class="text-slate-400 mt-2">Mở hộp ngẫu nhiên: Common(game_key) • Rare(giftcard) • Epic(account).</p>
  </div>

  <?php if(!$enabled): ?>
    <div class="mt-6 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200">Lootbox đang tạm tắt.</div>
  <?php else: ?>
    
    <div class="mt-6 card p-5">
      <div class="font-extrabold">Chọn loại lootbox</div>
      <div class="text-sm text-slate-400 mt-1">Để tránh nhận key/code không cần dùng, bạn có thể chọn loại mong muốn trước khi mở.</div>
      <div class="mt-4 grid sm:grid-cols-4 gap-3" id="lbType">
        <button type="button" class="lb-chip active" data-type="random">Random</button>
        <button type="button" class="lb-chip" data-type="game_key">Game Key</button>
        <button type="button" class="lb-chip" data-type="giftcard">Giftcard</button>
        <button type="button" class="lb-chip" data-type="account">Account</button>
      </div>
      <div class="mt-3 text-sm text-slate-400" id="lbTypeHint">Đang chọn: <b>Random</b> (tự random tier)</div>
    </div>
    <style>
      .lb-chip{padding:.75rem 1rem;border-radius:1rem;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.10);font-weight:800}
      .lb-chip.active{background:rgba(249,115,22,.18);border-color:rgba(249,115,22,.35);box-shadow:0 0 0 4px rgba(249,115,22,.08)}
    </style>
    <script>
      (function(){
        const wrap=document.getElementById('lbType'); if(!wrap) return;
        const hint=document.getElementById('lbTypeHint');
        let val='random';
        function label(t){
          if(t==='game_key') return 'Game Key';
          if(t==='giftcard') return 'Giftcard';
          if(t==='account') return 'Account';
          return 'Random';
        }
        wrap.addEventListener('click', (e)=>{
          const btn=e.target.closest('[data-type]'); if(!btn) return;
          val=btn.getAttribute('data-type')||'random';
          wrap.querySelectorAll('.lb-chip').forEach(b=>b.classList.toggle('active', b===btn));
          if(hint) hint.innerHTML='Đang chọn: <b>'+label(val)+'</b>' + (val==='random'?' (tự random tier)':' (ưu tiên đúng loại bạn chọn)');
          document.querySelectorAll('input[name="box_type"]').forEach(i=>i.value=val);
          // update confirm text
          document.querySelectorAll('form[data-lb-confirm]').forEach(f=>{
            const base=f.getAttribute('data-lb-confirm')||'';
            f.setAttribute('data-confirm', base.replace('{TYPE}', label(val)));
          });
        });
        // init hidden inputs
        document.querySelectorAll('input[name="box_type"]').forEach(i=>i.value=val);
        document.querySelectorAll('form[data-lb-confirm]').forEach(f=>{
          const base=f.getAttribute('data-lb-confirm')||'';
          f.setAttribute('data-confirm', base.replace('{TYPE}', label(val)));
        });
      })();
    </script>

    <div class="mt-6 grid md:grid-cols-2 gap-4">
      <div class="card p-5">
        <div class="font-extrabold text-lg">Mở bằng điểm</div>
        <div class="text-sm text-slate-400 mt-1">Giá: <b><?= (int)$pPts ?></b> điểm</div>
        <div class="mt-4 text-sm text-slate-300">Điểm hiện có: <b><?= (int)$pts ?></b></div>
        <form method="post" class="mt-4" data-once="1" data-lb-confirm="Xác nhận mở lootbox ({TYPE}) bằng <?= (int)$pPts ?> điểm?" data-loading="Đang mở lootbox...">
          <?= csrf_field() ?>
          <input type="hidden" name="request_token" value="<?= e($rt) ?>">
          <input type="hidden" name="pay" value="points">
          <input type="hidden" name="box_type" value="random">
          <button class="btn w-full" name="open_lootbox" value="1" type="submit">Mở lootbox (điểm)</button>
        </form>
      </div>

      <div class="card p-5">
        <div class="font-extrabold text-lg">Mở bằng tiền</div>
        <div class="text-sm text-slate-400 mt-1">Giá: <b><?= format_vnd((int)$pVnd) ?></b></div>
        <div class="mt-4 text-sm text-slate-300">Số dư hiện có: <b><?= format_vnd((int)$balance) ?></b></div>
        <form method="post" class="mt-4" data-once="1" data-lb-confirm="Xác nhận mở lootbox ({TYPE}) với giá <?= format_vnd((int)$pVnd) ?>?" data-loading="Đang mở lootbox...">
          <?= csrf_field() ?>
          <input type="hidden" name="request_token" value="<?= e($rt) ?>">
          <input type="hidden" name="pay" value="wallet">
          <input type="hidden" name="box_type" value="random">
          <button class="btn w-full" name="open_lootbox" value="1" type="submit">Mở lootbox (tiền)</button>
        </form>
      </div>
    </div>

    <div class="mt-6 card p-5 text-sm text-slate-300">
      <div class="font-extrabold">Lưu ý</div>
      <ul class="list-disc pl-5 mt-2 space-y-1 text-slate-400">
        <li>Key nhận được sẽ vào <b>Kho key</b> như đơn mua bình thường.</li>
        <li>Tỷ lệ tier do admin cài đặt. Nếu kho hết hàng tier nào đó sẽ báo lỗi.</li>
      </ul>
    </div>
  <?php endif; ?>
</div>


<!-- lootboxReveal -->

<script>
(function(){
  const forms = document.querySelectorAll('form[data-lootbox-open]');
  if(!forms.length) return;

  function confettiBurst(count=110){
    const wrap=document.createElement('div');
    wrap.style.position='fixed';wrap.style.inset='0';wrap.style.pointerEvents='none';wrap.style.zIndex='9999';
    document.body.appendChild(wrap);
    const w=window.innerWidth,h=window.innerHeight;
    for(let i=0;i<count;i++){
      const p=document.createElement('div');
      const size=6+Math.random()*7;
      const x=w*0.5 + (Math.random()-0.5)*140;
      const y=h*0.35 + (Math.random()-0.5)*90;
      const dx=(Math.random()-0.5)*16;
      const dy=-12-Math.random()*11;
      const rot=Math.random()*360;
      const hue=Math.floor(Math.random()*360);
      p.style.position='absolute';p.style.left=x+'px';p.style.top=y+'px';
      p.style.width=size+'px';p.style.height=(size*0.55)+'px';
      p.style.background='hsl('+hue+',90%,60%)';
      p.style.borderRadius='2px';
      p.style.transform='translate(-50%,-50%) rotate('+rot+'deg)';
      p.style.opacity='0.95';
      wrap.appendChild(p);
      const g=0.55+Math.random()*0.35;
      const life=900+Math.random()*650;
      const start=performance.now();
      function step(now){
        const t=(now-start)/16;
        const px=x+dx*t;
        const py=y+dy*t+g*t*t;
        p.style.left=px+'px';p.style.top=py+'px';
        p.style.transform='translate(-50%,-50%) rotate('+(rot+t*18)+'deg)';
        p.style.opacity = String(Math.max(0, 1- (now-start)/life));
        if(now-start<life) requestAnimationFrame(step); else p.remove();
      }
      requestAnimationFrame(step);
    }
    setTimeout(()=>wrap.remove(),1800);
  }

  let audioCtx=null;
  function sfx(type){
    try{
      audioCtx = audioCtx || new (window.AudioContext||window.webkitAudioContext)();
      const t0=audioCtx.currentTime;
      function tone(freq, dur, gain){
        const o=audioCtx.createOscillator(); const g=audioCtx.createGain();
        o.type='sine';o.frequency.value=freq;
        g.gain.setValueAtTime(0.0001,t0);
        g.gain.exponentialRampToValueAtTime(gain,t0+0.01);
        g.gain.exponentialRampToValueAtTime(0.0001,t0+dur);
        o.connect(g); g.connect(audioCtx.destination);
        o.start(t0); o.stop(t0+dur+0.02);
      }
      if(type==='legendary'){ tone(880,0.18,0.08); tone(990,0.22,0.07); tone(1180,0.24,0.06); }
      else if(type==='epic'){ tone(740,0.18,0.07); tone(880,0.22,0.06); }
      else if(type==='rare'){ tone(620,0.16,0.06); tone(740,0.18,0.05); }
      else { tone(520,0.14,0.05); }
    }catch(e){}
  }

  function tierLabel(t){
    if(t==='legendary') return 'Huyền thoại';
    if(t==='epic') return 'Sử thi';
    if(t==='rare') return 'Hiếm';
    return 'Thường';
  }

  function revealModal(data){
    const tier = (data.tier||'common').toLowerCase();
    const title = '🎁 Bạn nhận được: ' + (data.product||'');
    let html = '<div class="text-sm text-slate-300">Tier: <b>'+tierLabel(tier)+'</b></div>';
    html += '<div class="mt-3 p-3 rounded-xl bg-white/5 border border-white/10">';
    html += '<div class="text-xs text-slate-400">Key/Code</div>';
    html += '<div class="mt-1 font-mono text-lg font-extrabold break-all">'+(data.key||'')+'</div>';
    html += '</div>';
    html += '<div class="mt-3 text-sm text-slate-300">Mã đơn: <b>'+(data.order_code||'')+'</b></div>';
    html += '<div class="mt-3 text-xs text-slate-400">Mẹo: Sau khi nhận key/code, bạn nên kích hoạt/đổi mật khẩu (nếu là tài khoản) hoặc sử dụng sớm để tránh nhầm lẫn.</div>';
    if(window.RioKeyModal && RioKeyModal.alertHtml){
      RioKeyModal.alertHtml(title, html, { okText:'Vào Kho key' }).then(()=>{ window.location.href = '<?= e(route_url('my_keys')) ?>'; });
    }else{
      alert((data.msg||'')+'\n'+(data.key||'')); window.location.href='<?= e(route_url('my_keys')) ?>';
    }
  }

  function lootboxAnim(){
    // simple animation modal
    const wrap=document.createElement('div');
    wrap.style.position='fixed';wrap.style.inset='0';wrap.style.zIndex='9999';wrap.style.display='flex';
    wrap.style.alignItems='center';wrap.style.justifyContent='center';
    wrap.style.background='rgba(0,0,0,.55)';
    wrap.innerHTML = `
      <div style="width:320px;max-width:92vw" class="p-5 rounded-2xl border border-white/10 bg-slate-950/90">
        <div class="font-extrabold text-center">Đang mở lootbox...</div>
        <div class="text-sm text-slate-400 text-center mt-2">Hộp sẽ rung, phát sáng và reveal phần thưởng ✨</div>
        <div class="mt-5 flex justify-center">
          <div id="lbBox" style="width:140px;height:140px;border-radius:26px;background:linear-gradient(135deg, rgba(249,115,22,.35), rgba(99,102,241,.22));border:1px solid rgba(255,255,255,.15);position:relative;box-shadow:0 0 50px rgba(249,115,22,.18);transform:translateZ(0);">
            <div style="position:absolute;inset:10px;border-radius:20px;border:1px dashed rgba(255,255,255,.25);"></div>
            <div style="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:58px;height:58px;border-radius:16px;background:rgba(0,0,0,.25);border:1px solid rgba(255,255,255,.18);"></div>
          </div>
        </div>
        <div class="mt-5 text-xs text-slate-500 text-center">Vui lòng không bấm nhiều lần</div>
      </div>`;
    document.body.appendChild(wrap);
    const box = wrap.querySelector('#lbBox');
    let t=0;
    const timer = setInterval(()=>{
      t++;
      const shake = (t<16) ? (Math.sin(t*1.9)*6) : 0;
      const glow = (t<16) ? (0.18 + t*0.02) : 0.62;
      box.style.transform = `rotate(${shake}deg) scale(${1 + Math.min(0.08, t*0.006)})`;
      box.style.boxShadow = `0 0 ${30 + t*2}px rgba(249,115,22,${Math.min(0.45, glow)})`;
      if(t===16){
        // flash
        box.style.transition='all .18s ease';
        box.style.transform='scale(1.18)';
        box.style.boxShadow='0 0 80px rgba(250,204,21,.55)';
      }
    }, 80);
    return {
      close(){ clearInterval(timer); wrap.remove(); }
    };
  }

  let busy=false;
  forms.forEach(f=>{
    f.addEventListener('submit', async (e)=>{
      e.preventDefault();
      if(busy) return;
      busy=true;
      const confirmText = f.getAttribute('data-confirm') || 'Xác nhận mở lootbox?';
      if(window.RioKeyModal && RioKeyModal.confirm){
        const ok = await RioKeyModal.confirm('Xác nhận', confirmText);
        if(!ok){ busy=false; return; }
      }else{
        if(!confirm(confirmText)){ busy=false; return; }
      }
      const anim = lootboxAnim();
      try{
        const fd=new FormData(f);
        fd.append('ajax','1');
        const res = await fetch(window.location.href, { method:'POST', body: fd, credentials:'same-origin' });
        const data = await res.json().catch(()=>({ok:false,msg:'Có lỗi xảy ra'}));
        anim.close();
        if(data && data.ok){
          confettiBurst(120);
          sfx((data.tier||'common').toLowerCase());
          if(navigator.vibrate){ try{ navigator.vibrate([40,25,40]); }catch(e){} }
          revealModal(data);
        }else{
          if(window.RioKeyModal && RioKeyModal.alert){
            await RioKeyModal.alert('Không thể mở lootbox', data.msg || data.error || 'Có lỗi xảy ra');
          }else alert(data.msg||data.error||'Có lỗi xảy ra');
          busy=false;
        }
      }catch(err){
        anim.close();
        if(window.RioKeyModal && RioKeyModal.alert) await RioKeyModal.alert('Lỗi','Có lỗi xảy ra, vui lòng thử lại.');
        else alert('Có lỗi xảy ra, vui lòng thử lại.');
        busy=false;
      }
    });
  });
})();
</script>
