<?php
$u = auth_user(); require_auth(); csrf_require();
$uid=(int)$u['id'];
shop_ensure_schema();
showcase_ensure_schema();
$flash=null; $err=null;

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  $pid=(int)($_POST['product_id'] ?? 0);
  try{
    if($pid<=0) throw new Exception('Thiếu sản phẩm.');
    $res = showcase_toggle($uid,$pid);
    if(!$res['ok']) throw new Exception($res['error'] ?? 'Lỗi');
    $flash = ($res['pinned'] ?? false) ? 'Đã pin vào bộ sưu tập.' : 'Đã gỡ khỏi bộ sưu tập.';
  }catch(Throwable $e){ $err=$e->getMessage(); }
}

$cur = showcase_list($uid);
$curIds = array_map(fn($x)=>(int)$x['product_id'], $cur);

$st=db()->prepare("SELECT DISTINCT p.id,p.title,p.category,p.price_vnd
  FROM shop_products p
  JOIN shop_orders o ON o.product_id=p.id
  WHERE o.user_id=? ORDER BY o.id DESC LIMIT 80");
$st->execute([$uid]);
$purchased = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
$w = wishlist_items($uid);
?>
<div class="flex items-start justify-between gap-4">
  <div>
    <div class="text-2xl font-extrabold">Bộ sưu tập</div>
    <div class="text-sm text-slate-400 mt-1">Pin tối đa 6 sản phẩm để khoe trên trang cá nhân.</div>
  </div>
  <div class="flex gap-2">
    <a class="btn btn-ghost" href="<?= e(route_url('profile')) ?>">← Profile</a>
  </div>
</div>

<?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 grid lg:grid-cols-3 gap-4">
  <div class="lg:col-span-2 card p-5">
    <div class="flex items-center justify-between gap-3">
      <div class="font-extrabold text-lg">Đang pin (<?= count($cur) ?>/6)</div>
      <div class="text-xs text-slate-500">Tip: pin sản phẩm bạn thích nhất để khoe.</div>
    </div>
    <div class="mt-4 grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
      <?php if(!$cur): ?>
        <div class="text-sm text-slate-500">Chưa pin sản phẩm nào.</div>
      <?php else: foreach($cur as $it): ?>
        <div class="p-4 rounded-2xl bg-white/5 border border-white/10">
          <div class="text-xs text-slate-400"><?= e($it['category'] ?? '') ?></div>
          <div class="font-extrabold mt-1"><?= e($it['title'] ?? '') ?></div>
          <div class="mt-3 flex gap-2">
            <a class="btn btn-ghost flex-1" href="<?= e(route_url('product',['id'=>(int)$it['product_id']])) ?>">Xem</a>
            <form method="post" data-once="1">
              <?= csrf_field() ?>
              <input type="hidden" name="product_id" value="<?= (int)$it['product_id'] ?>">
              <button class="btn btn-danger" type="submit">Gỡ</button>
            </form>
          </div>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>

  <div class="card p-5">
    <div class="font-extrabold text-lg">Chọn sản phẩm để pin</div>

    <div class="mt-4">
      <div class="text-xs text-slate-500 mb-2">Từ đơn đã mua</div>
      <div class="grid gap-2 max-h-[280px] overflow-auto pr-1">
        <?php if(!$purchased): ?><div class="text-sm text-slate-500">Chưa có.</div><?php endif; ?>
        <?php foreach($purchased as $p): $on=in_array((int)$p['id'],$curIds,true); ?>
          <form method="post" data-once="1" class="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between gap-3">
            <?= csrf_field() ?>
            <input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>">
            <div>
              <div class="text-xs text-slate-400"><?= e($p['category'] ?? '') ?></div>
              <div class="font-extrabold"><?= e($p['title'] ?? '') ?></div>
            </div>
            <button class="btn <?= $on?'btn-ghost':'btn' ?>" type="submit"><?= $on?'Đang pin':'Pin' ?></button>
          </form>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="mt-6">
      <div class="text-xs text-slate-500 mb-2">Từ wishlist</div>
      <div class="grid gap-2 max-h-[220px] overflow-auto pr-1">
        <?php if(!$w): ?><div class="text-sm text-slate-500">Chưa có.</div><?php endif; ?>
        <?php foreach($w as $p): $on=in_array((int)$p['id'],$curIds,true); ?>
          <form method="post" data-once="1" class="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between gap-3">
            <?= csrf_field() ?>
            <input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>">
            <div>
              <div class="text-xs text-slate-400"><?= e($p['category'] ?? '') ?></div>
              <div class="font-extrabold"><?= e($p['title'] ?? '') ?></div>
            </div>
            <button class="btn <?= $on?'btn-ghost':'btn' ?>" type="submit"><?= $on?'Đang pin':'Pin' ?></button>
          </form>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>
