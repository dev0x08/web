<?php
$u = auth_user(); require_auth(); csrf_require();
$uid = (int)$u['id'];

$flash=null; $err=null;

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  $pid = (int)($_POST['product_id'] ?? 0);
  if($pid>0){
    $on = wishlist_toggle($uid,$pid);
    $flash = $on ? 'Đã thêm vào wishlist.' : 'Đã bỏ khỏi wishlist.';
    redirect(route_url('wishlist'));
  }
}

$items = wishlist_items($uid);
$wishCount = count($items);
?>
<div class="flex items-start justify-between gap-4">
  <div>
    <div class="text-2xl font-extrabold">Wishlist</div>
    <div class="text-sm text-slate-400 mt-1">Sản phẩm bạn đang theo dõi.</div>
  </div>
</div>

<?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 grid lg:grid-cols-3 gap-4">
  <div class="lg:col-span-2">
    <div class="grid sm:grid-cols-2 gap-4">
      <?php if(!$items): ?>
        <div class="card p-6 text-slate-500">Chưa có wishlist. Vào Shop và bấm ❤ để theo dõi sản phẩm.</div>
      <?php else: foreach($items as $p): ?>
        <?php
          $flashD = flash_active_discount($p['category'] ?? null);
          $ap = shop_final_price_for_user($uid, $p, $flashD);
          $price = (int)$ap['price'];
        ?>
        <div class="card p-5">
          <div class="flex items-start justify-between gap-3">
            <div>
              <div class="text-sm text-slate-400"><?= e($p['category'] ?? '') ?></div>
              <div class="text-lg font-extrabold mt-1"><?= e($p['title'] ?? '') ?></div>
            </div>
            <form method="post" data-once="1">
              <?= csrf_field() ?>
              <input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>">
              <button class="btn btn-ghost" type="submit">❤</button>
            </form>
          </div>

          <div class="mt-3 text-sm text-slate-300"><?= nl2br(e((string)($p['description'] ?? ''))) ?></div>

          <div class="mt-4 flex items-center justify-between">
            <div class="text-xl font-extrabold text-orange-200"><?= money_vnd($price) ?></div>
            <a class="btn" href="<?= e(route_url('shop')) ?>#p<?= (int)$p['id'] ?>">Mua</a>
          </div>

          <?php if($flashD>0): ?>
            <div class="mt-3 text-xs text-emerald-200">Đang Flash Sale: -<?= (int)$flashD ?>%</div>
          <?php endif; ?>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>

  <div class="card p-5">
    <div class="font-extrabold text-lg">Tổng quan</div>
    <div class="mt-3 text-sm text-slate-400">Bạn đang theo dõi <b><?= (int)$wishCount ?></b> sản phẩm.</div>
    <div class="mt-4 p-4 rounded-2xl bg-white/5 border border-white/5 text-sm text-slate-300">
      Tip: Wishlist tự show Flash Sale để bạn chốt nhanh.
    </div>
  </div>
</div>
