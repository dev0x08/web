<?php
$u = auth_user(); require_auth();
$uid = (int)($u['id'] ?? 0);
$wishIds = wishlist_ids($uid);
shop_ensure_schema();
$w = wallet_get($uid);
$balance = (float)($w['balance'] ?? 0);
$req_token = 'rt_' . bin2hex(random_bytes(16));

// Wishlist toggle
if ($_SERVER['REQUEST_METHOD']==='POST' && (($_POST['action'] ?? '')==='wishlist')) {
  csrf_require();
  $pid=(int)($_POST['product_id'] ?? 0);
  if($pid>0){ $on = wishlist_toggle($uid, $pid); flash_set('ok', $on ? 'Đã thêm vào wishlist.' : 'Đã bỏ khỏi wishlist.'); }
  redirect(route_url('shop') . '#p' . $pid);
}

// Buy product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buy_product_id'])) {
  csrf_require();
  $pid = (int)($_POST['buy_product_id'] ?? 0);
  $rt = (string)($_POST['request_token'] ?? '');
  $res = shop_buy($uid, $pid, $rt);
  if ($res['ok'] ?? false) {
    flash_set('ok','Mua key thành công! Mã đơn: '.($res['order_code'] ?? '').'. Key đã vào Kho key.');
    redirect(route_url('my_keys'));
  } else {
    flash_set('error', (string)($res['error'] ?? 'Có lỗi xảy ra'));
    redirect(route_url('shop'));
  }
}


$cat = (string)($_GET['cat'] ?? 'game_key');
$validCats = ['game_key','giftcard','account'];
if (!in_array($cat,$validCats,true)) $cat='game_key';
$items = shop_products(true, $cat);
$vip = vip_active($uid);
$vipD = vip_discount_pct($uid);
$flashSale = flash_active_sale($cat);
$flashD = $flashSale ? (int)($flashSale['discount_pct'] ?? 0) : 0;
?>
<div class="max-w-6xl mx-auto">
  <div class="text-center">
    <h1 class="text-3xl sm:text-4xl font-black tracking-tight">Shop <span class="text-orange-400">Key/Code Game</span></h1>
    <p class="text-slate-400 mt-2">Mua key tự động • Giao ngay trong Kho key sau khi thanh toán.</p>
  </div>

  <?php if($msg=flash_get('ok')): ?>
    <div class="mt-6 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200 max-w-3xl mx-auto"><?= e($msg) ?></div>
  <?php endif; ?>
  <?php if($msg=flash_get('error')): ?>
    <div class="mt-6 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200 max-w-3xl mx-auto"><?= e($msg) ?></div>
  <?php endif; ?>

  <div class="card p-5 sm:p-6 mt-8 max-w-3xl mx-auto border-amber-500/20">
    <div class="flex items-start gap-3">
      <div class="w-11 h-11 rounded-2xl bg-amber-500/10 border border-amber-500/20 grid place-items-center">
        <?= lucide_icon('shield-check','w-5 h-5 text-amber-300') ?>
      </div>
      <div class="flex-1">
        <div class="font-extrabold text-amber-200">QUY TẮC GIAO KEY</div>
        <ul class="mt-2 text-sm text-amber-100/80 space-y-1 list-disc list-inside">
          <li>Key được giao tự động ngay sau khi thanh toán.</li>
          <li>Vào mục <b>Kho key</b> để xem lại key đã mua/đổi.</li>
          <li>Nếu phát sinh lỗi hiếm, vui lòng báo Admin để hỗ trợ.</li>
        </ul>
      </div>
    </div>
  </div>

  
  <div class="mt-8 flex flex-wrap justify-center gap-2">
    <?php
      $tabs = [
        'game_key' => ['Key game','gamepad-2'],
        'giftcard' => ['Giftcard','credit-card'],
        'account'  => ['Tài khoản','user-round']
      ];
      foreach($tabs as $k=>$v):
        $active = $cat===$k;
    ?>
      <a class="px-4 py-2 rounded-2xl border <?= $active?'border-orange-500/40 bg-orange-500/10 text-orange-200':'border-white/10 bg-white/5 text-slate-200/80 hover:bg-white/10' ?>"
         href="<?= e(route_url('shop',['cat'=>$k])) ?>">
        <?= lucide_icon($v[1], 'w-4 h-4 inline-block mr-2') ?> <?= e($v[0]) ?>
      </a>
    <?php endforeach; ?>
  </div>

  <div class="mt-10">
    <div class="flex items-center gap-3">
      <span class="w-7 h-7 rounded-full bg-orange-500/20 border border-orange-500/30 grid place-items-center text-orange-200 font-bold">1</span>
      <div class="text-lg font-extrabold">Chọn sản phẩm</div>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
      <?php if(!$items): ?>
        <div class="text-slate-400">Chưa có sản phẩm. Admin vào <b>Shop sản phẩm & Key</b> để thêm.</div>
      <?php else: foreach($items as $p): ?>
        <?php
          $stock = (int)($p['stock'] ?? 0);
          $out = $stock <= 0;
          $base_price = shop_base_price_for_user($uid, $p);
          $ap = shop_final_price_for_user($uid, $p, $flashD);
          $price = (int)$ap['price'];
        ?>
        <div class="card p-5 hover:border-orange-500/30 transition relative overflow-hidden" id="p<?= (int)$p['id'] ?>">
          <?php if(!empty($p['image_url'])): ?>
            <div class="mb-4 rounded-2xl overflow-hidden border border-white/10">
              <img class="w-full h-32 object-cover" src="<?= e($p['image_url']) ?>" alt="<?= e($p['title']) ?>">
            </div>
          <?php endif; ?>
          <div class="absolute -right-10 -top-10 w-40 h-40 rounded-full bg-orange-500/10 blur-2xl"></div>
          <div class="flex items-start gap-4">
            <div class="w-14 h-14 rounded-2xl bg-slate-900/60 border border-slate-800/60 grid place-items-center">
              <?php
              $icon = (string)($p['icon'] ?? 'key-round');
              if (str_starts_with($icon,'http')) {
                echo '<img class="w-7 h-7 object-contain" src="'.e($icon).'" alt="icon">';
              } else {
                echo lucide_icon($icon,'w-7 h-7 text-orange-300');
              }
            ?>
            </div>
            <div class="min-w-0 flex-1">
              <div class="flex items-start justify-between gap-3">
                <div class="font-extrabold truncate"><?= e($p['title'] ?? '') ?></div>
                <div class="flex items-center gap-2 shrink-0">
                  <?php if($vipD>0): ?><span class="px-2 py-1 text-xs rounded-full bg-orange-500/15 border border-orange-500/30 text-orange-200">VIP -<?= (int)$vipD ?>%</span><?php endif; ?>
                  <?php if($flashD>0): ?><span class="px-2 py-1 text-xs rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-200">FLASH -<?= (int)$flashD ?>%</span><?php endif; ?>
                  <?php $wOn=in_array((int)$p['id'],$wishIds,true); ?>
                  <form method="post" class="ml-1" data-once="1" title="Wishlist">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="wishlist">
                    <input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>">
                    <button class="px-2 py-1 rounded-full border <?= $wOn?'border-rose-500/40 bg-rose-500/10 text-rose-200':'border-white/10 bg-white/5 text-slate-200/80 hover:bg-white/10' ?>" type="submit">❤</button>
                  </form>
                </div>
              </div>
              <div class="text-sm text-slate-400 mt-1 line-clamp-2"><?= e($p['description'] ?? '') ?></div>

              <div class="mt-3 flex items-center justify-between gap-2">
                <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-sm font-extrabold">
                  <?php if(($ap['total']??0)>0 && $base_price>$price): ?>
                    <span class="text-xs text-slate-500 line-through mr-2"><?= format_vnd($base_price) ?></span>
                    <?php endif; ?>
                    <?= lucide_icon('wallet','w-4 h-4 text-emerald-300') ?> <?= format_vnd($price) ?>
                </div>
                <span class="text-xs <?= $out?'text-rose-300':'text-slate-400' ?>">Tồn: <?= max(0,$stock) ?></span>
              </div>
            </div>
          </div>

          <form method="post" class="mt-4" data-once="1" data-buy="1" data-title="<?= e($p['title']) ?>" data-price="<?= (int)$price ?>" data-balance="<?= (float)$balance ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="request_token" value="<?= e($req_token) ?>">
            <input type="hidden" name="buy_product_id" value="<?= (int)$p['id'] ?>">
            <button class="btn w-full <?= $out?'opacity-50 cursor-not-allowed':'' ?>" <?= $out?'disabled':'' ?> type="submit">
              <?= $out ? 'Hết key' : 'Mua ngay' ?>
            </button>
          </form>
        </div>
      <?php endforeach; endif; ?>
    </div>

    <div class="text-center mt-6">
      <a class="btn btn-ghost inline-flex items-center gap-2" href="<?= e(route_url('my_keys')) ?>">
        Vào Kho key <?= lucide_icon('chevron-right','w-4 h-4') ?>
      </a>
      <div class="text-xs text-slate-500 mt-3">Nếu bạn muốn đổi key bằng điểm: vào mục <b>Đổi điểm lấy key</b>.</div>
    </div>
  </div>
</div>


<!-- Shop buy confirmation modal -->
<div id="ShopConfirmModal" class="hidden fixed inset-0 z-50">
  <div class="absolute inset-0 bg-black/70" onclick="ShopConfirmClose()"></div>
  <div class="relative max-w-lg mx-auto mt-24 card p-6">
    <div class="flex items-start justify-between gap-3">
      <div>
        <div class="text-lg font-extrabold">Xác nhận mua key</div>
        <div class="text-sm text-slate-400 mt-1">Kiểm tra số dư trước khi thanh toán</div>
      </div>
      <button class="btn btn-ghost" type="button" onclick="ShopConfirmClose()"><?= lucide_icon('x','w-4 h-4') ?></button>
    </div>

    <div class="mt-4 space-y-2 text-sm">
      <div class="flex items-center justify-between">
        <span class="text-slate-400">Sản phẩm</span>
        <span class="font-semibold text-slate-100" id="sc_title">-</span>
      </div>
      <div class="flex items-center justify-between">
        <span class="text-slate-400">Số dư hiện có</span>
        <span class="font-extrabold text-emerald-200" id="sc_balance">-</span>
      </div>
      <div class="flex items-center justify-between">
        <span class="text-slate-400">Giá mua</span>
        <span class="font-extrabold text-orange-200" id="sc_price">-</span>
      </div>
      <div class="flex items-center justify-between pt-2 border-t border-white/10">
        <span class="text-slate-300 font-semibold">Số dư còn lại</span>
        <span class="font-extrabold" id="sc_left">-</span>
      </div>
    </div>

    <div class="mt-5 flex gap-2 justify-end">
      <button class="btn btn-ghost" type="button" onclick="ShopConfirmClose()">Huỷ</button>
      <button class="btn" type="button" onclick="ShopConfirmOk()">Mua ngay</button>
    </div>
  </div>
</div>

<script>
let __shopConfirmForm = null;
function ShopConfirmClose(){
  document.getElementById('ShopConfirmModal').classList.add('hidden');
  __shopConfirmForm = null;
}
function ShopConfirmOpen(form){
  __shopConfirmForm = form;
  const title = form.getAttribute('data-title') || '-';
  const price = parseInt(form.getAttribute('data-price') || '0', 10);
  const bal = parseFloat(form.getAttribute('data-balance') || '0');
  const left = bal - price;

  document.getElementById('sc_title').textContent = title;
  document.getElementById('sc_balance').textContent = new Intl.NumberFormat('vi-VN').format(Math.floor(bal)) + ' đ';
  document.getElementById('sc_price').textContent = new Intl.NumberFormat('vi-VN').format(price) + ' đ';

  const leftEl = document.getElementById('sc_left');
  leftEl.textContent = new Intl.NumberFormat('vi-VN').format(Math.floor(left)) + ' đ';
  leftEl.className = 'font-extrabold ' + (left >= 0 ? 'text-emerald-200' : 'text-rose-200');

  document.getElementById('ShopConfirmModal').classList.remove('hidden');
}
function ShopConfirmOk(){
  if(!__shopConfirmForm) return;
  if(__shopConfirmForm.dataset.confirmed === '1') return;
  __shopConfirmForm.dataset.confirmed = '1';
  const f = __shopConfirmForm;
  ShopConfirmClose();
  f.submit();
}
document.addEventListener('DOMContentLoaded', function(){
  document.querySelectorAll('form[data-buy="1"]').forEach(function(form){
    form.addEventListener('submit', function(e){
      if(form.dataset.confirmed === '1') return;
      e.preventDefault();
      ShopConfirmOpen(form);
    });
  });
});
</script>
