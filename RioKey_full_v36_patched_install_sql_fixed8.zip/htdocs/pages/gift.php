<?php
$u = auth_user(); csrf_require();
$uid = (int)($u['id'] ?? 0);

$token = trim((string)($_GET['token'] ?? ''));
if($token===''){ http_response_code(404); echo 'Not found'; exit; }

$g = gift_by_token($token);
if(!$g){ http_response_code(404); echo 'Not found'; exit; }

$flash=null; $err=null;

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  try{
    require_auth();
    $res=gift_claim($token,$uid);
    if(!$res['ok']) throw new Exception($res['error'] ?? 'Lỗi');
    $flash='Bạn đã nhận quà thành công! Key đã vào Kho key.';
  }catch(Throwable $e){ $err=$e->getMessage(); }
}

$status = (string)($g['status'] ?? 'active');
?>
<div class="max-w-2xl mx-auto">
  <div class="card p-6">
    <div class="text-2xl font-extrabold">Nhận quà từ RioKey</div>
    <div class="text-sm text-slate-400 mt-2">Link tặng quà 1 lần – hãy nhận ngay trước khi hết hạn.</div>

    <?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
    <?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

    <div class="mt-5 p-4 rounded-2xl bg-white/5 border border-white/10">
      <div class="text-sm text-slate-300">Trạng thái: <b><?= e($status) ?></b></div>
      <div class="text-xs text-slate-500 mt-2">Hết hạn: <?= e((string)($g['expires_at'] ?? '')) ?></div>
    </div>

    <?php if($status==='active' && !$flash): ?>
      <form method="post" class="mt-4" data-once="1">
        <?= csrf_field() ?>
        <button class="btn w-full" type="submit">Nhận quà</button>
      </form>
      <div class="text-xs text-slate-500 mt-3">
        Khi nhận xong, key sẽ chuyển vào Kho key. Bạn nên kích hoạt/đổi mật khẩu (nếu là account) ngay để tránh lỗi/trùng.
      </div>
    <?php else: ?>
      <a class="btn btn-ghost w-full mt-4" href="<?= e(route_url('dashboard')) ?>">Về trang chủ</a>
    <?php endif; ?>
  </div>
</div>
