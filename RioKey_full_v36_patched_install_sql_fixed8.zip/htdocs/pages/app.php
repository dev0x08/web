<?php
csrf_require();
$items = app_links_active_list();
?>
<div class="max-w-3xl mx-auto">
  <div class="card p-6">
    <div class="text-2xl font-extrabold">Tải App RioKey</div>
    <div class="text-sm text-slate-400 mt-2">Chọn bản phù hợp để tải và cài đặt. Link 1 lần sẽ tự hết hiệu lực sau khi mở.</div>

    <div class="mt-6 grid gap-4">
      <?php if(!$items): ?>
        <div class="text-sm text-slate-500">Chưa có link tải app. Vui lòng quay lại sau.</div>
      <?php else: foreach($items as $it): ?>
        <?php
          $cover = trim((string)($it['cover_image'] ?? ''));
          $imgsRaw = (string)($it['images'] ?? '');
          $imgs = preg_split('/[\n\r,]+/', $imgsRaw);
          $imgs = array_values(array_filter(array_map(fn($x)=>trim((string)$x), $imgs), fn($x)=>$x!==''));
          if($cover!=='' && !in_array($cover,$imgs,true)) array_unshift($imgs,$cover);
          $hasBackup = !empty(trim((string)($it['url_backup'] ?? '')));
        ?>
        <div class="p-5 rounded-2xl bg-white/5 border border-white/10">
          <div class="flex items-start justify-between gap-4">
            <div class="flex items-start gap-4 min-w-0">
              <?php if($cover!==''): ?>
                <img src="<?= e($cover) ?>" alt="cover" class="w-16 h-16 rounded-2xl object-cover border border-white/10" loading="lazy" />
              <?php else: ?>
                <div class="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-slate-500 text-xs">APP</div>
              <?php endif; ?>
              <div class="min-w-0">
                <div class="font-extrabold text-xl truncate"><?= e($it['title'] ?? '') ?></div>
                <div class="text-xs text-slate-500 mt-1">
                  <?= e($it['platform'] ?? 'App') ?>
                  <?php if(($it['mode'] ?? '')==='once'): ?>
                    • <span class="text-orange-200">Link 1 lần</span>
                  <?php else: ?>
                    • <span class="text-emerald-200">Vĩnh viễn</span>
                  <?php endif; ?>
                  • <span class="text-slate-600">Downloads: <?= (int)($it['downloads'] ?? 0) ?></span>
                </div>
                <?php if(!empty($it['description'])): ?>
                  <div class="mt-3 text-sm text-slate-300 whitespace-pre-line"><?= e((string)$it['description']) ?></div>
                <?php endif; ?>
              </div>
            </div>

            <div class="flex flex-col gap-2 shrink-0">
              <a class="btn" href="<?= e(route_url('app_download',['token'=>(string)$it['token'],'src'=>'primary'])) ?>">Tải chính</a>
              <?php if($hasBackup): ?>
                <a class="btn btn-ghost" href="<?= e(route_url('app_download',['token'=>(string)$it['token'],'src'=>'backup'])) ?>">Tải dự phòng</a>
              <?php endif; ?>
              <div class="text-[11px] text-slate-500 text-right">Sau khi tải xong,<br>hãy cài đặt/đổi mật khẩu nếu cần.</div>
            </div>
          </div>

          <?php if($imgs): ?>
            <div class="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-2">
              <?php foreach(array_slice($imgs,0,8) as $img): ?>
                <a href="<?= e($img) ?>" target="_blank" class="block">
                  <img src="<?= e($img) ?>" alt="img" class="w-full h-24 rounded-xl object-cover border border-white/10 hover:border-orange-500/30 transition" loading="lazy" />
                </a>
              <?php endforeach; ?>
            </div>
            <?php if(count($imgs)>8): ?>
              <div class="text-xs text-slate-500 mt-2">+<?= (int)(count($imgs)-8) ?> hình nữa (bấm vào ảnh để mở)</div>
            <?php endif; ?>
          <?php endif; ?>
        </div>
      <?php endforeach; endif; ?>
    </div>

    <div class="mt-6 p-4 rounded-2xl bg-white/5 border border-white/10 text-sm text-slate-300">
      <div class="font-extrabold mb-1">Lưu ý</div>
      <ul class="list-disc pl-5 space-y-1 text-slate-400">
        <li>Nếu là tài khoản/game code: hãy <b>kích hoạt/đổi mật khẩu</b> ngay sau khi nhận để tránh lỗi hoặc trùng phiên.</li>
        <li>Link “1 lần” chỉ mở được 1 lần trên toàn hệ thống. Nếu mở nhầm, liên hệ admin để reset/link mới.</li>
      </ul>
    </div>
  </div>
</div>
