<?php
$u = auth_user();
$uid = (int)$u['id'];

shop_ensure_schema();

$w = wallet_get($uid);
$points = points_balance($uid);

// Banners + marquee
$banners = [];
$ann = [];
try {
  $bWhere = db_has_column('banners','is_active') ? "WHERE is_active=1" : '';
  $bOrder = db_has_column('banners','sort_order') ? "ORDER BY sort_order ASC, id DESC" : "ORDER BY id DESC";
  $banners = db()->query("SELECT * FROM banners {$bWhere} {$bOrder} LIMIT 10")->fetchAll() ?: [];

  // banner views (once per session)
  if (!isset($_SESSION['banner_seen'])) $_SESSION['banner_seen'] = [];
  foreach($banners as $bb){
    $bid = (int)($bb['id'] ?? 0);
    if ($bid<=0) continue;
    if (!isset($_SESSION['banner_seen'][$bid])) {
      $_SESSION['banner_seen'][$bid] = 1;
      try { if (db_has_column('banners','views')) db()->prepare("UPDATE banners SET views=views+1 WHERE id=?")->execute([$bid]); } catch (Throwable $e) {}
    }
  }

  $aWhere = db_has_column('announcements','is_active') ? "WHERE is_active=1" : '';
  $aOrder = db_has_column('announcements','sort_order') ? "ORDER BY sort_order ASC, id DESC" : "ORDER BY id DESC";
  $ann = db()->query("SELECT * FROM announcements {$aWhere} {$aOrder} LIMIT 10")->fetchAll() ?: [];
} catch (Throwable $e) {
  $banners = []; $ann = [];
}

$rankInfo = rank_progress_for_user($uid);
$orders_ok = (int)($rankInfo['orders_ok'] ?? 0);
$currentRank = $rankInfo['current'] ?: ['name'=>'ĐỒNG','rate_normal'=>0,'rate_promo'=>0,'icon'=>'badge-check'];
$nextRank = $rankInfo['next'];
$progressPct = (int)($rankInfo['pct'] ?? 0);
$remain = $nextRank ? max(0, (int)$nextRank['require_orders'] - $orders_ok) : 0;

// Shop stats
$st = db()->prepare("SELECT COUNT(*) c, COALESCE(SUM(amount_vnd),0) s FROM shop_orders WHERE user_id=?");
$st->execute([$uid]);
$row = $st->fetch(PDO::FETCH_ASSOC) ?: ['c'=>0,'s'=>0];
$total_keys = (int)($row['c'] ?? 0);
$total_spent = (int)($row['s'] ?? 0);

$recent = shop_user_orders($uid, 5);


// Leaderboard (Top points)
$leader_points = [];
try {
  $leader_points = db()->query("SELECT id, name, username, points FROM users ORDER BY points DESC, id DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) { $leader_points = []; }

// Activity feed: recent orders (global)
$activity = [];
try {
  $activity = db()->query("SELECT o.created_at, o.pay_method, o.amount_vnd, o.points, u.name AS user_name, u.username AS user_username, p.title AS product_title
    FROM shop_orders o
    JOIN users u ON u.id=o.user_id
    JOIN shop_products p ON p.id=o.product_id
    ORDER BY o.id DESC LIMIT 12")->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) { $activity = []; }

// Community links
$links = [];
try {
  $links = db()->query("SELECT * FROM community_links WHERE is_active=1 ORDER BY sort_order ASC, id DESC LIMIT 2")->fetchAll() ?: [];
} catch (Throwable $e) {}
?>

<?php if($ann): ?>
  <div class="mb-4 card p-3 overflow-hidden">
    <div class="flex items-center gap-2 text-sm text-slate-200">
      <?= lucide_icon('megaphone','w-4 h-4 text-orange-300') ?>
      <div class="marquee flex-1 whitespace-nowrap overflow-hidden">
        <div class="inline-block animate-marquee">
          <?php foreach($ann as $a): ?>
            <span class="mx-6 text-slate-300"><?= e($a['text'] ?? $a['title'] ?? '') ?></span>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>

<!-- HERO -->
<div class="card shadow-soft p-6 lg:p-8 overflow-hidden"
     style="background:linear-gradient(135deg, rgba(255,140,0,.92), rgba(255,140,0,.65)); border-color: rgba(255,170,70,.35);">
  <div class="max-w-3xl">
    <div class="text-2xl lg:text-3xl font-extrabold text-white">Xin chào, <?= e($u['name']) ?>! 👋</div>
    <div class="mt-2 text-white/90">
      Rank hiện tại: <b><?= e($currentRank['name'] ?? 'ĐỒNG') ?></b>
      • Tổng đơn key: <b><?= (int)$total_keys ?></b>
      <?php if($nextRank): ?>
        • Còn <b><?= (int)$remain ?></b> đơn để lên hạng <b><?= e($nextRank['name'] ?? '') ?></b>
      <?php endif; ?>
    </div>

    <div class="mt-5">
      <div class="flex items-center justify-between gap-3">
        <div class="text-sm text-white/90 font-semibold">Tiến độ Rank</div>
        <div class="text-sm text-white/90 font-extrabold"><?= (int)$progressPct ?>%</div>
      </div>
      <div class="mt-2 h-3 rounded-full bg-black/20 overflow-hidden">
        <div class="h-full bg-white/90" style="width: <?= (int)$progressPct ?>%"></div>
      </div>
    </div>

    <div class="mt-6 flex flex-wrap gap-3">
      <a class="btn btn-primary" href="<?= e(route_url('shop')) ?>">
        <?= lucide_icon('key','w-5 h-5') ?> Mua key ngay
      </a>
      <a class="btn" href="<?= e(route_url('rewards')) ?>">
        <?= lucide_icon('coins','w-5 h-5') ?> Đổi điểm lấy key
      </a>
      <a class="btn btn-ghost" href="<?= e(route_url('my_keys')) ?>">
        <?= lucide_icon('vault','w-5 h-5') ?> Kho key
      </a>
    </div>
  </div>
</div>

<!-- STATS -->
<div class="mt-6 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
  <div class="card p-5">
    <div class="flex items-center justify-between">
      <div class="text-sm text-slate-400">Số dư ví</div>
      <?= lucide_icon('wallet','w-5 h-5 text-orange-300') ?>
    </div>
    <div class="mt-2 text-2xl font-extrabold"><?= format_vnd((float)($w['balance'] ?? 0)) ?></div>
    <div class="text-xs text-slate-500 mt-1">Dùng để mua key trực tiếp</div>
  </div>
  <div class="card p-5">
    <div class="flex items-center justify-between">
      <div class="text-sm text-slate-400">Điểm hiện có</div>
      <?= lucide_icon('coins','w-5 h-5 text-amber-300') ?>
    </div>
    <div class="mt-2 text-2xl font-extrabold"><?= (int)$points ?> điểm</div>
    <div class="text-xs text-slate-500 mt-1">Làm nhiệm vụ để tích điểm</div>
  </div>
  <div class="card p-5">
    <div class="flex items-center justify-between">
      <div class="text-sm text-slate-400">Tổng đơn key</div>
      <?= lucide_icon('receipt','w-5 h-5 text-slate-200') ?>
    </div>
    <div class="mt-2 text-2xl font-extrabold"><?= (int)$total_keys ?></div>
    <div class="text-xs text-slate-500 mt-1">Tính cả mua & đổi điểm</div>
  </div>
  <div class="card p-5">
    <div class="flex items-center justify-between">
      <div class="text-sm text-slate-400">Tổng chi tiêu</div>
      <?= lucide_icon('shopping-cart','w-5 h-5 text-emerald-300') ?>
    </div>
    <div class="mt-2 text-2xl font-extrabold"><?= format_vnd((int)$total_spent) ?></div>
    <div class="text-xs text-slate-500 mt-1">Chỉ tính mua bằng ví</div>
  </div>
</div>

<!-- BANNERS -->
<?php if($banners): ?>
  <div class="mt-6">
    <div class="grid lg:grid-cols-3 gap-4">
      <?php foreach($banners as $b): ?>
        <a class="card overflow-hidden block" href="<?= e(route_url('go',['bid'=>(int)($b['id']??0),'u'=>($b['link_url']??'#')])) ?>">
          <?php if(!empty($b['image_url'])): ?>
            <img src="<?= e($b['image_url']) ?>" class="w-full h-40 object-cover" alt="">
          <?php else: ?>
            <div class="p-6 text-slate-200"><?= e($b['title'] ?? 'Banner') ?></div>
          <?php endif; ?>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
<?php endif; ?>

<!-- RECENT -->
<div class="mt-6 card p-5">
  <div class="flex items-center justify-between gap-3">
    <div>
      <div class="text-lg font-extrabold">Đơn gần đây</div>
      <div class="text-sm text-slate-400 mt-1">Xem nhanh 5 đơn gần nhất</div>
    </div>
    <a href="<?= e(route_url('orders')) ?>" class="btn btn-ghost">Xem tất cả</a>
  </div>

  <div class="mt-4 overflow-x-auto">
    <table class="min-w-full text-sm">
      <thead class="text-slate-400">
        <tr>
          <th class="text-left font-semibold px-3 py-2">Mã đơn</th>
          <th class="text-left font-semibold px-3 py-2">Sản phẩm</th>
          <th class="text-left font-semibold px-3 py-2">Thanh toán</th>
          <th class="text-left font-semibold px-3 py-2">Thời gian</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-white/5">
        <?php if(!$recent): ?>
          <tr><td colspan="4" class="px-3 py-4 text-slate-400">Chưa có đơn. Vào Shop Key để mua.</td></tr>
        <?php else: foreach($recent as $it): ?>
          <tr>
            <td class="px-3 py-3 font-extrabold"><?= e($it['order_code'] ?? '') ?></td>
            <td class="px-3 py-3"><?= e($it['product_title'] ?? '') ?></td>
            <td class="px-3 py-3">
              <?php if(($it['pay_method'] ?? '')==='wallet'): ?>
                <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-200 text-xs font-bold"><?= lucide_icon('wallet','w-4 h-4') ?> <?= format_vnd((int)($it['amount_vnd'] ?? 0)) ?></span>
              <?php else: ?>
                <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-200 text-xs font-bold"><?= lucide_icon('coins','w-4 h-4') ?> <?= (int)($it['points'] ?? 0) ?> điểm</span>
              <?php endif; ?>
            </td>
            <td class="px-3 py-3 text-slate-400"><?= e(date('d/m/Y H:i', strtotime($it['created_at'] ?? 'now'))) ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>


<!-- LEADERBOARD + ACTIVITY -->
<div class="mt-6 grid lg:grid-cols-2 gap-4">
  <div class="card p-5">
    <div class="flex items-center justify-between gap-3">
      <div>
        <div class="text-lg font-extrabold">Bảng xếp hạng</div>
        <div class="text-sm text-slate-400 mt-1">Top 10 người có điểm cao nhất</div>
      </div>
      <div class="text-xs text-slate-500">Không load trang cũ</div>
    </div>

    <div class="mt-4 overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="text-slate-400">
          <tr>
            <th class="text-left font-semibold px-3 py-2">#</th>
            <th class="text-left font-semibold px-3 py-2">User</th>
            <th class="text-left font-semibold px-3 py-2">Điểm</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-white/5">
          <?php if(!$leader_points): ?>
            <tr><td colspan="3" class="px-3 py-4 text-slate-400">Chưa có dữ liệu.</td></tr>
          <?php else: foreach($leader_points as $i=>$lp): ?>
            <tr>
              <td class="px-3 py-3 font-extrabold"><?= (int)($i+1) ?></td>
              <td class="px-3 py-3">
                <div class="font-semibold"><?= e($lp['name'] ?? '') ?></div>
                <div class="text-xs text-slate-500"><?= !empty($lp['username']) ? '@'.e($lp['username']) : '' ?></div>
              </td>
              <td class="px-3 py-3 font-extrabold text-amber-200"><?= (int)($lp['points'] ?? 0) ?></td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="card p-5">
    <div class="flex items-center justify-between gap-3">
      <div>
        <div class="text-lg font-extrabold">Hoạt động mua key</div>
        <div class="text-sm text-slate-400 mt-1">Giao dịch mới nhất (demo kiểu “... 5 phút trước”)</div>
      </div>
      <?= lucide_icon('activity','w-5 h-5 text-orange-300') ?>
    </div>

    <div class="mt-4 space-y-3">
      <?php if(!$activity): ?>
        <div class="text-slate-400">Chưa có hoạt động.</div>
      <?php else: foreach($activity as $a): ?>
        <div class="rounded-2xl border border-white/10 bg-black/20 p-4">
          <div class="font-semibold">
            <?= e($a['user_name'] ?? '') ?>
            <?php if(!empty($a['user_username'])): ?><span class="text-slate-500">@<?= e($a['user_username']) ?></span><?php endif; ?>
            đã mua <span class="text-orange-200"><?= e($a['product_title'] ?? '') ?></span>
          </div>
          <div class="text-sm text-slate-400 mt-1">
            <?php if(($a['pay_method'] ?? '')==='wallet'): ?>
              Giá <?= format_vnd((int)($a['amount_vnd'] ?? 0)) ?>
            <?php else: ?>
              <?= (int)($a['points'] ?? 0) ?> điểm
            <?php endif; ?>
            • <?= e(time_ago_vn($a['created_at'] ?? 'now')) ?>
          </div>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>
</div>


<?php if($links): ?>
<div class="mt-6 grid sm:grid-cols-2 gap-4">
  <?php foreach($links as $l): ?>
    <a href="<?= e($l['url'] ?? '#') ?>" class="card p-5 hover:border-orange-500/30 transition">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-2xl bg-white/5 border border-white/10 grid place-items-center"><?= lucide_icon('link','w-5 h-5') ?></div>
        <div class="min-w-0">
          <div class="font-extrabold truncate"><?= e($l['title'] ?? 'Link') ?></div>
          <div class="text-sm text-slate-400 mt-1 line-clamp-2"><?= e($l['description'] ?? '') ?></div>
        </div>
      </div>
    </a>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<style>
@keyframes marquee { 0% { transform: translateX(0); } 100% { transform: translateX(-50%); } }
.animate-marquee { animation: marquee 18s linear infinite; }
</style>
