<?php
csrf_require();
$token = trim((string)($_GET['token'] ?? ''));
if($token===''){ http_response_code(404); echo 'Not found'; exit; }

$src = (string)($_GET['src'] ?? 'primary');
$src = $src==='backup' ? 'backup' : 'primary';

$ip = client_ip();
$res = app_link_track_download($token, $ip);
if(!$res['ok']){
  http_response_code(403);
  $err = $res['error'] ?? 'Link không hợp lệ.';
  ?>
  <div class="max-w-2xl mx-auto">
    <div class="card p-6">
      <div class="text-2xl font-extrabold">Không thể tải</div>
      <div class="mt-3 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div>
      <a class="btn btn-ghost w-full mt-4" href="<?= e(route_url('app')) ?>">Quay lại</a>
    </div>
  </div>
  <?php
  exit;
}

$row = (array)($res['row'] ?? []);
$url = app_link_resolve_url($row, $src);
if($url===''){ http_response_code(404); echo 'Not found'; exit; }

try{ audit_log((int)(auth_user()['id'] ?? 0),'app_download','app_link',$token,['ip'=>$ip]); }catch(Throwable $e){}
redirect($url);
exit;
