<?php
$u = auth_user(); require_auth();
if(!is_vendor()) { http_response_code(404); include __DIR__ . '/404.php'; exit; }

$uid=(int)$u['id'];
$w = wallet_get($uid);

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  $amount = (float)($_POST['amount'] ?? 0);
  if($amount < 10000){ flash_set('error','Tối thiểu 10.000 đ'); redirect(route_url('wallet')); }
  try{
    wallet_apply($uid,'withdraw_create',$amount,'withdraw_requests',null,'User withdraw create');
    db()->prepare("INSERT INTO withdraw_requests(user_id,amount,status,created_at) VALUES (?,?, 'pending', NOW())")->execute([$uid,$amount]);
    flash_set('success','Đã tạo yêu cầu rút tiền.');
  }catch(Throwable $e){
    flash_set('error',$e->getMessage());
  }
  redirect(route_url('wallet'));
}

$tx = db()->prepare("SELECT * FROM wallet_transactions WHERE user_id=? ORDER BY id DESC LIMIT 10");
$tx->execute([$uid]);
$rows = $tx->fetchAll();
?>
<div class="grid grid-cols-1 xl:grid-cols-3 gap-4">
  <div class="card p-6">
    <div class="text-xl font-extrabold">Quản Lý Tài Chính</div>
    <div class="mt-5 card p-5 border border-blue-500/25" style="background:linear-gradient(135deg, rgba(37,99,235,.75), rgba(37,99,235,.35));">
      <div class="text-white/80 font-semibold">Số Dư Khả Dụng</div>
      <div class="text-4xl font-extrabold mt-1"><?= format_vnd($w['balance']) ?></div>
      <div class="text-white/70 mt-2 text-sm">✓ Đã đối soát</div>
    </div>
  </div>

  <div class="card p-6">
    <div class="text-lg font-extrabold">Tạo Yêu Cầu Rút Tiền</div>
    <form method="post" class="mt-4 space-y-3">
      <input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
      <div>
        <label class="text-sm text-slate-400">Số tiền muốn rút</label>
        <div class="mt-1 flex items-center gap-2">
          <input name="amount" inputmode="numeric" class="flex-1 px-4 py-3 rounded-2xl bg-white/5 border border-white/10 focus:outline-none focus:ring-2 focus:ring-blue-500/40" placeholder="0">
          <div class="px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-slate-300 font-bold">VND</div>
        </div>
        <div class="mt-2 text-xs text-slate-400">Tối thiểu: <b>10.000 đ</b> • Tối đa: <b><?= format_vnd($w['balance']) ?></b></div>
      </div>
      <button class="w-full py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 font-extrabold">Gửi Yêu Cầu</button>
    </form>
  </div>

  <div class="card p-6 xl:col-span-1">
    <div class="text-lg font-extrabold">Lịch Sử Giao Dịch</div>
    <div class="mt-4 overflow-hidden rounded-2xl border border-white/10">
      <div class="grid grid-cols-12 gap-3 px-4 py-3 text-[11px] uppercase tracking-widest text-slate-400 bg-black/25">
        <div class="col-span-4">Mã</div>
        <div class="col-span-4">Thời gian</div>
        <div class="col-span-2 text-right">Số tiền</div>
        <div class="col-span-2 text-right">Loại</div>
      </div>
      <?php if(!$rows): ?>
        <div class="px-4 py-6 text-slate-400">Chưa có giao dịch nào</div>
      <?php else: foreach($rows as $t): ?>
        <div class="grid grid-cols-12 gap-3 px-4 py-4 border-t border-white/10 items-center text-sm">
          <div class="col-span-4 font-bold">#<?= (int)$t['id'] ?></div>
          <div class="col-span-4 text-slate-400"><?= e($t['created_at']) ?></div>
          <div class="col-span-2 text-right font-extrabold <?= ($t['amount']>=0?'text-emerald-300':'text-rose-300') ?>">
            <?= ($t['amount']>=0?'+':'') . format_vnd($t['amount']) ?>
          </div>
          <div class="col-span-2 text-right text-slate-300"><?= e($t['type']) ?></div>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>
</div>
