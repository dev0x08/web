<?php
$u = auth_user(); require_auth();
$uid=(int)$u['id'];
if (isset($_GET['read'])) {
  $nid = (int)$_GET['read'];
  notify_mark_read($uid, $nid);
  redirect(route_url('notifications'));
}

$rows = notify_list($uid, 80);
?>
<div class="card p-6">
  <div class="flex items-center justify-between gap-3">
    <div class="text-xl font-extrabold">Thông báo</div>
    <div class="text-xs text-slate-400">Chạm vào thông báo để đánh dấu đã đọc</div>
  </div>

  <div class="mt-5 space-y-3">
    <?php if(!$rows): ?>
      <div class="text-slate-400">Chưa có thông báo</div>
    <?php else: foreach($rows as $n): ?>
      <a href="<?= e(route_url('notifications',['read'=>$n['id']])) ?>"
         class="block p-4 rounded-2xl border border-white/10 hover:bg-white/5 transition <?= ((int)$n['is_read']===0?'bg-orange-500/5':'bg-black/25') ?>">
        <div class="flex items-start gap-3">
          <div class="mt-0.5"><?= lucide_icon(((int)$n['is_read']===0?'bell-ring':'bell'),'w-5 h-5') ?></div>
          <div class="min-w-0">
            <div class="font-extrabold truncate"><?= e($n['title']) ?></div>
            <div class="text-sm text-slate-300 mt-1 break-words"><?= e($n['body']) ?></div>
            <?php if(!empty($n['link_url'])): ?>
              <div class="text-xs text-blue-300 mt-2 truncate"><?= e($n['link_url']) ?></div>
            <?php endif; ?>
            <div class="text-xs text-slate-500 mt-2"><?= e($n['created_at']) ?></div>
          </div>
          <?php if((int)$n['is_read']===0): ?>
            <span class="ml-auto w-2.5 h-2.5 rounded-full bg-orange-400 mt-2"></span>
          <?php endif; ?>
        </div>
      </a>
    <?php endforeach; endif; ?>
  </div>
</div>
