<?php
require_auth();
csrf_require();
support_ensure_schema();

$u = auth_user();
$uid = (int)($u['id'] ?? 0);

$ticket_id = (int)($_GET['id'] ?? 0);
$flash=null; $err=null;

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  try{
    $action=(string)($_POST['action'] ?? '');
    if($action==='create'){
      $type = (string)($_POST['type'] ?? 'general');
      $order_id = (int)($_POST['order_id'] ?? 0);
      $subject = trim((string)($_POST['subject'] ?? ''));
      $content = trim((string)($_POST['content'] ?? ''));
      if($content==='') throw new Exception('Vui lòng nhập nội dung.');
      // create ticket first to have ID for upload dir
      $tid = support_ticket_create($uid,$type, ($order_id>0?$order_id:null), $subject, $content, []);
      // handle uploads (optional) by appending a system message if any
      $att = support_handle_uploads($tid,'files',6);
      if($att){
        support_ticket_add_message($tid,'system',null,'(Đính kèm)', $att);
      }
      $flash='Đã tạo ticket. Staff sẽ phản hồi sớm.';
      redirect(route_url('support',['id'=>$tid]));
    }
    if($action==='reply'){
      if($ticket_id<=0) throw new Exception('Thiếu ticket.');
      $t = support_ticket_get($ticket_id);
      if(!$t || (int)$t['user_id']!==$uid) throw new Exception('Ticket không tồn tại.');
      if((string)$t['status']==='closed') throw new Exception('Ticket đã đóng.');
      $content = trim((string)($_POST['content'] ?? ''));
      if($content==='') throw new Exception('Vui lòng nhập nội dung.');
      $att = support_handle_uploads($ticket_id,'files',6);
      support_ticket_add_message($ticket_id,'user',$uid,$content,$att);
      $flash='Đã gửi phản hồi.';
      redirect(route_url('support',['id'=>$ticket_id]));
    }
  }catch(Throwable $e){ $err=$e->getMessage(); }
}

if($ticket_id>0){
  $t = support_ticket_get($ticket_id);
  if(!$t || (int)$t['user_id']!==$uid){
    http_response_code(404); echo 'Not found'; exit;
  }
  $msgs = support_ticket_messages($ticket_id);
  ?>
  <div class="flex items-start justify-between gap-3">
    <div>
      <div class="text-2xl font-extrabold">Ticket #<?= (int)$t['id'] ?></div>
      <div class="text-sm text-slate-400 mt-1">Trạng thái: <b><?= e($t['status']) ?></b> • <?= e($t['created_at'] ?? '') ?></div>
      <?php if(!empty($t['subject'])): ?><div class="text-slate-200 mt-2"><?= e($t['subject']) ?></div><?php endif; ?>
    </div>
    <a class="btn btn-ghost" href="<?= e(route_url('support')) ?>">← Danh sách</a>
  </div>

  <?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
  <?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

  <div class="mt-6 card p-5">
    <div class="font-extrabold text-lg">Trao đổi</div>
    <div class="mt-4 grid gap-3">
      <?php foreach($msgs as $m):
        $who = (string)($m['sender_type'] ?? 'user');
        $isUser = ($who==='user');
        $isStaff = ($who==='staff');
        $bubble = $isUser ? 'bg-white/5 border-white/10' : ($isStaff ? 'bg-orange-500/10 border-orange-500/20' : 'bg-slate-500/10 border-slate-500/20');
        $label = $isUser ? 'Bạn' : ($isStaff ? 'Staff' : 'Hệ thống');
        $atts = [];
        if(!empty($m['attachments'])){
          $tmp = json_decode((string)$m['attachments'], true);
          if(is_array($tmp)) $atts=$tmp;
        }
      ?>
        <div class="p-4 rounded-2xl border <?= $bubble ?>">
          <div class="text-xs text-slate-400 flex items-center justify-between gap-2">
            <div><?= e($label) ?></div>
            <div><?= e($m['created_at'] ?? '') ?></div>
          </div>
          <div class="mt-2 text-sm text-slate-200 whitespace-pre-line"><?= e($m['content'] ?? '') ?></div>

          <?php if($atts): ?>
            <div class="mt-3 grid sm:grid-cols-3 gap-2">
              <?php foreach($atts as $a): ?>
                <a class="block rounded-xl overflow-hidden border border-white/10 hover:border-orange-500/30 transition" href="<?= e(base_url($a)) ?>" target="_blank" rel="noopener">
                  <img src="<?= e(base_url($a)) ?>" alt="attach" class="w-full h-28 object-cover">
                </a>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>

    <?php if((string)$t['status']!=='closed'): ?>
      <form method="post" enctype="multipart/form-data" class="mt-5" data-once="1">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="reply">
        <textarea class="input min-h-[120px]" name="content" placeholder="Nhập phản hồi..."></textarea>
        <div class="mt-3 flex flex-col sm:flex-row gap-2 items-start sm:items-center justify-between">
          <input class="input" type="file" name="files[]" multiple accept="image/*">
          <button class="btn" type="submit">Gửi</button>
        </div>
        <div class="text-xs text-slate-500 mt-2">Tip: bạn có thể đính kèm ảnh chụp lỗi. (tối đa <?= (int)setting('upload_max_mb',5) ?>MB/ảnh)</div>
      </form>
    <?php else: ?>
      <div class="text-sm text-slate-500 mt-4">Ticket đã đóng.</div>
    <?php endif; ?>
  </div>
  <?php
  exit;
}

$tickets = support_user_tickets($uid, 200);
?>
<div class="flex items-start justify-between gap-3">
  <div>
    <div class="text-2xl font-extrabold">Hỗ trợ / Bảo hành</div>
    <div class="text-sm text-slate-400 mt-1">Gửi ticket để được hỗ trợ key lỗi, đổi key, refund...</div>
  </div>
</div>

<?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 grid lg:grid-cols-3 gap-4">
  <div class="card p-5">
    <div class="font-extrabold text-lg">Tạo ticket</div>
    <form method="post" enctype="multipart/form-data" class="mt-4 grid gap-3" data-once="1">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="create">
      <div>
        <div class="text-xs text-slate-500 mb-1">Loại</div>
        <select class="input" name="type">
          <option value="key_issue">Key lỗi</option>
          <option value="refund">Hoàn tiền</option>
          <option value="account_issue">Tài khoản lỗi</option>
          <option value="other">Khác</option>
        </select>
      </div>
      <div>
        <div class="text-xs text-slate-500 mb-1">Order ID (nếu có)</div>
        <input class="input" name="order_id" type="number" placeholder="Ví dụ: 123">
      </div>
      <div>
        <div class="text-xs text-slate-500 mb-1">Tiêu đề</div>
        <input class="input" name="subject" placeholder="Ví dụ: Key Steam bị trùng">
      </div>
      <div>
        <div class="text-xs text-slate-500 mb-1">Nội dung</div>
        <textarea class="input min-h-[140px]" name="content" placeholder="Mô tả vấn đề, kèm thời gian, ảnh..."></textarea>
      </div>
      <div>
        <div class="text-xs text-slate-500 mb-1">Ảnh (tuỳ chọn)</div>
        <input class="input" type="file" name="files[]" multiple accept="image/*">
      </div>
      <button class="btn w-full" type="submit">Gửi ticket</button>
      <div class="text-xs text-slate-500">Ticket sẽ được staff/mod xử lý sớm nhất.</div>
    </form>
  </div>

  <div class="lg:col-span-2 card p-5">
    <div class="font-extrabold text-lg">Ticket của bạn</div>
    <div class="mt-4 grid gap-2">
      <?php if(!$tickets): ?>
        <div class="text-sm text-slate-500">Chưa có ticket nào.</div>
      <?php else: foreach($tickets as $t): ?>
        <a class="p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-orange-500/30 transition"
           href="<?= e(route_url('support',['id'=>(int)$t['id']])) ?>">
          <div class="flex items-center justify-between gap-2">
            <div class="font-extrabold">#<?= (int)$t['id'] ?> • <?= e($t['type'] ?? '') ?></div>
            <div class="text-xs text-slate-400"><?= e($t['status'] ?? '') ?></div>
          </div>
          <?php if(!empty($t['subject'])): ?><div class="mt-1 text-slate-200"><?= e($t['subject']) ?></div><?php endif; ?>
          <?php if(!empty($t['staff_note'])): ?><div class="mt-2 text-xs text-orange-200">Staff note: <?= e($t['staff_note']) ?></div><?php endif; ?>
          <div class="text-xs text-slate-500 mt-2"><?= e($t['created_at'] ?? '') ?></div>
        </a>
      <?php endforeach; endif; ?>
    </div>
  </div>
</div>
