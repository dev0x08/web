<?php
$u = auth_user(); require_auth(); csrf_require();
$uid = (int)$u['id'];

$flash=null; $err=null;

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  $action = $_POST['action'] ?? '';
  try{
    if($action==='feature'){
      $bid = (int)($_POST['badge_id'] ?? 0);
      if($bid<=0) throw new Exception('Thiếu badge.');
      if(!user_has_badge($uid,$bid)) throw new Exception('Bạn chưa sở hữu badge này.');
      db()->prepare("UPDATE users SET featured_badge_id=? WHERE id=?")->execute([$bid,$uid]);
      $flash='Đã cập nhật badge nổi bật.';
      $u = auth_user();
    }
        if($action==='set_title_level'){
      $title = trim((string)($_POST['title'] ?? ''));
      $items = level_titles_available($uid);
      $ok=false;
      foreach($items as $it){ if((string)$it['title']===$title){ $ok=true; break; } }
      if(!$ok) throw new Exception('Title này chưa mở khoá theo level.');
      db()->prepare("UPDATE users SET display_title=? WHERE id=?")->execute([$title,$uid]);
      $flash='Đã chọn title theo level.';
      $u=auth_user();
    }

if($action==='set_title'){
      $bid = (int)($_POST['badge_id'] ?? 0);
      if($bid<=0) throw new Exception('Thiếu badge.');
      $st=db()->prepare("SELECT b.* FROM user_badges ub JOIN badges b ON b.id=ub.badge_id WHERE ub.user_id=? AND b.id=? LIMIT 1");
      $st->execute([$uid,$bid]);
      $b=$st->fetch(PDO::FETCH_ASSOC);
      if(!$b) throw new Exception('Badge không hợp lệ.');
      $title=trim((string)($b['title'] ?? ''));
      if($title==='') throw new Exception('Badge này không có title.');
      db()->prepare("UPDATE users SET display_title=? WHERE id=?")->execute([$title,$uid]);
      $flash='Đã chọn title: '.$title;
      $u = auth_user();
    }
    if($action==='clear_title'){
      db()->prepare("UPDATE users SET display_title=NULL WHERE id=?")->execute([$uid]);
      $flash='Đã xoá title.';
      $u = auth_user();
    }
  }catch(Throwable $e){ $err=$e->getMessage(); }
}

$earned = user_badges($uid);
$featured = (int)($u['featured_badge_id'] ?? 0);
$curTitle = trim((string)($u['display_title'] ?? ''));
?>
<div class="flex items-start justify-between gap-4">
  <div>
    <div class="text-2xl font-extrabold">Badge & Title</div>
    <div class="text-sm text-slate-400 mt-1">Sưu tầm badge và chọn title hiển thị.</div>
  </div>
</div>

<?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 grid lg:grid-cols-3 gap-4">
  <div class="lg:col-span-2 card p-5">
    <div class="flex items-center justify-between">
      <div class="font-extrabold text-lg">Badge đã sở hữu</div>
      <div class="text-xs text-slate-400"><?= count($earned) ?> badge</div>
    </div>

    <div class="mt-4 grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
      <?php if(!$earned): ?>
        <div class="text-sm text-slate-500">Chưa có badge nào. Hãy nạp/mua/điểm danh để nhận!</div>
      <?php else: foreach($earned as $b): ?>
        <?php $isFeat = $featured === (int)$b['id']; ?>
        <div class="p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-white/10 transition">
          <div class="flex items-start justify-between gap-3">
            <div class="w-10 h-10 rounded-2xl bg-white/5 flex items-center justify-center border border-white/10">
              <?= lucide_icon((string)$b['icon'],'w-5 h-5') ?>
            </div>
            <div class="text-[11px] px-2 py-1 rounded-full border border-white/10 text-slate-300">
              <?= strtoupper(e($b['rarity'])) ?>
            </div>
          </div>

          <div class="mt-3 font-extrabold"><?= e($b['name']) ?></div>
          <div class="text-xs text-slate-400 mt-1"><?= e($b['description'] ?? '') ?></div>
          <div class="text-[11px] text-slate-500 mt-2">Nhận lúc: <?= e($b['earned_at'] ?? '') ?></div>

          <div class="mt-3 flex gap-2">
            <form method="post" data-once="1" class="flex-1">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="feature">
              <input type="hidden" name="badge_id" value="<?= (int)$b['id'] ?>">
              <button class="btn w-full <?= $isFeat ? 'opacity-80' : '' ?>" type="submit"><?= $isFeat ? 'Đang nổi bật' : 'Đặt nổi bật' ?></button>
            </form>
          </div>

          <?php if(trim((string)($b['title'] ?? '')) !== ''): ?>
            <div class="mt-2 flex gap-2">
              <form method="post" data-once="1" class="flex-1">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="set_title">
                <input type="hidden" name="badge_id" value="<?= (int)$b['id'] ?>">
                <button class="btn btn-ghost w-full" type="submit">Chọn title</button>
              </form>
            </div>
          <?php endif; ?>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>

  <div class="card p-5">
    <div class="font-extrabold text-lg">Hiển thị hiện tại</div>

    <div class="mt-4 p-4 rounded-2xl bg-white/5 border border-white/5">
      <div class="text-xs text-slate-400">Title</div>
      <div class="mt-1 font-extrabold"><?= $curTitle!=='' ? e($curTitle) : 'Chưa đặt' ?></div>
      <form method="post" class="mt-3" data-once="1">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="clear_title">
        <button class="btn btn-ghost w-full" type="submit">Xoá title</button>
      </form>
    </div>

    <div class="mt-4 p-4 rounded-2xl bg-white/5 border border-white/5">
      <div class="text-xs text-slate-400">Badge nổi bật</div>
      <div class="mt-2 text-sm text-slate-300">
        <?= $featured>0 ? ('#'.$featured) : 'Chưa đặt' ?>
      </div>
      <div class="text-xs text-slate-500 mt-2">Badge nổi bật sẽ hiện trong trang cá nhân.</div>
    </div>

    <div class="mt-4 p-4 rounded-2xl bg-white/5 border border-white/5">
      <div class="font-extrabold">Gợi ý nhanh</div>
      <div class="text-sm text-slate-400 mt-2 leading-relaxed">
        - Nạp tiền lần đầu → nhận <b>First Topup</b><br>
        - Mua key lần đầu → nhận <b>First Purchase</b><br>
        - Điểm danh đủ 7 ngày → nhận <b>7-Day Streak</b>
      </div>
    </div>
  </div>
</div>
