<?php
$u = auth_user(); require_auth();
$uid = (int)($u['id'] ?? 0);
shop_ensure_schema();

$items = shop_user_orders($uid, 100);
?>
<div class="flex items-center justify-between gap-3">
  <div>
    <div class="text-2xl font-extrabold">Lịch sử mua</div>
    <div class="text-sm text-slate-400 mt-1">Xem các đơn mua/đổi key. Key nằm trong <a class="text-orange-300 hover:underline" href="<?= e(route_url('my_keys')) ?>">Kho key</a>.</div>
  </div>
  <a href="<?= e(route_url('shop')) ?>" class="btn btn-primary inline-flex items-center gap-2">
    <?= lucide_icon('shopping-bag','w-4 h-4') ?> Mua key
  </a>
</div>

<div class="card p-0 overflow-hidden mt-6">
  <div class="overflow-x-auto">
    <table class="w-full text-sm">
      <thead class="bg-white/5 text-slate-300">
        <tr>
          <th class="text-left px-4 py-3">Thời gian</th>
          <th class="text-left px-4 py-3">Mã đơn</th>
          <th class="text-left px-4 py-3">Sản phẩm</th>
          <th class="text-left px-4 py-3">Thanh toán</th>
          <th class="text-left px-4 py-3">Trạng thái</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-white/5">
      <?php if(!$items): ?>
        <tr><td colspan="5" class="px-4 py-6 text-slate-400">Chưa có đơn nào.</td></tr>
      <?php else: foreach($items as $it): ?>
        <tr>
          <td class="px-4 py-3 text-slate-400 whitespace-nowrap"><?= e(date('d/m/Y H:i', strtotime($it['created_at'] ?? 'now'))) ?></td>
          <td class="px-4 py-3 font-semibold"><?= e($it['order_code'] ?? '') ?></td>
          <td class="px-4 py-3"><?= e($it['product_title'] ?? '') ?></td>
          <td class="px-4 py-3">
            <?php if(($it['pay_method'] ?? '')==='wallet'): ?>
              <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-200 text-xs font-bold">
                <?= lucide_icon('wallet','w-4 h-4') ?> <?= format_vnd((int)($it['amount_vnd'] ?? 0)) ?>
              </span>
            <?php else: ?>
              <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-200 text-xs font-bold">
                <?= lucide_icon('coins','w-4 h-4') ?> <?= (int)($it['points'] ?? 0) ?> điểm
              </span>
            <?php endif; ?>
          </td>
          <td class="px-4 py-3">
            <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-slate-200 text-xs font-bold">
              <?= lucide_icon('check','w-4 h-4 text-emerald-300') ?> Đã giao
            </span>
          </td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
