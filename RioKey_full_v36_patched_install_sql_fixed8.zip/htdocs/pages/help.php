<?php
$contacts = [];
try {
  $contacts = db()->query("SELECT * FROM contacts WHERE is_active=1 ORDER BY id DESC")->fetchAll();
} catch(Throwable $e) { $contacts=[]; }
$email = null; $phone = null;
foreach ($contacts as $c) {
  if (!$email && !empty($c['email'])) $email = $c['email'];
  if (!$phone && !empty($c['phone'])) $phone = $c['phone'];
}
?>
<div class="max-w-6xl mx-auto">
  <div class="flex items-start justify-between gap-4">
    <div>
      <h1 class="text-2xl sm:text-3xl font-black tracking-tight">Trợ giúp</h1>
      <p class="text-slate-400 mt-1">Liên hệ hỗ trợ và các câu hỏi thường gặp</p>
    </div>
  </div>

  <div class="grid lg:grid-cols-2 gap-6 mt-6">
    <div class="card p-5">
      <div class="font-extrabold flex items-center gap-2"><?= lucide_icon('message-circle','w-5 h-5 text-emerald-300') ?> Live Chat</div>
      <div class="text-slate-400 mt-2">Trò chuyện trực tiếp với đội ngũ hỗ trợ của chúng tôi</div>
      <div class="text-xs text-slate-500 mt-2 italic">Nhấp vào biểu tượng chat ở góc màn hình để bắt đầu</div>
    </div>
    <div class="card p-5">
      <div class="font-extrabold flex items-center gap-2"><?= lucide_icon('mail','w-5 h-5 text-orange-300') ?> Email</div>
      <div class="text-slate-400 mt-2">Gửi email và chúng tôi sẽ phản hồi trong 24h</div>
      <div class="mt-2 text-orange-300 font-semibold"><?= e($email ?: 'support@example.com') ?></div>
    </div>

    <div class="card p-5">
      <div class="font-extrabold flex items-center gap-2"><?= lucide_icon('phone','w-5 h-5 text-blue-300') ?> Hotline</div>
      <div class="text-slate-400 mt-2">Hỗ trợ nhanh theo giờ hành chính</div>
      <div class="mt-2 text-blue-300 font-semibold"><?= e($phone ?: 'Chưa cập nhật') ?></div>
    </div>

    <div class="card p-5">
      <div class="font-extrabold flex items-center gap-2"><?= lucide_icon('facebook','w-5 h-5 text-sky-300') ?> Cộng đồng</div>
      <div class="text-slate-400 mt-2">Tham gia group/fanpage để cập nhật và hỏi đáp</div>
      <div class="text-xs text-slate-500 mt-2">Quản trị viên có thể cập nhật thông tin ở Admin → Contact.</div>
    </div>

    <div class="lg:col-span-2 card p-5">
      <div class="font-extrabold text-xl">Câu hỏi thường gặp</div>
      <div class="mt-4 space-y-3">
        <details class="rounded-2xl border border-slate-800/60 bg-slate-900/30 p-4">
          <summary class="cursor-pointer font-semibold">Làm thế nào để rút tiền?</summary>
          <div class="text-slate-400 mt-2">Vào mục <b>Tài chính</b> → nhập số tiền rút → chọn phương thức → gửi yêu cầu.</div>
        </details>
        <details class="rounded-2xl border border-slate-800/60 bg-slate-900/30 p-4">
          <summary class="cursor-pointer font-semibold">Làm thế nào để giới thiệu bạn bè?</summary>
          <div class="text-slate-400 mt-2">Vào mục <b>Giới thiệu</b> → sao chép link mời và gửi cho bạn bè.</div>
        </details>
        <details class="rounded-2xl border border-slate-800/60 bg-slate-900/30 p-4">
          <summary class="cursor-pointer font-semibold">Tài khoản bị khóa thì làm gì?</summary>
          <div class="text-slate-400 mt-2">Liên hệ email hỗ trợ và cung cấp thông tin đăng ký để được kiểm tra.</div>
        </details>
      </div>
    </div>
  </div>
</div>
