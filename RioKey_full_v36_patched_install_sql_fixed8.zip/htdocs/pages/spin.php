<?php
$u = auth_user(); require_auth();
$uid = (int)($u['id'] ?? 0);
spin_ensure_schema();
$can_free = spin_can_free($uid);
$price = (int)setting('spin_price_points',50);


if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['do_spin']) && (int)($_POST['ajax'] ?? 0)===1) {
  csrf_require();
  
  // anti double-submit + idempotency (avoid double click spam)
  if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }
  $rid = (string)($_POST['rid'] ?? '');
  if ($rid === '') { $rid = bin2hex(random_bytes(8)); }
  if (!isset($_SESSION['spin_used_rids'])) $_SESSION['spin_used_rids'] = [];
  if (isset($_SESSION['spin_used_rids'][$rid])) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($_SESSION['spin_used_rids'][$rid], JSON_UNESCAPED_UNICODE);
    exit;
  }
  $now = microtime(true);
  $lockUntil = (float)($_SESSION['spin_lock_until'] ?? 0);
  if ($lockUntil > $now) {
    $resp = ['ok'=>false,'msg'=>'Đang xử lý lượt quay trước đó, vui lòng chờ...'];
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($resp, JSON_UNESCAPED_UNICODE);
    exit;
  }
  $_SESSION['spin_lock_until'] = $now + 3.5;
$free = (int)($_POST['free'] ?? 0)===1;
  $res = spin_do($uid, $free);
    // cache response by rid to avoid duplicate processing
  $_SESSION['spin_used_rids'][$rid] = $res;
  // keep only last 50 rids
  if (count($_SESSION['spin_used_rids']) > 50) { $_SESSION['spin_used_rids'] = array_slice($_SESSION['spin_used_rids'], -50, null, true); }
  $_SESSION['spin_lock_until'] = microtime(true) + 0.2;
header('Content-Type: application/json; charset=utf-8');
  echo json_encode($res, JSON_UNESCAPED_UNICODE);
  exit;
}

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['do_spin'])) {
  csrf_require();
  
  if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }
  $now = microtime(true);
  $lockUntil = (float)($_SESSION['spin_lock_until'] ?? 0);
  if ($lockUntil > $now) {
    flash_set('error','Đang xử lý lượt quay trước đó, vui lòng chờ...');
    redirect(route_url('spin'));
  }
  $_SESSION['spin_lock_until'] = $now + 3.5;
$free = (int)($_POST['free'] ?? 0)===1;
  $res = spin_do($uid, $free);
  if ($res['ok'] ?? false) {
    flash_set('ok', (string)($res['msg'] ?? 'OK'));
  } else {
    flash_set('error', (string)($res['msg'] ?? 'Có lỗi'));
  }
  redirect(route_url('spin'));
}
$enabled = (int)setting('spin_enabled',0)===1;

$logs = db()->prepare("SELECT * FROM spin_logs WHERE user_id=? ORDER BY id DESC LIMIT 20");
$logs->execute([$uid]);
$logs = $logs->fetchAll(PDO::FETCH_ASSOC) ?: [];
?>
<div class="max-w-4xl mx-auto">
  <div class="text-center">
    <h1 class="text-3xl sm:text-4xl font-black tracking-tight">Vòng quay <span class="text-orange-400">may mắn</span></h1>
    <p class="text-slate-400 mt-2">Mỗi ngày 1 lượt miễn phí • Quay thêm bằng điểm.</p>
  </div>

  <?php if(!$enabled): ?>
    <div class="mt-6 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200">Vòng quay đang tạm tắt.</div>
  <?php else: ?>
    
    <div class="mt-6 grid lg:grid-cols-2 gap-4 items-start">
      <div class="card p-5">
        <div class="font-extrabold text-lg flex items-center justify-between">
          <span>Vòng quay</span>
          <span class="text-xs text-slate-400">Hiệu ứng quay + thông báo kết quả</span>
        </div>

        <div class="mt-5 flex justify-center">
          <div class="relative w-[320px] h-[320px] sm:w-[360px] sm:h-[360px]">
            <!-- pointer -->
            <div class="absolute -top-1 left-1/2 -translate-x-1/2 z-20">
              <div class="w-0 h-0 border-l-[14px] border-r-[14px] border-b-[26px] border-l-transparent border-r-transparent border-b-orange-400 drop-shadow"></div>
            </div>

            <!-- wheel -->
            <?php $rw = spin_rewards_list(); $n = max(1, count($rw)); $ang = 360/$n; ?>
            <div id="spinWheel" class="absolute inset-0 rounded-full border border-white/10 shadow-soft overflow-hidden select-none"
                 style="transform: rotate(0deg); transition: transform 4.2s cubic-bezier(.17,.67,.12,1);">
              <div class="absolute inset-0" style="background: conic-gradient(
                from -90deg,
                rgba(249,115,22,.90) 0deg <?= $ang ?>deg,
                rgba(15,23,42,.95) <?= $ang ?>deg <?= $ang*2 ?>deg,
                rgba(249,115,22,.90) <?= $ang*2 ?>deg <?= $ang*3 ?>deg,
                rgba(15,23,42,.95) <?= $ang*3 ?>deg <?= $ang*4 ?>deg,
                rgba(249,115,22,.90) <?= $ang*4 ?>deg <?= $ang*5 ?>deg,
                rgba(15,23,42,.95) <?= $ang*5 ?>deg 360deg
              );"></div>

              <!-- labels -->
              <?php foreach($rw as $i=>$r): $label = '+'.(int)$r[1].' điểm'; ?>
                <div class="absolute left-1/2 top-1/2 w-1/2 origin-left"
                     style="transform: rotate(<?= (-90 + $i*$ang + $ang/2) ?>deg);">
                  <div class="text-[12px] sm:text-[13px] font-black tracking-tight text-white drop-shadow"
                       style="transform: translateX(12px) rotate(90deg);">
                    <?= e($label) ?>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>

            <!-- center cap -->
            <div class="absolute inset-0 grid place-items-center z-10">
              <div class="w-20 h-20 rounded-full bg-slate-950/90 border border-white/10 grid place-items-center shadow-xl">
                <?= lucide_icon('sparkles','w-7 h-7 text-orange-300') ?>
              </div>
            </div>
          </div>
        </div>

        <div class="mt-5 text-center text-sm text-slate-400">
          Mỗi ngày <b>1 lượt free</b>. Quay thêm bằng điểm.
        </div>
      </div>

      <div class="space-y-4">
        <div class="card p-5">
          <div class="font-extrabold text-lg">Quay miễn phí</div>
          <div class="text-sm text-slate-400 mt-1"><?= $can_free ? 'Bạn còn lượt miễn phí hôm nay.' : 'Hôm nay bạn đã quay miễn phí rồi.' ?></div>
          <button id="btnSpinFree" class="btn w-full mt-4" type="button" <?= $can_free?'':'disabled' ?>>Quay miễn phí</button>
        </div>

        <div class="card p-5">
          <div class="font-extrabold text-lg">Quay bằng điểm</div>
          <div class="text-sm text-slate-400 mt-1">Giá: <b><?= (int)$price ?></b> điểm / lượt</div>
          <button id="btnSpinPaid" class="btn w-full mt-4" type="button">Quay ngay</button>
        </div>

        <form id="spinAjaxForm" method="post" class="hidden">
          <?= csrf_field() ?>
          <input type="hidden" name="do_spin" value="1">
          <input type="hidden" name="ajax" value="1">
          <input type="hidden" name="free" id="spinFreeField" value="0">
        </form>

        <div class="card p-5">
          <div class="font-extrabold">Lưu ý</div>
          <div class="text-sm text-slate-400 mt-2 leading-relaxed">
            Kết quả quay được ghi vào lịch sử. Nếu bạn bấm nhiều lần khi mạng lag, hệ thống sẽ tự chặn double-click.
          </div>
        </div>
      </div>
    </div>

    <script>
    (function(){
      const wheel = document.getElementById('spinWheel');
      const form = document.getElementById('spinAjaxForm');
      const freeField = document.getElementById('spinFreeField');
      const btnFree = document.getElementById('btnSpinFree');
      const btnPaid = document.getElementById('btnSpinPaid');
      let spinning = false;
      let currentDeg = 0;

      
      // effects
      let tickTimer = null;
      let lastTickSeg = null;
      let audioCtx = null;
      function confettiBurst(count=90){
        const wrap = document.createElement('div');
        wrap.style.position='fixed';wrap.style.inset='0';wrap.style.pointerEvents='none';wrap.style.zIndex='9999';
        document.body.appendChild(wrap);
        const w=window.innerWidth,h=window.innerHeight;
        for(let i=0;i<count;i++){
          const p=document.createElement('div');
          const size=6+Math.random()*6;
          const x=w*0.5 + (Math.random()-0.5)*120;
          const y=h*0.35 + (Math.random()-0.5)*80;
          const dx=(Math.random()-0.5)*14;
          const dy=-10-Math.random()*10;
          const rot=Math.random()*360;
          const hue=Math.floor(Math.random()*360);
          p.style.position='absolute';p.style.left=x+'px';p.style.top=y+'px';
          p.style.width=size+'px';p.style.height=(size*0.55)+'px';
          p.style.background='hsl('+hue+',90%,60%)';
          p.style.borderRadius='2px';
          p.style.transform='translate(-50%,-50%) rotate('+rot+'deg)';
          p.style.opacity='0.95';
          wrap.appendChild(p);
          let t=0;
          const g=0.55+Math.random()*0.35;
          const life=900+Math.random()*650;
          const start=performance.now();
          function step(now){
            t=(now-start)/16;
            const px=x+dx*t;
            const py=y+dy*t+g*t*t;
            p.style.left=px+'px';p.style.top=py+'px';
            p.style.transform='translate(-50%,-50%) rotate('+(rot+t*18)+'deg)';
            p.style.opacity = String(Math.max(0, 1- (now-start)/life));
            if(now-start<life) requestAnimationFrame(step); else p.remove();
          }
          requestAnimationFrame(step);
        }
        setTimeout(()=>wrap.remove(), 1800);
      }
      function winSound(ok=true){
        try{
          audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
          const t0 = audioCtx.currentTime;
          function tone(freq, dur, gain){
            const o=audioCtx.createOscillator();
            const g=audioCtx.createGain();
            o.type='sine';o.frequency.value=freq;
            g.gain.setValueAtTime(0.0001, t0);
            g.gain.exponentialRampToValueAtTime(gain, t0+0.01);
            g.gain.exponentialRampToValueAtTime(0.0001, t0+dur);
            o.connect(g); g.connect(audioCtx.destination);
            o.start(t0); o.stop(t0+dur+0.02);
          }
          if(ok){
            tone(660,0.18,0.06); tone(880,0.22,0.05); tone(990,0.26,0.045);
          }else{
            tone(180,0.18,0.06); tone(140,0.22,0.05);
          }
        }catch(e){}
      }
      function haptic(ok=true){
        try{
          if(navigator.vibrate){ navigator.vibrate(ok ? [40,25,40] : [25]); }
        }catch(e){}
      }

      function tickSound(){
        try{
          audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
          const o = audioCtx.createOscillator();
          const g = audioCtx.createGain();
          o.type = 'square';
          o.frequency.value = 900;
          g.gain.value = 0.03;
          o.connect(g); g.connect(audioCtx.destination);
          o.start();
          o.stop(audioCtx.currentTime + 0.02);
        }catch(e){}
      }
      function startTicks(n){
        // approximate ticking while spinning by sampling rotation
        lastTickSeg = null;
        tickTimer = setInterval(()=>{
          const tr = wheel.style.transform || '';
          const m = tr.match(/rotate\(([-0-9.]+)deg\)/);
          const deg = m ? parseFloat(m[1]) : currentDeg;
          const norm = ((deg % 360) + 360) % 360;
          const seg = Math.floor(norm / (360/n));
          if (seg !== lastTickSeg){
            lastTickSeg = seg;
            tickSound();
          }
        }, 90);
      }
      function stopTicks(){
        if (tickTimer){ clearInterval(tickTimer); tickTimer = null; }
      }
function modalAlert(title, desc){
        if (window.RioKeyModal && RioKeyModal.alert) return RioKeyModal.alert(title, desc);
        alert(desc || title);
      }
      function modalConfirm(title, desc, onOk){
        if (window.RioKeyModal && RioKeyModal.confirm) return RioKeyModal.confirm(title, desc, onOk);
        if (confirm(desc || title)) onOk();
      }
      function modalLoading(title, desc){
        if (window.RioKeyModal && RioKeyModal.loading) return RioKeyModal.loading(title, desc);
        return { close: ()=>{} };
      }

      async function doSpin(isFree){
        if (spinning) return;
        spinning = true;
        btnFree && (btnFree.disabled = true);
        btnPaid && (btnPaid.disabled = true);

        freeField.value = isFree ? '1' : '0';
        const ridField = document.getElementById('spinRid');
        if(ridField){ ridField.value = (Date.now().toString(36)+Math.random().toString(36).slice(2)); }
        const fd = new FormData(form);
        const loading = modalLoading('Đang quay...', 'Vui lòng chờ vòng quay dừng lại.');
        try{
          const res = await fetch(window.location.href, { method:'POST', body: fd, headers: {'X-Requested-With':'XMLHttpRequest'}});
          const data = await res.json();
          if(!(data && data.ok)){
            loading.close && loading.close();
            modalAlert('Không thể quay', (data && data.msg) ? data.msg : 'Có lỗi xảy ra.');
            throw new Error('spin failed');
          }
          const idx = parseInt(data.idx ?? 0, 10) || 0;
          const n = <?= (int)$n ?>;
          const angle = 360 / n;
          // land on center of segment
          const target = 360 - (idx * angle + angle/2);
          const extra = 360 * (3 + Math.floor(Math.random()*2)); // 3-4 spins
          currentDeg = (currentDeg % 360 + extra + target) ;
          wheel.classList.add('spin-glow');
          startTicks(n);
          wheel.style.transition = 'transform 4.2s cubic-bezier(.17,.67,.12,1)';
          wheel.style.transform = 'rotate(' + currentDeg + 'deg)';

          wheel.addEventListener('transitionend', function onEnd(){
            wheel.removeEventListener('transitionend', onEnd);
            stopTicks();
            wheel.classList.remove('spin-glow');
            loading.close && loading.close();
            if(data && data.ok){ confettiBurst(100); winSound(true); haptic(true); }
            else { winSound(false); haptic(false); }
            modalAlert('Kết quả vòng quay', data.msg || 'OK');
            // reload to update history/points
            setTimeout(()=>{ window.location.reload(); }, 700);
          }, { once:true });

        } catch(e){
          // restore
          stopTicks();
          wheel.classList.remove('spin-glow');
          loading.close && loading.close();
          spinning = false;
          btnFree && (btnFree.disabled = false);
          btnPaid && (btnPaid.disabled = false);
        }
      }

      if(btnFree){
        btnFree.addEventListener('click', ()=>{
          doSpin(true);
        });
      }
      if(btnPaid){
        btnPaid.addEventListener('click', ()=>{
          modalConfirm('Xác nhận quay', 'Dùng <?= (int)$price ?> điểm để quay?', ()=>doSpin(false));
        });
      }
    })();
    </script>


    <div class="mt-6 card p-5">
      <div class="font-extrabold text-lg">Lịch sử quay (20 lượt gần nhất)</div>
      <div class="mt-4 overflow-x-auto">
        <table class="min-w-full text-sm">
          <thead class="text-slate-400">
            <tr>
              <th class="text-left font-semibold px-3 py-2">Thời gian</th>
              <th class="text-left font-semibold px-3 py-2">Kết quả</th>
              <th class="text-left font-semibold px-3 py-2">Loại</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-white/5">
            <?php if(!$logs): ?><tr><td colspan="3" class="px-3 py-4 text-slate-500">Chưa có lịch sử.</td></tr><?php endif; ?>
            <?php foreach($logs as $l): ?>
              <tr>
                <td class="px-3 py-3 text-slate-400"><?= e($l['created_at'] ?? '') ?></td>
                <td class="px-3 py-3 font-extrabold text-emerald-200"><?= e($l['reward_value'] ?? '') ?> <?= ($l['reward_type']==='points')?'điểm':'' ?></td>
                <td class="px-3 py-3"><?= ((int)$l['is_free']===1)?'Free':'Paid' ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  <?php endif; ?>
</div>
