<?php
$steps = [
  ['n'=>1,'title'=>'Nạp tiền hoặc tích điểm','desc'=>'Nạp vào Ví để mua nhanh, hoặc làm Nhiệm vụ để tích điểm đổi key.','icon'=>'wallet'],
  ['n'=>2,'title'=>'Chọn sản phẩm','desc'=>'Vào Shop Key, chọn game/gói bạn cần và xem tồn kho.','icon'=>'key'],
  ['n'=>3,'title'=>'Mua / Đổi điểm','desc'=>'Bấm Mua (trừ Ví) hoặc Đổi điểm (trừ điểm). Hệ thống tự giao key.','icon'=>'shopping-cart'],
  ['n'=>4,'title'=>'Nhận key trong Kho','desc'=>'Key/code sẽ nằm trong Kho key — bạn có thể copy để kích hoạt ngay.','icon'=>'vault'],
];
?>
<div class="text-center mt-6 sm:mt-10">
  <div class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-200 text-xs font-bold">
    HƯỚNG DẪN RIOKEY
  </div>
  <h1 class="mt-4 text-3xl sm:text-4xl font-black tracking-tight">Mua key/code game <span class="text-orange-400">tự động</span></h1>
  <p class="mt-3 text-slate-300 max-w-2xl mx-auto">RioKey là shop bán key/code game giao ngay. Bạn có thể mua bằng Ví hoặc đổi bằng điểm từ Nhiệm vụ.</p>
</div>

<div class="mt-10 grid lg:grid-cols-2 gap-6">
  <div class="card p-6">
    <div class="flex items-center gap-3">
      <div class="w-11 h-11 rounded-2xl bg-orange-500/10 border border-orange-500/20 grid place-items-center">
        <?= lucide_icon('list-checks','w-6 h-6 text-orange-200') ?>
      </div>
      <div>
        <div class="text-lg font-extrabold">Quy trình mua key</div>
        <div class="text-sm text-slate-400">4 bước nhanh gọn — tối ưu cho mobile.</div>
      </div>
    </div>

    <div class="mt-6 grid sm:grid-cols-2 gap-4">
      <?php foreach ($steps as $s): ?>
      <div class="rounded-2xl border border-white/10 bg-white/5 p-5">
        <div class="flex items-center gap-3">
          <div class="w-9 h-9 rounded-xl bg-white/5 border border-white/10 grid place-items-center text-sm font-black">
            <?= e($s['n']) ?>
          </div>
          <div class="font-bold"><?= e($s['title']) ?></div>
        </div>
        <div class="mt-2 text-sm text-slate-400 leading-relaxed"><?= e($s['desc']) ?></div>
      </div>
      <?php endforeach; ?>
    </div>

    <div class="mt-6 rounded-2xl border border-blue-500/20 bg-blue-500/10 p-4 text-blue-100">
      <div class="flex items-start gap-3">
        <div class="mt-0.5"><?= lucide_icon('info','w-5 h-5 text-blue-200') ?></div>
        <div class="text-sm leading-relaxed">
          <b>Lưu ý:</b> Với key/code đã giao, vui lòng lưu lại ngay sau khi copy. Nếu cần hỗ trợ, gửi mã đơn trong mục Lịch sử.
        </div>
      </div>
    </div>
  </div>

  <div class="card p-6">
    <div class="flex items-center gap-3">
      <div class="w-11 h-11 rounded-2xl bg-purple-500/10 border border-purple-500/20 grid place-items-center">
        <?= lucide_icon('crown','w-6 h-6 text-purple-200') ?>
      </div>
      <div>
        <div class="text-lg font-extrabold">Cơ chế Rank</div>
        <div class="text-sm text-slate-400">Tăng rank theo số đơn mua/đổi key để nhận ưu đãi.</div>
      </div>
    </div>

    <div class="mt-6 space-y-3">
      <?php $ranks = ranks_all(); foreach($ranks as $r): ?>
        <?php $perks = json_decode($r['perks_json'] ?? '[]', true) ?: []; ?>
        <div class="rounded-2xl border border-white/10 bg-black/20 p-4 lg:p-5 hover:bg-white/5 transition">
          <div class="flex items-start justify-between gap-3">
            <div class="flex items-center gap-3 min-w-0">
              <span class="w-11 h-11 rounded-2xl bg-white/5 border border-white/10 grid place-items-center shrink-0">
                <?= lucide_icon($r['icon'] ?: 'badge-check','w-5 h-5') ?>
              </span>
              <div class="min-w-0">
                <div class="flex items-center gap-2">
                  <div class="font-extrabold text-slate-100 truncate"><?= e($r['name']) ?></div>
                  <?php if(!empty($r['badge_text'])): ?>
                    <span class="px-2 py-0.5 rounded-full text-[11px] bg-orange-600/20 text-orange-300 border border-orange-500/20">
                      <?= e($r['badge_text']) ?>
                    </span>
                  <?php endif; ?>
                </div>
                <div class="text-xs text-slate-400">
                  Điều kiện: <b class="text-slate-200"><?= e($r['condition_text'] ?: ('≥ '.$r['require_orders'].' đơn')) ?></b>
                </div>
              </div>
            </div>

            <div class="text-right shrink-0">
              <div class="text-xs text-slate-400">Ưu đãi</div>
              <div class="font-extrabold text-slate-100"><?= (int)$r['rate_normal'] ?>%</div>
            </div>
          </div>

          <div class="mt-3 text-sm text-slate-300">
            Ưu đãi đặc biệt: <b class="text-orange-300"><?= (int)$r['rate_promo'] ?>%</b>
          </div>

          <?php if($perks): ?>
            <div class="mt-3 flex flex-wrap gap-2">
              <?php foreach($perks as $p): ?>
                <span class="px-3 py-1 rounded-full text-xs bg-white/5 border border-white/10 text-slate-200">
                  <?= e($p) ?>
                </span>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
