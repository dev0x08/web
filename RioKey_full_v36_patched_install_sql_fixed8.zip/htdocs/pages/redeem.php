<?php
require_auth();
$u = auth_user();
$uid = (int)($u['id'] ?? 0);

$ok=null; $err=null;

if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_require();
  $code = (string)($_POST['code'] ?? '');
  $req = (string)($_POST['request_token'] ?? '');
  if ($req==='') $req = bin2hex(random_bytes(16));

  $res = coupon_redeem($uid, $code, $req);
  if ($res['ok']) $ok = $res['msg']; else $err = $res['msg'];
}
?>
<div class="max-w-xl">
  <div class="text-2xl font-extrabold">Nhập mã nhận thưởng</div>
  <div class="text-sm text-slate-400 mt-1">Redeem / Coupon: nhận điểm hoặc cộng tiền vào ví.</div>

  <?php if($ok): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($ok) ?></div><?php endif; ?>
  <?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

  <div class="mt-6 card p-6">
    <form method="post" class="space-y-3" data-once="1">
      <?= csrf_field() ?>
      <input type="hidden" name="request_token" value="<?= e(bin2hex(random_bytes(16))) ?>">
      <input class="input" name="code" placeholder="Nhập mã của bạn (VD: RIOKEY2026)" autocomplete="off">
      <button class="btn w-full" type="submit">Nhận thưởng</button>
    </form>
    <div class="mt-4 text-xs text-slate-500">
      Mỗi mã có thể giới hạn lượt dùng / hạn sử dụng / mỗi user chỉ dùng 1 lần.
    </div>
  </div>
</div>
