<?php
// Click tracker + redirect
$bid = isset($_GET['bid']) ? (int)$_GET['bid'] : 0;
$pid = isset($_GET['pid']) ? (int)$_GET['pid'] : 0;
$u = trim((string)($_GET['u'] ?? ''));
if ($u === '' || !preg_match('#^(https?://|/)#i', $u)) { redirect(route_url('dashboard')); }

try {
  if ($bid > 0 && db_has_table('banners') && db_has_column('banners','clicks')) {
    db()->prepare("UPDATE banners SET clicks=clicks+1 WHERE id=?")->execute([$bid]);
  }
  if ($pid > 0 && db_has_table('popups') && db_has_column('popups','clicks')) {
    db()->prepare("UPDATE popups SET clicks=clicks+1 WHERE id=?")->execute([$pid]);
  }
} catch (Throwable $e) {}

redirect($u);
