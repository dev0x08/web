<?php
$u = auth_user(); require_auth();
$uid = (int)($u['id'] ?? 0);
referral_ensure_schema();

$code = referral_code_for_user($uid);
$link = base_url('/auth/register.php?ref='.$code);

$st = db()->prepare("SELECT COUNT(*) FROM users WHERE referred_by=?");
$st->execute([$uid]);
$cnt = (int)($st->fetchColumn() ?: 0);

$st2 = db()->prepare("SELECT COUNT(*) FROM referral_rewards WHERE referrer_id=?");
$st2->execute([$uid]);
$rewarded = (int)($st2->fetchColumn() ?: 0);

$min = (int)setting('referral_min_amount_vnd',50000);
$rw = (int)setting('referral_reward_points',200);
$enabled = (int)setting('referral_enabled',1)===1;
?>
<div class="max-w-4xl mx-auto">
  <div class="text-center">
    <h1 class="text-3xl sm:text-4xl font-black tracking-tight">Mời bạn bè <span class="text-orange-400">nhận điểm</span></h1>
    <p class="text-slate-400 mt-2">Bạn nhận thưởng khi bạn bè nạp/mua lần đầu đạt ngưỡng.</p>
  </div>

  <?php if(!$enabled): ?>
    <div class="mt-6 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200">Referral đang tạm tắt.</div>
  <?php else: ?>
    <div class="mt-6 card p-5">
      <div class="font-extrabold text-lg">Link giới thiệu</div>
      <div class="text-sm text-slate-400 mt-1">Ngưỡng: <b><?= format_vnd((int)$min) ?></b> • Thưởng: <b>+<?= (int)$rw ?> điểm</b></div>
      <div class="mt-4 flex flex-col sm:flex-row gap-3">
        <input class="input flex-1" value="<?= e($link) ?>" readonly onclick="this.select();">
        <button class="btn" type="button" onclick="navigator.clipboard.writeText('<?= e(addslashes($link)) ?>'); this.innerText='Đã copy'; setTimeout(()=>this.innerText='Copy',1200);">Copy</button>
      </div>
      <div class="mt-4 grid sm:grid-cols-3 gap-3 text-sm">
        <div class="p-4 rounded-2xl bg-slate-900/50 border border-white/5"><div class="text-slate-400">Bạn bè đã đăng ký</div><div class="text-2xl font-black mt-1"><?= (int)$cnt ?></div></div>
        <div class="p-4 rounded-2xl bg-slate-900/50 border border-white/5"><div class="text-slate-400">Lượt đã thưởng</div><div class="text-2xl font-black mt-1"><?= (int)$rewarded ?></div></div>
        <div class="p-4 rounded-2xl bg-slate-900/50 border border-white/5"><div class="text-slate-400">Mã của bạn</div><div class="text-2xl font-black mt-1"><?= e($code) ?></div></div>
      </div>
    </div>
  <?php endif; ?>
</div>
