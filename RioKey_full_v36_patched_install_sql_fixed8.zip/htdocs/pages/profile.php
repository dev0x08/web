<?php
$u = auth_user(); require_auth(); csrf_require();
$uid=(int)$u['id'];

$flash=null; $err=null;

$cover = trim((string)($u['profile_cover'] ?? 'orange'));
$frame = trim((string)($u['avatar_frame'] ?? 'none'));

$coverOptions = [
  'orange' => 'bg-orange-500/15 border-orange-500/25',
  'cyan'   => 'bg-cyan-500/15 border-cyan-500/25',
  'violet' => 'bg-violet-500/15 border-violet-500/25',
  'emerald'=> 'bg-emerald-500/15 border-emerald-500/25',
];

$frameOptions = [
  'none' => 'border-white/10',
  'neo' => 'border-cyan-500/40 shadow-[0_0_0_3px_rgba(34,211,238,0.15)]',
  'flame' => 'border-orange-500/40 shadow-[0_0_0_3px_rgba(249,115,22,0.18)]',
  'royal' => 'border-violet-500/40 shadow-[0_0_0_3px_rgba(168,85,247,0.18)]',
];

if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_check();
  $action=$_POST['action'] ?? '';
  try {
    if($action==='update_profile'){
      $name=trim($_POST['name'] ?? '');
      $phone=trim($_POST['phone'] ?? '');
      if($name==='') throw new Exception('Vui lòng nhập họ và tên.');
      db()->prepare("UPDATE users SET name=?, phone=? WHERE id=?")->execute([$name,$phone,$uid]);
      audit_log($uid,'user_update_profile','user',(string)$uid,[]);
      $flash='Đã cập nhật thông tin cá nhân.';
      $u=auth_user();
    } elseif($action==='update_bank'){
      $bank_name=trim($_POST['bank_name'] ?? '');
      $bank_account=trim($_POST['bank_account'] ?? '');
      $bank_owner=trim($_POST['bank_owner'] ?? '');
      db()->prepare("UPDATE users SET bank_name=?, bank_account=?, bank_owner=? WHERE id=?")
        ->execute([$bank_name,$bank_account,$bank_owner,$uid]);
      $flash='Đã cập nhật thông tin ngân hàng.';
      $u=auth_user();
    } elseif($action==='change_password'){
      $old=(string)($_POST['old_password'] ?? '');
      $new=(string)($_POST['new_password'] ?? '');
      $new2=(string)($_POST['new_password2'] ?? '');
      if(!password_verify($old, $u['password_hash'] ?? '')) throw new Exception('Mật khẩu hiện tại không đúng.');
      if(strlen($new)<6) throw new Exception('Mật khẩu mới tối thiểu 6 ký tự.');
      if($new!==$new2) throw new Exception('Xác nhận mật khẩu không khớp.');
      $hash=password_hash($new, PASSWORD_DEFAULT);
      db()->prepare("UPDATE users SET password_hash=? WHERE id=?")->execute([$hash,$uid]);
      $flash='Đã đổi mật khẩu.';
      $u=auth_user();
    } elseif($action==='set_frame'){
      $f=trim((string)($_POST['frame'] ?? 'none'));
      $basic = ['none','neo','flame'];
      $pro = ['royal'];
      $allowed = $basic;
      if(vip_active($uid) || (int)(db()->query("SELECT COUNT(*) FROM user_badges WHERE user_id=".(int)$uid)->fetchColumn() ?: 0) >= 5) {
        $allowed = array_merge($allowed,$pro);
      }
      if(!in_array($f,$allowed,true)) $f='none';
      db()->prepare("UPDATE users SET avatar_frame=? WHERE id=?")->execute([$f,$uid]);
      $flash='Đã cập nhật khung avatar.';
      $u=auth_user();
    } elseif($action==='set_cover'){
      $c=trim((string)($_POST['cover'] ?? 'orange'));
      if(!array_key_exists($c,$coverOptions)) $c='orange';
      db()->prepare("UPDATE users SET profile_cover=? WHERE id=?")->execute([$c,$uid]);
      $flash='Đã đổi theme trang cá nhân.';
      $u=auth_user();
    } elseif($action==='upload_avatar'){
      if(!isset($_FILES['avatar']) || !is_uploaded_file($_FILES['avatar']['tmp_name'])) throw new Exception('Vui lòng chọn file.');
      $f=$_FILES['avatar'];
      if(($f['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) throw new Exception('Upload lỗi.');
      if(($f['size'] ?? 0) > 1024*1024) throw new Exception('File quá lớn (tối đa 1MB).');
      $tmp=(string)$f['tmp_name'];
      $type = mime_content_type($tmp);
      $allow=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
      if(!isset($allow[$type])) throw new Exception('Định dạng không hỗ trợ.');
      $ext=$allow[$type];
      ensure_upload_dirs();
      $name = 'u'.$uid.'_'.bin2hex(random_bytes(6)).'.'.$ext;
      $dest = __DIR__ . '/../uploads/avatars/' . $name;
      if(!move_uploaded_file($tmp,$dest)) throw new Exception('Không lưu được file.');
      // delete old
      $old = trim((string)($u['avatar'] ?? ''));
      if($old !== '' && is_file(__DIR__ . '/../uploads/avatars/' . $old)) { @unlink(__DIR__ . '/../uploads/avatars/' . $old); }
      db()->prepare("UPDATE users SET avatar=? WHERE id=?")->execute([$name,$uid]);
      $flash='Đã cập nhật avatar.';
      $u=auth_user();
    } elseif($action==='set_vault_pin'){
      $pin = trim((string)($_POST['pin'] ?? ''));
      if(!preg_match('/^[0-9]{4,6}$/',$pin)) throw new Exception('PIN gồm 4-6 chữ số.');
      $hash = password_hash($pin, PASSWORD_DEFAULT);
      db()->prepare("UPDATE users SET vault_pin_hash=? WHERE id=?")->execute([$hash,$uid]);
      $flash='Đã bật Vault PIN.';
      $u=auth_user();
    } elseif($action==='clear_vault_pin'){
      db()->prepare("UPDATE users SET vault_pin_hash=NULL WHERE id=?")->execute([$uid]);
      unset($_SESSION['vault_ok_until']);
      $flash='Đã tắt Vault PIN.';
      $u=auth_user();
    }

  } catch(Throwable $e){
    $err=$e->getMessage();
  }
}

$points = (int)($u['points'] ?? 0);
$balance = (float)(wallet_get($uid)['balance'] ?? 0);

$orders = (int)(db()->query("SELECT COUNT(*) FROM shop_orders WHERE user_id=".(int)$uid)->fetchColumn() ?: 0);
$badgeCount = (int)(db()->query("SELECT COUNT(*) FROM user_badges WHERE user_id=".(int)$uid)->fetchColumn() ?: 0);
$lv = user_level_info($uid);

$join = (string)($u['created_at'] ?? '');

$featuredId = (int)($u['featured_badge_id'] ?? 0);
$featured = null;
if($featuredId>0){
  $st=db()->prepare("SELECT b.* FROM user_badges ub JOIN badges b ON b.id=ub.badge_id WHERE ub.user_id=? AND b.id=? LIMIT 1");
  $st->execute([$uid,$featuredId]);
  $featured=$st->fetch(PDO::FETCH_ASSOC) ?: null;
}

$tab = $_GET['tab'] ?? 'overview';
$cover = trim((string)($u['profile_cover'] ?? 'orange'));
$frame = trim((string)($u['avatar_frame'] ?? 'none'));

if(!array_key_exists($cover,$coverOptions)) $cover='orange';
?>
<div class="flex items-start justify-between gap-4">
  <div>
    <div class="text-2xl font-extrabold">Trang cá nhân</div>
    <div class="text-sm text-slate-400 mt-1">Quản lý thông tin + khoe badge + theo dõi wishlist.</div>
  </div>
  <div class="flex gap-2">
    <a class="btn btn-ghost" href="<?= e(route_url('badges')) ?>">Badge</a>
    <a class="btn btn-ghost" href="<?= e(route_url('wishlist')) ?>">Wishlist</a>
  </div>
</div>

<?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 card overflow-hidden border-white/10">
  <div class="p-6 border-b border-white/10 <?= e($coverOptions[$cover]) ?>">
    <div class="flex items-center justify-between gap-4">
      <div class="flex items-center gap-4">
        <div class="w-16 h-16 rounded-3xl bg-slate-900/50 border grid place-items-center <?= e($frameOptions[$frame] ?? 'border-white/10') ?> text-orange-200 font-extrabold text-xl">
          <?= strtoupper(substr(e($u['username'] ?? 'U'),0,1)) ?>
        </div>
        <div>
          <div class="text-xl font-extrabold"><?= e($u['name'] ?? $u['username'] ?? '') ?></div>
          <div class="text-sm text-slate-500 mt-1">
            <?= e(trim((string)($u['display_title'] ?? '')) !== '' ? (string)$u['display_title'] : 'Thành viên') ?>
            • tham gia <?= e($join) ?>
          </div>
        </div>
      </div>

      <?php if($featured): ?>
        <div class="hidden sm:flex items-center gap-3 px-4 py-3 rounded-2xl bg-white/5 border border-white/10">
          <div class="w-10 h-10 rounded-2xl bg-white/5 border border-white/10 grid place-items-center">
            <?= lucide_icon((string)$featured['icon'],'w-5 h-5') ?>
          </div>
          <div>
            <div class="text-xs text-slate-400">Badge nổi bật</div>
            <div class="font-extrabold"><?= e($featured['name']) ?></div>
          </div>
        </div>
      <?php endif; ?>
    </div>

    <div class="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-3">
      <div class="p-4 rounded-2xl bg-white/5 border border-white/10">
        <div class="text-xs text-slate-400">Số dư</div>
        <div class="mt-1 font-extrabold text-emerald-200"><?= money_vnd((int)$balance) ?></div>
      </div>
      <div class="p-4 rounded-2xl bg-white/5 border border-white/10">
        <div class="text-xs text-slate-400">Điểm</div>
        <div class="mt-1 font-extrabold text-orange-200"><?= (int)$points ?></div>
      </div>
      <div class="p-4 rounded-2xl bg-white/5 border border-white/10">
        <div class="text-xs text-slate-400">Đơn hàng</div>
        <div class="mt-1 font-extrabold"><?= (int)$orders ?></div>
      </div>
      <div class="p-4 rounded-2xl bg-white/5 border border-white/10">
        <div class="text-xs text-slate-400">Badge</div>
        <div class="mt-1 font-extrabold"><?= (int)$badgeCount ?></div>
      </div>

    <div class="mt-4 p-4 rounded-2xl bg-white/5 border border-white/10">
      <div class="flex items-center justify-between gap-3">
        <div class="font-extrabold">Level <?= (int)$lv['level'] ?></div>
        <div class="text-sm text-slate-300"><?= (int)$lv['cur'] ?>/<?= (int)$lv['need'] ?> XP</div>
      </div>
      <?php $pct = (int)round(((int)$lv['cur'] / max(1,(int)$lv['need']))*100); ?>
      <div class="mt-3 h-2 rounded-full bg-white/5 overflow-hidden border border-white/10">
        <div class="h-2 bg-orange-500/60" style="width: <?= (int)$pct ?>%"></div>
      </div>
      <div class="text-xs text-slate-500 mt-2">Nạp/mua/điểm danh đều nhận XP. Admin chỉnh tỉ lệ trong Settings.</div>
    </div>

    </div>
  </div>

  <div class="p-5">
    <div class="flex flex-wrap gap-2">
      <?php $tabs=['overview'=>'Tổng quan','settings'=>'Cài đặt','bank'=>'Ngân hàng','security'=>'Bảo mật']; ?>
      <?php foreach($tabs as $k=>$label): ?>
        <a class="px-4 py-2 rounded-2xl border <?= $tab===$k?'border-orange-500/40 bg-orange-500/10 text-orange-200':'border-white/10 bg-white/5 text-slate-200/80 hover:bg-white/10' ?>"
           href="<?= e(route_url('profile',['tab'=>$k])) ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
    </div>

    <?php if($tab==='overview'): ?>
      <div class="mt-5 grid lg:grid-cols-3 gap-4">
        <div class="lg:col-span-2 card p-5">
          <div class="font-extrabold text-lg">Giới thiệu nhanh</div>
          <div class="text-sm text-slate-400 mt-2 leading-relaxed">
            Đây là profile card của bạn trên <b>RioKey</b>. Hãy sưu tầm badge để khoe thành tích và chọn title cho chất nhé!
          </div>

          
  <div id="vault" class="mt-4 p-5 rounded-2xl bg-white/5 border border-white/10">
    <div class="flex items-center justify-between gap-3">
      <div>
        <div class="font-extrabold text-lg">Vault PIN</div>
        <div class="text-sm text-slate-400 mt-1">Thiết lập PIN để mở khóa mua key và tăng bảo mật. PIN chỉ gồm 4–8 chữ số.</div>
      </div>
      <?php if (vault_is_set($uid)): ?>
        <span class="px-3 py-1 rounded-full text-xs font-extrabold bg-emerald-500/15 text-emerald-200 border border-emerald-500/25">Đã thiết lập</span>
      <?php else: ?>
        <span class="px-3 py-1 rounded-full text-xs font-extrabold bg-amber-500/15 text-amber-200 border border-amber-500/25">Chưa thiết lập</span>
      <?php endif; ?>
    </div>

    <form class="mt-4" method="post" action="<?= e(route_url('profile')) ?>#vault" data-confirm="Xác nhận cập nhật PIN Vault? Bạn nên ghi nhớ để tránh mất quyền mua key.">
      <?= csrf_field() ?>
      <input type="hidden" name="do_vault_pin" value="1">
      <div class="grid sm:grid-cols-2 gap-3">
        <div>
          <div class="text-sm font-bold mb-1">PIN mới</div>
          <input class="input w-full" type="password" inputmode="numeric" pattern="[0-9]*" name="vault_pin" placeholder="4-8 chữ số">
        </div>
        <div>
          <div class="text-sm font-bold mb-1">Nhập lại PIN</div>
          <input class="input w-full" type="password" inputmode="numeric" pattern="[0-9]*" name="vault_pin2" placeholder="Nhập lại PIN">
        </div>
      </div>
      <div class="mt-3 flex items-center gap-2">
        <button class="btn btn-primary" type="submit">Lưu PIN Vault</button>
        <div class="text-xs text-slate-400">* PIN được mã hóa, admin không xem được PIN gốc.</div>
      </div>
    </form>
  </div>

<div class="mt-4 p-4 rounded-2xl bg-white/5 border border-white/10">
            <div class="flex items-center justify-between gap-3">
              <div class="font-extrabold">Đơn mua gần đây</div>
              <a class="text-sm text-orange-200 hover:underline" href="<?= e(route_url('my_keys')) ?>">Xem kho key →</a>
            </div>
            <?php
              $st = db()->prepare("SELECT o.id,o.created_at,p.title,p.category,o.amount_vnd AS price_vnd
                FROM shop_orders o JOIN shop_products p ON p.id=o.product_id
                WHERE o.user_id=? ORDER BY o.id DESC LIMIT 6");
              $st->execute([$uid]);
              $recent = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
            ?>
            <div class="mt-3 grid gap-2">
              <?php if(!$recent): ?>
                <div class="text-sm text-slate-500">Chưa có đơn hàng nào.</div>
              <?php else: foreach($recent as $it): ?>
                <div class="flex items-center justify-between gap-3 p-3 rounded-2xl bg-white/5 border border-white/10">
                  <div>
                    <div class="text-sm text-slate-400"><?= e($it['category'] ?? '') ?></div>
                    <div class="font-extrabold"><?= e($it['title'] ?? '') ?></div>
                    <div class="text-xs text-slate-500 mt-1"><?= e($it['created_at'] ?? '') ?></div>
                  </div>
                  <div class="text-sm font-extrabold text-orange-200"><?= money_vnd((int)($it['price'] ?? 0)) ?></div>
                </div>
              <?php endforeach; endif; ?>
            </div>
          </div>

          <div class="mt-4 p-4 rounded-2xl bg-white/5 border border-white/10">
            <div class="flex items-center justify-between gap-3">
              <div class="font-extrabold">Bộ sưu tập</div>
              <a class="text-sm text-orange-200 hover:underline" href="<?= e(route_url('showcase')) ?>">Quản lý →</a>
            </div>
            <?php $sc = showcase_list($uid); ?>
            <div class="mt-3 grid sm:grid-cols-3 gap-2">
              <?php if(!$sc): ?>
                <div class="text-sm text-slate-500 sm:col-span-3">Chưa pin sản phẩm. Vào “Quản lý” để chọn tối đa 6 sản phẩm.</div>
              <?php else: foreach($sc as $it): ?>
                <a class="p-3 rounded-2xl bg-white/5 border border-white/10 hover:border-orange-500/30 transition" href="<?= e(route_url('product',['id'=>(int)$it['product_id']])) ?>">
                  <div class="text-xs text-slate-400"><?= e($it['category'] ?? '') ?></div>
                  <div class="font-extrabold mt-1 line-clamp-2"><?= e($it['title'] ?? '') ?></div>
                </a>
              <?php endforeach; endif; ?>
            </div>
          </div>
</div>
        </div>

        <div class="card p-5">
          <div class="font-extrabold text-lg">Theme trang cá nhân</div>
          <div class="mt-4">
            <div class="font-extrabold">Khung avatar</div>
            <div class="text-sm text-slate-400 mt-1">Khung <b>Royal</b> mở khi VIP hoặc có ≥ 5 badge.</div>
            <form method="post" class="mt-3 grid grid-cols-2 gap-2" data-once="1">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="set_frame">
              <?php $allowed=['none','neo','flame']; if(vip_active($uid) || (int)(db()->query("SELECT COUNT(*) FROM user_badges WHERE user_id=".(int)$uid)->fetchColumn() ?: 0) >= 5) $allowed[]='royal'; ?>
              <?php foreach($allowed as $k): ?>
                <button name="frame" value="<?= e($k) ?>" class="px-4 py-3 rounded-2xl border border-white/10 bg-white/5 hover:bg-white/10 text-sm font-extrabold <?= ($frame===$k)?'border-orange-500/40 bg-orange-500/10 text-orange-200':'' ?>" type="submit"><?= strtoupper(e($k)) ?></button>
              <?php endforeach; ?>
            </form>
          </div>
          <div class="text-sm text-slate-400 mt-2">Chọn màu cover bạn thích.</div>
          <form method="post" class="mt-4 grid grid-cols-2 gap-2" data-once="1">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="set_cover">
            <?php foreach($coverOptions as $k=>$cls): ?>
              <button name="cover" value="<?= e($k) ?>" class="px-4 py-3 rounded-2xl border <?= e($cls) ?> hover:opacity-90 text-sm font-extrabold" type="submit">
                <?= strtoupper(e($k)) ?>
              </button>
            <?php endforeach; ?>
          </form>
        </div>
      </div>

    <?php elseif($tab==='settings'): ?>
      <div class="mt-5 grid lg:grid-cols-3 gap-4">
      <div class="card p-5">
        <div class="font-extrabold text-lg">Avatar</div>
        <div class="text-sm text-slate-400 mt-2">Upload ảnh (jpg/png/webp) ≤ 1MB.</div>
        <form method="post" enctype="multipart/form-data" class="mt-4" data-once="1">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="upload_avatar">
          <input class="input w-full" type="file" name="avatar" accept="image/png,image/jpeg,image/webp">
          <button class="btn w-full mt-3" type="submit">Cập nhật avatar</button>
        </form>
      </div>

      <div class="lg:col-span-2 card p-5">
        <div class="font-extrabold text-lg">Thông tin cá nhân</div>
        <form method="post" class="mt-4 grid sm:grid-cols-2 gap-4" data-once="1">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="update_profile">
          <div>
            <label class="label">Họ và tên</label>
            <input class="input w-full" name="name" value="<?= e($u['name'] ?? '') ?>" placeholder="Nguyễn Văn A">
          </div>
          <div>
            <label class="label">Số điện thoại</label>
            <input class="input w-full" name="phone" value="<?= e($u['phone'] ?? '') ?>" placeholder="09xxxx">
          </div>
          <div class="sm:col-span-2">
            <button class="btn w-full" type="submit">Lưu</button>
          </div>
        </form>
      </div>
    </div>

    <?php elseif($tab==='bank'): ?>
      <div class="mt-5 card p-5">
        <div class="font-extrabold text-lg">Thông tin ngân hàng</div>
        <form method="post" class="mt-4 grid sm:grid-cols-3 gap-4" data-once="1">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="update_bank">
          <div>
            <label class="label">Ngân hàng</label>
            <input class="input w-full" name="bank_name" value="<?= e($u['bank_name'] ?? '') ?>" placeholder="Vietcombank">
          </div>
          <div>
            <label class="label">Số tài khoản</label>
            <input class="input w-full" name="bank_account" value="<?= e($u['bank_account'] ?? '') ?>" placeholder="0123456789">
          </div>
          <div>
            <label class="label">Chủ tài khoản</label>
            <input class="input w-full" name="bank_owner" value="<?= e($u['bank_owner'] ?? '') ?>" placeholder="NGUYEN VAN A">
          </div>
          <div class="sm:col-span-3">
            <button class="btn w-full" type="submit">Lưu</button>
          </div>
        </form>
      </div>

    <?php elseif($tab==='security'): ?>
      <div class="mt-5 card p-5">
        <div class="font-extrabold text-lg">Đổi mật khẩu</div>
        <form method="post" class="mt-4 grid sm:grid-cols-3 gap-4" data-once="1">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="change_password">
          <div>
            <label class="label">Mật khẩu hiện tại</label>
            <input class="input w-full" type="password" name="old_password">
          </div>
          <div>
            <label class="label">Mật khẩu mới</label>
            <input class="input w-full" type="password" name="new_password">
          </div>
          <div>
            <label class="label">Xác nhận</label>
            <input class="input w-full" type="password" name="new_password2">
          </div>
          <div class="sm:col-span-3">
            <button class="btn w-full" type="submit">Đổi mật khẩu</button>
          </div>
        </form>
        <div class="mt-6 p-4 rounded-2xl bg-white/5 border border-white/10">
          <div class="font-extrabold">Vault PIN (ẩn/hiện key)</div>
          <div class="text-sm text-slate-400 mt-1">Bật PIN để phải nhập PIN trước khi xem/copy key trong Kho key.</div>

          <div class="mt-3 grid sm:grid-cols-2 gap-3">
            <form method="post" data-once="1" class="flex gap-2">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="set_vault_pin">
              <input class="input flex-1" name="pin" placeholder="PIN 4-6 số" inputmode="numeric" pattern="[0-9]*" maxlength="6">
              <button class="btn" type="submit">Bật/Đổi PIN</button>
            </form>

            <form method="post" data-once="1" onsubmit="return confirm('Tắt Vault PIN?');">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="clear_vault_pin">
              <button class="btn btn-ghost w-full" type="submit">Tắt PIN</button>
            </form>
          </div>
        </div>

      </div>
    <?php endif; ?>

  </div>
</div>
