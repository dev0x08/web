<?php
$u = auth_user();
$uid = (int)($u['id'] ?? 0);
$today = date('Y-m-d');
$yesterday = date('Y-m-d', strtotime('-1 day'));

$msg = null; $err = null;

$checkinsTable = 'checkins';
$rewardsTable  = 'checkin_rewards';
$missionsTable = 'missions';
$claimsTable   = 'mission_claims';


// ---- RioKey: seed demo missions (only when missions table is empty) ----
function riokey_seed_missions_demo(string $missionsTable): void {
  static $seeded=false;
  if ($seeded) return;
  $seeded=true;

  try {
    $c = (int)(db()->query("SELECT COUNT(*) FROM {$missionsTable}")->fetchColumn() ?: 0);
    if ($c > 0) return;
  } catch (Throwable $e) { return; }

  $hasType = db_has_column($missionsTable,'type');
  $hasIcon = db_has_column($missionsTable,'icon');
  $hasActive = db_has_column($missionsTable,'is_active');
  $hasSort = db_has_column($missionsTable,'sort');
  $hasDesc = db_has_column($missionsTable,'description');

  $demo = [
    ['Điểm danh hôm nay', 'Điểm danh mỗi ngày để tăng streak', 20, 'check-circle', 'auto', 1],
    ['Cập nhật hồ sơ', 'Thêm tên/điện thoại để bảo mật tài khoản', 30, 'user-check', 'auto', 2],
    ['Tham gia group Community', 'Dán link profile/group/screenshot để admin duyệt', 60, 'messages-square', 'manual', 3],
    ['Like fanpage Facebook', 'Gửi link profile + screenshot đã like để duyệt', 80, 'thumbs-up', 'manual', 4],
    ['Chia sẻ bài viết shop', 'Gửi link bài share để được duyệt', 100, 'share-2', 'manual', 5],
  ];

  if(!db()->inTransaction()) db()->beginTransaction();
  try {
    foreach($demo as $d){
      [$title,$desc,$pts,$icon,$type,$sort] = $d;
      $cols = ['title','points'];
      $vals = [$title,(int)$pts];

      if ($hasDesc){ $cols[]='description'; $vals[]=$desc; }
      if ($hasIcon){ $cols[]='icon'; $vals[]=$icon; }
      if ($hasType){ $cols[]='type'; $vals[]=$type; }
      if ($hasActive){ $cols[]='is_active'; $vals[]=1; }
      if ($hasSort){ $cols[]='sort'; $vals[]=(int)$sort; }

      $place = implode(',', array_fill(0,count($cols),'?'));
      $sql = "INSERT INTO {$missionsTable}(".implode(',',$cols).") VALUES({$place})";
      db()->prepare($sql)->execute($vals);
    }
    db()->commit();
  } catch(Throwable $e){
    try { if(db()->inTransaction()) db()->rollBack(); } catch(Throwable $x){}
  }
}
riokey_seed_missions_demo($missionsTable);

// Column detection (supports both old/new schema)
$streakCol = db_has_column($checkinsTable, 'streak') ? 'streak'
  : (db_has_column($checkinsTable, 'streak_count') ? 'streak_count' : null);

$checkinHasRewardCol = db_has_column($checkinsTable, 'reward_points');

// Prefer day_index because many DB dumps keep day_no as legacy/default.
$rewardDayCol = db_has_column($rewardsTable, 'day_index') ? 'day_index'
  : (db_has_column($rewardsTable, 'day_no') ? 'day_no' : null);

$rewardPointsCol = db_has_column($rewardsTable, 'reward_points') ? 'reward_points'
  : (db_has_column($rewardsTable, 'points') ? 'points' : null);

$rewardHasActive = db_has_column($rewardsTable, 'is_active');

$missionsHasActive = db_has_column($missionsTable, 'is_active');
$missionsSortCol   = db_has_column($missionsTable, 'sort') ? 'sort' : null;
$missionsHasType   = db_has_column($missionsTable, 'type');
$missionsHasIcon   = db_has_column($missionsTable, 'icon');
$missionsHasUrl    = db_has_column($missionsTable, 'action_url');

$claimsHasDate = db_has_column($claimsTable, 'claim_date');
$claimsHasPoints = db_has_column($claimsTable, 'points');


// --- RioKey anti-fraud: manual approval missions ---
try {
  if (!db_has_column($claimsTable,'status')) db()->exec("ALTER TABLE {$claimsTable} ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'approved'");
  if (!db_has_column($claimsTable,'evidence')) db()->exec("ALTER TABLE {$claimsTable} ADD COLUMN evidence TEXT NULL");
  if (!db_has_column($claimsTable,'reviewed_by')) db()->exec("ALTER TABLE {$claimsTable} ADD COLUMN reviewed_by INT NULL");
  if (!db_has_column($claimsTable,'reviewed_at')) db()->exec("ALTER TABLE {$claimsTable} ADD COLUMN reviewed_at DATETIME NULL");

  // Unique guard (anti double-click)
  try{
    if ($claimsHasDate) {
      db()->exec("ALTER TABLE {$claimsTable} ADD UNIQUE KEY uq_user_mission_day (user_id, mission_id, claim_date)");
    } else {
      db()->exec("ALTER TABLE {$claimsTable} ADD UNIQUE KEY uq_user_mission (user_id, mission_id)");
    }
  } catch (Throwable $e2) {}
} catch (Throwable $e) {}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_require();
  $action = $_POST['action'] ?? '';

  // CHECKIN
  if ($action === 'checkin') {
    try {
      // Already checked in today?
      $st = db()->prepare("SELECT * FROM {$checkinsTable} WHERE user_id=? AND checkin_date=? LIMIT 1");
      $st->execute([$uid, $today]);
      if ($st->fetch()) {
        $err = 'Hôm nay bạn đã điểm danh rồi.';
      } else {
        // Find yesterday streak
        $st = db()->prepare("SELECT * FROM {$checkinsTable} WHERE user_id=? AND checkin_date=? LIMIT 1");
        $st->execute([$uid, $yesterday]);
        $prev = $st->fetch(PDO::FETCH_ASSOC);

        $prevStreak = 0;
        if ($prev && $streakCol) $prevStreak = (int)($prev[$streakCol] ?? 0);

        $streak = $prev ? ($prevStreak + 1) : 1;

        // loop 7 days
        $dayNo = (($streak - 1) % 7) + 1;

        $reward = 0;
        if ($rewardDayCol && $rewardPointsCol) {
          $whereActive = $rewardHasActive ? " AND is_active=1" : "";
          $st = db()->prepare("SELECT {$rewardPointsCol} AS pts FROM {$rewardsTable} WHERE {$rewardDayCol}=? {$whereActive} LIMIT 1");
          $st->execute([$dayNo]);
          $reward = (int)(($st->fetch(PDO::FETCH_ASSOC)['pts'] ?? 0));
        }

        // Insert checkin row
        if ($streakCol) {
          if ($checkinHasRewardCol) {
            $sql = "INSERT INTO {$checkinsTable}(user_id,checkin_date,{$streakCol},reward_points) VALUES(?,?,?,?)";
            db()->prepare($sql)->execute([$uid, $today, $streak, $reward]);
          } else {
            $sql = "INSERT INTO {$checkinsTable}(user_id,checkin_date,{$streakCol}) VALUES(?,?,?)";
            db()->prepare($sql)->execute([$uid, $today, $streak]);
          }
        } else {
          // fallback: minimal insert
          db()->prepare("INSERT INTO {$checkinsTable}(user_id,checkin_date) VALUES(?,?)")->execute([$uid, $today]);
        }

        // grant points
        if ($reward > 0) {
          points_add($uid, $reward, 'checkin', 'Điểm danh ngày '.$dayNo.' (streak '.$streak.')');
        }
        $msg = 'Điểm danh thành công! +'.$reward.' điểm.';
        try{ achievements_check($uid,'checkin',['streak'=>$streak,'dayNo'=>$dayNo]); } catch(Throwable $e){}
        try{ $xp = (int)setting('xp_checkin','5'); if($xp<0) $xp=0; if($xp>0) user_add_xp($uid,$xp,'checkin'); } catch(Throwable $e){}
      }
    } catch (Throwable $e) {
      $err = 'Có lỗi khi điểm danh.';
    }
  }


  // CLAIM MISSION
  if ($action === 'claim_mission') {
    if ($uid <= 0) { $err = 'Bạn cần đăng nhập.'; }
    $mid = (int)($_POST['mission_id'] ?? 0);
    if ($mid > 0 && !$err) {
      try {
        $whereActive = $missionsHasActive ? " AND is_active=1" : "";
        $st = db()->prepare("SELECT * FROM {$missionsTable} WHERE id=? {$whereActive} LIMIT 1");
        $st->execute([$mid]);
        $m = $st->fetch(PDO::FETCH_ASSOC);
        if (!$m) throw new Exception('Nhiệm vụ không tồn tại.');

        $points = (int)($m['points'] ?? 0);
        $mtype = (string)($m['type'] ?? 'auto');

        // Type rules:
        // - daily: claim 1 lần mỗi ngày (auto)
        // - manual / need_review / manual_daily: cần bằng chứng + admin/mod duyệt
        // - other: claim 1 lần (auto)
        $isManual = in_array($mtype, ['manual','need_review','manual_daily'], true);
        $isDaily  = in_array($mtype, ['daily','manual_daily'], true);

        $evidence = trim((string)($_POST['evidence'] ?? ''));

        // Find existing claim (daily -> today only, non-daily -> any)
        $claim = null;
        if ($claimsHasDate && $isDaily) {
          $st = db()->prepare("SELECT * FROM {$claimsTable} WHERE user_id=? AND mission_id=? AND claim_date=? ORDER BY id DESC LIMIT 1");
          $st->execute([$uid, $mid, $today]);
          $claim = $st->fetch(PDO::FETCH_ASSOC) ?: null;
        } else {
          $st = db()->prepare("SELECT * FROM {$claimsTable} WHERE user_id=? AND mission_id=? ORDER BY id DESC LIMIT 1");
          $st->execute([$uid, $mid]);
          $claim = $st->fetch(PDO::FETCH_ASSOC) ?: null;
        }

        if ($isManual) {
          if ($evidence === '' || mb_strlen($evidence) < 5) throw new Exception('Vui lòng nhập bằng chứng (link / mô tả / ảnh screenshot link).');

          // If rejected, allow resubmit (update)
          if ($claim && (string)($claim['status'] ?? '') === 'rejected') {
            db()->prepare("UPDATE {$claimsTable} SET status='pending', evidence=?, reviewed_by=NULL, reviewed_at=NULL WHERE id=?")
              ->execute([$evidence, (int)$claim['id']]);
            $msg = 'Đã gửi lại bằng chứng. Vui lòng chờ admin/mod duyệt.';
          } else {
            if ($claim) throw new Exception('Bạn đã gửi/nhận nhiệm vụ này rồi.');

            // Insert pending claim
            try {
              if ($claimsHasDate && $claimsHasPoints) {
                db()->prepare("INSERT INTO {$claimsTable}(user_id,mission_id,claim_date,points,status,evidence) VALUES(?,?,?,?,?,?)")
                  ->execute([$uid, $mid, $today, $points, 'pending', $evidence]);
              } elseif ($claimsHasDate) {
                db()->prepare("INSERT INTO {$claimsTable}(user_id,mission_id,claim_date,status,evidence) VALUES(?,?,?,?,?)")
                  ->execute([$uid, $mid, $today, 'pending', $evidence]);
              } elseif ($claimsHasPoints) {
                db()->prepare("INSERT INTO {$claimsTable}(user_id,mission_id,points,status,evidence) VALUES(?,?,?,?,?)")
                  ->execute([$uid, $mid, $points, 'pending', $evidence]);
              } else {
                db()->prepare("INSERT INTO {$claimsTable}(user_id,mission_id,status,evidence) VALUES(?,?,?,?)")
                  ->execute([$uid, $mid, 'pending', $evidence]);
              }
            } catch (Throwable $e) {
              // duplicate key (double-click)
              throw new Exception('Bạn đã gửi nhiệm vụ này rồi.');
            }

            $msg = 'Đã gửi bằng chứng. Vui lòng chờ admin/mod duyệt.';
          }

        } else {
          // Auto mission
          if ($claim) throw new Exception('Bạn đã nhận nhiệm vụ này rồi.');

          if(!db()->inTransaction()) db()->beginTransaction();
          try {
            if ($claimsHasDate && $claimsHasPoints) {
              db()->prepare("INSERT INTO {$claimsTable}(user_id,mission_id,claim_date,points,status) VALUES(?,?,?,?,?)")
                ->execute([$uid, $mid, $today, $points, 'approved']);
            } elseif ($claimsHasDate) {
              db()->prepare("INSERT INTO {$claimsTable}(user_id,mission_id,claim_date,status) VALUES(?,?,?,?)")
                ->execute([$uid, $mid, $today, 'approved']);
            } elseif ($claimsHasPoints) {
              db()->prepare("INSERT INTO {$claimsTable}(user_id,mission_id,points,status) VALUES(?,?,?,?)")
                ->execute([$uid, $mid, $points, 'approved']);
            } else {
              db()->prepare("INSERT INTO {$claimsTable}(user_id,mission_id,status) VALUES(?,?,?)")
                ->execute([$uid, $mid, 'approved']);
            }
            $cid = (int)db()->lastInsertId();
            if ($points > 0) points_add($uid, $points, 'mission', 'claim:'.$cid, 'Hoàn thành: '.($m['title'] ?? 'Nhiệm vụ'));
            db()->commit();
          } catch (Throwable $e) {
            try { if(db()->inTransaction()) db()->rollBack(); } catch(Throwable $x){}
            throw $e;
          }

          $msg = 'Nhận thưởng thành công! +'.$points.' điểm.';
        }
      } catch (Throwable $e) {
        $err = $e->getMessage() ?: 'Có lỗi khi nhận nhiệm vụ.';
      }
    }
  }
}

$balance = points_balance($uid);

// checkin status
$st = db()->prepare("SELECT * FROM {$checkinsTable} WHERE user_id=? AND checkin_date=? LIMIT 1");
$st->execute([$uid, $today]);
$todayCheckin = $st->fetch(PDO::FETCH_ASSOC);

$streakNow = 0;
if ($todayCheckin && $streakCol) $streakNow = (int)($todayCheckin[$streakCol] ?? 0);
$dayNoNow = $todayCheckin ? ((($streakNow - 1) % 7) + 1) : null;

// rewards list
$orderCol = $rewardDayCol ?: 'id';
$rewards = db()->query("SELECT * FROM {$rewardsTable} ORDER BY {$orderCol} ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];

// missions list
$whereActive = $missionsHasActive ? "WHERE is_active=1" : "";
$orderSql = "ORDER BY id DESC";
if ($missionsSortCol) $orderSql = "ORDER BY {$missionsSortCol} ASC, id DESC";
$missions = db()->query("SELECT * FROM {$missionsTable} {$whereActive} {$orderSql}")->fetchAll(PDO::FETCH_ASSOC) ?: [];

// claims map
$claimsToday = [];
$claimsAny = [];

try {
  if ($claimsHasDate) {
    $st = db()->prepare("SELECT id, mission_id, claim_date, status FROM {$claimsTable} WHERE user_id=? AND claim_date=?");
    $st->execute([$uid, $today]);
    foreach (($st->fetchAll(PDO::FETCH_ASSOC) ?: []) as $c) {
      $claimsToday[(int)$c['mission_id']] = ['id'=>(int)$c['id'],'status'=>(string)($c['status'] ?? 'approved'),'claim_date'=>$c['claim_date']];
    }
  }
  $st = db()->prepare("SELECT id, mission_id, claim_date, status FROM {$claimsTable} WHERE user_id=? ORDER BY id DESC LIMIT 800");
  $st->execute([$uid]);
  foreach (($st->fetchAll(PDO::FETCH_ASSOC) ?: []) as $c) {
    $mid = (int)$c['mission_id'];
    if (!isset($claimsAny[$mid])) {
      $claimsAny[$mid] = ['id'=>(int)$c['id'],'status'=>(string)($c['status'] ?? 'approved'),'claim_date'=>$c['claim_date'] ?? null];
    }
  }
} catch (Throwable $e) {}

$tx = points_recent($uid, 20);
?>

<div class="flex items-start justify-between gap-3">
  <div>
    <div class="text-2xl font-black">Nhiệm vụ</div>
    <div class="text-slate-400 mt-1">Điểm danh theo streak + nhiệm vụ nhận điểm.</div>
  </div>
  <div class="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-white/5 border border-white/10">
    <?= lucide_icon('coins','w-5 h-5 text-amber-300') ?>
    <span class="font-extrabold"><?= (int)$balance ?></span>
    <span class="text-slate-400 text-sm">điểm</span>
  </div>
</div>

<?php if($msg): ?><div class="mt-4 rounded-2xl border border-emerald-500/25 bg-emerald-500/10 p-4 text-emerald-200 text-sm"><?= e($msg) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 rounded-2xl border border-rose-500/25 bg-rose-500/10 p-4 text-rose-200 text-sm"><?= e($err) ?></div><?php endif; ?>

<div class="grid lg:grid-cols-3 gap-4 mt-6">
  <div class="card p-5">
    <div class="font-extrabold flex items-center gap-2"><?= lucide_icon('calendar-check','w-5 h-5 text-orange-300') ?> Điểm danh 7 ngày</div>
    <div class="text-sm text-slate-400 mt-1">Điểm thưởng cấu hình trong Admin.</div>

    <div class="mt-4 grid grid-cols-7 gap-2">
      <?php foreach($rewards as $r):
        $d = (int)($r[$rewardDayCol ?: 'id'] ?? 0);
        $pts = (int)(($r[$rewardPointsCol ?: 'points'] ?? $r['points'] ?? 0));
        $active = $todayCheckin && $dayNoNow !== null && $d === (int)$dayNoNow;
      ?>
        <div class="rounded-2xl border <?= $active?'border-orange-400/40 bg-orange-500/10':'border-white/10 bg-white/5' ?> p-3 text-center">
          <div class="text-[11px] tracking-widest uppercase text-slate-400 font-black">Day <?= (int)$d ?></div>
          <div class="mt-1 font-extrabold text-slate-100"><?= (int)$pts ?></div>
          <div class="text-[11px] text-slate-500">điểm</div>
        </div>
      <?php endforeach; ?>
    </div>

    <form method="post" class="mt-4">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="checkin">
      <button class="btn btn-primary w-full" <?= $todayCheckin?'disabled':'' ?>>
        <?= lucide_icon('check','w-5 h-5') ?>
        <?= $todayCheckin ? 'Đã điểm danh hôm nay' : 'Điểm danh nhận điểm' ?>
      </button>
    </form>
  </div>

  <div class="lg:col-span-2 space-y-4">
    <div class="card p-5">
      <div class="font-extrabold flex items-center gap-2"><?= lucide_icon('list-checks','w-5 h-5 text-orange-300') ?> Danh sách nhiệm vụ</div>

      <div class="mt-4 space-y-3">
        <?php foreach($missions as $m):
          $mid = (int)($m['id'] ?? 0);
          $mtype = (string)($m['type'] ?? 'auto');
          $isManual = in_array($mtype, ['manual','need_review','manual_daily'], true);
          $isDaily  = in_array($mtype, ['daily','manual_daily'], true);

          $claimInfo = null;
          if ($isDaily && $claimsHasDate) $claimInfo = $claimsToday[$mid] ?? null;
          else $claimInfo = $claimsAny[$mid] ?? null;

          $claimed = $claimInfo !== null;
          $cstatus = (string)($claimInfo['status'] ?? '');

          $icon = $missionsHasIcon ? ($m['icon'] ?: 'sparkles') : 'sparkles';
          $actionUrl = $missionsHasUrl ? ($m['action_url'] ?: '') : '';
        ?>
          <div class="rounded-2xl border border-white/10 bg-white/5 p-4 flex items-start justify-between gap-3">
            <div class="flex items-start gap-3 min-w-0">
              <div class="w-11 h-11 rounded-2xl bg-white/5 border border-white/10 grid place-items-center">
                <?= lucide_icon($icon,'w-5 h-5 text-amber-300') ?>
              </div>
              <div class="min-w-0">
                <div class="font-extrabold text-slate-100 truncate"><?= e($m['title'] ?? '') ?></div>
                <div class="text-sm text-slate-400 mt-1 line-clamp-2"><?= e($m['description'] ?? '') ?></div>
                <?php if($actionUrl): ?>
                  <a class="text-xs text-blue-300 font-bold mt-2 inline-flex items-center gap-1" href="<?= e($actionUrl) ?>"><?= lucide_icon('arrow-right','w-4 h-4') ?> Đi tới</a>
                <?php endif; ?>
              </div>
            </div>

            <?php if($isManual && (!$claimed || $cstatus==='rejected')): ?>
            <form method="post" class="shrink-0 w-[280px] max-w-full">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="claim_mission">
              <input type="hidden" name="mission_id" value="<?= (int)$mid ?>">
              <textarea class="input !h-[78px]" name="evidence" placeholder="Dán bằng chứng: link profile / link bài đăng / link ảnh screenshot..."></textarea>
              <button class="btn btn-primary w-full mt-2 !px-4 !py-2">
                <?= lucide_icon('send','w-4 h-4') ?>
                Gửi bằng chứng
              </button>
            </form>
            <?php else: ?>
            <form method="post" class="shrink-0">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="claim_mission">
              <input type="hidden" name="mission_id" value="<?= (int)$mid ?>">
              <button class="btn btn-primary !px-4 !py-2" <?= $claimed?'disabled':'' ?>>
                <?= lucide_icon('gift','w-4 h-4') ?>
                <?= $claimed ? (
                    ($cstatus==='pending' ? 'Chờ duyệt' : ($cstatus==='rejected' ? 'Bị từ chối' : 'Đã nhận'))
                  ) : '+'.(int)($m['points'] ?? 0).' điểm' ?>
              </button>
            </form>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
        <?php if(!$missions): ?><div class="text-slate-500 text-sm">Chưa có nhiệm vụ.</div><?php endif; ?>
      </div>
    </div>

    <div class="card p-5">
      <div class="font-extrabold flex items-center gap-2"><?= lucide_icon('history','w-5 h-5 text-orange-300') ?> Lịch sử điểm gần đây</div>
      <div class="mt-4 space-y-2">
        <?php foreach($tx as $t): ?>
          <div class="flex items-center justify-between gap-3 text-sm rounded-2xl border border-white/10 bg-white/5 px-4 py-3">
            <div class="min-w-0">
              <div class="font-bold text-slate-200 truncate"><?= e($t['note'] ?? '') ?></div>
              <div class="text-xs text-slate-500 mt-1"><?= e($t['created_at'] ?? '') ?></div>
            </div>
            <div class="font-extrabold <?= ((int)$t['points']>=0)?'text-emerald-300':'text-rose-300' ?>">
              <?= (int)$t['points'] ?>
            </div>
          </div>
        <?php endforeach; ?>
        <?php if(!$tx): ?><div class="text-slate-500 text-sm">Chưa có giao dịch điểm.</div><?php endif; ?>
      </div>
    </div>

  </div>
</div>
