<?php
$u = auth_user(); require_auth();
$uid = (int)$u['id'];

$enabled = (int)setting('topup_enabled', 1) === 1;
if (!$enabled) {
  echo '<div class="card p-6">Tính năng nạp tiền đang tạm tắt.</div>';
  return;
}

csrf_require();

$min = (int)setting('topup_min_amount', 10000);
$bank_id = trim((string)setting('bank_id', ''));
$bank_acc = trim((string)setting('bank_account_no', ''));
$bank_name = trim((string)setting('bank_account_name', ''));
$template = trim((string)setting('vietqr_template', 'compact2'));
$prefix = trim((string)setting('topup_prefix', 'NAP'));
if ($prefix === '') $prefix = 'NAP';

$err = null;

function vietqr_img_url_local(string $bankId, string $accNo, string $template, int $amount, string $addInfo, string $accName): string {
  $base = "https://img.vietqr.io/image/{$bankId}-{$accNo}-{$template}.png";
  return $base . '?' . http_build_query([
    'amount' => $amount,
    'addInfo' => $addInfo,
    'accountName' => $accName,
  ]);
}

function topup_make_code(): string {
  $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  $out = 'TP';
  for ($i=0; $i<8; $i++) $out .= $alphabet[random_int(0, strlen($alphabet)-1)];
  return $out;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_check();
  $amount = (int)($_POST['amount'] ?? 0);
  if ($amount < $min) $err = 'Số tiền tối thiểu là ' . number_format($min,0,',','.') . 'đ';
  if (!$err) {
    $code = topup_make_code();
    $pay_note = $prefix . ' ' . $code;
    db()->prepare("INSERT INTO topup_requests(user_id,code,amount,pay_note,status,created_at) VALUES (?,?,?,?, 'pending', NOW())")
      ->execute([$uid,$code,$amount,$pay_note]);

    audit_log((int)$u['id'],'topup_create','topup',$code,['amount'=>$amount]);

    redirect(route_url('topup') . '?code=' . urlencode($code));
  }
}

$show_code = trim($_GET['code'] ?? '');
$qr_url = null;
$show_req = null;
if ($show_code !== '') {
  $st = db()->prepare("SELECT * FROM topup_requests WHERE user_id=? AND code=? ORDER BY id DESC LIMIT 1");
  $st->execute([$uid,$show_code]);
  $show_req = $st->fetch();
  if ($show_req && $bank_id !== '' && $bank_acc !== '' && $bank_name !== '') {
    $qr_url = vietqr_img_url_local($bank_id, $bank_acc, $template, (int)$show_req['amount'], (string)$show_req['pay_note'], $bank_name);
  }
}

$st2 = db()->prepare("SELECT * FROM topup_requests WHERE user_id=? ORDER BY id DESC LIMIT 10");
$st2->execute([$uid]);
$rows = $st2->fetchAll();

function pill_class(string $status): string {
  if ($status==='approved') return 'inline-flex items-center rounded-full bg-emerald-500/15 text-emerald-200 border border-emerald-500/25 px-3 py-1 text-xs font-extrabold';
  if ($status==='rejected') return 'inline-flex items-center rounded-full bg-rose-500/15 text-rose-200 border border-rose-500/25 px-3 py-1 text-xs font-extrabold';
  return 'inline-flex items-center rounded-full bg-amber-500/15 text-amber-200 border border-amber-500/25 px-3 py-1 text-xs font-extrabold';
}
?>

<div class="grid grid-cols-1 xl:grid-cols-3 gap-4">
  <div class="card p-6">
    <div class="text-xl font-extrabold">Nạp tiền</div>
    <div class="text-slate-400 text-sm mt-1">Nhập số tiền bạn muốn nạp. Hệ thống tạo nội dung chuyển khoản và QR VietQR để bạn quét.</div>

    <?php if ($err): ?>
      <div class="mt-4 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-200 px-4 py-3 text-sm"><?=htmlspecialchars($err)?></div>
    <?php endif; ?>

    <form method="post" class="mt-5 space-y-4">
      <?=csrf_field()?>
      <label class="block text-sm font-semibold text-slate-200">Số tiền (VNĐ)</label>
      <div class="flex items-center gap-2">
        <input name="amount" type="number" min="<?=$min?>" step="1000"
               class="w-full rounded-xl bg-slate-900/60 border border-white/10 px-4 py-3 text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/60"
               placeholder="Ví dụ: 50000" required>
        <button class="btn btn-primary whitespace-nowrap px-4 py-3 rounded-xl">Tạo yêu cầu</button>
      </div>
      <div class="text-xs text-slate-500">Tối thiểu <?=number_format($min,0,',','.')?>đ</div>
    </form>

    <div class="mt-6 rounded-2xl border border-white/10 bg-slate-900/40 p-4">
      <div class="font-semibold">Thông tin nhận tiền</div>
      <div class="text-sm text-slate-300 mt-2 space-y-1">
        <div>Ngân hàng: <span class="text-slate-100 font-semibold"><?=htmlspecialchars($bank_id ?: 'Chưa cấu hình')?></span></div>
        <div>STK: <span class="text-slate-100 font-semibold"><?=htmlspecialchars($bank_acc ?: 'Chưa cấu hình')?></span></div>
        <div>Chủ TK: <span class="text-slate-100 font-semibold"><?=htmlspecialchars($bank_name ?: 'Chưa cấu hình')?></span></div>
      </div>
      <div class="text-xs text-slate-500 mt-2">Admin có thể thay đổi trong Admin → Cài đặt.</div>
    </div>
  </div>

  <div class="card p-6 xl:col-span-2">
    <div class="text-xl font-extrabold">Thanh toán</div>
    <?php if ($show_req): ?>
      <div class="mt-4 grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div class="lg:col-span-2 rounded-2xl border border-white/10 bg-slate-900/40 p-5">
          <div class="text-sm text-slate-400">Yêu cầu</div>
          <div class="mt-1 text-lg font-bold">#<?=htmlspecialchars($show_req['code'])?> • <?=number_format((int)$show_req['amount'],0,',','.')?>đ</div>
          <div class="mt-3 text-sm">
            Nội dung chuyển khoản:
            <div class="mt-2 flex items-center gap-2">
              <input readonly value="<?=htmlspecialchars($show_req['pay_note'])?>" class="w-full rounded-xl bg-slate-950/60 border border-white/10 px-4 py-3 text-slate-100">
              <button type="button" class="btn px-4 py-3 rounded-xl bg-white/10 hover:bg-white/15"
                onclick="navigator.clipboard.writeText('<?=htmlspecialchars($show_req['pay_note'])?>')">Copy</button>
            </div>
          </div>
          <div class="mt-3 text-xs text-slate-500">Chuyển khoản xong, chờ MOD/Admin duyệt để cộng vào ví.</div>

          <div class="mt-4 flex items-center gap-3">
            <span class="<?=pill_class($show_req['status'])?>">
              <?=htmlspecialchars(strtoupper($show_req['status']))?>
            </span>
            <span class="text-xs text-slate-500">Tạo lúc: <?=htmlspecialchars($show_req['created_at'])?></span>
          </div>
        </div>

        <div class="rounded-2xl border border-white/10 bg-slate-900/40 p-5">
          <div class="font-semibold">Quét QR</div>
          <?php if ($qr_url): ?>
            <img src="<?=htmlspecialchars($qr_url)?>" alt="VietQR" class="mt-3 w-full rounded-xl border border-white/10 bg-white p-2">
            <div class="mt-2 text-xs text-slate-500">QR tự điền số tiền & nội dung.</div>
          <?php else: ?>
            <div class="mt-3 text-sm text-slate-400">Chưa cấu hình VietQR (bank_id/STK/chủ TK).</div>
          <?php endif; ?>
        </div>
      </div>
    <?php else: ?>
      <div class="mt-4 rounded-2xl border border-white/10 bg-slate-900/40 p-5 text-slate-300 text-sm">
        Tạo yêu cầu nạp tiền để hiện QR và nội dung chuyển khoản.
      </div>
    <?php endif; ?>

    <div class="mt-6">
      <div class="font-semibold text-slate-100">Lịch sử nạp</div>
      <div class="mt-3 overflow-hidden rounded-2xl border border-white/10">
        <table class="w-full text-sm">
          <thead class="bg-white/5 text-slate-300">
            <tr>
              <th class="text-left px-4 py-3">Mã</th>
              <th class="text-right px-4 py-3">Số tiền</th>
              <th class="text-left px-4 py-3">Trạng thái</th>
              <th class="text-left px-4 py-3">Thời gian</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-white/5">
          <?php foreach($rows as $r): ?>
            <tr class="hover:bg-white/5">
              <td class="px-4 py-3 font-semibold"><a class="text-blue-300 hover:underline" href="<?=route_url('topup')?>?code=<?=urlencode($r['code'])?>">#<?=htmlspecialchars($r['code'])?></a></td>
              <td class="px-4 py-3 text-right"><?=number_format((int)$r['amount'],0,',','.')?>đ</td>
              <td class="px-4 py-3">
                <span class="<?=pill_class($r['status'])?>"><?=htmlspecialchars(strtoupper($r['status']))?></span>
              </td>
              <td class="px-4 py-3 text-slate-400"><?=htmlspecialchars($r['created_at'])?></td>
            </tr>
          <?php endforeach; ?>
          <?php if(!$rows): ?>
            <tr><td colspan="4" class="px-4 py-6 text-center text-slate-500">Chưa có yêu cầu nạp.</td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</div>
