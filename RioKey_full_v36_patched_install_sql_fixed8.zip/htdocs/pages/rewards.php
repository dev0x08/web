<?php
$u = auth_user(); require_auth();
$uid = (int)($u['id'] ?? 0);
shop_ensure_schema();
$req_token = 'rt_' . bin2hex(random_bytes(16));

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['redeem_product_id'])) {
  csrf_require();
  $pid = (int)($_POST['redeem_product_id'] ?? 0);
  $rt = (string)($_POST['request_token'] ?? '');
  $res = shop_redeem_points($uid, $pid, $rt);
  if ($res['ok'] ?? false) {
    flash_set('ok','Đổi key thành công! Mã đơn: '.($res['order_code'] ?? '').'. Key đã vào Kho key.');
    redirect(route_url('my_keys'));
  } else {
    flash_set('error',(string)($res['error'] ?? 'Có lỗi xảy ra'));
    redirect(route_url('rewards'));
  }
}

// Only show products with points_price > 0
$all = shop_products(true);
$cat = (string)($_GET['cat'] ?? 'all');
$validCats = ['game_key','giftcard','account','all'];
if (!in_array($cat,$validCats,true)) $cat='all';
$items = array_values(array_filter($all, function($p) use ($cat){
  if ((int)($p['points_price'] ?? 0) <= 0) return false;
  if ($cat==='all') return true;
  return (string)($p['category'] ?? 'game_key') === $cat;
}));
?>
<div class="flex items-center justify-between gap-3">
  <div>
    <div class="text-2xl font-extrabold">Đổi điểm lấy key</div>
    <div class="text-sm text-slate-400 mt-1">Đổi điểm để nhận key/code tự động • Giao ngay trong Kho key</div>
  </div>

<div class="mt-4 flex flex-wrap gap-2">
  <?php
    $tabs = [
      'all' => ['Tất cả','layers'],
      'game_key' => ['Key game','gamepad-2'],
      'giftcard' => ['Giftcard','credit-card'],
      'account'  => ['Tài khoản','user-round']
    ];
    foreach($tabs as $k=>$v):
      $active = $cat===$k;
  ?>
    <a class="px-3 py-2 rounded-2xl border <?= $active?'border-orange-500/40 bg-orange-500/10 text-orange-200':'border-white/10 bg-white/5 text-slate-200/80 hover:bg-white/10' ?>"
       href="<?= e(route_url('rewards',['cat'=>$k])) ?>">
      <?= lucide_icon($v[1], 'w-4 h-4 inline-block mr-2') ?> <?= e($v[0]) ?>
    </a>
  <?php endforeach; ?>
</div>

  <div class="hidden sm:flex items-center gap-2 px-3 py-2 rounded-2xl bg-white/5 border border-white/10">
    <?= lucide_icon('coins','w-4 h-4 text-amber-300') ?>
    <div class="text-sm font-extrabold"><?=(int)($u['points'] ?? 0)?> điểm</div>
  </div>
</div>

<?php if($msg=flash_get('ok')): ?>
  <div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($msg) ?></div>
<?php endif; ?>
<?php if($msg=flash_get('error')): ?>
  <div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($msg) ?></div>
<?php endif; ?>

<div class="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
  <?php if(!$items): ?>
    <div class="text-slate-400">Chưa có sản phẩm đổi điểm. Admin vào "Shop sản phẩm & Key" để thêm.</div>
  <?php else: foreach($items as $it): ?>
    <?php
      $stock = (int)($it['stock'] ?? 0);
      $out = ($stock <= 0);
      $cost = (int)($it['points_price'] ?? 0);
    ?>
    <div class="card p-5 relative overflow-hidden">
      <div class="absolute -right-10 -top-10 w-40 h-40 rounded-full bg-orange-500/10 blur-2xl"></div>
      <div class="flex items-start gap-4">
        <div class="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 overflow-hidden grid place-items-center">
          <?= lucide_icon('key-round','w-7 h-7') ?>
        </div>
        <div class="min-w-0 flex-1">
          <div class="font-extrabold truncate"><?= e($it['title'] ?? '') ?></div>
          <div class="text-sm text-slate-400 mt-1 line-clamp-2"><?= e($it['description'] ?? '') ?></div>
          <div class="mt-3 flex items-center justify-between gap-2">
            <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-sm font-extrabold">
              <?= lucide_icon('coins','w-4 h-4 text-amber-300') ?> <?= $cost ?> điểm
            </div>
            <span class="text-xs <?= $out?'text-rose-300':'text-slate-400' ?>">Còn <?= max(0,$stock) ?></span>
          </div>
        </div>
      </div>

      <form method="post" class="mt-4" data-once="1" data-confirm="'Xác nhận đổi sản phẩm này bằng điểm? Điểm sẽ bị trừ và key sẽ được đưa vào Kho key.'">
        <?= csrf_field() ?>
        <input type="hidden" name="redeem_product_id" value="<?= (int)($it['id'] ?? 0) ?>">
        <button class="btn w-full <?= $out?'opacity-50 cursor-not-allowed':'' ?>" <?= $out?'disabled':'' ?> type="submit">
          <?= $out ? 'Hết hàng' : 'Đổi ngay' ?>
        </button>
      </form>
    </div>
  <?php endforeach; endif; ?>
</div>
