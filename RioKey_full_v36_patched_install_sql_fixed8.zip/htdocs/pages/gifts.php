<?php
$u = auth_user(); require_auth(); csrf_require();
$uid=(int)$u['id'];
gifts_ensure_schema();
shop_ensure_schema();

$flash=null; $err=null;

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  $action=$_POST['action'] ?? '';
  try{
    if($action==='create'){
      $key_id=(int)($_POST['user_key_id'] ?? 0);
      $res=gift_create($uid,$key_id);
      if(!$res['ok']) throw new Exception($res['error'] ?? 'Lỗi');
      $link = base_url('index.php?route=gift&token='.$res['token']);
      $flash='Đã tạo link tặng quà (hết hạn sau '.$res['expires_days'].' ngày). Copy link bên dưới.';
      $_SESSION['gift_last_link']=$link;
      $_SESSION['gift_last_show']=1;
    } elseif($action==='revoke'){
      $gid=(int)($_POST['gift_id'] ?? 0);
      $res=gift_revoke($uid,$gid);
      if(!$res['ok']) throw new Exception($res['error'] ?? 'Lỗi');
      $flash='Đã thu hồi gift link.';
    }
  }catch(Throwable $e){ $err=$e->getMessage(); }
}

$last = (string)($_SESSION['gift_last_link'] ?? '');
$show_last = (int)($_SESSION['gift_last_show'] ?? 0)===1;
if(!$show_last){ $last=''; }
unset($_SESSION['gift_last_show']);
$out = gifts_outgoing($uid, 200);

$st=db()->prepare("SELECT k.id,k.created_at,p.title,p.category
  FROM shop_user_keys k JOIN shop_products p ON p.id=k.product_id
  WHERE k.user_id=? AND k.activated_at IS NULL AND (k.gift_link_id IS NULL OR k.gift_link_id=0)
  ORDER BY k.id DESC LIMIT 100");
$st->execute([$uid]);
$keys = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
?>
<div class="flex items-start justify-between gap-4">
  <div>
    <div class="text-2xl font-extrabold">Tặng quà</div>
    <div class="text-sm text-slate-400 mt-1">Tạo link 1 lần để tặng key cho bạn bè. Link có hạn sử dụng.</div>
  </div>
</div>

<?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<?php if($last!==''): ?>
  <div class="mt-4 card p-5">
    <div class="font-extrabold">Link vừa tạo</div>
    <div class="mt-2 flex gap-2">
      <input class="input flex-1" value="<?= e($last) ?>" readonly onclick="this.select()">
      <button class="btn" type="button" onclick="navigator.clipboard.writeText('<?= e($last) ?>')">Copy</button>
    </div>
    <div class="text-xs text-slate-500 mt-2">Gửi link này cho bạn bè. Người nhận đăng nhập và bấm Nhận quà.</div>
  </div>
<?php endif; ?>

<div class="mt-6 grid lg:grid-cols-3 gap-4">
  <div class="lg:col-span-2 card p-5">
    <div class="font-extrabold text-lg">Tạo link tặng quà</div>
    <div class="text-sm text-slate-400 mt-2">Chỉ tặng được key chưa kích hoạt và chưa có gift link.</div>

    <div class="mt-4 grid gap-3">
      <?php if(!$keys): ?>
        <div class="text-sm text-slate-500">Không có key phù hợp để tặng.</div>
      <?php else: foreach($keys as $k): ?>
        <form method="post" data-once="1" class="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between gap-3">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="create">
          <input type="hidden" name="user_key_id" value="<?= (int)$k['id'] ?>">
          <div>
            <div class="text-xs text-slate-400"><?= e($k['category'] ?? '') ?></div>
            <div class="font-extrabold"><?= e($k['title'] ?? '') ?></div>
            <div class="text-xs text-slate-500 mt-1">Key #<?= (int)$k['id'] ?> • <?= e($k['created_at'] ?? '') ?></div>
          </div>
          <button class="btn" type="submit">Tạo link</button>
        </form>
      <?php endforeach; endif; ?>
    </div>
  </div>

  <div class="card p-5">
    <div class="font-extrabold text-lg">Lịch sử gift link</div>
    <div class="mt-3 grid gap-2 max-h-[560px] overflow-auto pr-1">
      <?php if(!$out): ?>
        <div class="text-sm text-slate-500">Chưa tạo gift link.</div>
      <?php else: foreach($out as $g): ?>
        <div class="p-4 rounded-2xl bg-white/5 border border-white/10">
          <div class="font-extrabold"><?= e($g['product_title'] ?? '') ?></div>
          <div class="text-xs text-slate-500 mt-1">Token: <?= e(substr((string)$g['token'],0,12)) ?>…</div>
          <div class="text-xs text-slate-500 mt-1">Trạng thái: <b><?= e($g['status']) ?></b></div>
          <div class="text-xs text-slate-500 mt-1">Hết hạn: <?= e((string)($g['expires_at'] ?? '')) ?></div>
          <?php if((string)$g['status']==='active'): ?>
            <form method="post" class="mt-3" data-once="1" onsubmit="return confirm('Thu hồi gift link?');">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="revoke">
              <input type="hidden" name="gift_id" value="<?= (int)$g['id'] ?>">
              <button class="btn btn-ghost w-full" type="submit">Thu hồi</button>
            </form>
          <?php endif; ?>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>
</div>
