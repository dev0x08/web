<div class="grid place-items-center min-h-[70vh]">
  <div class="max-w-xl w-full">
    <div class="card p-8 text-center">
      <div class="mx-auto w-16 h-16 rounded-2xl bg-orange-500/10 border border-orange-500/20 grid place-items-center">
        <?= lucide_icon('search', 'w-8 h-8 text-orange-300') ?>
      </div>
      <h1 class="mt-6 text-2xl sm:text-3xl font-black tracking-tight">Không tìm thấy trang</h1>
      <p class="mt-2 text-slate-400">Đường dẫn bạn truy cập không tồn tại hoặc đã bị thay đổi.</p>

      <div class="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
        <a href="<?= e(route_url('dashboard')) ?>" class="btn btn-primary">
          <?= lucide_icon('arrow-left', 'w-5 h-5') ?>
          Về trang chủ
        </a>
        <a href="<?= e(route_url('help')) ?>" class="btn btn-ghost">
          <?= lucide_icon('life-buoy', 'w-5 h-5') ?>
          Trợ giúp
        </a>
      </div>

      <div class="mt-8 text-xs text-slate-500">Mã lỗi: 404</div>
    </div>
  </div>
</div>
