<?php
$u = auth_user(); require_auth();
$uid = (int)($u['id'] ?? 0);
shop_ensure_schema();

// handle activate + vault reveal
if($_SERVER['REQUEST_METHOD']==='POST'){
  // activate
  if(isset($_POST['activate_order'])){
    csrf_require();
    $id=(int)($_POST['activate_order'] ?? 0);
    if($id>0){
      db()->prepare("UPDATE shop_user_keys SET activated_at=NOW() WHERE id=? AND user_id=? AND activated_at IS NULL")->execute([$id,$uid]);
    }
    redirect(route_url('my_keys'));
  }

  // reveal key requires Vault PIN every time
  if(($_POST['action'] ?? '')==='reveal_key'){
    csrf_require();
    $pin = trim((string)($_POST['pin'] ?? ''));
    $kid = (int)($_POST['key_id'] ?? 0);

    if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }
    $fails = (int)($_SESSION['vault_fail'] ?? 0);
    $lockUntil = (int)($_SESSION['vault_lock_until'] ?? 0);
    if ($lockUntil > time()) {
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(['ok'=>false,'msg'=>'Thử sai quá nhiều. Vui lòng đợi 30 giây rồi thử lại.'], JSON_UNESCAPED_UNICODE);
      exit;
    }

    if(!vault_verify_pin($uid, $pin)){
      $fails++;
      $_SESSION['vault_fail'] = $fails;
      if($fails >= 5){
        $_SESSION['vault_lock_until'] = time() + 30;
        $_SESSION['vault_fail'] = 0;
      }
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(['ok'=>false,'msg'=>'PIN Vault không đúng.'], JSON_UNESCAPED_UNICODE);
      exit;
    }

    $_SESSION['vault_fail'] = 0;
    $st = db()->prepare("SELECT key_code FROM shop_user_keys WHERE id=? AND user_id=? LIMIT 1");
    $st->execute([$kid,$uid]);
    $kc = $st->fetchColumn();
    if(!$kc){
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(['ok'=>false,'msg'=>'Không tìm thấy key.'], JSON_UNESCAPED_UNICODE);
      exit;
    }
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok'=>true,'key'=>$kc], JSON_UNESCAPED_UNICODE);
    exit;
  }
}


$items = shop_user_keys($uid, 200);
?>
<form method="post" class="hidden"><?= csrf_field() ?></form>
<div class="flex items-center justify-between gap-3">
  <div>
    <div class="text-2xl font-extrabold">Kho key</div>
    <div class="text-sm text-slate-400 mt-1">Tất cả key/code bạn đã mua hoặc đổi bằng điểm</div>
  </div>
  <a href="<?= e(route_url('shop')) ?>" class="btn btn-ghost inline-flex items-center gap-2">
    <?= lucide_icon('key','w-4 h-4') ?> Vào Shop
  </a>
</div>

<div class="mt-6 card overflow-hidden">
  <div class="overflow-x-auto">
    <table class="min-w-full text-sm">
      <thead class="bg-white/5 text-slate-300">
        <tr>
          <th class="text-left px-4 py-3">Thời gian</th>
          <th class="text-left px-4 py-3">Sản phẩm</th>
          <th class="text-left px-4 py-3">Thanh toán</th>
          <th class="text-left px-4 py-3">Key/Code</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-white/5">
      <?php if(!$items): ?>
        <tr>
          <td colspan="4" class="px-4 py-6 text-slate-400">Bạn chưa có key nào. Vào Shop để mua/đổi.</td>
        </tr>
      <?php else: foreach($items as $it): ?>
        <tr>
          <td class="px-4 py-3 text-slate-400 whitespace-nowrap"><?= e(date('d/m/Y H:i', strtotime($it['created_at'] ?? 'now'))) ?></td>
          <td class="px-4 py-3 font-semibold"><?= e($it['product_title'] ?? '') ?><div class="text-xs text-slate-500 mt-1">Mã đơn: <?= e($it['order_code'] ?? '') ?></div></td>
          <td class="px-4 py-3">
            <?php if(($it['pay_method'] ?? '')==='wallet'): ?>
              <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-200 text-xs font-bold">
                <?= lucide_icon('wallet','w-4 h-4') ?> <?= format_vnd((int)($it['amount_vnd'] ?? 0)) ?>
              </span>
            <?php else: ?>
              <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-200 text-xs font-bold">
                <?= lucide_icon('coins','w-4 h-4') ?> <?= (int)($it['points'] ?? 0) ?> điểm
              </span>
            <?php endif; ?>
          </td>
          <td class="px-4 py-3">
            <div class="flex items-center gap-2">
              <input class="input !py-2 !h-auto text-xs bg-black/30" readonly value="••••••••••••••••" data-id="<?= (int)($it['id'] ?? 0) ?>">
              <button type="button" class="btn btn-ghost" onclick="riokeyRevealAndCopy(this)">
                <?= lucide_icon('copy','w-4 h-4') ?>
              </button>
            </div>
          </td>
          <td class="px-4 py-3">
            <?php if(!empty($it['activated_at'])): ?>
              <span class="px-2 py-1 text-xs rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-200">Đã kích hoạt</span>
            <?php else: ?>
              <span class="px-2 py-1 text-xs rounded-full bg-slate-500/10 border border-white/10 text-slate-300">Chưa kích hoạt</span>
            <?php endif; ?>
          </td>
          <td class="px-4 py-3 text-right">
            <?php if(empty($it['activated_at'])): ?>
              <form method="post" class="inline" data-once="1" data-confirm="'Bạn xác nhận đã kích hoạt/sử dụng key này? (Sau khi kích hoạt, hệ thống sẽ đánh dấu để bạn dễ quản lý.)'">
                <?= csrf_field() ?>
                <button class="btn btn-ghost" name="activate_order" value="<?= (int)($it['id'] ?? 0) ?>" type="submit">Đã kích hoạt</button>
              </form>
            <?php else: ?>
              <span class="text-xs text-slate-500">OK</span>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>



<!-- Vault PIN Modal -->
<div id="vaultPinModal" class="hidden fixed inset-0 z-50">
  <div class="absolute inset-0 bg-black/70" onclick="riokeyCloseVault()"></div>
  <div class="relative max-w-md mx-auto mt-28 card p-6">
    <div class="flex items-start justify-between gap-3">
      <div class="text-lg font-extrabold">Nhập Vault PIN</div>
      <button class="btn btn-ghost" type="button" onclick="riokeyCloseVault()"><?= lucide_icon('x','w-4 h-4') ?></button>
    </div>
    <div class="text-sm text-slate-300 mt-3 leading-relaxed">
      Vì bạn đã bật Vault PIN, hệ thống cần xác minh trước khi hiện/copy key.
    </div>
    <div class="mt-4 flex gap-2">
      <input id="vaultPinInput" class="input flex-1" placeholder="PIN 4-6 số" inputmode="numeric" pattern="[0-9]*" maxlength="6">
      <button class="btn" type="button" onclick="riokeySubmitVault()">Xác nhận</button>
    </div>
    <div id="vaultPinErr" class="text-rose-200 text-sm mt-3 hidden">PIN không đúng.</div>
    <div class="text-xs text-slate-500 mt-4">Tip: Bạn có thể tắt/đổi PIN ở Trang cá nhân → Bảo mật.</div>
  </div>
</div>

<!-- Popup guidance -->
<div id="keyGuidanceModal" class="hidden fixed inset-0 z-50">
  <div class="absolute inset-0 bg-black/70" onclick="riokeyCloseGuidance()"></div>
  <div class="relative max-w-lg mx-auto mt-28 card p-6">
    <div class="flex items-start justify-between gap-3">
      <div class="text-lg font-extrabold">Lưu ý khi sử dụng key/tài khoản</div>
      <button class="btn btn-ghost" type="button" onclick="riokeyCloseGuidance()"><?= lucide_icon('x','w-4 h-4') ?></button>
    </div>
    <div class="text-sm text-slate-300 mt-3 leading-relaxed">
      Key/Code và tài khoản là thông tin nhạy cảm. Sau khi nhận, bạn nên:
      <ul class="list-disc ml-5 mt-2 space-y-1 text-slate-300">
        <li>Nhập key và <b>kích hoạt ngay</b> trên nền tảng tương ứng.</li>
        <li>Nếu là <b>tài khoản</b>, hãy <b>đổi mật khẩu</b> / bật bảo mật (2FA) nếu có.</li>
        <li>Không chia sẻ key công khai. Tránh đăng nhập trên máy lạ để hạn chế rủi ro.</li>
      </ul>
      Nếu gặp lỗi, chụp màn hình và liên hệ hỗ trợ để được xử lý nhanh.
    </div>
    <div class="mt-4 flex justify-end">
      <button class="btn" type="button" onclick="riokeyCloseGuidance()">Đã hiểu</button>
    </div>
  </div>
</div>

<script>
function riokeyCloseGuidance(){
  document.getElementById('keyGuidanceModal').classList.add('hidden');
}
let __pendingRevealBtn=null;
function riokeyCloseVault(){
  document.getElementById('vaultPinModal').classList.add('hidden');
}
async function riokeySubmitVault(){
  const pin = (document.getElementById('vaultPinInput').value||'').trim();
  const err = document.getElementById('vaultPinErr');
  if(err) err.classList.add('hidden');
  const fd = new FormData();
  fd.append('action','vault_verify');
  fd.append('pin', pin);
  fd.append('csrf_token', '<?= e(csrf_token()) ?>');
  const res = await fetch('', {method:'POST', body: fd});
  const j = await res.json();
  if(j && j.ok){
    riokeyCloseVault();
    if(__pendingRevealBtn){
      const b=__pendingRevealBtn; __pendingRevealBtn=null;
      riokeyRevealAndCopy(b, true);
    }
  } else {
    if(err) err.classList.remove('hidden');
  }
}
function riokeyRevealAndCopy(btn, __skipVault){
  const needVault = (<?= $vaultNeed ? '1' : '0' ?>) === 1;
  if(needVault && !__skipVault){
    __pendingRevealBtn = btn;
    document.getElementById('vaultPinInput').value='';
    document.getElementById('vaultPinErr').classList.add('hidden');
    document.getElementById('vaultPinModal').classList.remove('hidden');
    return;
  }
  const td = btn.closest('td');
  const input = td ? td.querySelector('input[data-key]') : null;
  if(!input) return;
  const real = input.getAttribute('data-key') || '';
  if(real === '') return;

  input.value = real;

  try { navigator.clipboard.writeText(real); } catch(e){}

  const modal = document.getElementById('keyGuidanceModal');
  if(modal) modal.classList.remove('hidden');
}
</script>
