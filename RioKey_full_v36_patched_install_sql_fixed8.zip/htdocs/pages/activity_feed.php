<?php
// JSON feed for recent purchases (for mini-toast)
header('Content-Type: application/json; charset=utf-8');
shop_ensure_schema();

$since = (int)($_GET['since'] ?? 0);
$limit = 8;
$sql = "SELECT o.id,o.created_at,o.amount_vnd,o.pay_method,p.title
        FROM shop_orders o
        JOIN shop_products p ON p.id=o.product_id
        WHERE o.status='delivered' " . ($since>0 ? "AND o.id>? " : "") . "
        ORDER BY o.id DESC LIMIT {$limit}";
$st = db()->prepare($sql);
if($since>0){ $st->bindValue(1,$since,PDO::PARAM_INT); }
$st->execute();
$rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
// mask user identity by default
$out = [];
foreach(array_reverse($rows) as $r){
  $out[] = [
    'id'=>(int)$r['id'],
    'title'=>(string)$r['title'],
    'amount_vnd'=>(int)$r['amount_vnd'],
    'pay_method'=>(string)$r['pay_method'],
    'created_at'=>(string)$r['created_at'],
  ];
}
echo json_encode(['ok'=>true,'items'=>$out], JSON_UNESCAPED_UNICODE);
exit;
