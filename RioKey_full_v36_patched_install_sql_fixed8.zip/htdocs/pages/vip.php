<?php
$u = auth_user(); require_auth();
$uid = (int)($u['id'] ?? 0);
vip_ensure_schema();
$w = wallet_get($uid);
$balance = (float)($w['balance'] ?? 0);

$active = vip_active($uid);

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['buy_vip_plan'])) {
  csrf_require();
  $plan_id = (int)($_POST['buy_vip_plan'] ?? 0);
  $rt = (string)($_POST['request_token'] ?? '');
  $res = vip_buy($uid, $plan_id, $rt);
  if ($res['ok'] ?? false) {
    flash_set('ok', (string)($res['msg'] ?? 'Mua VIP thành công'));
    redirect(route_url('vip'));
  } else {
    flash_set('error', (string)($res['msg'] ?? 'Có lỗi'));
    redirect(route_url('vip'));
  }
}

$plans = db()->query("SELECT * FROM vip_plans WHERE is_active=1 ORDER BY price_vnd ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
$req_token = 'viprt_' . bin2hex(random_bytes(16));
?>
<div class="max-w-5xl mx-auto">
  <div class="text-center">
    <h1 class="text-3xl sm:text-4xl font-black tracking-tight">RioKey <span class="text-orange-400">VIP</span></h1>
    <p class="text-slate-400 mt-2">Giảm giá khi mua key + cộng thêm % điểm tích luỹ.</p>
  </div>

  <?php if($active): ?>
    <div class="mt-6 card p-5 border-emerald-500/20 bg-emerald-500/5">
      <div class="flex items-center justify-between gap-3">
        <div>
          <div class="font-extrabold text-lg">Bạn đang là VIP</div>
          <div class="text-sm text-slate-300 mt-1">
            Gói: <b><?= e($active['title'] ?? '') ?></b> • Giảm <b>-<?= (int)$active['discount_pct'] ?>%</b> • Bonus điểm <b>+<?= (int)$active['points_bonus_pct'] ?>%</b>
          </div>
        </div>
        <div class="text-sm text-slate-300">Hạn: <b><?= e($active['expires_at'] ?? '') ?></b></div>
      </div>
    </div>
  <?php else: ?>
    <div class="mt-6 card p-5">
      <div class="font-extrabold text-lg">Chưa kích hoạt VIP</div>
      <div class="text-sm text-slate-400 mt-1">Mua VIP để nhận ưu đãi.</div>
    </div>
  <?php endif; ?>

  <div class="mt-6 grid md:grid-cols-2 gap-4">
    <?php foreach($plans as $p): ?>
      <div class="card p-5 hover:border-orange-500/30 transition">
        <div class="flex items-start justify-between gap-3">
          <div>
            <div class="text-lg font-extrabold"><?= e($p['title']) ?></div>
            <div class="text-sm text-slate-400 mt-1"><?= (int)$p['duration_days'] ?> ngày • Giảm -<?= (int)$p['discount_pct'] ?>% • Bonus điểm +<?= (int)$p['points_bonus_pct'] ?>%</div>
          </div>
          <?= lucide_icon('crown','w-6 h-6 text-orange-300') ?>
        </div>

        <div class="mt-4 flex items-center justify-between">
          <div class="text-2xl font-black text-emerald-200"><?= format_vnd((int)$p['price_vnd']) ?></div>
          <form method="post" data-once="1">
            <?= csrf_field() ?>
            <input type="hidden" name="request_token" value="<?= e($req_token) ?>">
            <button class="btn" name="buy_vip_plan" value="<?= (int)$p['id'] ?>" type="submit"
              data-confirm='Xác nhận mua VIP <?= e(addslashes($p['title'])) ?> với giá <?= format_vnd((int)$p['price_vnd']) ?>?'>
              Mua VIP
            </button>
          </form>
        </div>
        <div class="text-xs text-slate-500 mt-2">Số dư hiện có: <b><?= format_vnd((int)$balance) ?></b></div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
