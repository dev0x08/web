<?php
$u = auth_user(); csrf_require();
$uid = (int)($u['id'] ?? 0);

shop_ensure_schema();
reviews_ensure_schema();

$product_id = (int)($_GET['id'] ?? 0);
if($product_id<=0) { http_response_code(404); echo "Not found"; exit; }

$st = db()->prepare("SELECT * FROM shop_products WHERE id=? AND is_active=1 LIMIT 1");
$st->execute([$product_id]);
$p = $st->fetch(PDO::FETCH_ASSOC);
if(!$p) { http_response_code(404); echo "Not found"; exit; }

$flash=null; $err=null;

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  $action = $_POST['action'] ?? '';
  try {
    if($action==='review'){
      require_auth();
      $rating = (int)($_POST['rating'] ?? 0);
      $content = (string)($_POST['content'] ?? '');
      $res = review_upsert($uid, $product_id, $rating, $content);
      if(!$res['ok']) throw new Exception($res['error'] ?? 'Lỗi');
      $flash = ($res['status'] ?? '')==='pending' ? 'Đã gửi đánh giá (chờ duyệt).' : 'Đã lưu đánh giá. Cảm ơn bạn!';
    }
    if($action==='wishlist'){
      require_auth();
      $on = wishlist_toggle($uid, $product_id);
      flash_set('ok', $on ? 'Đã thêm vào wishlist.' : 'Đã bỏ khỏi wishlist.');
      redirect(route_url('product').'?id='.(int)$product_id);
    }
  } catch(Throwable $e){ $err=$e->getMessage(); }
}

$flashD = flash_active_discount($p['category'] ?? null);
$ap = $uid>0 ? shop_final_price_for_user($uid, $p, $flashD) : ['price'=>(int)($p['price_vnd'] ?? 0), 'total'=>0];
$price = (int)$ap['price'];

$sum = review_get_summary($product_id);
$reviews = review_list($product_id, 30);
$wOn = $uid>0 ? in_array($product_id, wishlist_ids($uid), true) : false;
?>
<div class="flex items-start justify-between gap-4">
  <div>
    <div class="text-sm text-slate-400"><?= e($p['category'] ?? '') ?></div>
    <div class="text-2xl font-extrabold mt-1"><?= e($p['title'] ?? '') ?></div>
    <div class="text-sm text-slate-400 mt-2 max-w-3xl"><?= nl2br(e((string)($p['description'] ?? ''))) ?></div>
  </div>
  <div class="flex gap-2">
    <a class="btn btn-ghost" href="<?= e(route_url('shop')) ?>">← Shop</a>
  </div>
</div>

<?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 grid lg:grid-cols-3 gap-4">
  <div class="lg:col-span-2 card p-6">
    <div class="flex items-center justify-between gap-4">
      <div class="text-xl font-extrabold text-orange-200"><?= money_vnd($price) ?></div>
      <div class="flex items-center gap-2">
        <?php if($uid>0): ?>
          <form method="post" data-once="1">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="wishlist">
            <button class="btn btn-ghost" type="submit"><?= $wOn ? '❤ Đang theo dõi' : '❤ Wishlist' ?></button>
          </form>
        <?php endif; ?>
        <form method="post" action="<?= e(route_url('shop')) ?>" data-once="1">
          <?= csrf_field() ?>
          <input type="hidden" name="product_id" value="<?= (int)$product_id ?>">
          <button class="btn" type="submit">Mua ngay</button>
        </form>
      </div>
    </div>

    <div class="mt-6 p-4 rounded-2xl bg-white/5 border border-white/10">
      <div class="flex items-center justify-between gap-4">
        <div class="font-extrabold">Đánh giá</div>
        <div class="text-sm text-slate-300">
          <span class="font-extrabold"><?= number_format((float)$sum['avg'],1) ?></span>/5 • <?= (int)$sum['count'] ?> lượt
        </div>
      </div>

      <div class="mt-3 text-lg"><?= review_star_row((int)round((float)$sum['avg'])) ?></div>

      <?php if($uid>0 && review_can_write($uid,$product_id)): ?>
        <form method="post" class="mt-4 grid gap-3" data-once="1">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="review">
          <div class="grid sm:grid-cols-3 gap-3">
            <div>
              <label class="label">Số sao</label>
              <select class="input w-full" name="rating">
                <option value="5">5 ★</option>
                <option value="4">4 ★</option>
                <option value="3">3 ★</option>
                <option value="2">2 ★</option>
                <option value="1">1 ★</option>
              </select>
            </div>
            <div class="sm:col-span-2">
              <label class="label">Nội dung</label>
              <input class="input w-full" name="content" placeholder="Cảm nhận ngắn gọn...">
            </div>
          </div>
          <button class="btn" type="submit">Gửi đánh giá</button>
          <div class="text-xs text-slate-500">Chỉ người đã mua mới đánh giá được (Verified Purchase).</div>
        </form>
      <?php elseif($uid===0): ?>
        <div class="text-sm text-slate-500 mt-4">Đăng nhập để đánh giá.</div>
      <?php else: ?>
        <div class="text-sm text-slate-500 mt-4">Bạn cần mua sản phẩm trước khi đánh giá.</div>
      <?php endif; ?>
    </div>

    <div class="mt-4 grid gap-3">
      <?php if(!$reviews): ?>
        <div class="text-sm text-slate-500">Chưa có đánh giá.</div>
      <?php else: foreach($reviews as $r): ?>
        <div class="p-4 rounded-2xl bg-white/5 border border-white/10">
          <div class="flex items-center justify-between gap-3">
            <div class="font-extrabold"><?= e($r['username'] ?? '') ?></div>
            <div class="text-sm"><?= review_star_row((int)$r['rating']) ?></div>
          </div>
          <?php if(trim((string)($r['content'] ?? ''))!==''): ?>
            <div class="text-sm text-slate-300 mt-2"><?= e((string)$r['content']) ?></div>
          <?php endif; ?>
          <div class="text-xs text-slate-500 mt-2"><?= e($r['created_at'] ?? '') ?></div>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>

  <div class="card p-6">
    <div class="font-extrabold text-lg">Gợi ý an toàn</div>
    <div class="text-sm text-slate-300 mt-3 leading-relaxed">
      Sau khi nhận key/tài khoản, bạn nên <b>kích hoạt ngay</b> hoặc <b>đổi mật khẩu</b> (nếu là account) để tránh bị trùng/hết hạn do dùng chậm.
    </div>

    <div class="mt-5 p-4 rounded-2xl bg-white/5 border border-white/10">
      <div class="font-extrabold">Vault PIN</div>
      <div class="text-sm text-slate-400 mt-1">Bật PIN để phải xác minh trước khi xem/copy key.</div>
      <a class="btn btn-ghost w-full mt-3" href="<?= e(route_url('profile',['tab'=>'security'])) ?>">Bật Vault PIN</a>
    </div>
  </div>
</div>
