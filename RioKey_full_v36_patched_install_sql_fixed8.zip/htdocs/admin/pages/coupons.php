<?php
require_staff();
if (!is_admin()) { http_response_code(403); echo 'Forbidden'; return; }
coupons_ensure_schema();

$aid = (int)((auth_user()['id'] ?? 0));
$ok=null; $err=null;

$edit_id = (int)($_GET['edit'] ?? 0);
$edit = null;
if ($edit_id>0) {
  $st=db()->prepare("SELECT * FROM coupons WHERE id=? LIMIT 1");
  $st->execute([$edit_id]);
  $edit=$st->fetch(PDO::FETCH_ASSOC) ?: null;
}

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_require();
  $action=$_POST['action']??'';
  try {
    if($action==='save'){
      $id=(int)($_POST['id']??0);
      $code=coupon_normalize_code((string)($_POST['code']??''));
      $reward_type=(string)($_POST['reward_type']??'points');
      $reward_amount=(int)($_POST['reward_amount']??0);
      $max_uses_raw=trim((string)($_POST['max_uses']??''));
      $max_uses = ($max_uses_raw==='') ? null : (int)$max_uses_raw;
      $per_user_once=isset($_POST['per_user_once'])?1:0;
      $expires_at_raw=trim((string)($_POST['expires_at']??''));
      $expires_at = ($expires_at_raw==='') ? null : $expires_at_raw;
      $is_active=isset($_POST['is_active'])?1:0;
      $note=trim((string)($_POST['note']??''));

      if($code==='') throw new Exception('Mã không được để trống');
      if(!preg_match('/^[A-Z0-9_-]{3,64}$/',$code)) throw new Exception('Mã chỉ gồm A-Z 0-9 _ - (3~64 ký tự)');
      if(!in_array($reward_type,['wallet','points'],true)) throw new Exception('Loại thưởng không hợp lệ');
      if($reward_amount<=0) throw new Exception('Số thưởng phải > 0');
      if($max_uses!==null && $max_uses<=0) throw new Exception('Max uses phải > 0 hoặc để trống');

      if($id>0){
        $st=db()->prepare("UPDATE coupons SET code=?,reward_type=?,reward_amount=?,max_uses=?,per_user_once=?,expires_at=?,is_active=?,note=? WHERE id=?");
        $st->execute([$code,$reward_type,$reward_amount,$max_uses,$per_user_once,$expires_at,$is_active,$note,$id]);
        audit_log($aid,'coupon_update','coupons',(string)$id,['code'=>$code]);
        $ok='Đã cập nhật coupon.';
        redirect(admin_url('coupons',['edit'=>$id]));
      } else {
        $st=db()->prepare("INSERT INTO coupons(code,reward_type,reward_amount,max_uses,per_user_once,expires_at,is_active,note,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,NOW())");
        $st->execute([$code,$reward_type,$reward_amount,$max_uses,$per_user_once,$expires_at,$is_active,$note,$aid]);
        $id=(int)db()->lastInsertId();
        audit_log($aid,'coupon_create','coupons',(string)$id,['code'=>$code]);
        $ok='Đã tạo coupon.';
        redirect(admin_url('coupons',['edit'=>$id]));
      }
    }

    if($action==='delete'){
      $id=(int)($_POST['id']??0);
      if($id<=0) throw new Exception('ID không hợp lệ');
      db()->prepare("DELETE FROM coupons WHERE id=?")->execute([$id]);
      audit_log($aid,'coupon_delete','coupons',(string)$id,[]);
      $ok='Đã xoá coupon.';
      redirect(admin_url('coupons'));
    }
  } catch (Throwable $e) {
    $err=$e->getMessage();
  }
}

$coupons = db()->query("SELECT c.*,
  (SELECT COUNT(*) FROM coupon_redemptions r WHERE r.coupon_id=c.id) AS used_cnt
  FROM coupons c ORDER BY c.id DESC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC) ?: [];
?>
<div class="flex items-start justify-between gap-4">
  <div>
    <div class="text-2xl font-extrabold">Coupons / Redeem</div>
    <div class="text-sm text-slate-400 mt-1">Tạo mã thưởng: giới hạn lượt dùng, hạn sử dụng, mỗi user 1 lần.</div>
  </div>
</div>

<?php if($ok): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($ok) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 grid lg:grid-cols-3 gap-4">
  <div class="card p-5 lg:col-span-1">
    <div class="font-extrabold text-lg"><?= $edit ? 'Sửa coupon' : 'Tạo coupon' ?></div>
    <form method="post" class="mt-4 space-y-3" data-once="1">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">

      <input class="input" name="code" placeholder="Mã (VD: RIOKEY2026)" value="<?= e($edit['code'] ?? '') ?>">
      <div class="grid grid-cols-2 gap-3">
        <select class="input" name="reward_type">
          <option value="points" <?= (($edit['reward_type'] ?? 'points')==='points')?'selected':'' ?>>Điểm</option>
          <option value="wallet" <?= (($edit['reward_type'] ?? '')==='wallet')?'selected':'' ?>>Tiền ví (VNĐ)</option>
        </select>
        <input class="input" type="number" name="reward_amount" placeholder="Số thưởng" value="<?= (int)($edit['reward_amount'] ?? 0) ?>">
      </div>

      <input class="input" name="max_uses" placeholder="Giới hạn lượt dùng (trống = vô hạn)" value="<?= e($edit['max_uses'] ?? '') ?>">
      <label class="flex items-center gap-2 text-sm text-slate-200">
        <input type="checkbox" name="per_user_once" <?= ((int)($edit['per_user_once'] ?? 1)===1)?'checked':'' ?>> Mỗi user chỉ dùng 1 lần
      </label>

      <input class="input" name="expires_at" placeholder="Hạn dùng (YYYY-MM-DD HH:MM:SS) hoặc trống" value="<?= e($edit['expires_at'] ?? '') ?>">

      <label class="flex items-center gap-2 text-sm text-slate-200">
        <input type="checkbox" name="is_active" <?= ((int)($edit['is_active'] ?? 1)===1)?'checked':'' ?>> Kích hoạt
      </label>

      <input class="input" name="note" placeholder="Ghi chú" value="<?= e($edit['note'] ?? '') ?>">

      <button class="btn w-full" type="submit"><?= $edit ? 'Lưu' : 'Tạo mã' ?></button>
    </form>

    <?php if($edit): ?>
      <form method="post" class="mt-3" data-once="1" onsubmit="return confirm('Xoá coupon này?');">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
        <button class="btn btn-ghost w-full" type="submit">Xoá</button>
      </form>
    <?php endif; ?>
  </div>

  <div class="lg:col-span-2 card p-5">
    <div class="font-extrabold text-lg">Danh sách coupon</div>
    <div class="mt-4 overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="text-slate-400">
          <tr>
            <th class="text-left font-semibold px-3 py-2">ID</th>
            <th class="text-left font-semibold px-3 py-2">Code</th>
            <th class="text-left font-semibold px-3 py-2">Thưởng</th>
            <th class="text-left font-semibold px-3 py-2">Used/Max</th>
            <th class="text-left font-semibold px-3 py-2">Hết hạn</th>
            <th class="text-left font-semibold px-3 py-2">Trạng thái</th>
            <th class="text-right font-semibold px-3 py-2"></th>
          </tr>
        </thead>
        <tbody class="divide-y divide-white/5">
          <?php if(!$coupons): ?>
            <tr><td colspan="7" class="px-3 py-4 text-slate-500">Chưa có coupon.</td></tr>
          <?php else: foreach($coupons as $c): 
            $used=(int)($c['used_cnt']??0);
            $max=$c['max_uses'];
          ?>
            <tr>
              <td class="px-3 py-3"><?= (int)$c['id'] ?></td>
              <td class="px-3 py-3 font-extrabold text-orange-200"><?= e($c['code']) ?></td>
              <td class="px-3 py-3">
                +<?= (int)$c['reward_amount'] ?> <?= ($c['reward_type']==='wallet')?'đ':'điểm' ?>
                <?php if((int)($c['per_user_once']??1)===1): ?><span class="text-xs text-slate-500">• 1 lần/user</span><?php endif; ?>
              </td>
              <td class="px-3 py-3"><?= $used ?> / <?= ($max===null||$max==='')?'∞':(int)$max ?></td>
              <td class="px-3 py-3 text-slate-400"><?= e($c['expires_at'] ?? '') ?></td>
              <td class="px-3 py-3">
                <?= ((int)($c['is_active']??0)===1) ? '<span class="text-emerald-200">ON</span>' : '<span class="text-rose-200">OFF</span>' ?>
              </td>
              <td class="px-3 py-3 text-right">
                <a class="btn btn-ghost" href="<?= e(admin_url('coupons',['edit'=>$c['id']])) ?>">Sửa</a>
              </td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
