<div class="grid place-items-center min-h-[70vh]">
  <div class="card p-8 text-center max-w-xl w-full">
    <div class="mx-auto w-16 h-16 rounded-2xl bg-orange-500/10 border border-orange-500/20 grid place-items-center">
      <?= lucide_icon('shield-alert','w-8 h-8 text-orange-300') ?>
    </div>
    <h1 class="mt-6 text-2xl font-black">Không tìm thấy trang</h1>
    <p class="mt-2 text-slate-400">Trang admin bạn yêu cầu không tồn tại.</p>
    <a class="btn mt-6 inline-flex" href="<?= e(base_url('/admin/dashboard')) ?>">Quay về Dashboard</a>
  </div>
</div>
