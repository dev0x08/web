<?php
$u = auth_user(); require_staff();
shop_ensure_schema();

$rows = shop_admin_orders(300);
?>
<div class="card p-6">
  <div class="flex items-center justify-between gap-3">
    <div>
      <div class="text-xl font-extrabold">Đơn mua key</div>
      <div class="text-sm text-slate-400 mt-1">Đơn được giao tự động sau khi trừ ví/điểm.</div>
    </div>
    <?php if(is_admin()): ?>
      <a class="btn btn-ghost" href="<?= e(admin_url('products')) ?>"><?= lucide_icon('key','w-4 h-4') ?> Quản lý sản phẩm</a>
    <?php endif; ?>
  </div>

  <div class="mt-4 overflow-hidden rounded-2xl border border-white/10">
    <table class="w-full text-sm">
      <thead class="bg-white/5 text-slate-300">
        <tr>
          <th class="text-left px-4 py-3">Thời gian</th>
          <th class="text-left px-4 py-3">Mã đơn</th>
          <th class="text-left px-4 py-3">User</th>
          <th class="text-left px-4 py-3">Sản phẩm</th>
          <th class="text-left px-4 py-3">Thanh toán</th>
          <th class="text-left px-4 py-3">Trạng thái</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-white/5">
      <?php if(!$rows): ?>
        <tr><td colspan="6" class="px-4 py-6 text-slate-400 text-center">Chưa có đơn.</td></tr>
      <?php else: foreach($rows as $o): ?>
        <tr>
          <td class="px-4 py-3 text-slate-400 whitespace-nowrap"><?= e(date('d/m/Y H:i', strtotime($o['created_at'] ?? 'now'))) ?></td>
          <td class="px-4 py-3 font-extrabold"><?= e($o['order_code'] ?? '') ?></td>
          <td class="px-4 py-3"><?= e(($o['user_username'] ?? '') ?: ($o['user_name'] ?? '')) ?></td>
          <td class="px-4 py-3"><?= e($o['product_title'] ?? '') ?></td>
          <td class="px-4 py-3">
            <?php if(($o['pay_method'] ?? '')==='wallet'): ?>
              <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-200 text-xs font-bold">
                <?= lucide_icon('wallet','w-4 h-4') ?> <?= format_vnd((int)($o['amount_vnd'] ?? 0)) ?>
              </span>
            <?php else: ?>
              <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-200 text-xs font-bold">
                <?= lucide_icon('coins','w-4 h-4') ?> <?= (int)($o['points'] ?? 0) ?> điểm
              </span>
            <?php endif; ?>
          </td>
          <td class="px-4 py-3">
            <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-slate-200 text-xs font-bold">
              <?= lucide_icon('check-circle','w-4 h-4 text-emerald-300') ?> <?= e($o['status'] ?? 'delivered') ?>
            </span>
          </td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
