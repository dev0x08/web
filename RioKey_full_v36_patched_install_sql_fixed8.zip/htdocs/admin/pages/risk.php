<?php
require_staff();

$days = (int)($_GET['days'] ?? 7);
if ($days<1) $days=7;
$since = date('Y-m-d H:i:s', time() - $days*86400);

$redeem = [];
if (db_has_table('coupon_redemptions') && db_has_column('coupon_redemptions','ip')) {
  $redeem = db()->prepare("SELECT ip, COUNT(*) cnt, COUNT(DISTINCT user_id) users
    FROM coupon_redemptions WHERE created_at>=? AND ip IS NOT NULL AND ip<>'' GROUP BY ip ORDER BY cnt DESC LIMIT 20");
  $redeem->execute([$since]);
  $redeem = $redeem->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

$orders = [];
if (db_has_table('shop_orders') && db_has_column('shop_orders','ip')) {
  $st = db()->prepare("SELECT ip, COUNT(*) cnt, COUNT(DISTINCT user_id) users
    FROM shop_orders WHERE created_at>=? AND ip IS NOT NULL AND ip<>'' GROUP BY ip ORDER BY cnt DESC LIMIT 20");
  $st->execute([$since]);
  $orders = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

$shared = [];
if (db_has_column('users','last_ip')) {
  $st = db()->query("SELECT last_ip ip, COUNT(*) cnt FROM users WHERE last_ip IS NOT NULL AND last_ip<>'' GROUP BY last_ip HAVING cnt>=3 ORDER BY cnt DESC LIMIT 20");
  $shared = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}
?>
<div class="flex items-start justify-between gap-4">
  <div>
    <div class="text-2xl font-extrabold">Risk Center</div>
    <div class="text-sm text-slate-400 mt-1">Nhìn nhanh IP đáng nghi (redeem/coupon, mua hàng, nhiều account chung IP).</div>
  </div>
  <div class="flex gap-2">
    <a class="btn btn-ghost" href="<?= e(admin_url('risk',['days'=>7])) ?>">7d</a>
    <a class="btn btn-ghost" href="<?= e(admin_url('risk',['days'=>30])) ?>">30d</a>
  </div>
</div>

<div class="mt-6 grid lg:grid-cols-3 gap-4">
  <div class="card p-5">
    <div class="text-lg font-extrabold">Coupon Redeem theo IP (<?= (int)$days ?> ngày)</div>
    <div class="mt-4 overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="text-slate-400"><tr><th class="text-left px-3 py-2">IP</th><th class="text-right px-3 py-2">Count</th><th class="text-right px-3 py-2">Users</th></tr></thead>
        <tbody class="divide-y divide-white/5">
          <?php if(!$redeem): ?><tr><td colspan="3" class="px-3 py-4 text-slate-500">Chưa có dữ liệu.</td></tr>
          <?php else: foreach($redeem as $r): ?>
            <tr><td class="px-3 py-3"><?= e($r['ip']) ?></td><td class="px-3 py-3 text-right"><?= (int)$r['cnt'] ?></td><td class="px-3 py-3 text-right"><?= (int)$r['users'] ?></td></tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="card p-5">
    <div class="text-lg font-extrabold">Mua key theo IP (<?= (int)$days ?> ngày)</div>
    <div class="mt-4 overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="text-slate-400"><tr><th class="text-left px-3 py-2">IP</th><th class="text-right px-3 py-2">Orders</th><th class="text-right px-3 py-2">Users</th></tr></thead>
        <tbody class="divide-y divide-white/5">
          <?php if(!$orders): ?><tr><td colspan="3" class="px-3 py-4 text-slate-500">Chưa có dữ liệu.</td></tr>
          <?php else: foreach($orders as $r): ?>
            <tr><td class="px-3 py-3"><?= e($r['ip']) ?></td><td class="px-3 py-3 text-right"><?= (int)$r['cnt'] ?></td><td class="px-3 py-3 text-right"><?= (int)$r['users'] ?></td></tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="card p-5">
    <div class="text-lg font-extrabold">Nhiều account chung IP</div>
    <div class="mt-4 overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="text-slate-400"><tr><th class="text-left px-3 py-2">IP</th><th class="text-right px-3 py-2">Users</th></tr></thead>
        <tbody class="divide-y divide-white/5">
          <?php if(!$shared): ?><tr><td colspan="2" class="px-3 py-4 text-slate-500">Chưa có dữ liệu.</td></tr>
          <?php else: foreach($shared as $r): ?>
            <tr><td class="px-3 py-3"><?= e($r['ip']) ?></td><td class="px-3 py-3 text-right"><?= (int)$r['cnt'] ?></td></tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
