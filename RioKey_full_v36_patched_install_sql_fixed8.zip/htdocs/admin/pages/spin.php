<?php
require_staff();
if (!is_admin()) { http_response_code(403); echo 'Forbidden'; return; }
$flash=null; $err=null;
$aid = (int)((auth_user()['id'] ?? 0));

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_require();
  try{
    setting_set('spin_enabled', isset($_POST['spin_enabled']) ? '1' : '0');
    setting_set('spin_price_points', (string)(int)($_POST['spin_price_points'] ?? 50));
    audit_log($aid,'spin_settings','settings',null,[]);
    $flash='Đã lưu cài đặt vòng quay.';
  } catch(Throwable $e){ $err=$e->getMessage(); }
}
$en = (int)setting('spin_enabled',1)===1;
$price = (int)setting('spin_price_points',50);
?>
<div class="text-2xl font-extrabold">Vòng quay Settings</div>
<div class="text-sm text-slate-400 mt-1">Mỗi ngày 1 lượt miễn phí + lượt quay bằng điểm.</div>

<?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 card p-5 max-w-2xl">
  <form method="post" class="space-y-4" data-once="1">
    <?= csrf_field() ?>
    <label class="flex items-center gap-2 text-sm text-slate-200">
      <input type="checkbox" name="spin_enabled" <?= $en?'checked':'' ?>> Bật vòng quay
    </label>
    <div>
      <label class="text-sm text-slate-300">Giá mỗi lượt quay (điểm)</label>
      <input class="input mt-1" name="spin_price_points" value="<?= (int)$price ?>">
    </div>
    <button class="btn" type="submit">Lưu</button>
  </form>
</div>
