<?php
$flash = null; $err = null;

$hasRankName = db_has_column('users','rank_name');

if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_require();
  $action = $_POST['action'] ?? '';
  if ($action==='create') {
    $name=trim($_POST['name']??''); $email=strtolower(trim($_POST['email']??'')); $phone=trim($_POST['phone']??'');
    $pass=(string)($_POST['password']??''); $is_admin=(int)($_POST['is_admin']??0);
    $role = trim((string)($_POST['role'] ?? 'user'));
    $wallet_balance = isset($_POST['wallet_balance']) ? (float)$_POST['wallet_balance'] : 0;
    $points = isset($_POST['points']) ? (int)$_POST['points'] : 0;
    $vendor_fee_percent = trim((string)($_POST['vendor_fee_percent'] ?? ''));
    $vendor_payout_info = trim((string)($_POST['vendor_payout_info'] ?? ''));
    $vendor_active = (int)($_POST['vendor_active'] ?? 1) ? 1 : 0;
    if ($name===''||$email===''||$pass==='') $err='Thiếu dữ liệu.';
    elseif (!filter_var($email,FILTER_VALIDATE_EMAIL)) $err='Email không hợp lệ.';
    elseif (strlen($pass)<6) $err='Mật khẩu tối thiểu 6 ký tự.';
    else {
      try{
        $hash=password_hash($pass,PASSWORD_DEFAULT);
        $ref=substr(bin2hex(random_bytes(6)),0,10);
        db()->prepare("INSERT INTO users (name,email,password_hash,phone,ref_code,is_admin) VALUES (?,?,?,?,?,?)")
          ->execute([$name,$email,$hash,$phone,$ref,$is_admin]);
        $newId = (int)db()->lastInsertId();
        try { db()->prepare("UPDATE users SET role=? WHERE id=?")->execute([$role,$newId]); } catch(Throwable $e) {}
        try { if ($points !== 0) points_add($newId, $points, 'admin_set', 'admin:create:'.$newId.':'.time(), 'Admin set initial points'); } catch(Throwable $e) {}
        try { if (abs($wallet_balance) > 0.00001) wallet_apply($newId, 'admin_adjust', $wallet_balance, 'users', $newId, 'Admin set initial balance'); } catch(Throwable $e) {}
        try {
          if (db_has_column('users','vendor_fee_percent')) {
            $vfp = $vendor_fee_percent!=='' ? (float)str_replace(',','.', $vendor_fee_percent) : null;
            $vp = $vendor_payout_info!=='' ? $vendor_payout_info : null;
            db()->prepare("UPDATE users SET vendor_fee_percent=?, vendor_payout_info=?, vendor_active=? WHERE id=?")
              ->execute([$vfp,$vp,$vendor_active,$newId]);
          }
        } catch(Throwable $e) {}

        $flash='Đã tạo user.';
      }catch(Throwable $e){ $err='Không tạo được (email có thể đã tồn tại).'; }
    }
  }
  if ($action==='update' && !$err) {
    $id=(int)($_POST['id']??0);
    $name=trim($_POST['name']??''); $phone=trim($_POST['phone']??''); $rank=trim($_POST['rank_name']??'ĐỒNG');
    $is_admin=(int)($_POST['is_admin']??0);
    $role = trim((string)($_POST['role'] ?? 'user'));
    $vendor_fee_percent = trim((string)($_POST['vendor_fee_percent'] ?? ''));
    $vendor_payout_info = trim((string)($_POST['vendor_payout_info'] ?? ''));
    $vendor_active = (int)($_POST['vendor_active'] ?? 1) ? 1 : 0;
    $set_balance = isset($_POST['wallet_balance']) ? (float)$_POST['wallet_balance'] : null;
    $set_points = isset($_POST['points']) ? (int)$_POST['points'] : null;
    if ($hasRankName) {
      db()->prepare("UPDATE users SET name=?, phone=?, rank_name=?, is_admin=?, role=? WHERE id=?")
        ->execute([$name,$phone,$rank,$is_admin,$role,$id]);
    } else {
      db()->prepare("UPDATE users SET name=?, phone=?, is_admin=?, role=? WHERE id=?")
        ->execute([$name,$phone,$is_admin,$role,$id]);
    }
    // Vendor fields (optional)
    try{
      if (db_has_column('users','vendor_fee_percent')) {
        $vfp = $vendor_fee_percent!=='' ? (float)str_replace(',','.', $vendor_fee_percent) : null;
        $vp = $vendor_payout_info!=='' ? $vendor_payout_info : null;
        db()->prepare("UPDATE users SET vendor_fee_percent=?, vendor_payout_info=?, vendor_active=? WHERE id=?")
          ->execute([$vfp,$vp,$vendor_active,$id]);
      }
    }catch(Throwable $e){}

    if (!empty($_POST['password'])) {
      $pass=(string)$_POST['password'];
      if (strlen($pass)>=6) {
        $hash=password_hash($pass,PASSWORD_DEFAULT);
        db()->prepare("UPDATE users SET password_hash=? WHERE id=?")->execute([$hash,$id]);
      }
    }
    $flash='Đã cập nhật user.';

    // Admin chỉnh số dư ví & điểm (có ghi ledger)
    if ($set_balance !== null) {
      try {
        $w = wallet_get($id);
        $cur = (float)($w['balance'] ?? 0);
        $diff = (float)$set_balance - $cur;
        if (abs($diff) > 0.00001) {
          wallet_apply($id, 'admin_adjust', $diff, 'users', $id, 'Admin set balance');
        }
      } catch(Throwable $e) {}
    }
    if ($set_points !== null) {
      try {
        $curp = points_balance($id);
        $diffp = (int)$set_points - (int)$curp;
        if ($diffp !== 0) {
          points_add($id, $diffp, 'admin_adjust', 'admin:set:'.$id.':'.time(), 'Admin set points');
        }
      } catch(Throwable $e) {}
    }

  }
  if ($action==='delete' && !$err) {
    $id=(int)($_POST['id']??0);
    db()->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
    $flash='Đã xoá user.';
  }
}

$users = db()->query("SELECT * FROM users ORDER BY id DESC LIMIT 200")->fetchAll();
?>
<div class="flex items-center justify-between gap-4">
  <div>
    <h1 class="text-2xl font-black">Quản lý User</h1>
    <p class="text-slate-400 mt-1">Xem / thêm / sửa / xoá người dùng</p>
  </div>
</div>

<?php if ($err): ?><div class="mt-4 rounded-2xl border border-rose-500/30 bg-rose-500/10 p-4 text-rose-200 text-sm"><?= e($err) ?></div><?php endif; ?>
<?php if ($flash): ?><div class="mt-4 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-4 text-emerald-200 text-sm"><?= e($flash) ?></div><?php endif; ?>

<div class="grid lg:grid-cols-3 gap-6 mt-6">
  <div class="card p-5">
    <div class="font-extrabold flex items-center gap-2"><?= lucide_icon('user-plus','w-5 h-5 text-orange-300') ?> Thêm user</div>
    <form class="mt-4 space-y-3" method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="create">
      <input class="input" name="name" placeholder="Họ tên" required>
      <input class="input" type="email" name="email" placeholder="Email" required>
      <input class="input" name="wallet_balance" type="number" step="0.01" placeholder="Số dư ví" value="0">
          <input class="input" name="points" type="number" step="1" placeholder="Điểm" value="0">
          <select class="input" name="role">
            <?php $r = 'user'; ?>
            <option value="user" <?= $r==='user'?'selected':'' ?>>user</option>
            <option value="mod" <?= $r==='mod'?'selected':'' ?>>mod</option>
            <option value="admin" <?= $r==='admin'?'selected':'' ?>>admin</option>
            <option value="vendor" <?= $r==='vendor'?'selected':'' ?>>vendor</option>
          </select>
          <input class="input" name="vendor_fee_percent" type="number" step="0.01" placeholder="CTV fee % (optional)">
          <select class="input" name="vendor_active">
            <option value="1" selected>CTV active</option>
            <option value="0">CTV disabled</option>
          </select>
          <textarea class="input" name="vendor_payout_info" rows="2" placeholder="CTV payout info (optional)"></textarea>
          <input class="input" name="phone" placeholder="Phone">
      <input class="input" type="password" name="password" placeholder="Mật khẩu (>=6)" required>
      <label class="flex items-center gap-2 text-sm text-slate-300">
        <input type="checkbox" class="accent-orange-500" name="is_admin" value="1"> Admin
      </label>
      <button class="btn btn-primary w-full">Tạo</button>
    </form>
  </div>

  <div class="lg:col-span-2 card p-0 overflow-hidden">
    <div class="p-5 border-b border-slate-800/60 flex items-center justify-between">
      <div class="font-extrabold flex items-center gap-2"><?= lucide_icon('users','w-5 h-5 text-orange-300') ?> Danh sách</div>
      <div class="text-xs text-slate-500"><?= count($users) ?> users</div>
    </div>
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <thead class="text-slate-400">
          <tr class="border-b border-slate-800/60">
            <th class="text-left p-4">ID</th>
            <th class="text-left p-4">Tên</th>
            <th class="text-left p-4">Email</th>
            <th class="text-left p-4">Phone</th>
            <th class="text-left p-4">Rank</th>
            <th class="text-left p-4">Role</th>
            <th class="text-right p-4">Hành động</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach($users as $u): ?>
          <tr class="border-b border-slate-800/40 hover:bg-slate-900/40">
            <td class="p-4 text-slate-400">#<?= (int)$u['id'] ?></td>
            <td class="p-4 font-semibold"><?= e($u['name']) ?></td>
            <td class="p-4 text-slate-300"><?= e($u['email']) ?></td>
            <td class="p-4 text-slate-300"><?= e($u['phone']) ?></td>
            <td class="p-4 text-slate-300"><?= $hasRankName ? e($u['rank_name'] ?? '-') : '-' ?></td>
            <td class="p-4">
              <?php if ((int)$u['is_admin']===1): ?>
                <span class="badge badge-warn">Admin</span>
              <?php else: ?>
                <span class="badge">User</span>
              <?php endif; ?>
            </td>
            <td class="p-4 text-right">
              <button class="btn btn-ghost !px-3 !py-2" 
                onclick="document.getElementById('edit-<?= (int)$u['id'] ?>').showModal()">
                <?= lucide_icon('pencil','w-4 h-4') ?>
              </button>
              <form class="inline" method="post" onsubmit="return confirm('Xoá user này?')">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
                <button class="btn btn-ghost !px-3 !py-2 text-rose-200">
                  <?= lucide_icon('trash-2','w-4 h-4') ?>
                </button>
              </form>

              <dialog id="edit-<?= (int)$u['id'] ?>" class="rounded-3xl bg-slate-950 border border-slate-800/70 text-slate-100 p-0 w-[min(720px,95vw)]">
                <div class="p-5 border-b border-slate-800/60 flex items-center justify-between">
                  <div class="font-extrabold">Sửa #<?= (int)$u['id'] ?></div>
                  <button class="btn btn-ghost !px-3 !py-2" onclick="this.closest('dialog').close()"><?= lucide_icon('x','w-5 h-5') ?></button>
                </div>
                <form method="post" class="p-5 space-y-3">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="update">
                  <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
                  <div class="grid sm:grid-cols-2 gap-3">
                    <div>
                      <label class="text-sm text-slate-300">Họ tên</label>
                      <input class="input mt-2" name="name" value="<?= e($u['name']) ?>">
                    </div>
                    <div>
                      <label class="text-sm text-slate-300">Phone</label>
                      <input class="input mt-2" name="phone" value="<?= e($u['phone']) ?>">
                    </div>
                    <div>
                      <label class="text-sm text-slate-300">Role</label>
                      <?php $r = (string)($u['role'] ?? 'user'); ?>
                      <select class="input mt-2" name="role">
                        <option value="user" <?= $r==='user'?'selected':'' ?>>user</option>
                        <option value="mod" <?= $r==='mod'?'selected':'' ?>>mod</option>
                        <option value="admin" <?= $r==='admin'?'selected':'' ?>>admin</option>
                        <option value="vendor" <?= $r==='vendor'?'selected':'' ?>>vendor</option>
                      </select>
                    </div>
                    <div>
                      <label class="text-sm text-slate-300">Số dư ví (VNĐ)</label>
                      <?php $wb = 0; try { $w = wallet_get((int)$u['id']); $wb = (float)($w['balance'] ?? 0); } catch(Throwable $e) { $wb = 0; } ?>
                      <input class="input mt-2" name="wallet_balance" type="number" step="0.01" value="<?= e((string)$wb) ?>">
                    </div>
                    <div>
                      <label class="text-sm text-slate-300">Điểm</label>
                      <input class="input mt-2" name="points" type="number" step="1" value="<?= (int)($u['points'] ?? 0) ?>">
                    </div>
                    <div>
                      <label class="text-sm text-slate-300">CTV fee % (optional)</label>
                      <input class="input mt-2" name="vendor_fee_percent" type="number" step="0.01" value="<?= e((string)($u['vendor_fee_percent'] ?? '')) ?>" placeholder="vd 10">
                    </div>
                    <div>
                      <label class="text-sm text-slate-300">CTV active</label>
                      <?php $va = (int)($u['vendor_active'] ?? 1); ?>
                      <select class="input mt-2" name="vendor_active">
                        <option value="1" <?= $va===1?'selected':'' ?>>active</option>
                        <option value="0" <?= $va===0?'selected':'' ?>>disabled</option>
                      </select>
                    </div>
                    <div class="sm:col-span-2">
                      <label class="text-sm text-slate-300">CTV payout info</label>
                      <textarea class="input mt-2" name="vendor_payout_info" rows="2"><?= e((string)($u['vendor_payout_info'] ?? '')) ?></textarea>
                    </div>

                    <?php if ($hasRankName): ?>
                    <div>
                      <label class="text-sm text-slate-300">Rank</label>
                      <input class="input mt-2" name="rank_name" value="<?= e($u['rank_name'] ?? 'ĐỒNG') ?>">
                    </div>
                    <?php endif; ?>
                    <div>
                      <label class="text-sm text-slate-300">Mật khẩu mới (để trống nếu không đổi)</label>
                      <input class="input mt-2" type="password" name="password" placeholder="******">
                    </div>
                  </div>
                  <label class="flex items-center gap-2 text-sm text-slate-300">
                    <input type="checkbox" class="accent-orange-500" name="is_admin" value="1" <?= (int)$u['is_admin']===1?'checked':'' ?>>
                    Admin
                  </label>
                  <div class="flex justify-end gap-2 pt-2">
                    <button type="button" class="btn btn-ghost" onclick="this.closest('dialog').close()">Hủy</button>
                    <button class="btn btn-primary">Lưu</button>
                  </div>
                </form>
              </dialog>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
