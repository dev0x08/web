<?php
$pdo=db();
$kpi = [
  'users' => (int)($pdo->query("SELECT COUNT(*) c FROM users")->fetch()['c'] ?? 0),
  'orders_total' => (int)($pdo->query("SELECT COUNT(*) c FROM orders")->fetch()['c'] ?? 0),
  'orders_approved' => (int)($pdo->query("SELECT COUNT(*) c FROM orders WHERE status='approved'")->fetch()['c'] ?? 0),
  'points_tx' => (int)($pdo->query("SELECT COUNT(*) c FROM point_transactions")->fetch()['c'] ?? 0),
  'redeem_pending' => (int)($pdo->query("SELECT COUNT(*) c FROM reward_redemptions WHERE status='pending'")->fetch()['c'] ?? 0),
  'notif_total' => (int)($pdo->query("SELECT COUNT(*) c FROM notifications")->fetch()['c'] ?? 0),
];
$topPoints = $pdo->query("SELECT id, username, name, points FROM users ORDER BY points DESC LIMIT 8")->fetchAll() ?: [];
$topOrders = $pdo->query("SELECT u.username, u.name, COUNT(o.id) c
                          FROM users u JOIN orders o ON o.user_id=u.id
                          WHERE o.status='approved'
                          GROUP BY u.id ORDER BY c DESC LIMIT 8")->fetchAll() ?: [];
?>
<div class="max-w-6xl">
  <div class="text-2xl font-extrabold">Báo cáo</div>
  <div class="text-sm text-slate-400 mt-1">Tổng quan hệ thống • KPI • Top users</div>

  <div class="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
    <?php foreach([
      ['Users','users','users'],
      ['Orders (tổng)','orders_total','package'],
      ['Orders approved','orders_approved','check-circle'],
      ['Giao dịch điểm','points_tx','coins'],
      ['Đổi quà chờ duyệt','redeem_pending','clipboard-list'],
      ['Thông báo đã tạo','notif_total','bell'],
    ] as $it): ?>
      <div class="card p-5">
        <div class="flex items-center gap-3">
          <div class="w-11 h-11 rounded-2xl bg-white/5 border border-white/10 grid place-items-center">
            <?= lucide_icon($it[2],'w-5 h-5') ?>
          </div>
          <div>
            <div class="text-xs text-slate-400"><?= e($it[0]) ?></div>
            <div class="text-2xl font-extrabold"><?= (int)$kpi[$it[1]] ?></div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <div class="mt-6 grid lg:grid-cols-2 gap-4">
    <div class="card p-6">
      <div class="text-lg font-extrabold">Top điểm</div>
      <div class="mt-4 space-y-2">
        <?php foreach($topPoints as $i=>$u): ?>
          <div class="flex items-center justify-between gap-3 p-3 rounded-2xl bg-black/25 border border-white/10">
            <div class="min-w-0">
              <div class="font-bold truncate"><?= e($u['name'] ?: $u['username']) ?></div>
              <div class="text-xs text-slate-500">@<?= e($u['username']) ?></div>
            </div>
            <div class="text-sm font-extrabold"><?= (int)$u['points'] ?> điểm</div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="card p-6">
      <div class="text-lg font-extrabold">Top đơn approved (tổng)</div>
      <div class="mt-4 space-y-2">
        <?php foreach($topOrders as $i=>$u): ?>
          <div class="flex items-center justify-between gap-3 p-3 rounded-2xl bg-black/25 border border-white/10">
            <div class="min-w-0">
              <div class="font-bold truncate"><?= e($u['name'] ?: $u['username']) ?></div>
              <div class="text-xs text-slate-500">@<?= e($u['username']) ?></div>
            </div>
            <div class="text-sm font-extrabold"><?= (int)$u['c'] ?> đơn</div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <div class="mt-6 card p-6">
    <div class="text-lg font-extrabold">Xuất dữ liệu</div>
    <div class="text-sm text-slate-400 mt-1">CSV export để lọc/đối soát</div>
    <div class="mt-4 flex flex-wrap gap-2">
      <a class="btn" href="<?= e(base_url('/admin/export.php?type=users')) ?>">Users.csv</a>
      <a class="btn" href="<?= e(base_url('/admin/export.php?type=orders')) ?>">Orders.csv</a>
      <a class="btn" href="<?= e(base_url('/admin/export.php?type=points')) ?>">Points.csv</a>
      <a class="btn" href="<?= e(base_url('/admin/export.php?type=redemptions')) ?>">Redemptions.csv</a>
      <a class="btn" href="<?= e(base_url('/admin/export.php?type=audit')) ?>">Audit.csv</a>
    </div>
  </div>
</div>
