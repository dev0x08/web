<?php
$flash=null; $err=null;

$hasActive = db_has_column('contacts','is_active');

if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_require();
  $action=$_POST['action']??'';
  if ($action==='create') {
    $title=trim($_POST['title']??''); $email=trim($_POST['email']??''); $phone=trim($_POST['phone']??''); $active=(int)($_POST['is_active']??1);
    if($title==='') $err='Thiếu title.';
    else {
      if ($hasActive) {
        db()->prepare("INSERT INTO contacts (title,email,phone,is_active) VALUES (?,?,?,?)")->execute([$title,$email,$phone,$active]);
      } else {
        db()->prepare("INSERT INTO contacts (title,email,phone) VALUES (?,?,?)")->execute([$title,$email,$phone]);
      }
      $flash='Đã thêm contact.';
    }
  }
  if ($action==='update' && !$err) {
    $id=(int)($_POST['id']??0);
    $title=trim($_POST['title']??''); $email=trim($_POST['email']??''); $phone=trim($_POST['phone']??''); $active=(int)($_POST['is_active']??0);
    if ($hasActive) {
      db()->prepare("UPDATE contacts SET title=?,email=?,phone=?,is_active=? WHERE id=?")->execute([$title,$email,$phone,$active,$id]);
    } else {
      db()->prepare("UPDATE contacts SET title=?,email=?,phone=? WHERE id=?")->execute([$title,$email,$phone,$id]);
    }
    $flash='Đã cập nhật contact.';
  }
  if ($action==='delete' && !$err) {
    $id=(int)($_POST['id']??0);
    db()->prepare("DELETE FROM contacts WHERE id=?")->execute([$id]);
    $flash='Đã xoá contact.';
  }
}

$rows = db()->query("SELECT * FROM contacts ORDER BY id DESC")->fetchAll();
?>
<h1 class="text-2xl font-black">Quản lý Contact</h1>
<p class="text-slate-400 mt-1">Quản lý title / email / phone hiển thị ở trang trợ giúp</p>

<?php if($err): ?><div class="mt-4 rounded-2xl border border-rose-500/30 bg-rose-500/10 p-4 text-rose-200 text-sm"><?= e($err) ?></div><?php endif; ?>
<?php if($flash): ?><div class="mt-4 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-4 text-emerald-200 text-sm"><?= e($flash) ?></div><?php endif; ?>

<div class="grid lg:grid-cols-3 gap-6 mt-6">
  <div class="card p-5">
    <div class="font-extrabold flex items-center gap-2"><?= lucide_icon('mail-plus','w-5 h-5 text-orange-300') ?> Thêm contact</div>
    <form class="mt-4 space-y-3" method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="create">
      <input class="input" name="title" placeholder="Title (VD: Email)" required>
      <input class="input" name="email" placeholder="Email (tuỳ chọn)">
      <input class="input" name="phone" placeholder="Phone (tuỳ chọn)">
      <?php if ($hasActive): ?>
      <label class="flex items-center gap-2 text-sm text-slate-300">
        <input type="checkbox" class="accent-orange-500" name="is_active" value="1" checked> Active
      </label>
      <?php endif; ?>
      <button class="btn btn-primary w-full">Thêm</button>
    </form>
  </div>

  <div class="lg:col-span-2 card p-0 overflow-hidden">
    <div class="p-5 border-b border-slate-800/60 font-extrabold flex items-center gap-2"><?= lucide_icon('contacts','w-5 h-5 text-orange-300') ?> Danh sách</div>
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <thead class="text-slate-400">
          <tr class="border-b border-slate-800/60">
            <th class="text-left p-4">Title</th>
            <th class="text-left p-4">Email</th>
            <th class="text-left p-4">Phone</th>
          <?php if($hasActive): ?><th class="text-left p-4">Active</th><?php endif; ?>
            <th class="text-right p-4">Hành động</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach($rows as $c): ?>
          <tr class="border-b border-slate-800/40 hover:bg-slate-900/40">
            <td class="p-4 font-semibold"><?= e($c['title']) ?></td>
            <td class="p-4 text-slate-300"><?= e($c['email']) ?></td>
            <td class="p-4 text-slate-300"><?= e($c['phone']) ?></td>
            <?php if($hasActive): ?>
              <td class="p-4"><?= (int)($c['is_active']??0)===1 ? '<span class="badge badge-ok">ON</span>' : '<span class="badge">OFF</span>' ?></td>
            <?php endif; ?>
            <td class="p-4 text-right">
              <button class="btn btn-ghost !px-3 !py-2" onclick="document.getElementById('cedit-<?= (int)$c['id'] ?>').showModal()"><?= lucide_icon('pencil','w-4 h-4') ?></button>
              <form class="inline" method="post" onsubmit="return confirm('Xoá contact này?')">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                <button class="btn btn-ghost !px-3 !py-2 text-rose-200"><?= lucide_icon('trash-2','w-4 h-4') ?></button>
              </form>

              <dialog id="cedit-<?= (int)$c['id'] ?>" class="rounded-3xl bg-slate-950 border border-slate-800/70 text-slate-100 p-0 w-[min(720px,95vw)]">
                <div class="p-5 border-b border-slate-800/60 flex items-center justify-between">
                  <div class="font-extrabold">Sửa contact</div>
                  <button class="btn btn-ghost !px-3 !py-2" onclick="this.closest('dialog').close()"><?= lucide_icon('x','w-5 h-5') ?></button>
                </div>
                <form method="post" class="p-5 space-y-3">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="update">
                  <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                  <input class="input" name="title" value="<?= e($c['title']) ?>" required>
                  <input class="input" name="email" value="<?= e($c['email']) ?>">
                  <input class="input" name="phone" value="<?= e($c['phone']) ?>">
                  <?php if ($hasActive): ?>
                  <label class="flex items-center gap-2 text-sm text-slate-300">
                    <input type="checkbox" class="accent-orange-500" name="is_active" value="1" <?= (int)($c['is_active']??0)===1?'checked':'' ?>> Active
                  </label>
                  <?php endif; ?>
                  <div class="flex justify-end gap-2 pt-2">
                    <button type="button" class="btn btn-ghost" onclick="this.closest('dialog').close()">Hủy</button>
                    <button class="btn btn-primary">Lưu</button>
                  </div>
                </form>
              </dialog>

            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
