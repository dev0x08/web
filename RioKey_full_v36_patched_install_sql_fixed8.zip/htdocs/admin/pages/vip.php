<?php
require_staff();
if (!is_admin()) { http_response_code(403); echo 'Forbidden'; return; }
vip_ensure_schema();

$flash=null; $err=null;
$aid = (int)((auth_user()['id'] ?? 0));

$edit_id = (int)($_GET['edit'] ?? 0);
$edit = null;
if ($edit_id>0){
  $st=db()->prepare("SELECT * FROM vip_plans WHERE id=? LIMIT 1");
  $st->execute([$edit_id]);
  $edit = $st->fetch(PDO::FETCH_ASSOC) ?: null;
}

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_require();
  $action = $_POST['action'] ?? '';

  try{
    if($action==='save'){
      $id = (int)($_POST['id'] ?? 0);
      $title = trim((string)($_POST['title'] ?? ''));
      $price = (int)($_POST['price_vnd'] ?? 0);
      $days = (int)($_POST['duration_days'] ?? 30);
      $disc = (int)($_POST['discount_pct'] ?? 0);
      $bonus = (int)($_POST['points_bonus_pct'] ?? 0);
      $on = isset($_POST['is_active']) ? 1 : 0;

      if($title==='') throw new Exception('Tiêu đề không được trống');
      if($price<=0) throw new Exception('Giá phải > 0');
      if($days<=0) throw new Exception('Số ngày phải > 0');
      $disc = max(0,min(80,$disc));
      $bonus = max(0,min(300,$bonus));

      if($id>0){
        db()->prepare("UPDATE vip_plans SET title=?,price_vnd=?,duration_days=?,discount_pct=?,points_bonus_pct=?,is_active=? WHERE id=?")
          ->execute([$title,$price,$days,$disc,$bonus,$on,$id]);
        audit_log($aid,'vip_plan_update','vip_plans',(string)$id,['title'=>$title]);
        redirect(admin_url('vip',['edit'=>$id]));
      } else {
        db()->prepare("INSERT INTO vip_plans(title,price_vnd,duration_days,discount_pct,points_bonus_pct,is_active,created_at) VALUES(?,?,?,?,?,?,NOW())")
          ->execute([$title,$price,$days,$disc,$bonus,$on]);
        $id = (int)db()->lastInsertId();
        audit_log($aid,'vip_plan_create','vip_plans',(string)$id,['title'=>$title]);
        redirect(admin_url('vip',['edit'=>$id]));
      }
    }
    if($action==='delete'){
      $id=(int)($_POST['id'] ?? 0);
      if($id<=0) throw new Exception('ID không hợp lệ');
      db()->prepare("DELETE FROM vip_plans WHERE id=?")->execute([$id]);
      audit_log($aid,'vip_plan_delete','vip_plans',(string)$id,[]);
      redirect(admin_url('vip'));
    }
  } catch(Throwable $e){
    $err = $e->getMessage();
  }
}

$plans = db()->query("SELECT * FROM vip_plans ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
?>
<div class="flex items-start justify-between gap-4">
  <div>
    <div class="text-2xl font-extrabold">VIP Plans</div>
    <div class="text-sm text-slate-400 mt-1">Tạo gói VIP: giảm giá % và cộng thêm % điểm khi mua hàng.</div>
  </div>
</div>

<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 grid lg:grid-cols-3 gap-4">
  <div class="card p-5">
    <div class="font-extrabold text-lg"><?= $edit ? 'Sửa gói' : 'Tạo gói' ?></div>
    <form method="post" class="mt-4 space-y-3" data-once="1">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
      <input class="input" name="title" placeholder="Tên gói" value="<?= e($edit['title'] ?? '') ?>">
      <input class="input" type="number" name="price_vnd" placeholder="Giá (VNĐ)" value="<?= (int)($edit['price_vnd'] ?? 99000) ?>">
      <input class="input" type="number" name="duration_days" placeholder="Thời hạn (ngày)" value="<?= (int)($edit['duration_days'] ?? 30) ?>">
      <div class="grid grid-cols-2 gap-3">
        <input class="input" type="number" name="discount_pct" placeholder="Giảm giá (%)" value="<?= (int)($edit['discount_pct'] ?? 5) ?>">
        <input class="input" type="number" name="points_bonus_pct" placeholder="Bonus điểm (%)" value="<?= (int)($edit['points_bonus_pct'] ?? 20) ?>">
      </div>
      <label class="flex items-center gap-2 text-sm text-slate-200">
        <input type="checkbox" name="is_active" <?= ((int)($edit['is_active'] ?? 1)===1)?'checked':'' ?>> Kích hoạt
      </label>
      <button class="btn w-full" type="submit"><?= $edit ? 'Lưu' : 'Tạo gói' ?></button>
    </form>

    <?php if($edit): ?>
      <form method="post" class="mt-3" data-once="1" onsubmit="return confirm('Xoá gói VIP này?');">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
        <button class="btn btn-ghost w-full" type="submit">Xoá</button>
      </form>
    <?php endif; ?>
  </div>

  <div class="card p-5 lg:col-span-2">
    <div class="font-extrabold text-lg">Danh sách gói</div>
    <div class="mt-4 overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="text-slate-400">
          <tr>
            <th class="text-left font-semibold px-3 py-2">ID</th>
            <th class="text-left font-semibold px-3 py-2">Gói</th>
            <th class="text-left font-semibold px-3 py-2">Giá</th>
            <th class="text-left font-semibold px-3 py-2">Hạn</th>
            <th class="text-left font-semibold px-3 py-2">Giảm</th>
            <th class="text-left font-semibold px-3 py-2">Bonus điểm</th>
            <th class="text-left font-semibold px-3 py-2">Trạng thái</th>
            <th class="text-right font-semibold px-3 py-2"></th>
          </tr>
        </thead>
        <tbody class="divide-y divide-white/5">
          <?php if(!$plans): ?><tr><td colspan="8" class="px-3 py-4 text-slate-500">Chưa có gói.</td></tr><?php endif; ?>
          <?php foreach($plans as $p): ?>
            <tr>
              <td class="px-3 py-3"><?= (int)$p['id'] ?></td>
              <td class="px-3 py-3 font-extrabold"><?= e($p['title']) ?></td>
              <td class="px-3 py-3"><?= format_vnd((int)$p['price_vnd']) ?></td>
              <td class="px-3 py-3"><?= (int)$p['duration_days'] ?> ngày</td>
              <td class="px-3 py-3">-<?= (int)$p['discount_pct'] ?>%</td>
              <td class="px-3 py-3">+<?= (int)$p['points_bonus_pct'] ?>%</td>
              <td class="px-3 py-3"><?= ((int)$p['is_active']===1) ? '<span class="text-emerald-200">ON</span>' : '<span class="text-rose-200">OFF</span>' ?></td>
              <td class="px-3 py-3 text-right"><a class="btn btn-ghost" href="<?= e(admin_url('vip',['edit'=>$p['id']])) ?>">Sửa</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
