<?php
$rows = db()->query("SELECT l.*, u.username FROM admin_audit_logs l LEFT JOIN users u ON u.id=l.admin_id ORDER BY l.id DESC LIMIT 200")->fetchAll() ?: [];
?>
<div class="max-w-6xl">
  <div class="text-2xl font-extrabold">Audit log</div>
  <div class="text-sm text-slate-400 mt-1">Theo dõi admin đã làm gì • phục vụ debug & chống gian lận</div>

  <div class="mt-6 space-y-3">
    <?php if(!$rows): ?>
      <div class="text-slate-400">Chưa có log.</div>
    <?php else: foreach($rows as $r): ?>
      <div class="card p-5">
        <div class="flex items-start justify-between gap-3">
          <div class="min-w-0">
            <div class="font-extrabold truncate"><?= e($r['action']) ?></div>
            <div class="text-sm text-slate-300 mt-1">
              Admin: <b><?= e($r['username'] ?? ('#'.$r['admin_id'])) ?></b>
              • Target: <b><?= e($r['target_type']) ?></b> <?= e((string)$r['target_id']) ?>
            </div>
            <div class="text-xs text-slate-500 mt-2">
              IP: <?= e($r['ip']) ?> • <?= e($r['created_at']) ?>
            </div>
            <?php if(!empty($r['meta_json'])): ?>
              <pre class="mt-3 text-xs text-slate-400 whitespace-pre-wrap"><?= e($r['meta_json']) ?></pre>
            <?php endif; ?>
          </div>
          <div class="opacity-70"><?= lucide_icon('shield-check') ?></div>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>
