<?php
admin_require();
csrf_require();
reviews_ensure_schema();
shop_ensure_schema();

$tab = $_GET['tab'] ?? 'pending';
$allow = ['pending','approved','hidden'];
if(!in_array($tab,$allow,true)) $tab='pending';

$flash=null; $err=null;

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  $action = $_POST['action'] ?? '';
  $id = (int)($_POST['id'] ?? 0);
  try {
    if($id<=0) throw new Exception('Thiếu ID.');
    if($action==='approve') admin_review_set_status($id,'approved');
    elseif($action==='hide') admin_review_set_status($id,'hidden');
    elseif($action==='pending') admin_review_set_status($id,'pending');
    elseif($action==='delete') db()->prepare("DELETE FROM product_reviews WHERE id=?")->execute([$id]);
    $flash='Đã cập nhật.';
  } catch(Throwable $e){ $err=$e->getMessage(); }
}

$items = admin_review_list($tab, 300);
?>
<div class="flex items-start justify-between gap-4">
  <div>
    <div class="text-2xl font-extrabold">Reviews</div>
    <div class="text-sm text-slate-400 mt-1">Duyệt/ẩn đánh giá sản phẩm.</div>
  </div>
</div>

<?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 flex gap-2">
  <?php foreach(['pending'=>'Chờ duyệt','approved'=>'Đã duyệt','hidden'=>'Đã ẩn'] as $k=>$label): ?>
    <a class="px-4 py-2 rounded-2xl border <?= $tab===$k?'border-orange-500/40 bg-orange-500/10 text-orange-200':'border-white/10 bg-white/5 text-slate-200/80 hover:bg-white/10' ?>"
      href="<?= e(route_url('admin_reviews',['tab'=>$k])) ?>"><?= e($label) ?></a>
  <?php endforeach; ?>
</div>

<div class="mt-4 card p-0 overflow-hidden">
  <div class="overflow-x-auto">
    <table class="table w-full">
      <thead>
        <tr>
          <th>ID</th>
          <th>Sản phẩm</th>
          <th>User</th>
          <th>Sao</th>
          <th>Nội dung</th>
          <th>Ngày</th>
          <th class="text-right">Thao tác</th>
        </tr>
      </thead>
      <tbody>
        <?php if(!$items): ?>
          <tr><td colspan="7" class="p-6 text-slate-500">Không có dữ liệu.</td></tr>
        <?php else: foreach($items as $r): ?>
          <tr>
            <td class="p-3">#<?= (int)$r['id'] ?></td>
            <td class="p-3">
              <div class="font-extrabold"><?= e($r['product_title'] ?? '') ?></div>
              <div class="text-xs text-slate-500">PID: <?= (int)$r['product_id'] ?></div>
            </td>
            <td class="p-3"><?= e($r['username'] ?? '') ?></td>
            <td class="p-3"><?= review_star_row((int)$r['rating']) ?></td>
            <td class="p-3 max-w-[420px]"><?= e((string)($r['content'] ?? '')) ?></td>
            <td class="p-3 text-xs text-slate-500"><?= e($r['created_at'] ?? '') ?></td>
            <td class="p-3 text-right">
              <div class="flex justify-end gap-2">
                <form method="post" data-once="1">
                  <?= csrf_field() ?>
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <input type="hidden" name="action" value="approve">
                  <button class="btn btn-ghost" type="submit">Duyệt</button>
                </form>
                <form method="post" data-once="1">
                  <?= csrf_field() ?>
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <input type="hidden" name="action" value="hide">
                  <button class="btn btn-ghost" type="submit">Ẩn</button>
                </form>
                <form method="post" data-once="1" onsubmit="return confirm('Xoá review?');">
                  <?= csrf_field() ?>
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <input type="hidden" name="action" value="delete">
                  <button class="btn btn-danger" type="submit">Xoá</button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
