<?php
$flash=null;
if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_require();

  // Feature toggles
  setting_set('captcha_enabled', isset($_POST['captcha_enabled']));
  setting_set('captcha_login_enabled', isset($_POST['captcha_login_enabled']));
  setting_set('popup_enabled', isset($_POST['popup_enabled']));
  setting_set('wishlist_enabled', isset($_POST['wishlist_enabled']));
  setting_set('lootbox_enabled', isset($_POST['lootbox_enabled']));
  setting_set('spin_enabled', isset($_POST['spin_enabled']));
  setting_set('vip_enabled', isset($_POST['vip_enabled']));
  setting_set('gifts_enabled', isset($_POST['gifts_enabled']));
  setting_set('community_enabled', isset($_POST['community_enabled']));
  setting_set('app_enabled', isset($_POST['app_enabled']));
  setting_set('vault_required', isset($_POST['vault_required']));

  // Google login
  setting_set('google_login_enabled', isset($_POST['google_login_enabled']));
  setting_set('google_client_id', trim((string)($_POST['google_client_id'] ?? '')));
  setting_set('google_client_secret', trim((string)($_POST['google_client_secret'] ?? '')));

  $flash = 'Đã lưu cài đặt.';
}

$google_on = (int)setting('google_login_enabled',0)===1;
$google_client_id = (string)setting('google_client_id','');
$google_client_secret = (string)setting('google_client_secret','');

$features = [
  ['key'=>'captcha_enabled','label'=>'Chống spam (Captcha tổng)','hint'=>'Bật captcha cho các hành vi nghi vấn.'],
  ['key'=>'captcha_login_enabled','label'=>'Captcha khi đăng nhập','hint'=>'Bật captcha riêng cho form login.'],
  ['key'=>'popup_enabled','label'=>'Popup hệ thống','hint'=>'Cho phép hiển thị popup/confirm đẹp thay cho popup mặc định.'],
  ['key'=>'wishlist_enabled','label'=>'Wishlist','hint'=>'Cho phép user lưu sản phẩm yêu thích.'],
  ['key'=>'lootbox_enabled','label'=>'Lootbox','hint'=>'Mở hộp nhận key ngẫu nhiên.'],
  ['key'=>'spin_enabled','label'=>'Vòng quay','hint'=>'Quay nhận quà/điểm.'],
  ['key'=>'vip_enabled','label'=>'VIP','hint'=>'Mua VIP để nhận ưu đãi.'],
  ['key'=>'gifts_enabled','label'=>'Tặng quà','hint'=>'Gửi key/gift cho bạn bè.'],
  ['key'=>'community_enabled','label'=>'Cộng đồng','hint'=>'Bật trang cộng đồng/forum.'],
];
?>
<h1 class="text-2xl font-black">Cài đặt</h1>
<p class="text-slate-400 mt-1">Bật/tắt các tính năng</p>

<?php if($flash): ?>
  <div class="mt-4 rounded-2xl border border-emerald-500/25 bg-emerald-500/10 p-4 text-emerald-200 text-sm"><?= e($flash) ?></div>
<?php endif; ?>

<form class="mt-6 space-y-6" method="post">
  <?= csrf_field() ?>

  <div class="space-y-6">
    <div class="card p-5">
      <div class="font-extrabold flex items-center gap-2"><?= lucide_icon('sliders-horizontal','w-5 h-5 text-orange-300') ?> Tính năng</div>
      <div class="mt-4 space-y-3">
        <?php foreach($features as $f): $on=(int)setting($f['key'],0)===1; ?>
          <div class="flex items-start justify-between gap-4 p-3 rounded-2xl border border-white/10 bg-white/5">
            <div>
              <div class="font-semibold"><?= e($f['label']) ?></div>
              <div class="text-sm text-slate-400 mt-0.5"><?= e($f['hint']) ?></div>
            </div>
            <label class="switch mt-1">
              <input type="checkbox" name="<?= e($f['key']) ?>" <?= $on?'checked':'' ?>>
              <span class="slider"></span>
            </label>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="card p-5">
      <div class="font-extrabold flex items-center gap-2"><?= lucide_icon('key-round','w-5 h-5 text-orange-300') ?> Google Login</div>
      <div class="mt-4 space-y-4">
        <div class="flex items-center justify-between gap-4 p-3 rounded-2xl border border-white/10 bg-white/5">
          <div>
            <div class="font-semibold">Bật đăng nhập Google</div>
            <div class="text-sm text-slate-400 mt-0.5">Redirect URL: <span class="font-mono text-slate-300">/auth/google-callback.php</span></div>
          </div>
          <label class="switch mt-1">
            <input type="checkbox" name="google_login_enabled" <?= $google_on ? 'checked' : '' ?>>
            <span class="slider"></span>
          </label>
        </div>

        <label class="block">
          <span class="text-sm text-slate-300">Google Client ID</span>
          <input class="input mt-2" name="google_client_id" value="<?= e($google_client_id) ?>" placeholder="xxxx.apps.googleusercontent.com">
        </label>

        <label class="block">
          <span class="text-sm text-slate-300">Google Client Secret</span>
          <input class="input mt-2" name="google_client_secret" value="<?= e($google_client_secret) ?>" placeholder="GOCSPX-...">
        </label>
      </div>
    </div>

    <div class="flex justify-end">
      <button class="btn" type="submit">Lưu cài đặt</button>
    </div>
  </div>

  <div class="lg:col-span-1 space-y-6">
    <div class="card p-5">
      <div class="font-extrabold flex items-center gap-2"><?= lucide_icon('info','w-5 h-5 text-orange-300') ?> Gợi ý</div>
      <ul class="mt-3 text-sm text-slate-300 space-y-2 list-disc list-inside">
        <li>Nếu Lootbox/Spin không hoạt động, hãy kiểm tra đã import DB đầy đủ và ví/điểm user đủ.</li>
        <li>Bật Popup hệ thống để dùng modal đẹp thay vì popup mặc định của trình duyệt.</li>
        <li>Google Login cần cấu hình đúng Redirect URL theo domain của bạn.</li>
      </ul>
    </div>
  </div>
</form>
