<?php
require_staff();
if (!is_admin()) { http_response_code(403); echo 'Forbidden'; return; }
flash_ensure_schema();

$err=null;
$aid = (int)((auth_user()['id'] ?? 0));
$edit_id = (int)($_GET['edit'] ?? 0);
$edit = null;
if ($edit_id>0){
  $st=db()->prepare("SELECT * FROM flash_sales WHERE id=? LIMIT 1");
  $st->execute([$edit_id]);
  $edit = $st->fetch(PDO::FETCH_ASSOC) ?: null;
}

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_require();
  $action = $_POST['action'] ?? '';
  try{
    if($action==='save'){
      $id=(int)($_POST['id'] ?? 0);
      $title=trim((string)($_POST['title'] ?? ''));
      $category=trim((string)($_POST['category'] ?? ''));
      $disc=(int)($_POST['discount_pct'] ?? 0);
      $starts=trim((string)($_POST['starts_at'] ?? ''));
      $ends=trim((string)($_POST['ends_at'] ?? ''));
      $on=isset($_POST['is_active'])?1:0;

      if($title==='') throw new Exception('Tiêu đề không được trống');
      $disc=max(0,min(80,$disc));
      if($starts==='' || $ends==='') throw new Exception('Vui lòng nhập thời gian bắt đầu/kết thúc');
      if(strtotime($starts)===false || strtotime($ends)===false) throw new Exception('Định dạng thời gian không hợp lệ');
      if(strtotime($ends) <= strtotime($starts)) throw new Exception('Kết thúc phải sau bắt đầu');

      $category = $category==='' ? null : $category;

      if($id>0){
        db()->prepare("UPDATE flash_sales SET title=?,category=?,discount_pct=?,starts_at=?,ends_at=?,is_active=? WHERE id=?")
          ->execute([$title,$category,$disc,$starts,$ends,$on,$id]);
        audit_log($aid,'flash_update','flash_sales',(string)$id,['title'=>$title]);
        redirect(admin_url('flash_sales',['edit'=>$id]));
      } else {
        db()->prepare("INSERT INTO flash_sales(title,category,discount_pct,starts_at,ends_at,is_active,created_at) VALUES(?,?,?,?,?,?,NOW())")
          ->execute([$title,$category,$disc,$starts,$ends,$on]);
        $id=(int)db()->lastInsertId();
        audit_log($aid,'flash_create','flash_sales',(string)$id,['title'=>$title]);
        redirect(admin_url('flash_sales',['edit'=>$id]));
      }
    }
    if($action==='delete'){
      $id=(int)($_POST['id'] ?? 0);
      if($id<=0) throw new Exception('ID không hợp lệ');
      db()->prepare("DELETE FROM flash_sales WHERE id=?")->execute([$id]);
      audit_log($aid,'flash_delete','flash_sales',(string)$id,[]);
      redirect(admin_url('flash_sales'));
    }
  } catch(Throwable $e){ $err=$e->getMessage(); }
}

$sales = db()->query("SELECT * FROM flash_sales ORDER BY id DESC LIMIT 100")->fetchAll(PDO::FETCH_ASSOC) ?: [];
$cats = ['','game_key','giftcard','account'];
?>
<div class="flex items-start justify-between gap-4">
  <div>
    <div class="text-2xl font-extrabold">Flash Sale</div>
    <div class="text-sm text-slate-400 mt-1">Giảm giá theo thời gian (có thể theo chuyên mục).</div>
  </div>
</div>

<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 grid lg:grid-cols-3 gap-4">
  <div class="card p-5">
    <div class="font-extrabold text-lg"><?= $edit ? 'Sửa sale' : 'Tạo sale' ?></div>
    <form method="post" class="mt-4 space-y-3" data-once="1">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
      <input class="input" name="title" placeholder="Tên chương trình" value="<?= e($edit['title'] ?? '') ?>">
      <select class="input" name="category">
        <?php foreach($cats as $c): ?>
          <option value="<?= e($c) ?>" <?= (($edit['category'] ?? '')===$c)?'selected':'' ?>><?= $c===''?'Tất cả':$c ?></option>
        <?php endforeach; ?>
      </select>
      <input class="input" type="number" name="discount_pct" placeholder="Giảm (%)" value="<?= (int)($edit['discount_pct'] ?? 10) ?>">
      <input class="input" name="starts_at" placeholder="Bắt đầu (YYYY-MM-DD HH:MM:SS)" value="<?= e($edit['starts_at'] ?? '') ?>">
      <input class="input" name="ends_at" placeholder="Kết thúc (YYYY-MM-DD HH:MM:SS)" value="<?= e($edit['ends_at'] ?? '') ?>">
      <label class="flex items-center gap-2 text-sm text-slate-200">
        <input type="checkbox" name="is_active" <?= ((int)($edit['is_active'] ?? 1)===1)?'checked':'' ?>> Kích hoạt
      </label>
      <button class="btn w-full" type="submit"><?= $edit ? 'Lưu' : 'Tạo sale' ?></button>
    </form>
    <?php if($edit): ?>
      <form method="post" class="mt-3" data-once="1" onsubmit="return confirm('Xoá sale này?');">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
        <button class="btn btn-ghost w-full" type="submit">Xoá</button>
      </form>
    <?php endif; ?>
  </div>

  <div class="card p-5 lg:col-span-2">
    <div class="font-extrabold text-lg">Danh sách sale</div>
    <div class="mt-4 overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="text-slate-400">
          <tr>
            <th class="text-left font-semibold px-3 py-2">ID</th>
            <th class="text-left font-semibold px-3 py-2">Tên</th>
            <th class="text-left font-semibold px-3 py-2">Cat</th>
            <th class="text-left font-semibold px-3 py-2">Giảm</th>
            <th class="text-left font-semibold px-3 py-2">Bắt đầu</th>
            <th class="text-left font-semibold px-3 py-2">Kết thúc</th>
            <th class="text-left font-semibold px-3 py-2">Trạng thái</th>
            <th class="text-right font-semibold px-3 py-2"></th>
          </tr>
        </thead>
        <tbody class="divide-y divide-white/5">
          <?php if(!$sales): ?><tr><td colspan="8" class="px-3 py-4 text-slate-500">Chưa có sale.</td></tr><?php endif; ?>
          <?php foreach($sales as $s): ?>
            <tr>
              <td class="px-3 py-3"><?= (int)$s['id'] ?></td>
              <td class="px-3 py-3 font-extrabold"><?= e($s['title']) ?></td>
              <td class="px-3 py-3"><?= e($s['category'] ?? 'all') ?></td>
              <td class="px-3 py-3">-<?= (int)$s['discount_pct'] ?>%</td>
              <td class="px-3 py-3 text-slate-400"><?= e($s['starts_at']) ?></td>
              <td class="px-3 py-3 text-slate-400"><?= e($s['ends_at']) ?></td>
              <td class="px-3 py-3"><?= ((int)$s['is_active']===1) ? '<span class="text-emerald-200">ON</span>' : '<span class="text-rose-200">OFF</span>' ?></td>
              <td class="px-3 py-3 text-right"><a class="btn btn-ghost" href="<?= e(admin_url('flash_sales',['edit'=>$s['id']])) ?>">Sửa</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
