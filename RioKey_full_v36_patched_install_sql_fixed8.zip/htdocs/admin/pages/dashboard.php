<?php
$u = auth_user();
$uCount = (int)db()->query("SELECT COUNT(*) c FROM users")->fetch()['c'];
$oCount = (int)db()->query("SELECT COUNT(*) c FROM orders")->fetch()['c'];
$wCount = (int)db()->query("SELECT COUNT(*) c FROM withdraw_requests")->fetch()['c'];
$links = (int)db()->query("SELECT COUNT(*) c FROM community_links")->fetch()['c'];
?>
<div class="card p-6">
  <div class="text-2xl font-extrabold">Admin Dashboard</div>
  <div class="text-slate-400 mt-1">Quản trị nội dung Community và theo dõi số liệu.</div>

  <div class="mt-6 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
    <div class="card p-5">
      <div class="text-slate-400 font-semibold">Users</div>
      <div class="text-3xl font-extrabold mt-1"><?= $uCount ?></div>
    </div>
    <div class="card p-5">
      <div class="text-slate-400 font-semibold">Orders</div>
      <div class="text-3xl font-extrabold mt-1"><?= $oCount ?></div>
    </div>
    <div class="card p-5">
      <div class="text-slate-400 font-semibold">Withdraw</div>
      <div class="text-3xl font-extrabold mt-1"><?= $wCount ?></div>
    </div>
    <div class="card p-5">
      <div class="text-slate-400 font-semibold">Community Links</div>
      <div class="text-3xl font-extrabold mt-1"><?= $links ?></div>
    </div>
  </div>
</div>


<?php
// Low stock alerts
$low = [];
try {
  shop_ensure_schema();
  $default = (int)setting('low_stock_default', 10);
  if (!db_has_column('shop_products','low_stock_threshold')) {
    try { db()->exec("ALTER TABLE shop_products ADD COLUMN low_stock_threshold INT NOT NULL DEFAULT 0"); } catch (Throwable $e) {}
  }
  $sql = "SELECT p.*, 
    (SELECT COUNT(*) FROM shop_keys k WHERE k.product_id=p.id AND k.is_sold=0) AS stock
    FROM shop_products p WHERE p.is_active=1 ORDER BY stock ASC LIMIT 30";
  $rows = db()->query($sql)->fetchAll(PDO::FETCH_ASSOC) ?: [];
  foreach($rows as $p){
    $th = (int)($p['low_stock_threshold'] ?? 0);
    if ($th<=0) $th = $default;
    if ((int)$p['stock'] <= $th) $low[] = ['id'=>$p['id'],'title'=>$p['title'],'stock'=>$p['stock'],'th'=>$th,'category'=>$p['category']];
  }
} catch (Throwable $e) { $low = []; }

$pendPosts = 0; $pendCmt = 0;
try {
  if (db_has_column('community_posts','is_approved')) $pendPosts = (int)db()->query("SELECT COUNT(*) c FROM community_posts WHERE is_active=1 AND is_approved=0")->fetch()['c'];
  if (db_has_column('community_comments','is_approved')) $pendCmt = (int)db()->query("SELECT COUNT(*) c FROM community_comments WHERE is_approved=0")->fetch()['c'];
} catch (Throwable $e) {}
?>
<div class="mt-6 grid lg:grid-cols-2 gap-4">
  <div class="card p-6">
    <div class="flex items-center justify-between">
      <div>
        <div class="text-lg font-extrabold">Low stock</div>
        <div class="text-sm text-slate-400 mt-1">Sản phẩm sắp hết key (<= ngưỡng cảnh báo)</div>
      </div>
      <?= lucide_icon('package-minus','w-5 h-5 text-orange-300') ?>
    </div>

    <div class="mt-4 space-y-2">
      <?php if(!$low): ?>
        <div class="text-sm text-slate-500">Kho đang ổn.</div>
      <?php else: foreach($low as $p): ?>
        <div class="flex items-center justify-between p-3 rounded-2xl bg-white/5 border border-white/5">
          <div>
            <div class="font-semibold"><?= e($p['title']) ?></div>
            <div class="text-xs text-slate-500"><?= e($p['category']) ?> • #<?= (int)$p['id'] ?></div>
          </div>
          <div class="text-right">
            <div class="font-extrabold text-rose-200"><?= (int)$p['stock'] ?></div>
            <div class="text-xs text-slate-500">ngưỡng <?= (int)$p['th'] ?></div>
          </div>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>

  <div class="card p-6">
    <div class="flex items-center justify-between">
      <div>
        <div class="text-lg font-extrabold">Moderation</div>
        <div class="text-sm text-slate-400 mt-1">Hàng chờ duyệt community</div>
      </div>
      <?= lucide_icon('check-check','w-5 h-5 text-orange-300') ?>
    </div>
    <div class="mt-6 grid grid-cols-2 gap-4">
      <div class="p-4 rounded-2xl bg-white/5 border border-white/5">
        <div class="text-slate-400 font-semibold">Bài chờ duyệt</div>
        <div class="text-3xl font-extrabold mt-1"><?= (int)$pendPosts ?></div>
      </div>
      <div class="p-4 rounded-2xl bg-white/5 border border-white/5">
        <div class="text-slate-400 font-semibold">BL chờ duyệt</div>
        <div class="text-3xl font-extrabold mt-1"><?= (int)$pendCmt ?></div>
      </div>
    </div>
    <div class="mt-4">
      <a class="btn" href="<?= e(admin_url('modqueue')) ?>">Đi tới Duyệt bài</a>
    </div>
  </div>
</div>
