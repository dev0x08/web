<?php
require_staff();
if (!is_admin()) { http_response_code(403); echo 'Forbidden'; return; }
referral_ensure_schema();
$flash=null; $err=null;
$aid = (int)((auth_user()['id'] ?? 0));

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_require();
  try{
    setting_set('referral_enabled', isset($_POST['referral_enabled']) ? '1' : '0');
    setting_set('referral_min_amount_vnd', (string)(int)($_POST['referral_min_amount_vnd'] ?? 50000));
    setting_set('referral_reward_points', (string)(int)($_POST['referral_reward_points'] ?? 200));
    audit_log($aid,'referral_settings','settings',null,[]);
    $flash='Đã lưu cài đặt referral.';
  } catch(Throwable $e){ $err=$e->getMessage(); }
}
$en=(int)setting('referral_enabled',1)===1;
$min=(int)setting('referral_min_amount_vnd',50000);
$rw=(int)setting('referral_reward_points',200);

$stats = db()->query("SELECT COUNT(*) AS cnt, COALESCE(SUM(reward_points),0) AS sum_points FROM referral_rewards")->fetch(PDO::FETCH_ASSOC) ?: ['cnt'=>0,'sum_points'=>0];
?>
<div class="text-2xl font-extrabold">Referral Settings</div>
<div class="text-sm text-slate-400 mt-1">Mời bạn bè: thưởng điểm khi bạn bè nạp/mua lần đầu đạt ngưỡng.</div>

<?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 grid lg:grid-cols-3 gap-4">
  <div class="card p-5 lg:col-span-2">
    <form method="post" class="space-y-4" data-once="1">
      <?= csrf_field() ?>
      <label class="flex items-center gap-2 text-sm text-slate-200">
        <input type="checkbox" name="referral_enabled" <?= $en?'checked':'' ?>> Bật referral
      </label>
      <div class="grid sm:grid-cols-2 gap-4">
        <div>
          <label class="text-sm text-slate-300">Ngưỡng nạp/mua đầu (VNĐ)</label>
          <input class="input mt-1" name="referral_min_amount_vnd" value="<?= (int)$min ?>">
        </div>
        <div>
          <label class="text-sm text-slate-300">Thưởng cho người mời (điểm)</label>
          <input class="input mt-1" name="referral_reward_points" value="<?= (int)$rw ?>">
        </div>
      </div>
      <button class="btn" type="submit">Lưu</button>
    </form>
  </div>
  <div class="card p-5">
    <div class="font-extrabold text-lg">Thống kê</div>
    <div class="mt-3 text-sm text-slate-300">Số lượt thưởng: <b><?= (int)$stats['cnt'] ?></b></div>
    <div class="mt-2 text-sm text-slate-300">Tổng điểm đã thưởng: <b><?= (int)$stats['sum_points'] ?></b></div>
  </div>
</div>
