<?php
$flash=null; $err=null;

if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_require();
  $action=$_POST['action']??'';
  if ($action==='toggle_global') {
    setting_set('popup_enabled', isset($_POST['popup_enabled']));
    $flash='Đã cập nhật bật/tắt Popup toàn hệ thống.';
  }
  if ($action==='create') {
    $title=trim($_POST['title']??''); $content=trim($_POST['content']??'');
    $btn_text=trim($_POST['button_text']??''); $btn_url=trim($_POST['button_url']??'');
    $active=(int)($_POST['is_active']??0);
    if($title===''||$content==='') $err='Thiếu title/content.';
    else {
      if ($active===1) db()->query("UPDATE popups SET is_active=0");
      db()->prepare("INSERT INTO popups (title,content,button_text,button_url,is_active) VALUES (?,?,?,?,?)")
        ->execute([$title,$content,$btn_text,$btn_url,$active]);
      $flash='Đã tạo popup.';
    }
  }
  if ($action==='update' && !$err) {
    $id=(int)($_POST['id']??0);
    $title=trim($_POST['title']??''); $content=trim($_POST['content']??'');
    $btn_text=trim($_POST['button_text']??''); $btn_url=trim($_POST['button_url']??'');
    $active=(int)($_POST['is_active']??0);
    if ($active===1) db()->query("UPDATE popups SET is_active=0");
    db()->prepare("UPDATE popups SET title=?,content=?,button_text=?,button_url=?,is_active=? WHERE id=?")
      ->execute([$title,$content,$btn_text,$btn_url,$active,$id]);
    $flash='Đã cập nhật popup.';
  }
  if ($action==='delete' && !$err) {
    $id=(int)($_POST['id']??0);
    db()->prepare("DELETE FROM popups WHERE id=?")->execute([$id]);
    $flash='Đã xoá popup.';
  }
}

$global_on = setting_get('popup_enabled', true);
$rows = db()->query("SELECT * FROM popups ORDER BY id DESC")->fetchAll();
?>
<h1 class="text-2xl font-black">Quản lý Popup</h1>
<p class="text-slate-400 mt-1">Popup hiển thị khi vào web (có ON/OFF hoạt động)</p>

<?php if($err): ?><div class="mt-4 rounded-2xl border border-rose-500/30 bg-rose-500/10 p-4 text-rose-200 text-sm"><?= e($err) ?></div><?php endif; ?>
<?php if($flash): ?><div class="mt-4 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-4 text-emerald-200 text-sm"><?= e($flash) ?></div><?php endif; ?>

<div class="card p-5 mt-6">
  <div class="flex items-center justify-between gap-4">
    <div class="font-extrabold flex items-center gap-2"><?= lucide_icon('toggle-left','w-5 h-5 text-orange-300') ?> Bật/Tắt toàn hệ thống</div>
    <form method="post" class="flex items-center gap-3">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="toggle_global">
      <label class="flex items-center gap-2 text-sm text-slate-300">
        <input type="checkbox" class="accent-orange-500" name="popup_enabled" value="1" <?= $global_on?'checked':'' ?>>
        Cho phép popup
      </label>
      <button class="btn btn-primary">Lưu</button>
    </form>
  </div>
</div>

<div class="grid lg:grid-cols-3 gap-6 mt-6">
  <div class="card p-5">
    <div class="font-extrabold flex items-center gap-2"><?= lucide_icon('sparkles','w-5 h-5 text-orange-300') ?> Tạo popup</div>
    <form class="mt-4 space-y-3" method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="create">
      <input class="input" name="title" placeholder="Tiêu đề" required>
      <textarea class="input min-h-[120px]" name="content" placeholder="Nội dung" required></textarea>
      <input class="input" name="button_text" placeholder="Text nút (VD: Xem ngay)">
      <input class="input" name="button_url" placeholder="Link nút (VD: https://...)">
      <label class="flex items-center gap-2 text-sm text-slate-300">
        <input type="checkbox" class="accent-orange-500" name="is_active" value="1"> Set làm popup đang chạy
      </label>
      <button class="btn btn-primary w-full">Tạo</button>
    </form>
  </div>

  <div class="lg:col-span-2 card p-0 overflow-hidden">
    <div class="p-5 border-b border-slate-800/60 font-extrabold flex items-center gap-2"><?= lucide_icon('list','w-5 h-5 text-orange-300') ?> Danh sách</div>
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <thead class="text-slate-400">
          <tr class="border-b border-slate-800/60">
            <th class="text-left p-4">Title</th>
            <th class="text-left p-4">Active</th>
            <th class="text-left p-4">Created</th>
            <th class="text-right p-4">Hành động</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach($rows as $p): ?>
          <tr class="border-b border-slate-800/40 hover:bg-slate-900/40">
            <td class="p-4 font-semibold"><?= e($p['title']) ?></td>
            <td class="p-4"><?= (int)$p['is_active']===1 ? '<span class="badge badge-ok">ON</span>' : '<span class="badge">OFF</span>' ?></td>
            <td class="p-4 text-slate-300"><?= e($p['created_at']) ?></td>
            <td class="p-4 text-right">
              <button class="btn btn-ghost !px-3 !py-2" onclick="document.getElementById('pedit-<?= (int)$p['id'] ?>').showModal()"><?= lucide_icon('pencil','w-4 h-4') ?></button>
              <form class="inline" method="post" onsubmit="return confirm('Xoá popup này?')">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                <button class="btn btn-ghost !px-3 !py-2 text-rose-200"><?= lucide_icon('trash-2','w-4 h-4') ?></button>
              </form>

              <dialog id="pedit-<?= (int)$p['id'] ?>" class="rounded-3xl bg-slate-950 border border-slate-800/70 text-slate-100 p-0 w-[min(720px,95vw)]">
                <div class="p-5 border-b border-slate-800/60 flex items-center justify-between">
                  <div class="font-extrabold">Sửa popup</div>
                  <button class="btn btn-ghost !px-3 !py-2" onclick="this.closest('dialog').close()"><?= lucide_icon('x','w-5 h-5') ?></button>
                </div>
                <form method="post" class="p-5 space-y-3">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="update">
                  <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                  <input class="input" name="title" value="<?= e($p['title']) ?>" required>
                  <textarea class="input min-h-[140px]" name="content" required><?= e($p['content']) ?></textarea>
                  <input class="input" name="button_text" value="<?= e($p['button_text']) ?>" placeholder="Text nút">
                  <input class="input" name="button_url" value="<?= e($p['button_url']) ?>" placeholder="Link nút">
                  <label class="flex items-center gap-2 text-sm text-slate-300">
                    <input type="checkbox" class="accent-orange-500" name="is_active" value="1" <?= (int)$p['is_active']===1?'checked':'' ?>>
                    Set làm popup đang chạy
                  </label>
                  <div class="flex justify-end gap-2 pt-2">
                    <button type="button" class="btn btn-ghost" onclick="this.closest('dialog').close()">Hủy</button>
                    <button class="btn btn-primary">Lưu</button>
                  </div>
                </form>
              </dialog>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
