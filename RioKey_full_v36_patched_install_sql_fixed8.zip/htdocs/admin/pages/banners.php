<?php
$flash=null; $err=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_require();
  $action=$_POST['action']??'';
  if($action==='create'){
    $img=trim($_POST['image_url']??'');
    $link=trim($_POST['link_url']??'');
    $sort=(int)($_POST['sort_order']??0);
    $on=isset($_POST['is_active'])?1:0;
    if($img==='') $err='Vui lòng nhập URL ảnh.';
    else {
      db()->prepare("INSERT INTO banners(image_url,link_url,sort_order,is_active) VALUES(?,?,?,?)")->execute([$img,$link,$sort,$on]);
      $flash='Đã thêm banner.';
    }
  }
  if($action==='toggle'){
    $id=(int)($_POST['id']??0);
    db()->prepare("UPDATE banners SET is_active=IF(is_active=1,0,1) WHERE id=?")->execute([$id]);
    $flash='Đã cập nhật trạng thái.';
  }
  if($action==='delete'){
    $id=(int)($_POST['id']??0);
    db()->prepare("DELETE FROM banners WHERE id=?")->execute([$id]);
    $flash='Đã xoá.';
  }
}
$rows=db()->query("SELECT * FROM banners ORDER BY sort_order ASC, id DESC")->fetchAll()?:[];
?>
<h1 class="text-2xl font-black">Banner Dashboard</h1>
<p class="text-slate-400 mt-1">Chỉ nhập URL ảnh (không upload).</p>

<?php if($flash): ?><div class="mt-4 rounded-2xl border border-emerald-500/25 bg-emerald-500/10 p-4 text-emerald-200 text-sm"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 rounded-2xl border border-rose-500/25 bg-rose-500/10 p-4 text-rose-200 text-sm"><?= e($err) ?></div><?php endif; ?>

<div class="card p-5 mt-6">
  <div class="font-extrabold">Thêm banner</div>
  <form method="post" class="mt-4 grid md:grid-cols-4 gap-3">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="create">
    <div class="md:col-span-2">
      <label>Image URL</label>
      <input class="input" name="image_url" placeholder="https://..." required>
    </div>
    <div>
      <label>Link URL</label>
      <input class="input" name="link_url" placeholder="https://...">
    </div>
    <div>
      <label>Sort</label>
      <input class="input" name="sort_order" type="number" value="0">
    </div>
    <div class="md:col-span-4 flex items-center justify-between">
      <label class="inline-flex items-center gap-2">
        <input type="checkbox" name="is_active" checked>
        <span class="text-sm text-slate-200 font-semibold">Active</span>
      </label>
      <button class="btn btn-primary">Thêm</button>
    </div>
  </form>
</div>

<div class="card p-5 mt-6">
  <div class="font-extrabold">Danh sách</div>
  <div class="mt-4 space-y-3">
    <?php foreach($rows as $r): ?>
      <div class="rounded-2xl border border-white/10 bg-white/5 p-4 flex items-center gap-3">
        <img src="<?= e($r['image_url']) ?>" class="w-28 h-16 object-cover rounded-xl border border-white/10" alt="">
        <div class="min-w-0 flex-1">
          <div class="font-bold truncate"><?= e($r['image_url']) ?></div>
          <div class="text-xs text-slate-500 mt-1 truncate"><?= e($r['link_url'] ?: '—') ?></div>
          <div class="text-xs text-slate-500 mt-1">sort: <?= (int)$r['sort_order'] ?> • <?= (int)$r['is_active']===1?'ON':'OFF' ?></div>
        </div>
        <form method="post" class="flex items-center gap-2">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
          <button name="action" value="toggle" class="btn btn-ghost !px-3 !py-2"><?= (int)$r['is_active']===1?'Tắt':'Bật' ?></button>
          <button name="action" value="delete" class="btn btn-ghost !px-3 !py-2" onclick="return confirm('Xoá banner?')">Xoá</button>
        </form>
      </div>
    <?php endforeach; ?>
    <?php if(!$rows): ?><div class="text-slate-500 text-sm">Chưa có banner.</div><?php endif; ?>
  </div>
</div>
