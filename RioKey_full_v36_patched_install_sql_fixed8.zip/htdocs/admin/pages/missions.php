<?php
$flash=null; $err=null;

$tbl='missions';
$hasType = db_has_column($tbl,'type');
$hasIcon = db_has_column($tbl,'icon');
$hasUrl  = db_has_column($tbl,'action_url');
$hasSort = db_has_column($tbl,'sort');
$hasActive = db_has_column($tbl,'is_active');

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_require();
  $action=$_POST['action']??'';

  if($action==='create'){
    $title=trim($_POST['title']??'');
    $desc=trim($_POST['description']??'');
    $points=(int)($_POST['points']??0);
    $type=$_POST['type']??'daily';
    $icon=trim($_POST['icon']??'sparkles');
    $url=trim($_POST['action_url']??'');
    $sort=(int)($_POST['sort']??0);
    $on=isset($_POST['is_active'])?1:0;

    if($title==='') $err='Vui lòng nhập tiêu đề.';
    else {
      $cols=['title','description','points'];
      $vals=[$title,$desc,$points];

      if($hasType){ $cols[]='type'; $vals[]=$type; }
      if($hasIcon){ $cols[]='icon'; $vals[]=$icon; }
      if($hasUrl){ $cols[]='action_url'; $vals[]=$url; }
      if($hasSort){ $cols[]='sort'; $vals[]=$sort; }
      if($hasActive){ $cols[]='is_active'; $vals[]=$on; }

      $ph = implode(',', array_fill(0,count($cols),'?'));
      $sql = "INSERT INTO {$tbl}(".implode(',',$cols).") VALUES({$ph})";
      db()->prepare($sql)->execute($vals);

      $flash='Đã thêm nhiệm vụ.';
    }
  }

  if($action==='toggle' && $hasActive){
    $id=(int)($_POST['id']??0);
    db()->prepare("UPDATE {$tbl} SET is_active=IF(is_active=1,0,1) WHERE id=?")->execute([$id]);
    $flash='Đã cập nhật.';
  }

  if($action==='delete'){
    $id=(int)($_POST['id']??0);
    db()->prepare("DELETE FROM {$tbl} WHERE id=?")->execute([$id]);
    $flash='Đã xoá.';
  }
}

$order="ORDER BY id DESC";
if($hasSort) $order="ORDER BY sort ASC, id DESC";
$rows=db()->query("SELECT * FROM {$tbl} {$order}")->fetchAll(PDO::FETCH_ASSOC)?:[];
?>
<h1 class="text-2xl font-black">Nhiệm vụ</h1>
<p class="text-slate-400 mt-1">Admin thêm nhiệm vụ từ DB.</p>

<?php if($flash): ?><div class="mt-4 rounded-2xl border border-emerald-500/25 bg-emerald-500/10 p-4 text-emerald-200 text-sm"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 rounded-2xl border border-rose-500/25 bg-rose-500/10 p-4 text-rose-200 text-sm"><?= e($err) ?></div><?php endif; ?>

<div class="card p-5 mt-6">
  <div class="font-extrabold">Thêm nhiệm vụ</div>
  <form method="post" class="mt-4 grid md:grid-cols-4 gap-3">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="create">

    <div class="md:col-span-2">
      <label>Tiêu đề</label>
      <input class="input" name="title" required>
    </div>

    <?php if($hasType): ?>
    <div>
      <label>Loại</label>
      <select class="input" name="type">
        <option value="daily">Hằng ngày (auto)</option>
        <option value="auto">1 lần (auto)</option>
        <option value="manual">Cần bằng chứng (duyệt 1 lần)</option>
        <option value="manual_daily">Cần bằng chứng (duyệt theo ngày)</option>
        <option value="unlimited">Không giới hạn (legacy)</option>
        <option value="extended">Mở rộng (legacy)</option>
      </select>
    </div>
    <?php endif; ?>

    <div>
      <label>Điểm</label>
      <input class="input" name="points" type="number" value="0">
    </div>

    <div class="md:col-span-2">
      <label>Mô tả</label>
      <input class="input" name="description" placeholder="Mô tả ngắn">
    </div>

    <?php if($hasIcon): ?>
    <div>
      <label>Icon (lucide)</label>
      <input class="input" name="icon" value="sparkles">
    </div>
    <?php endif; ?>

    <?php if($hasUrl): ?>
    <div>
      <label>Action URL</label>
      <input class="input" name="action_url" placeholder="/referral hoặc https://...">
    </div>
    <?php endif; ?>

    <?php if($hasSort): ?>
    <div class="md:col-span-4">
      <label>Sort</label>
      <input class="input" name="sort" type="number" value="0">
    </div>
    <?php endif; ?>

    <div class="md:col-span-4 flex items-center justify-between">
      <?php if($hasActive): ?>
      <label class="inline-flex items-center gap-2">
        <input type="checkbox" name="is_active" checked>
        <span class="text-sm text-slate-200 font-semibold">Active</span>
      </label>
      <?php else: ?>
      <div></div>
      <?php endif; ?>
      <button class="btn btn-primary">Thêm</button>
    </div>
  </form>
</div>

<div class="card p-5 mt-6">
  <div class="font-extrabold">Danh sách</div>
  <div class="mt-4 space-y-3">
    <?php foreach($rows as $r): ?>
      <div class="rounded-2xl border border-white/10 bg-white/5 p-4 flex items-start justify-between gap-3">
        <div class="min-w-0">
          <div class="font-bold text-slate-100 truncate"><?= e($r['title'] ?? '') ?></div>
          <div class="text-sm text-slate-400 mt-1 line-clamp-2"><?= e($r['description'] ?? '') ?></div>
          <div class="text-xs text-slate-500 mt-1">
            +<?= (int)($r['points'] ?? 0) ?> điểm
            <?php if($hasType): ?> • <?= e($r['type'] ?? '') ?><?php endif; ?>
            <?php if($hasIcon): ?> • icon: <?= e($r['icon'] ?? '') ?><?php endif; ?>
          </div>
        </div>
        <form method="post" class="flex items-center gap-2 shrink-0">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)($r['id'] ?? 0) ?>">
          <?php if($hasActive): ?>
            <button name="action" value="toggle" class="btn btn-ghost !px-3 !py-2"><?= (int)($r['is_active'] ?? 0)===1?'Tắt':'Bật' ?></button>
          <?php endif; ?>
          <button name="action" value="delete" class="btn btn-ghost !px-3 !py-2" onclick="return confirm('Xoá nhiệm vụ?')">Xoá</button>
        </form>
      </div>
    <?php endforeach; ?>
    <?php if(!$rows): ?><div class="text-slate-500 text-sm">Chưa có nhiệm vụ.</div><?php endif; ?>
  </div>
</div>
