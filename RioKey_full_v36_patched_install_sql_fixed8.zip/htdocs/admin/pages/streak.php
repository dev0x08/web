<?php
$flash=null; $err=null;

$tbl='checkin_rewards';
// Prefer day_index (day_no is legacy in some dumps)
$dayCol = db_has_column($tbl,'day_index') ? 'day_index' : (db_has_column($tbl,'day_no') ? 'day_no' : 'id');
$ptsCol = db_has_column($tbl,'reward_points') ? 'reward_points' : (db_has_column($tbl,'points') ? 'points' : 'reward_points');
$hasActive = db_has_column($tbl,'is_active');

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_require();
  $action=$_POST['action']??'';

  if($action==='save'){
    $day=(int)($_POST['day']??0);
    $pts=(int)($_POST['points']??0);
    $on=isset($_POST['is_active'])?1:0;
    if($day<=0) $err='Ngày không hợp lệ.';
    else{
      // upsert by day
      $st=db()->prepare("SELECT id FROM {$tbl} WHERE {$dayCol}=? LIMIT 1");
      $st->execute([$day]);
      $row=$st->fetch(PDO::FETCH_ASSOC);

      if($row){
        $sets=["{$ptsCol}=?"];
        $vals=[$pts];
        if($hasActive){ $sets[]="is_active=?"; $vals[]=$on; }
        $vals[]=(int)$row['id'];
        db()->prepare("UPDATE {$tbl} SET ".implode(',',$sets)." WHERE id=?")->execute($vals);
      } else {
        $cols=[$dayCol,$ptsCol];
        $vals=[$day,$pts];
        if($hasActive){ $cols[]='is_active'; $vals[]=$on; }
        $ph=implode(',',array_fill(0,count($cols),'?'));
        db()->prepare("INSERT INTO {$tbl}(".implode(',',$cols).") VALUES({$ph})")->execute($vals);
      }
      $flash='Đã lưu cấu hình.';
    }
  }

  if($action==='seed7'){
    // create 7 rows default if empty
    for($i=1;$i<=7;$i++){
      $st=db()->prepare("SELECT id FROM {$tbl} WHERE {$dayCol}=? LIMIT 1");
      $st->execute([$i]);
      if(!$st->fetch()){
        $cols=[$dayCol,$ptsCol];
        $vals=[$i, 10*$i];
        if($hasActive){ $cols[]='is_active'; $vals[]=1; }
        $ph=implode(',',array_fill(0,count($cols),'?'));
        db()->prepare("INSERT INTO {$tbl}(".implode(',',$cols).") VALUES({$ph})")->execute($vals);
      }
    }
    $flash='Đã tạo vòng 7 ngày mặc định.';
  }
}

$order = "ORDER BY {$dayCol} ASC";
$rows = db()->query("SELECT * FROM {$tbl} {$order}")->fetchAll(PDO::FETCH_ASSOC) ?: [];
?>
<h1 class="text-2xl font-black">Streak Reward</h1>
<p class="text-slate-400 mt-1">Admin tự cấu hình reward theo từng ngày streak (vòng 7 ngày).</p>

<?php if($flash): ?><div class="mt-4 rounded-2xl border border-emerald-500/25 bg-emerald-500/10 p-4 text-emerald-200 text-sm"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 rounded-2xl border border-rose-500/25 bg-rose-500/10 p-4 text-rose-200 text-sm"><?= e($err) ?></div><?php endif; ?>

<div class="card p-5 mt-6">
  <div class="flex items-center justify-between">
    <div class="font-extrabold">Cấu hình 7 ngày</div>
    <form method="post">
      <?= csrf_field() ?>
      <button class="btn btn-ghost" name="action" value="seed7" onclick="return confirm('Tạo vòng 7 ngày mặc định?')">Seed 7 ngày</button>
    </form>
  </div>

  <div class="mt-4 overflow-x-auto">
    <table class="w-full text-sm">
      <thead>
        <tr class="text-left text-slate-400">
          <th class="py-2 pr-3">Day</th>
          <th class="py-2 pr-3">Points</th>
          <?php if($hasActive): ?><th class="py-2 pr-3">Active</th><?php endif; ?>
          <th class="py-2 pr-3"></th>
        </tr>
      </thead>
      <tbody>
      <?php foreach($rows as $r):
        $d=(int)($r[$dayCol] ?? 0);
        $pts=(int)($r[$ptsCol] ?? 0);
      ?>
        <tr class="border-t border-white/10">
          <td class="py-3 pr-3 font-bold"><?= $d ?></td>
          <td class="py-3 pr-3"><?= $pts ?></td>
          <?php if($hasActive): ?><td class="py-3 pr-3"><?= ((int)($r['is_active']??1)===1)?'ON':'OFF' ?></td><?php endif; ?>
          <td class="py-3 pr-3">
            <form method="post" class="flex items-center gap-2 justify-end">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="save">
              <input type="hidden" name="day" value="<?= $d ?>">
              <input class="input !w-32" type="number" name="points" value="<?= $pts ?>">
              <?php if($hasActive): ?>
                <label class="inline-flex items-center gap-2 text-xs text-slate-300">
                  <input type="checkbox" name="is_active" <?= ((int)($r['is_active']??1)===1)?'checked':'' ?>>
                  Active
                </label>
              <?php endif; ?>
              <button class="btn btn-primary !px-3 !py-2">Lưu</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if(!$rows): ?><tr><td class="py-4 text-slate-500" colspan="4">Chưa có dữ liệu.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
