<?php
require_staff();
if (!is_admin()) { http_response_code(403); echo 'Forbidden'; return; }
$flash=null; $err=null;
$aid = (int)((auth_user()['id'] ?? 0));

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_require();
  try{
    setting_set('lootbox_enabled', isset($_POST['lootbox_enabled']) ? '1' : '0');
    setting_set('lootbox_price_points', (string)(int)($_POST['lootbox_price_points'] ?? 200));
    setting_set('lootbox_price_vnd', (string)(int)($_POST['lootbox_price_vnd'] ?? 20000));
    setting_set('lootbox_w_common', (string)(int)($_POST['lootbox_w_common'] ?? 70));
    setting_set('lootbox_w_rare', (string)(int)($_POST['lootbox_w_rare'] ?? 25));
    setting_set('lootbox_w_epic', (string)(int)($_POST['lootbox_w_epic'] ?? 5));
    audit_log($aid,'lootbox_settings','settings',null,[]);
    $flash='Đã lưu cài đặt lootbox.';
  } catch(Throwable $e){ $err=$e->getMessage(); }
}

$en = (int)setting('lootbox_enabled',1)===1;
$pPts = (int)setting('lootbox_price_points',200);
$pVnd = (int)setting('lootbox_price_vnd',20000);
$wC = (int)setting('lootbox_w_common',70);
$wR = (int)setting('lootbox_w_rare',25);
$wE = (int)setting('lootbox_w_epic',5);
?>
<div class="text-2xl font-extrabold">Lootbox Settings</div>
<div class="text-sm text-slate-400 mt-1">Lootbox chọn ngẫu nhiên key theo tier (game_key/giftcard/account).</div>

<?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 card p-5 max-w-3xl">
  <form method="post" class="space-y-4" data-once="1">
    <?= csrf_field() ?>
    <label class="flex items-center gap-2 text-sm text-slate-200">
      <input type="checkbox" name="lootbox_enabled" <?= $en?'checked':'' ?>> Bật lootbox
    </label>

    <div class="grid sm:grid-cols-2 gap-4">
      <div>
        <label class="text-sm text-slate-300">Giá (điểm)</label>
        <input class="input mt-1" name="lootbox_price_points" value="<?= (int)$pPts ?>">
      </div>
      <div>
        <label class="text-sm text-slate-300">Giá (VNĐ)</label>
        <input class="input mt-1" name="lootbox_price_vnd" value="<?= (int)$pVnd ?>">
      </div>
    </div>

    <div class="grid sm:grid-cols-3 gap-4">
      <div>
        <label class="text-sm text-slate-300">Tỷ lệ Common (%)</label>
        <input class="input mt-1" name="lootbox_w_common" value="<?= (int)$wC ?>">
      </div>
      <div>
        <label class="text-sm text-slate-300">Tỷ lệ Rare (%)</label>
        <input class="input mt-1" name="lootbox_w_rare" value="<?= (int)$wR ?>">
      </div>
      <div>
        <label class="text-sm text-slate-300">Tỷ lệ Epic (%)</label>
        <input class="input mt-1" name="lootbox_w_epic" value="<?= (int)$wE ?>">
      </div>
    </div>

    <div class="text-xs text-slate-500">
      Mapping tier → category: Common=game_key • Rare=giftcard • Epic=account.
    </div>
    <button class="btn" type="submit">Lưu</button>
  </form>
</div>
