<?php
require_staff();
community_ensure_schema();

$flash=null; $err=null;

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_require();
  $action = $_POST['action'] ?? '';
  try {
    if($action==='approve_post'){
      $id=(int)($_POST['id']??0);
      db()->prepare("UPDATE community_posts SET is_approved=1 WHERE id=?")->execute([$id]);
      $flash='Đã duyệt bài.';
      redirect(admin_url('modqueue'));
    }
    if($action==='reject_post'){
      $id=(int)($_POST['id']??0);
      db()->prepare("UPDATE community_posts SET is_approved=0, is_active=0 WHERE id=?")->execute([$id]);
      $flash='Đã ẩn bài.';
      redirect(admin_url('modqueue'));
    }
    if($action==='lock_post'){
      $id=(int)($_POST['id']??0);
      if (db_has_column('community_posts','is_locked')) {
        db()->prepare("UPDATE community_posts SET is_locked=1 WHERE id=?")->execute([$id]);
      }
      $flash='Đã khoá chủ đề.';
      redirect(admin_url('modqueue'));
    }
    if($action==='approve_comment'){
      $id=(int)($_POST['id']??0);
      db()->prepare("UPDATE community_comments SET is_approved=1 WHERE id=?")->execute([$id]);
      $flash='Đã duyệt bình luận.';
      redirect(admin_url('modqueue'));
    }
    if($action==='delete_comment'){
      $id=(int)($_POST['id']??0);
      db()->prepare("DELETE FROM community_comments WHERE id=?")->execute([$id]);
      $flash='Đã xoá bình luận.';
      redirect(admin_url('modqueue'));
    }
    if($action==='warn'){
      $uid=(int)($_POST['user_id']??0);
      $w=(int)($_POST['warnings']??1);
      if ($uid>0 && db_has_column('users','warnings')) {
        db()->prepare("UPDATE users SET warnings=GREATEST(warnings,0)+? WHERE id=?")->execute([$w,$uid]);
      }
      $flash='Đã cảnh cáo user.';
      redirect(admin_url('modqueue'));
    }
    if($action==='mute'){
      $uid=(int)($_POST['user_id']??0);
      $mins=(int)($_POST['minutes']??1440);
      if ($uid>0 && db_has_column('users','mute_until')) {
        db()->prepare("UPDATE users SET mute_until=DATE_ADD(NOW(), INTERVAL ? MINUTE) WHERE id=?")->execute([$mins,$uid]);
      }
      $flash='Đã mute user.';
      redirect(admin_url('modqueue'));
    }
  } catch (Throwable $e) { $err=$e->getMessage(); }
}

// Pending posts/comments
$pendingPosts = [];
if (db_has_column('community_posts','is_approved')) {
  $pendingPosts = db()->query("SELECT p.*, u.username FROM community_posts p LEFT JOIN users u ON u.id=p.user_id WHERE p.is_active=1 AND p.is_approved=0 ORDER BY p.id DESC LIMIT 50")->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

$pendingComments = [];
if (db_has_column('community_comments','is_approved')) {
  $pendingComments = db()->query("SELECT c.*, u.username, p.title AS post_title FROM community_comments c
    LEFT JOIN users u ON u.id=c.user_id
    LEFT JOIN community_posts p ON p.id=c.post_id
    WHERE c.is_approved=0 ORDER BY c.id DESC LIMIT 80")->fetchAll(PDO::FETCH_ASSOC) ?: [];
}
?>
<div class="flex items-start justify-between gap-4">
  <div>
    <div class="text-2xl font-extrabold">Duyệt bài / bình luận</div>
    <div class="text-sm text-slate-400 mt-1">Hàng chờ duyệt + thao tác nhanh cho Mod/Admin.</div>
  </div>
</div>

<?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 grid lg:grid-cols-2 gap-4">
  <div class="card p-5">
    <div class="text-lg font-extrabold">Bài viết chờ duyệt</div>
    <div class="mt-4 space-y-3">
      <?php if(!$pendingPosts): ?>
        <div class="text-slate-500 text-sm">Không có.</div>
      <?php else: foreach($pendingPosts as $p): ?>
        <div class="p-4 rounded-2xl bg-white/5 border border-white/5">
          <div class="font-extrabold"><?= e($p['title'] ?? '') ?></div>
          <div class="text-xs text-slate-500 mt-1">by <?= e($p['username'] ?? 'unknown') ?> • #<?= (int)$p['id'] ?></div>
          <div class="text-sm text-slate-200 mt-2 line-clamp-3"><?= e($p['excerpt'] ?? '') ?></div>

          <div class="mt-3 flex flex-wrap gap-2">
            <form method="post" data-once="1">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="approve_post">
              <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
              <button class="btn" type="submit">Duyệt</button>
            </form>
            <form method="post" data-once="1" onsubmit="return confirm('Ẩn bài này?');">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="reject_post">
              <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
              <button class="btn btn-ghost" type="submit">Ẩn</button>
            </form>
            <form method="post" data-once="1">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="lock_post">
              <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
              <button class="btn btn-ghost" type="submit">Khoá</button>
            </form>

            <form method="post" class="ml-auto flex gap-2 items-center" data-once="1">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="warn">
              <input type="hidden" name="user_id" value="<?= (int)($p['user_id'] ?? 0) ?>">
              <input class="input w-20" name="warnings" value="1">
              <button class="btn btn-ghost" type="submit">Warn</button>
            </form>

            <form method="post" class="flex gap-2 items-center" data-once="1">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="mute">
              <input type="hidden" name="user_id" value="<?= (int)($p['user_id'] ?? 0) ?>">
              <input class="input w-24" name="minutes" value="1440">
              <button class="btn btn-ghost" type="submit">Mute</button>
            </form>
          </div>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>

  <div class="card p-5">
    <div class="text-lg font-extrabold">Bình luận chờ duyệt</div>
    <div class="mt-4 space-y-3">
      <?php if(!$pendingComments): ?>
        <div class="text-slate-500 text-sm">Không có.</div>
      <?php else: foreach($pendingComments as $c): ?>
        <div class="p-4 rounded-2xl bg-white/5 border border-white/5">
          <div class="text-xs text-slate-500">Post: <?= e($c['post_title'] ?? '') ?> • by <?= e($c['username'] ?? 'unknown') ?> • #<?= (int)$c['id'] ?></div>
          <div class="text-sm text-slate-200 mt-2"><?= e($c['content'] ?? '') ?></div>
          <div class="mt-3 flex gap-2">
            <form method="post" data-once="1">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="approve_comment">
              <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
              <button class="btn" type="submit">Duyệt</button>
            </form>
            <form method="post" data-once="1" onsubmit="return confirm('Xoá bình luận này?');">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete_comment">
              <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
              <button class="btn btn-ghost" type="submit">Xoá</button>
            </form>
          </div>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>
</div>
