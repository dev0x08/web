<?php
require_staff();
risk_ensure_schema();

$flash=null; $err=null;

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_require();
  $act=(string)($_POST['action']??'');
  try{
    if($act==='block'){
      $ip=trim((string)($_POST['ip']??''));
      $mins=(int)($_POST['minutes']??10);
      $reason=trim((string)($_POST['reason']??'Manual block'));
      if($ip==='') throw new Exception('Thiếu IP');
      if($mins<1) $mins=10;
      ip_block($ip,$reason,$mins,(int)auth_user()['id']);
      $flash='Đã block IP.';
    }
    if($act==='unblock'){
      $ip=trim((string)($_POST['ip']??''));
      if($ip==='') throw new Exception('Thiếu IP');
      ip_unblock($ip);
      $flash='Đã unblock IP.';
    }
  } catch (Throwable $e){ $err=$e->getMessage(); }
}

$rows = db()->query("SELECT * FROM ip_blocks ORDER BY created_at DESC LIMIT 200")->fetchAll(PDO::FETCH_ASSOC) ?: [];
?>
<div class="flex items-start justify-between gap-4">
  <div>
    <div class="text-2xl font-extrabold">IP Blocks</div>
    <div class="text-sm text-slate-400 mt-1">Chặn IP tạm thời (anti-spam/DDOS).</div>
  </div>
</div>

<?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 card p-5">
  <div class="font-extrabold">Block IP mới</div>
  <form method="post" class="mt-3 grid sm:grid-cols-4 gap-3" data-once="1">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="block">
    <input class="input" name="ip" placeholder="1.2.3.4">
    <input class="input" name="minutes" placeholder="minutes" value="10">
    <input class="input" name="reason" placeholder="reason" value="Manual block">
    <button class="btn" type="submit">Block</button>
  </form>
</div>

<div class="mt-4 card p-5 overflow-x-auto">
  <table class="min-w-full text-sm">
    <thead class="text-slate-400">
      <tr>
        <th class="text-left px-3 py-2">IP</th>
        <th class="text-left px-3 py-2">Reason</th>
        <th class="text-left px-3 py-2">Created</th>
        <th class="text-left px-3 py-2">Expires</th>
        <th class="text-right px-3 py-2"></th>
      </tr>
    </thead>
    <tbody class="divide-y divide-white/5">
      <?php if(!$rows): ?><tr><td colspan="5" class="px-3 py-4 text-slate-500">Chưa có.</td></tr>
      <?php else: foreach($rows as $r): ?>
        <tr>
          <td class="px-3 py-3 font-semibold"><?= e($r['ip'] ?? '') ?></td>
          <td class="px-3 py-3 text-slate-300"><?= e($r['reason'] ?? '') ?></td>
          <td class="px-3 py-3 text-xs text-slate-500"><?= e($r['created_at'] ?? '') ?></td>
          <td class="px-3 py-3 text-xs text-slate-500"><?= e($r['expires_at'] ?? 'never') ?></td>
          <td class="px-3 py-3 text-right">
            <form method="post" data-once="1" onsubmit="return confirm('Unblock IP này?');">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="unblock">
              <input type="hidden" name="ip" value="<?= e($r['ip']) ?>">
              <button class="btn btn-ghost" type="submit">Unblock</button>
            </form>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>
