<?php
$admin = auth_user();
$aid = (int)($admin['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_require();

  $title = trim((string)($_POST['title'] ?? ''));
  $body  = trim((string)($_POST['body'] ?? ''));
  $link  = trim((string)($_POST['link_url'] ?? ''));
  $aud   = (string)($_POST['audience'] ?? 'all');
  $user_id = (int)($_POST['user_id'] ?? 0);
  $rank_slug = trim((string)($_POST['rank_slug'] ?? ''));

  if ($title === '' || $body === '') {
    flash_set('error','Vui lòng nhập tiêu đề và nội dung.');
    redirect(admin_url('notifications'));
  }

  if (!in_array($aud, ['all','user','rank','vip','role','inactive'], true)) $aud = 'all';
  $role = trim((string)($_POST['role'] ?? ''));
  $inactive_days = (int)($_POST['inactive_days'] ?? 7);


  try {
    if ($aud === 'user') {
      if ($user_id <= 0) {
        flash_set('error','Nhập user_id hợp lệ.');
        redirect(admin_url('notifications'));
      }
      notify_user($user_id, $title, $body, $link ?: null);
    } elseif ($aud === 'rank') {
      if ($rank_slug === '') {
        flash_set('error','Nhập rank_slug hợp lệ.');
        redirect(admin_url('notifications'));
      }
      $uids = db()->query("SELECT id FROM users")->fetchAll(PDO::FETCH_ASSOC) ?: [];
      foreach ($uids as $r) {
        $uid = (int)$r['id'];
        $rp = rank_progress_for_user($uid);
        $slug = (string)($rp['current']['slug'] ?? '');
        if ($slug === $rank_slug) {
          notify_user($uid, $title, $body, $link ?: null);
        }
      }
    } else {
      notify_all($title, $body, $link ?: null);
    }

    audit_log($aid,'notify_create','notification',null,[
      'audience'=>$aud,
      'user_id'=>$user_id,
      'rank_slug'=>$rank_slug,
      'title'=>$title
    ]);

    flash_set('ok','Đã gửi thông báo.');
  } catch (Throwable $e) {
    flash_set('error','Không gửi được thông báo (lỗi DB).');
  }

  redirect(admin_url('notifications'));
}

$rows = db()->query("SELECT * FROM notifications ORDER BY id DESC LIMIT 80")->fetchAll(PDO::FETCH_ASSOC) ?: [];
?>

<div class="max-w-4xl">
  <div class="text-2xl font-extrabold">Thông báo</div>
  <div class="text-sm text-slate-400 mt-1">Gửi thông báo cho toàn hệ thống / theo rank / 1 user</div>

  <?php if($m=flash_get('ok')): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($m) ?></div><?php endif; ?>
  <?php if($m=flash_get('error')): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($m) ?></div><?php endif; ?>

  <div class="card p-6 mt-6">
    <div class="text-lg font-extrabold">Tạo thông báo</div>
    <form method="post" class="mt-4 grid sm:grid-cols-2 gap-4">
      <?= csrf_field() ?>
      <div class="sm:col-span-2">
        <label class="label">Tiêu đề</label>
        <input class="input w-full" name="title" placeholder="Ví dụ: Bảo trì 10 phút..." />
      </div>
      <div class="sm:col-span-2">
        <label class="label">Nội dung</label>
        <textarea class="input w-full" name="body" rows="3" placeholder="Nội dung thông báo..."></textarea>
      </div>
      <div class="sm:col-span-2">
        <label class="label">Link (tuỳ chọn)</label>
        <input class="input w-full" name="link_url" placeholder="/dashboard hoặc https://..." />
      </div>

      <div>
        <label class="label">Đối tượng</label>
        <select class="input w-full" name="audience" id="aud">
          <option value="all">Tất cả</option>
          <option value="vip">Chỉ VIP</option>
          <option value="role">Theo Role</option>
          <option value="inactive">User Inactive</option>
          <option value="rank">Theo Rank (rank_slug)</option>
          <option value="user">1 User (user_id)</option>
        </select>
      </div>
      <div>
        <label class="label">rank_slug / user_id</label>
        <input class="input w-full" name="rank_slug" placeholder="rank_slug (nếu theo rank)" />
        <input class="input w-full mt-2" name="user_id" placeholder="user_id (nếu gửi 1 user)" />
      </div>

      <div class="sm:col-span-2">
        <button class="btn btn-primary" type="submit">Gửi thông báo</button>
      </div>
    </form>
  </div>

  <div class="mt-6 card p-6">
    <div class="text-lg font-extrabold">Gần đây</div>
    <div class="mt-4 space-y-3">
      <?php foreach($rows as $n): ?>
        <div class="p-4 rounded-2xl bg-black/25 border border-white/10">
          <div class="flex items-center justify-between gap-3">
            <div class="font-extrabold truncate">#<?= (int)($n['id'] ?? 0) ?> • <?= e($n['title'] ?? '') ?></div>
            <div class="text-xs text-slate-500"><?= e($n['created_at'] ?? '') ?></div>
          </div>
          <div class="text-sm text-slate-300 mt-1 whitespace-pre-line"><?= e($n['body'] ?? '') ?></div>
          <div class="text-xs text-slate-500 mt-2">To user_id: <b><?= (int)($n['user_id'] ?? 0) ?></b></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<script>
(function(){
  const sel = document.querySelector('select[name="audience"]');
  const user = document.getElementById('userFields');
  const rank = document.getElementById('rankFields');
  const role = document.getElementById('roleFields');
  const inactive = document.getElementById('inactiveFields');
  function upd(){
    const v = sel ? sel.value : '';
    if(user) user.classList.toggle('hidden', v!=='user');
    if(rank) rank.classList.toggle('hidden', v!=='rank');
    if(role) role.classList.toggle('hidden', v!=='role');
    if(inactive) inactive.classList.toggle('hidden', v!=='inactive');
  }
  if(sel){ sel.addEventListener('change', upd); upd(); }
})();
</script>
