<?php
csrf_require();
$admin=auth_user(); $aid=(int)$admin['id'];

if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_check();
  $rid=(int)($_POST['id'] ?? 0);
  $act=$_POST['act'] ?? '';
  $note=trim($_POST['note'] ?? '');

  $st=db()->prepare("SELECT rr.*, r.title FROM reward_redemptions rr JOIN rewards r ON r.id=rr.reward_id WHERE rr.id=? LIMIT 1");
  $st->execute([$rid]);
  $row=$st->fetch();
  if(!$row){ flash_set('error','Không tìm thấy đơn đổi quà'); redirect(admin_url('redemptions')); }

  if($act==='approve'){
    db()->prepare("UPDATE reward_redemptions SET status='approved', admin_note=?, updated_at=NOW() WHERE id=?")->execute([$note,$rid]);
    audit_log($aid,'redeem_approve','reward_redemption',(string)$rid,['note'=>$note]);
    notify_user((int)$row['user_id'],'Đổi quà được duyệt','Đơn #'.$rid.' ('.$row['title'].') đã được duyệt. '.$note, route_url('profile',['tab'=>'rewards']));
    flash_set('ok','Đã duyệt đơn #'.$rid);
  } elseif($act==='reject'){
    // refund points
    $uid=(int)$row['user_id']; $cost=(int)$row['cost_points'];
    db()->prepare("UPDATE reward_redemptions SET status='rejected', admin_note=?, updated_at=NOW() WHERE id=?")->execute([$note,$rid]);
    points_add($uid, +$cost, 'redeem_refund', 'redeem_refund:'.$rid, 'Hoàn điểm do từ chối đơn đổi quà #'.$rid);
    audit_log($aid,'redeem_reject','reward_redemption',(string)$rid,['note'=>$note,'refund'=>$cost]);
    notify_user($uid,'Đổi quà bị từ chối','Đơn #'.$rid.' ('.$row['title'].') bị từ chối. Điểm đã được hoàn. '.$note, route_url('profile',['tab'=>'rewards']));
    flash_set('ok','Đã từ chối & hoàn điểm cho đơn #'.$rid);
  }
  redirect(admin_url('redemptions'));
}

$status = $_GET['status'] ?? 'pending';
if(!in_array($status,['pending','approved','rejected','all'],true)) $status='pending';

$sql="SELECT rr.*, u.username, u.name, r.title
      FROM reward_redemptions rr
      JOIN users u ON u.id=rr.user_id
      JOIN rewards r ON r.id=rr.reward_id ";
if($status!=='all') $sql.=" WHERE rr.status=".db()->quote($status);
$sql.=" ORDER BY rr.id DESC LIMIT 120";
$rows=db()->query($sql)->fetchAll() ?: [];
?>
<div class="max-w-6xl">
  <div class="flex items-center justify-between gap-3">
    <div>
      <div class="text-2xl font-extrabold">Đổi quà</div>
      <div class="text-sm text-slate-400 mt-1">Duyệt thủ công • hoàn điểm khi từ chối</div>
    </div>
    <div class="flex gap-2">
      <?php foreach(['pending'=>'Chờ','approved'=>'Đã duyệt','rejected'=>'Từ chối','all'=>'Tất cả'] as $k=>$v): ?>
        <a class="px-3 py-2 rounded-xl border border-white/10 text-sm hover:bg-white/5 <?= $status===$k?'bg-white/5':'' ?>"
           href="<?= e(admin_url('redemptions').'?status='.$k) ?>"><?= e($v) ?></a>
      <?php endforeach; ?>
    </div>
  </div>

  <?php if($m=flash_get('ok')): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($m) ?></div><?php endif; ?>
  <?php if($m=flash_get('error')): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($m) ?></div><?php endif; ?>

  <div class="mt-6 space-y-3">
    <?php if(!$rows): ?>
      <div class="text-slate-400">Không có dữ liệu.</div>
    <?php else: foreach($rows as $r): ?>
      <div class="card p-5">
        <div class="flex items-start justify-between gap-3">
          <div class="min-w-0">
            <div class="font-extrabold">#<?= (int)$r['id'] ?> • <?= e($r['title']) ?></div>
            <div class="text-sm text-slate-300 mt-1">
              User: <b><?= e($r['name'] ?: $r['username']) ?></b> (<?= e($r['username']) ?>) • Cost: <b><?= (int)$r['cost_points'] ?></b> điểm
            </div>
            <div class="text-xs text-slate-500 mt-2">Tạo: <?= e($r['created_at']) ?> • Trạng thái: <b><?= e($r['status']) ?></b></div>
            <?php if(!empty($r['admin_note'])): ?>
              <div class="text-xs text-slate-400 mt-2">Note: <?= e($r['admin_note']) ?></div>
            <?php endif; ?>
          </div>
          <?php if($r['status']==='pending'): ?>
            <form method="post" class="w-full max-w-sm">
              <?= csrf_field() ?>
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <label class="label">Ghi chú admin (tuỳ chọn)</label>
              <input class="input w-full" name="note" placeholder="Ví dụ: gửi mã voucher qua Zalo..." />
              <div class="mt-3 flex gap-2">
                <button class="btn" name="act" value="approve" type="submit">Duyệt</button>
                <button class="btn btn-ghost text-rose-200" name="act" value="reject" type="submit" onclick="return confirm('Từ chối & hoàn điểm?')">Từ chối</button>
              </div>
            </form>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>
