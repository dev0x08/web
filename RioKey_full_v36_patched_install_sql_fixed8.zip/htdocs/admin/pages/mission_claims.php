<?php
require_staff();
if (!(is_admin() || is_mod())) { http_response_code(403); echo 'Forbidden'; return; }

$tbl = 'mission_claims';
$missions = 'missions';

try {
  if (!db_has_column($tbl,'status')) db()->exec("ALTER TABLE {$tbl} ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'approved'");
  if (!db_has_column($tbl,'evidence')) db()->exec("ALTER TABLE {$tbl} ADD COLUMN evidence TEXT NULL");
  if (!db_has_column($tbl,'reviewed_by')) db()->exec("ALTER TABLE {$tbl} ADD COLUMN reviewed_by INT NULL");
  if (!db_has_column($tbl,'reviewed_at')) db()->exec("ALTER TABLE {$tbl} ADD COLUMN reviewed_at DATETIME NULL");
} catch (Throwable $e) {}

$aid = (int)(auth_user()['id'] ?? 0);
$ok=null; $err=null;

if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_require();
  $action = $_POST['action'] ?? '';
  $id = (int)($_POST['id'] ?? 0);

  try {
    $st = db()->prepare("SELECT c.*, m.title, m.points AS mpoints FROM {$tbl} c JOIN {$missions} m ON m.id=c.mission_id WHERE c.id=? LIMIT 1");
    $st->execute([$id]);
    $c = $st->fetch(PDO::FETCH_ASSOC);
    if (!$c) throw new Exception('Claim không tồn tại');

    if ($action==='approve') {
      if (($c['status'] ?? '') === 'approved') {
        $ok='Đã duyệt trước đó.';
      } else {
        db()->beginTransaction();
        db()->prepare("UPDATE {$tbl} SET status='approved', reviewed_by=?, reviewed_at=NOW() WHERE id=?")->execute([$aid,$id]);
        $pts = (int)($c['points'] ?? $c['mpoints'] ?? 0);
        if ($pts > 0) {
          points_add((int)$c['user_id'], $pts, 'mission', 'claim:'.$id, 'Duyệt nhiệm vụ: '.($c['title'] ?? ''));
        }
        db()->commit();
        $ok='Đã duyệt và cộng điểm.';
      }
    }

    if ($action==='reject') {
      db()->prepare("UPDATE {$tbl} SET status='rejected', reviewed_by=?, reviewed_at=NOW() WHERE id=?")->execute([$aid,$id]);
      $ok='Đã từ chối.';
    }
  } catch (Throwable $e) {
    try { db()->rollBack(); } catch(Throwable $x) {}
    $err=$e->getMessage();
  }
}

$rows = db()->query("SELECT c.*, u.name AS user_name, u.username AS user_username, m.title AS mission_title
  FROM mission_claims c
  JOIN users u ON u.id=c.user_id
  JOIN missions m ON m.id=c.mission_id
  WHERE c.status='pending'
  ORDER BY c.id DESC
  LIMIT 200")->fetchAll() ?: [];
?>
<div class="flex items-center justify-between gap-3">
  <div>
    <div class="text-2xl font-extrabold">Duyệt nhiệm vụ</div>
    <div class="text-sm text-slate-400 mt-1">Các yêu cầu nhiệm vụ cần duyệt (chống gian lận).</div>
  </div>
</div>

<?php if($ok): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($ok) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 card p-5">
  <?php if(!$rows): ?>
    <div class="text-slate-400">Không có yêu cầu pending.</div>
  <?php else: ?>
    <div class="space-y-3">
      <?php foreach($rows as $r): ?>
        <div class="rounded-2xl border border-white/10 bg-black/20 p-4">
          <div class="font-extrabold"><?= e($r['mission_title']) ?></div>
          <div class="text-sm text-slate-400 mt-1">
            User: <?= e($r['user_name'] ?? '') ?> <?= !empty($r['user_username']) ? '@'.e($r['user_username']) : '' ?>
            • Claim #<?= (int)$r['id'] ?>
          </div>
          <?php if(!empty($r['evidence'])): ?>
            <div class="text-sm text-slate-200 mt-2 break-all">
              Bằng chứng: <span class="text-amber-200"><?= e($r['evidence']) ?></span>
            </div>
          <?php endif; ?>
          <div class="mt-3 flex gap-2">
            <form method="post" data-once="1">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="approve">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button class="btn">Duyệt</button>
            </form>
            <form method="post" data-once="1">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="reject">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button class="btn btn-ghost">Từ chối</button>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
