<?php
?>
<div class="max-w-3xl">
  <div class="text-2xl font-extrabold">Xuất CSV</div>
  <div class="text-sm text-slate-400 mt-1">Tải dữ liệu về để đối soát</div>

  <div class="mt-6 card p-6">
    <div class="flex flex-wrap gap-2">
      <a class="btn" href="<?= e(base_url('/admin/export.php?type=users')) ?>">Users.csv</a>
      <a class="btn" href="<?= e(base_url('/admin/export.php?type=orders')) ?>">Orders.csv</a>
      <a class="btn" href="<?= e(base_url('/admin/export.php?type=points')) ?>">Points.csv</a>
      <a class="btn" href="<?= e(base_url('/admin/export.php?type=redemptions')) ?>">Redemptions.csv</a>
      <a class="btn" href="<?= e(base_url('/admin/export.php?type=notifications')) ?>">Notifications.csv</a>
      <a class="btn" href="<?= e(base_url('/admin/export.php?type=audit')) ?>">Audit.csv</a>
    </div>
    <div class="text-xs text-slate-500 mt-4">Mẹo: mở bằng Excel/Google Sheets để lọc.</div>
  </div>
</div>
