<?php
$u = auth_user(); require_staff();
$uid = (int)$u['id'];
$role = $u['role'] ?? (is_admin() ? 'admin' : 'mod');

$err=null; $flash=null;

if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_require();
  $action = $_POST['action'] ?? '';
  $id = (int)($_POST['id'] ?? 0);

  if ($action === 'approve') {
    db()->beginTransaction();
    try {
      $st = db()->prepare("SELECT t.*, us.email, us.name FROM topup_requests t JOIN users us ON us.id=t.user_id WHERE t.id=? FOR UPDATE");
      $st->execute([$id]);
      $top = $st->fetch();
      if (!$top) throw new Exception('Không tìm thấy yêu cầu.');
      if ($top['status'] !== 'pending') { db()->commit(); redirect(base_url('/admin/topups')); }

      $amount = (float)$top['amount'];
      if ($role !== 'admin' && !can_approve_topup_amount($amount)) {
        audit_log($uid,'topup_denied_limit','topup',(string)$id,[
          'role'=>$role,'amount'=>$amount,'limit'=>(float)($u['mod_topup_limit'] ?? 0),'code'=>$top['code']
        ]);
        throw new Exception('Vượt hạn mức duyệt nạp của MOD.');
      }

      db()->prepare("UPDATE topup_requests SET status='approved', approved_at=NOW() WHERE id=?")->execute([$id]);
      db()->commit();

      try{ wallet_apply_once((int)$top['user_id'],'topup_approved',$amount,'topup_requests',(int)$id,'Topup approved'); } catch(Throwable $e){}
      try{ achievements_check((int)$top['user_id'],'topup_approved',['amount'=>$amount,'id'=>$id]); } catch(Throwable $e){}
      try{ $xp = xp_from_amount_vnd((int)$amount,'topup'); if($xp>0) user_add_xp((int)$top['user_id'],$xp,'topup'); } catch(Throwable $e){}
      // Tích điểm theo % khi nạp (admin set)
      try{
        $rate = (float)str_replace(',', '.', (string)setting('points_rate_topup','0'));
        if ($rate < 0) $rate = 0; if ($rate > 100) $rate = 100;
        $earn = (int)floor(((float)$amount) * $rate / 100.0);
        if ($earn > 0) points_add((int)$top['user_id'], $earn, 'topup', 'topup:'.$id, 'Tích điểm nạp tiền ('.$rate.'%)');
        // Referral reward for first qualifying topup
        try { referral_try_reward((int)$top['user_id'], 'topup', (int)$amount); } catch (Throwable $e) {}

      } catch(Throwable $e){}
      audit_log($uid,'topup_approve','topup',(string)$id,['role'=>$role,'amount'=>$amount,'code'=>$top['code'],'user_id'=>(int)$top['user_id']]);
      $flash = 'Đã duyệt nạp #' . $top['code'];
    } catch (Throwable $e) {
      db()->rollBack();
      $err = $e->getMessage();
    }
  }

  if ($action === 'reject') {
    $note = trim($_POST['note'] ?? '');
    $st = db()->prepare("SELECT * FROM topup_requests WHERE id=? LIMIT 1");
    $st->execute([$id]);
    $top = $st->fetch();
    if ($top && $top['status']==='pending') {
      db()->prepare("UPDATE topup_requests SET status='rejected', admin_note=? WHERE id=?")->execute([$note,$id]);
      audit_log($uid,'topup_reject','topup',(string)$id,['role'=>$role,'amount'=>(float)$top['amount'],'code'=>$top['code'],'note'=>$note]);
      $flash = 'Đã từ chối nạp #' . $top['code'];
    }
  }
}

$rows = db()->query("SELECT t.*, u.email, u.name FROM topup_requests t JOIN users u ON u.id=t.user_id ORDER BY t.id DESC LIMIT 200")->fetchAll();
?>
<div class="card p-6">
  <div class="flex items-center justify-between gap-3">
    <div>
      <div class="text-xl font-extrabold">Duyệt nạp tiền</div>
      <div class="text-sm text-slate-400 mt-1">MOD chỉ duyệt trong hạn mức. Admin duyệt mọi mức.</div>
    </div>
    <?php if (!is_admin()): ?>
      <div class="text-xs text-slate-400">
        Hạn mức nạp: <span class="font-extrabold text-slate-200"><?=number_format((float)($u['mod_topup_limit'] ?? 0),0,',','.')?>đ</span>
      </div>
    <?php endif; ?>
  </div>

  <?php if ($err): ?>
    <div class="mt-4 rounded-2xl border border-rose-500/30 bg-rose-500/10 text-rose-200 px-4 py-3 text-sm"><?=htmlspecialchars($err)?></div>
  <?php elseif ($flash): ?>
    <div class="mt-4 rounded-2xl border border-emerald-500/25 bg-emerald-500/10 text-emerald-200 px-4 py-3 text-sm"><?=htmlspecialchars($flash)?></div>
  <?php endif; ?>

  <div class="mt-4 overflow-hidden rounded-2xl border border-white/10">
    <table class="w-full text-sm">
      <thead class="bg-white/5 text-slate-300">
        <tr>
          <th class="text-left px-4 py-3">Mã</th>
          <th class="text-left px-4 py-3">User</th>
          <th class="text-right px-4 py-3">Số tiền</th>
          <th class="text-left px-4 py-3">Nội dung</th>
          <th class="text-left px-4 py-3">Trạng thái</th>
          <th class="text-right px-4 py-3">Thao tác</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-white/5">
      <?php foreach($rows as $t):
        $status=$t['status'];
        $pill = $status==='approved' ? 'bg-emerald-500/15 text-emerald-200 border-emerald-500/20'
              : ($status==='rejected' ? 'bg-rose-500/15 text-rose-200 border-rose-500/20'
              : 'bg-amber-500/15 text-amber-200 border-amber-500/20');
        $amount=(float)$t['amount'];
        $can = is_admin() ? true : can_approve_topup_amount($amount);
      ?>
        <tr class="hover:bg-white/5">
          <td class="px-4 py-3 font-semibold">#<?=htmlspecialchars($t['code'])?></td>
          <td class="px-4 py-3">
            <div class="font-semibold"><?=htmlspecialchars($t['name'])?></div>
            <div class="text-xs text-slate-400"><?=htmlspecialchars($t['email'])?></div>
          </td>
          <td class="px-4 py-3 text-right font-extrabold"><?=number_format($amount,0,',','.')?>đ</td>
          <td class="px-4 py-3 text-slate-200 font-semibold"><?=htmlspecialchars($t['pay_note'])?></td>
          <td class="px-4 py-3">
            <span class="inline-flex items-center rounded-full border px-3 py-1 text-xs font-extrabold <?=$pill?>">
              <?= $status==='approved'?'Đã duyệt':($status==='rejected'?'Từ chối':'Chờ duyệt') ?>
            </span>
          </td>
          <td class="px-4 py-3 text-right">
            <?php if ($status==='pending'): ?>
              <form method="post" class="inline-flex gap-2 items-center justify-end">
                <?=csrf_field()?>
                <input type="hidden" name="id" value="<?=$t['id']?>">
                <button name="action" value="approve"
                  class="btn btn-primary !px-4 !py-2 rounded-xl <?= $can?'':'opacity-40 pointer-events-none' ?>"
                  title="<?= $can?'':'Vượt hạn mức' ?>">Duyệt</button>
                <button name="action" value="reject"
                  class="btn btn-ghost !px-4 !py-2 rounded-xl">Từ chối</button>
              </form>
            <?php else: ?>
              <span class="text-xs text-slate-500">—</span>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if(!$rows): ?>
        <tr><td colspan="6" class="px-4 py-6 text-center text-slate-500">Chưa có yêu cầu nạp.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
