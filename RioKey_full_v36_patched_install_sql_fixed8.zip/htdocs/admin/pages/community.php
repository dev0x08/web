<?php
$flash=null; $err=null;

if($_SERVER['REQUEST_METHOD']==='POST' && (($_POST['action'] ?? '')==='community_settings')){
  csrf_require();
  setting_set('community_enabled', isset($_POST['community_enabled']) ? '1' : '0');
  setting_set('community_min_days', trim((string)($_POST['community_min_days'] ?? '30')));
  setting_set('community_min_topup', trim((string)($_POST['community_min_topup'] ?? '0')));
  $flash='Đã lưu cài đặt Community.';
  redirect(admin_url('community'));
}

$tbl='community_posts';
$hasExcerpt = db_has_column($tbl,'excerpt');
$hasPinned  = db_has_column($tbl,'is_pinned');
$hasActive  = db_has_column($tbl,'is_active');
$hasUserId  = db_has_column($tbl,'user_id');
$hasApproved = db_has_column($tbl,'is_approved');
$hasLocked = db_has_column($tbl,'is_locked');

$edit_id = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$editPost = null;

if($edit_id>0){
  $st=db()->prepare("SELECT * FROM {$tbl} WHERE id=? LIMIT 1");
  $st->execute([$edit_id]);
  $editPost=$st->fetch(PDO::FETCH_ASSOC) ?: null;
$selTagIds = [];
if($editPost){
  try{
    $stt=db()->prepare("SELECT tag_id FROM community_post_tags WHERE post_id=?");
    $stt->execute([(int)$editPost['id']]);
    $selTagIds=array_map('intval', array_column($stt->fetchAll(PDO::FETCH_ASSOC)?:[],'tag_id'));
  } catch (Throwable $e) { $selTagIds=[]; }
}
}

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_require();
  $action=$_POST['action']??'';

  if($action==='save'){
    community_ensure_schema();
    $id=(int)($_POST['id']??0);
    $title=trim($_POST['title']??'');
    $content=trim($_POST['content']??'');
    $excerpt=trim($_POST['excerpt']??'');
    $pinned=isset($_POST['is_pinned'])?1:0;
    $active=isset($_POST['is_active'])?1:0;
    $approved=isset($_POST['is_approved'])?1:0;
    $locked=isset($_POST['is_locked'])?1:0;
    $tag_ids = $_POST['tag_ids'] ?? [];
    if (!is_array($tag_ids)) $tag_ids = [];
    $tag_ids = array_values(array_unique(array_map('intval',$tag_ids)));

    if($title==='' || $content===''){ $err='Vui lòng nhập tiêu đề và nội dung.'; }
    else{
      // derive excerpt if not provided or column not supported
      if(!$hasExcerpt){
        $excerpt='';
      } else {
        if($excerpt===''){
          $raw=$content;
          $excerpt=function_exists('mb_substr') ? mb_substr($raw,0,160,'UTF-8') : substr($raw,0,160);
          if(strlen($raw)>160) $excerpt.='...';
        }
      }

      $cols=['title','content'];
      $vals=[$title,$content];

      if($hasExcerpt){ $cols[]='excerpt'; $vals[]=$excerpt; }
      if($hasPinned){ $cols[]='is_pinned'; $vals[]=$pinned; }
      if($hasActive){ $cols[]='is_active'; $vals[]=$active; }
      if($hasApproved){ $cols[]='is_approved'; $vals[]=$approved; }
      if($hasLocked){ $cols[]='is_locked'; $vals[]=$locked; }

      if($id>0){
        // history
        try {
          $old = db()->prepare("SELECT title, content FROM {$tbl} WHERE id=? LIMIT 1");
          $old->execute([$id]);
          if($o=$old->fetch(PDO::FETCH_ASSOC)){
            if ((string)$o['title'] !== (string)$title || (string)$o['content'] !== (string)$content) {
              db()->prepare("INSERT INTO community_edits(post_id,editor_id,old_title,old_content,note,created_at) VALUES(?,?,?,?,?,NOW())")
                ->execute([$id,(int)((auth_user()['id']??0)), (string)$o['title'], (string)$o['content'], 'admin_edit']);
            }
          }
        } catch (Throwable $e) {}

        $set = implode(',', array_map(fn($c)=>"{$c}=?", $cols));
        $vals[]=$id;
        db()->prepare("UPDATE {$tbl} SET {$set} WHERE id=?")->execute($vals);
        // sync tags
        try {
          db()->prepare("DELETE FROM community_post_tags WHERE post_id=?")->execute([$id]);
          foreach($tag_ids as $tid){ db()->prepare("INSERT INTO community_post_tags(post_id,tag_id) VALUES(?,?)")->execute([$id,$tid]); }
        } catch (Throwable $e) {}
        $flash='Đã cập nhật bài viết.';
        redirect(admin_url('community',['edit'=>$id]));
      } else {
        if($hasUserId){
          $cols[]='user_id';
          $vals[]= (int)((auth_user()['id'] ?? 0) ?: 1);
        }
        $cols[]='created_at';
        $place = implode(',', array_fill(0,count($cols),'?'));
        $vals[] = date('Y-m-d H:i:s');
        db()->prepare("INSERT INTO {$tbl}(".implode(',',$cols).") VALUES({$place})")->execute($vals);
        $newId=(int)db()->lastInsertId();
        // sync tags
        try {
          db()->prepare("DELETE FROM community_post_tags WHERE post_id=?")->execute([$newId]);
          foreach($tag_ids as $tid){ db()->prepare("INSERT INTO community_post_tags(post_id,tag_id) VALUES(?,?)")->execute([$newId,$tid]); }
        } catch (Throwable $e) {}
        $flash='Đã thêm bài viết.';
        redirect(admin_url('community'));
      }
    }
  }

  if($action==='delete'){
    $id=(int)($_POST['id']??0);
    if($id>0){
      db()->prepare("DELETE FROM {$tbl} WHERE id=?")->execute([$id]);
      $flash='Đã xoá.';
      redirect(admin_url('community'));
    }
  }
}

// list
$order = 'ORDER BY id DESC';
if($hasPinned) $order = 'ORDER BY is_pinned DESC, id DESC';
$posts = db()->query("SELECT * FROM {$tbl} {$order} LIMIT 50")->fetchAll(PDO::FETCH_ASSOC) ?: [];
$tags = db()->query("SELECT * FROM community_tags ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
?>
<h1 class="text-2xl font-black">Community Posts</h1>
<p class="text-slate-400 mt-1">Thêm/sửa/xoá bài viết Community.</p>

<div class="mt-6 card p-5 max-w-3xl">
  <div class="text-lg font-extrabold">Cài đặt Community</div>
  <div class="text-sm text-slate-400 mt-1">Bật/tắt + điều kiện được đăng bài/bình luận.</div>

  <form method="post" class="mt-4 space-y-4" data-once="1">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="community_settings">

    <?php
      $ce = (int)setting('community_enabled', 1)===1;
      $md = (int)setting('community_min_days', 30);
      $mt = (int)setting('community_min_topup', 0);
    ?>

    <label class="flex items-center gap-2 text-sm text-slate-200">
      <input type="checkbox" name="community_enabled" <?= $ce?'checked':'' ?>> Bật Community
    </label>

    <div class="grid sm:grid-cols-2 gap-4">
      <div>
        <label class="text-sm text-slate-300">Tài khoản tối thiểu (ngày)</label>
        <input class="input mt-1" name="community_min_days" value="<?= (int)$md ?>">
      </div>
      <div>
        <label class="text-sm text-slate-300">Tổng nạp tối thiểu (VNĐ)</label>
        <input class="input mt-1" name="community_min_topup" value="<?= (int)$mt ?>">
      </div>
    </div>

    <div class="text-xs text-slate-500">User được đăng nếu đủ <b>một trong hai</b> điều kiện.</div>
    <button class="btn" type="submit">Lưu</button>
  </form>
</div>


<?php if($flash): ?><div class="mt-4 rounded-2xl border border-emerald-500/25 bg-emerald-500/10 p-4 text-emerald-200 text-sm"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 rounded-2xl border border-rose-500/25 bg-rose-500/10 p-4 text-rose-200 text-sm"><?= e($err) ?></div><?php endif; ?>

<div class="grid lg:grid-cols-3 gap-4 mt-6">
  <div class="card p-5 lg:col-span-1">
    <div class="font-extrabold"><?= $editPost?'Sửa bài viết':'Thêm bài viết' ?></div>
    <form method="post" class="mt-4 space-y-3">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?= (int)($editPost['id'] ?? 0) ?>">

      <div>
        <label>Tiêu đề</label>
        <input class="input" name="title" value="<?= e($editPost['title'] ?? '') ?>" required>
      </div>

      <?php if($hasExcerpt): ?>
      <div>
        <label>Excerpt</label>
        <input class="input" name="excerpt" value="<?= e($editPost['excerpt'] ?? '') ?>" placeholder="Tóm tắt ngắn (tuỳ chọn)">
      </div>
      <?php endif; ?>

      <div>
        <label>Nội dung</label>
        <textarea class="input" name="content" rows="8" required><?= e($editPost['content'] ?? '') ?></textarea>
      </div>

      <div class="flex flex-wrap items-center gap-4 pt-1">
        <?php if($hasPinned): ?>
          <label class="inline-flex items-center gap-2 text-sm"><input type="checkbox" name="is_pinned" value="1" <?= ((int)($editPost['is_pinned'] ?? 0)===1?'checked':'') ?>> Pinned</label>
        <?php endif; ?>
        <?php if($hasActive): ?>
          <label class="inline-flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" <?= ((int)($editPost['is_active'] ?? 1)===1?'checked':'') ?>> Active</label>
        <?php endif; ?>
      </div>

      <div class="flex flex-wrap items-center gap-4 pt-1">
        <?php if($hasApproved): ?>
          <label class="inline-flex items-center gap-2 text-sm"><input type="checkbox" name="is_approved" value="1" <?= ((int)($editPost['is_approved'] ?? 1)===1?'checked':'') ?>> Approved</label>
        <?php endif; ?>
        <?php if($hasLocked): ?>
          <label class="inline-flex items-center gap-2 text-sm"><input type="checkbox" name="is_locked" value="1" <?= ((int)($editPost['is_locked'] ?? 0)===1?'checked':'') ?>> Locked</label>
        <?php endif; ?>
      </div>

      <?php if($tags): ?>
      <div class="pt-2">
        <div class="text-sm text-slate-300 font-semibold mb-2">Tags</div>
        <div class="flex flex-wrap gap-2">
          <?php foreach($tags as $t): ?>
            <label class="inline-flex items-center gap-2 text-sm px-3 py-2 rounded-2xl bg-white/5 border border-white/5">
              <input type="checkbox" name="tag_ids[]" value="<?= (int)$t['id'] ?>" <?= in_array((int)$t['id'],$selTagIds,true)?'checked':'' ?>>
              <span><?= e($t['name'] ?? '') ?></span>
            </label>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>

      <div class="flex items-center justify-end gap-2 pt-2"> gap-2 pt-2">
        <?php if($editPost): ?>
          <a class="btn btn-ghost" href="<?= e(admin_url('community')) ?>">Huỷ</a>
        <?php endif; ?>
        <button class="btn btn-primary"><?= $editPost?'Lưu':'Thêm' ?></button>
      </div>
    </form>
  </div>

  <div class="card p-5 lg:col-span-2">
    <div class="font-extrabold">Danh sách</div>
    <div class="mt-4 space-y-3">
      <?php foreach($posts as $p): ?>
        <div class="rounded-2xl border border-white/10 bg-white/5 p-4 flex items-start justify-between gap-3">
          <div class="min-w-0">
            <div class="font-bold text-slate-100 truncate"><?= e($p['title'] ?? '') ?></div>
            <?php
              $meta=[];
              if($hasPinned && (int)($p['is_pinned']??0)===1) $meta[]='PIN';
              if($hasActive) $meta[] = ((int)($p['is_active']??1)===1?'ON':'OFF');
              $meta[] = $p['created_at'] ?? '';
            ?>
            <div class="text-xs text-slate-500 mt-1"><?= e(implode(' • ', array_filter($meta))) ?></div>
          </div>
          <div class="flex items-center gap-2 shrink-0">
            <a class="btn btn-ghost !px-3 !py-2" href="<?= e(admin_url('community',['edit'=>(int)($p['id']??0)])) ?>">Sửa</a>
            <form method="post" onsubmit="return confirm('Xoá bài viết?')">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= (int)($p['id']??0) ?>">
              <button class="btn btn-ghost !px-3 !py-2">Xoá</button>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
      <?php if(!$posts): ?><div class="text-slate-500 text-sm">Chưa có bài viết.</div><?php endif; ?>
    </div>
  </div>
</div>