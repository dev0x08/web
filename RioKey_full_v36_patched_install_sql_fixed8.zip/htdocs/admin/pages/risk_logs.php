<?php
require_staff();
security_ensure_schema();
risk_ensure_schema();

$flash=null; $err=null;

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_require();
  $act=(string)($_POST['action']??'');
  try {
    if($act==='mute'){
      $uid=(int)($_POST['user_id']??0);
      $mins=(int)($_POST['minutes']??60);
      if($uid<=0) throw new Exception('Thiếu user_id');
      if($mins<1) $mins=60;
      if (db_has_column('users','mute_until')) {
        db()->prepare("UPDATE users SET mute_until=DATE_ADD(NOW(), INTERVAL ? MINUTE) WHERE id=?")->execute([$mins,$uid]);
      }
      audit_log((int)auth_user()['id'],'user_mute', json_encode(['user_id'=>$uid,'minutes'=>$mins],JSON_UNESCAPED_UNICODE));
      $flash='Đã mute user.';
      redirect(admin_url('risk_logs'));
    }

    if($act==='ban' || $act==='unban'){
      if(!is_admin()) throw new Exception('Chỉ Admin được ban/unban.');
      $uid=(int)($_POST['user_id']??0);
      if($uid<=0) throw new Exception('Thiếu user_id');
      $reason=trim((string)($_POST['reason']??''));
      if (db_has_column('users','is_banned')) {
        if($act==='ban'){
          db()->prepare("UPDATE users SET is_banned=1, ban_reason=? WHERE id=?")->execute([$reason,$uid]);
          audit_log((int)auth_user()['id'],'user_ban', json_encode(['user_id'=>$uid,'reason'=>$reason],JSON_UNESCAPED_UNICODE));
          $flash='Đã ban user.';
        } else {
          db()->prepare("UPDATE users SET is_banned=0, ban_reason=NULL WHERE id=?")->execute([$uid]);
          audit_log((int)auth_user()['id'],'user_unban', json_encode(['user_id'=>$uid],JSON_UNESCAPED_UNICODE));
          $flash='Đã unban user.';
        }
      }
      redirect(admin_url('risk_logs'));
    }

    if($act==='block_ip' || $act==='unblock_ip'){
      $ip=trim((string)($_POST['ip']??''));
      if($ip==='') throw new Exception('Thiếu ip');
      if($act==='block_ip'){
        $mins=(int)($_POST['minutes']??(int)setting('ip_req_block_minutes',5));
        if($mins<1) $mins=5;
        $reason=trim((string)($_POST['reason']??'Manual block'));
        ip_block($ip, $reason, $mins, (int)auth_user()['id']);
        audit_log((int)auth_user()['id'],'ip_block', json_encode(['ip'=>$ip,'minutes'=>$mins,'reason'=>$reason],JSON_UNESCAPED_UNICODE));
        $flash='Đã block IP.';
      } else {
        ip_unblock($ip);
        audit_log((int)auth_user()['id'],'ip_unblock', json_encode(['ip'=>$ip],JSON_UNESCAPED_UNICODE));
        $flash='Đã unblock IP.';
      }
      redirect(admin_url('risk_logs'));
    }

    if($act==='resolve_flag'){
      $id=(int)($_POST['id']??0);
      if($id<=0) throw new Exception('Thiếu flag id');
      db()->prepare("UPDATE risk_flags SET status='resolved', updated_at=NOW() WHERE id=?")->execute([$id]);
      $flash='Đã resolve flag.';
      redirect(admin_url('risk_logs'));
    }

  } catch (Throwable $e) { $err=$e->getMessage(); }
}

$type = trim((string)($_GET['type'] ?? ''));
$uid = (int)($_GET['user_id'] ?? 0);
$ip  = trim((string)($_GET['ip'] ?? ''));
$limit = 200;

$where = "WHERE 1=1";
$params = [];
if($type!==''){ $where.=" AND type=?"; $params[]=$type; }
if($uid>0){ $where.=" AND user_id=?"; $params[]=$uid; }
if($ip!==''){ $where.=" AND ip=?"; $params[]=$ip; }

$st = db()->prepare("SELECT l.*, u.username FROM security_logs l LEFT JOIN users u ON u.id=l.user_id {$where} ORDER BY l.id DESC LIMIT {$limit}");
$st->execute($params);
$rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

$types = db()->query("SELECT type, COUNT(*) c FROM security_logs GROUP BY type ORDER BY c DESC")->fetchAll(PDO::FETCH_ASSOC) ?: [];

$flags = db()->query("SELECT f.*, u.username FROM risk_flags f LEFT JOIN users u ON u.id=f.user_id WHERE f.status='open' ORDER BY f.score DESC, f.id DESC LIMIT 30")->fetchAll(PDO::FETCH_ASSOC) ?: [];
?>
<div class="flex items-start justify-between gap-4">
  <div>
    <div class="text-2xl font-extrabold">Risk Logs</div>
    <div class="text-sm text-slate-400 mt-1">Timeline hành vi + auto-flag + one-click mute/ban/block IP.</div>
  </div>
</div>

<?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 grid lg:grid-cols-3 gap-4">
  <div class="lg:col-span-2 card p-5">
    <form method="get" class="grid sm:grid-cols-4 gap-3">
      <div>
        <label class="label">Type</label>
        <select class="input w-full" name="type">
          <option value="">-- tất cả --</option>
          <?php foreach($types as $t): ?>
            <option value="<?= e($t['type']) ?>" <?= ($type===$t['type'])?'selected':'' ?>><?= e($t['type']) ?> (<?= (int)$t['c'] ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="label">user_id</label>
        <input class="input w-full" name="user_id" value="<?= $uid>0 ? (int)$uid : '' ?>" placeholder="123">
      </div>
      <div>
        <label class="label">ip</label>
        <input class="input w-full" name="ip" value="<?= e($ip) ?>" placeholder="1.2.3.4">
      </div>
      <div class="flex items-end">
        <button class="btn w-full" type="submit">Lọc</button>
      </div>
    </form>
  </div>

  <div class="card p-5">
    <div class="font-extrabold text-lg">Auto Flags (open)</div>
    <div class="text-sm text-slate-400 mt-1">Hành vi nghi vấn (tự tạo từ rules).</div>
    <div class="mt-4 space-y-2">
      <?php if(!$flags): ?>
        <div class="text-sm text-slate-500">Chưa có.</div>
      <?php else: foreach($flags as $f): ?>
        <div class="p-3 rounded-2xl bg-white/5 border border-white/5">
          <div class="flex items-center justify-between gap-2">
            <div class="font-semibold"><?= e($f['type'] ?? '') ?></div>
            <div class="text-xs text-orange-200 font-extrabold">score <?= (int)($f['score'] ?? 1) ?></div>
          </div>
          <div class="text-xs text-slate-500 mt-1"><?= e($f['reason'] ?? '') ?></div>
          <div class="text-xs text-slate-500 mt-1">
            <?= !empty($f['username']) ? e($f['username']).' #'.(int)$f['user_id'] : '' ?>
            <?= !empty($f['ip']) ? (' • '.e($f['ip'])) : '' ?>
          </div>
          <div class="mt-2 flex gap-2">
            <form method="post" data-once="1" class="inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="resolve_flag">
              <input type="hidden" name="id" value="<?= (int)$f['id'] ?>">
              <button class="btn btn-ghost" type="submit">Resolve</button>
            </form>
            <?php if(!empty($f['user_id'])): ?>
              <form method="post" data-once="1" class="inline">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="mute">
                <input type="hidden" name="user_id" value="<?= (int)$f['user_id'] ?>">
                <input type="hidden" name="minutes" value="1440">
                <button class="btn" type="submit">Mute 1d</button>
              </form>
            <?php endif; ?>
            <?php if(!empty($f['ip'])): ?>
              <form method="post" data-once="1" class="inline" onsubmit="return confirm('Block IP này?');">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="block_ip">
                <input type="hidden" name="ip" value="<?= e($f['ip']) ?>">
                <input type="hidden" name="minutes" value="60">
                <input type="hidden" name="reason" value="Auto-flag block">
                <button class="btn" type="submit">Block 60m</button>
              </form>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>
</div>

<div class="mt-4 card p-5 overflow-x-auto">
  <table class="min-w-full text-sm">
    <thead class="text-slate-400">
      <tr>
        <th class="text-left px-3 py-2">Time</th>
        <th class="text-left px-3 py-2">Type</th>
        <th class="text-left px-3 py-2">User</th>
        <th class="text-left px-3 py-2">IP</th>
        <th class="text-left px-3 py-2">Details</th>
        <th class="text-right px-3 py-2"></th>
      </tr>
    </thead>
    <tbody class="divide-y divide-white/5">
      <?php if(!$rows): ?>
        <tr><td colspan="6" class="px-3 py-4 text-slate-500">Chưa có log.</td></tr>
      <?php else: foreach($rows as $r): ?>
        <tr>
          <td class="px-3 py-3 text-xs text-slate-500"><?= e($r['created_at'] ?? '') ?></td>
          <td class="px-3 py-3 font-semibold"><?= e($r['type'] ?? '') ?></td>
          <td class="px-3 py-3"><?= e($r['username'] ?? 'system') ?> <?= $r['user_id'] ? ('#'.(int)$r['user_id']) : '' ?></td>
          <td class="px-3 py-3"><?= e($r['ip'] ?? '') ?></td>
          <td class="px-3 py-3"><div class="text-xs text-slate-400 break-words"><?= e($r['details'] ?? '') ?></div></td>
          <td class="px-3 py-3 text-right">
            <div class="inline-flex flex-wrap justify-end gap-2">
              <?php if(!empty($r['ip'])): ?>
                <form method="post" data-once="1" class="inline" onsubmit="return confirm('Block IP này 10 phút?');">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="block_ip">
                  <input type="hidden" name="ip" value="<?= e($r['ip']) ?>">
                  <input type="hidden" name="minutes" value="10">
                  <input type="hidden" name="reason" value="Manual block from risk logs">
                  <button class="btn btn-ghost" type="submit">Block 10m</button>
                </form>
              <?php endif; ?>

              <?php if(!empty($r['user_id'])): ?>
                <form method="post" data-once="1" class="inline">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="mute">
                  <input type="hidden" name="user_id" value="<?= (int)$r['user_id'] ?>">
                  <input type="hidden" name="minutes" value="60">
                  <button class="btn btn-ghost" type="submit">Mute 60m</button>
                </form>

                <?php if(is_admin()): ?>
                  <form method="post" data-once="1" class="inline" onsubmit="return confirm('BAN user này?');">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="ban">
                    <input type="hidden" name="user_id" value="<?= (int)$r['user_id'] ?>">
                    <input type="hidden" name="reason" value="Ban from risk logs">
                    <button class="btn" type="submit">BAN</button>
                  </form>

                  <form method="post" data-once="1" class="inline" onsubmit="return confirm('UNBAN user này?');">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="unban">
                    <input type="hidden" name="user_id" value="<?= (int)$r['user_id'] ?>">
                    <button class="btn btn-ghost" type="submit">UNBAN</button>
                  </form>
                <?php endif; ?>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>
