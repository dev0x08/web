<?php
require_staff();
csrf_require();
app_links_ensure_schema();

$flash=null; $err=null;

$edit_id = (int)($_GET['edit'] ?? 0);
$edit = $edit_id ? app_link_get($edit_id) : null;

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  $action = $_POST['action'] ?? '';
  try{
    if($action==='create'){
      $res = app_link_create($_POST);
      if(!$res['ok']) throw new Exception($res['error'] ?? 'Lỗi tạo link');
      $flash = 'Đã tạo link tải app.';
      $edit_id = 0; $edit = null;
    }elseif($action==='update'){
      $id = (int)($_POST['id'] ?? 0);
      $res = app_link_update($id, $_POST);
      if(!$res['ok']) throw new Exception($res['error'] ?? 'Lỗi cập nhật');
      $flash = 'Đã cập nhật.';
      $edit_id = 0; $edit = null;
    }elseif($action==='delete'){
      $id = (int)($_POST['id'] ?? 0);
      $res = app_link_delete($id);
      if(!$res['ok']) throw new Exception($res['error'] ?? 'Lỗi xoá');
      $flash = 'Đã xoá link.';
      if($edit_id===$id){ $edit_id=0; $edit=null; }
    }elseif($action==='reset_used'){
      $id = (int)($_POST['id'] ?? 0);
      $res = app_link_reset_used($id);
      if(!$res['ok']) throw new Exception($res['error'] ?? 'Lỗi reset');
      $flash = 'Đã reset trạng thái đã dùng.';
    }elseif($action==='regen_token'){
      $id = (int)($_POST['id'] ?? 0);
      $res = app_link_regen_token($id);
      if(!$res['ok']) throw new Exception($res['error'] ?? 'Lỗi regen');
      $flash = 'Đã tạo token mới (và reset used).';
    }else{
      throw new Exception('Action không hợp lệ.');
    }
  }catch(Throwable $e){
    $err=$e->getMessage();
  }
}

$rows = app_links_admin_list(400);
?>
<div class="flex items-start justify-between gap-4">
  <div>
    <div class="text-2xl font-extrabold">Link tải App</div>
    <div class="text-sm text-slate-400 mt-1">Quản lý link tải: <b>1 lần</b> hoặc <b>vĩnh viễn</b>. Trang user: <span class="text-orange-200">/app</span></div>
  </div>
  <div class="flex gap-2">
    <a class="btn btn-ghost" href="<?= e(route_url('app')) ?>" target="_blank">Mở trang tải app</a>
  </div>
</div>

<?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 grid lg:grid-cols-3 gap-4">
  <div class="lg:col-span-2 card p-5">
    <div class="flex items-center justify-between gap-3">
      <div class="font-extrabold text-lg">Danh sách link</div>
      <div class="text-xs text-slate-500">Tip: link “1 lần” phù hợp cho file nhạy cảm.</div>
    </div>

    <div class="mt-4 overflow-auto">
      <table class="min-w-full text-sm">
        <thead>
          <tr class="text-left text-slate-400">
            <th class="py-2 pr-4">App</th>
            <th class="py-2 pr-4">Chế độ</th>
            <th class="py-2 pr-4">Trạng thái</th>
            <th class="py-2 pr-4">Tải</th>
            <th class="py-2 pr-4">Token</th>
            <th class="py-2 pr-2 text-right">Hành động</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-white/10">
          <?php if(!$rows): ?>
            <tr><td class="py-4 text-slate-500" colspan="6">Chưa có link.</td></tr>
          <?php else: foreach($rows as $r): ?>
            <tr class="align-top">
              <td class="py-3 pr-4">
                <div class="flex items-start gap-3">
                  <?php if(!empty($r['cover_image'])): ?>
                    <img src="<?= e((string)$r['cover_image']) ?>" alt="cover" class="w-12 h-12 rounded-xl object-cover border border-white/10" loading="lazy" />
                  <?php else: ?>
                    <div class="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-slate-500 text-xs">APP</div>
                  <?php endif; ?>
                  <div class="min-w-0">
                    <div class="font-extrabold"><?= e($r['title'] ?? '') ?></div>
                    <div class="text-xs text-slate-500 mt-1"><?= e($r['platform'] ?? '') ?></div>
                    <?php if(!empty($r['description'])): ?>
                      <div class="text-xs text-slate-600 mt-1 line-clamp-2"><?= e((string)$r['description']) ?></div>
                    <?php endif; ?>
                    <div class="text-xs text-slate-600 mt-2">Chính: <?= e(substr((string)($r['url'] ?? ''),0,56)) ?><?= strlen((string)($r['url'] ?? ''))>56?'…':'' ?></div>
                    <?php if(!empty($r['url_backup'])): ?>
                      <div class="text-xs text-slate-600 mt-1">Dự phòng: <?= e(substr((string)($r['url_backup'] ?? ''),0,56)) ?><?= strlen((string)($r['url_backup'] ?? ''))>56?'…':'' ?></div>
                    <?php endif; ?>
                  </div>
                </div>
                <?php if(!empty($r['used_at'])): ?>
                  <div class="text-xs text-orange-200 mt-1">Used: <?= e($r['used_at']) ?><?= !empty($r['used_ip'])?' • '.e($r['used_ip']):'' ?></div>
                <?php endif; ?>
              </td>
              <td class="py-3 pr-4">
                <?php if(($r['mode'] ?? '')==='once'): ?>
                  <span class="px-2 py-1 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-200">1 lần</span>
                <?php else: ?>
                  <span class="px-2 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-200">Vĩnh viễn</span>
                <?php endif; ?>
              </td>
              <td class="py-3 pr-4">
                <?php if((int)($r['is_active'] ?? 0)===1): ?>
                  <span class="px-2 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-200">ON</span>
                <?php else: ?>
                  <span class="px-2 py-1 rounded-full bg-rose-500/10 border border-rose-500/20 text-rose-200">OFF</span>
                <?php endif; ?>
              </td>
              <td class="py-3 pr-4"><?= (int)($r['downloads'] ?? 0) ?></td>
              <td class="py-3 pr-4">
                <div class="text-xs text-slate-300"><?= e(substr((string)$r['token'],0,12)) ?>…</div>
                <a class="text-xs text-orange-200 hover:underline" target="_blank" href="<?= e(route_url('app_download',['token'=>(string)$r['token'],'src'=>'primary'])) ?>">Test chính</a>
                <?php if(!empty($r['url_backup'])): ?>
                  <div><a class="text-xs text-orange-200 hover:underline" target="_blank" href="<?= e(route_url('app_download',['token'=>(string)$r['token'],'src'=>'backup'])) ?>">Test dự phòng</a></div>
                <?php endif; ?>
              </td>
              <td class="py-3 pr-2 text-right">
                <div class="flex justify-end gap-2 flex-wrap">
                  <a class="btn btn-ghost" href="<?= e(admin_url('apps',['edit'=>(int)$r['id']])) ?>">Sửa</a>

                  <?php if(($r['mode'] ?? '')==='once'): ?>
                    <form method="post" data-once="1" onsubmit="return confirm('Reset used cho link 1 lần?');">
                      <?= csrf_field() ?>
                      <input type="hidden" name="action" value="reset_used">
                      <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                      <button class="btn btn-ghost" type="submit">Reset</button>
                    </form>
                    <form method="post" data-once="1" onsubmit="return confirm('Tạo token mới? Link cũ sẽ mất hiệu lực.');">
                      <?= csrf_field() ?>
                      <input type="hidden" name="action" value="regen_token">
                      <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                      <button class="btn btn-ghost" type="submit">Token mới</button>
                    </form>
                  <?php endif; ?>

                  <form method="post" data-once="1" onsubmit="return confirm('Xoá link này?');">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                    <button class="btn btn-danger" type="submit">Xoá</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="card p-5">
    <div class="font-extrabold text-lg"><?= $edit?'Cập nhật link':'Tạo link mới' ?></div>
    <div class="text-sm text-slate-400 mt-1">Chế độ “1 lần” chỉ mở được 1 lần toàn hệ thống.</div>

    <form method="post" class="mt-4 space-y-3" data-once="1">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="<?= $edit?'update':'create' ?>">
      <?php if($edit): ?><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><?php endif; ?>

      <div>
        <div class="text-xs text-slate-500 mb-1">Tên app</div>
        <input class="input w-full" name="title" value="<?= e($edit['title'] ?? '') ?>" placeholder="RioKey Android / iOS / PC...">
      </div>

      <div>
        <div class="text-xs text-slate-500 mb-1">Platform</div>
        <input class="input w-full" name="platform" value="<?= e($edit['platform'] ?? '') ?>" placeholder="Android / iOS / Windows...">
      </div>

      <div>
        <div class="text-xs text-slate-500 mb-1">Mô tả</div>
        <textarea class="input w-full" name="description" rows="4" placeholder="Mô tả ngắn: tính năng, yêu cầu, lưu ý... (hiển thị ở /app)"><?= e($edit['description'] ?? '') ?></textarea>
      </div>

      <div>
        <div class="text-xs text-slate-500 mb-1">Ảnh cover (URL)</div>
        <input class="input w-full" name="cover_image" value="<?= e($edit['cover_image'] ?? '') ?>" placeholder="https://.../cover.jpg">
        <div class="text-[11px] text-slate-500 mt-1">Có thể là link ảnh CDN/Drive direct. Nếu bỏ trống sẽ hiện placeholder.</div>
      </div>

      <div>
        <div class="text-xs text-slate-500 mb-1">Hình ảnh mô tả (nhiều URL)</div>
        <textarea class="input w-full" name="images" rows="4" placeholder="Mỗi dòng 1 link ảnh hoặc phân cách bằng dấu phẩy."><?= e($edit['images'] ?? '') ?></textarea>
      </div>

      <div>
        <div class="text-xs text-slate-500 mb-1">Link tải chính</div>
        <textarea class="input w-full" name="url" rows="3" placeholder="https://..."><?= e($edit['url'] ?? '') ?></textarea>
      </div>

      <div>
        <div class="text-xs text-slate-500 mb-1">Link tải dự phòng (tuỳ chọn)</div>
        <textarea class="input w-full" name="url_backup" rows="3" placeholder="https://... (bỏ trống thì /app sẽ tự ẩn nút dự phòng)"><?= e($edit['url_backup'] ?? '') ?></textarea>
      </div>

      <div class="grid grid-cols-2 gap-3">
        <div>
          <div class="text-xs text-slate-500 mb-1">Chế độ</div>
          <select class="input w-full" name="mode">
            <?php $m = (string)($edit['mode'] ?? 'forever'); ?>
            <option value="forever" <?= $m==='forever'?'selected':'' ?>>Vĩnh viễn</option>
            <option value="once" <?= $m==='once'?'selected':'' ?>>Chỉ 1 lần</option>
          </select>
        </div>
        <div>
          <div class="text-xs text-slate-500 mb-1">Trạng thái</div>
          <?php $a = (int)($edit['is_active'] ?? 1); ?>
          <select class="input w-full" name="is_active">
            <option value="1" <?= $a===1?'selected':'' ?>>Bật</option>
            <option value="0" <?= $a===0?'selected':'' ?>>Tắt</option>
          </select>
        </div>
      </div>

      <button class="btn w-full" type="submit"><?= $edit?'Lưu thay đổi':'Tạo link' ?></button>

      <?php if($edit): ?>
        <a class="btn btn-ghost w-full" href="<?= e(admin_url('apps')) ?>">Huỷ sửa</a>
      <?php endif; ?>
    </form>

    <div class="mt-5 p-4 rounded-2xl bg-white/5 border border-white/10 text-xs text-slate-400">
      <div class="font-extrabold text-slate-200 mb-1">Link user</div>
      <div>/app</div>
    </div>
  </div>
</div>
