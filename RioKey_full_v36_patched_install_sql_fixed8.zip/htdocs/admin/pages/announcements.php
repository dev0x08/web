<?php
$flash=null; $err=null;

$tbl='announcements';
$hasLink = db_has_column($tbl,'link_url');
$hasSort = db_has_column($tbl,'sort_order');
$hasActive = db_has_column($tbl,'is_active');

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_require();
  $action=$_POST['action']??'';

  if($action==='create'){
    $content=trim($_POST['content']??'');
    $link=trim($_POST['link_url']??'');
    $sort=(int)($_POST['sort_order']??0);
    $on=isset($_POST['is_active'])?1:0;

    if($content==='') $err='Vui lòng nhập nội dung.';
    else {
      $cols=['content'];
      $vals=[$content];
      if($hasLink){ $cols[]='link_url'; $vals[]=$link; }
      if($hasSort){ $cols[]='sort_order'; $vals[]=$sort; }
      if($hasActive){ $cols[]='is_active'; $vals[]=$on; }
      $ph = implode(',', array_fill(0,count($cols),'?'));
      db()->prepare("INSERT INTO {$tbl}(".implode(',',$cols).") VALUES({$ph})")->execute($vals);
      $flash='Đã thêm.';
    }
  }

  if($action==='toggle' && $hasActive){
    $id=(int)($_POST['id']??0);
    db()->prepare("UPDATE {$tbl} SET is_active=IF(is_active=1,0,1) WHERE id=?")->execute([$id]);
    $flash='Đã cập nhật.';
  }

  if($action==='delete'){
    $id=(int)($_POST['id']??0);
    db()->prepare("DELETE FROM {$tbl} WHERE id=?")->execute([$id]);
    $flash='Đã xoá.';
  }
}

$order="ORDER BY id DESC";
if($hasSort) $order="ORDER BY sort_order ASC, id DESC";
$rows=db()->query("SELECT * FROM {$tbl} {$order}")->fetchAll(PDO::FETCH_ASSOC)?:[];
?>
<h1 class="text-2xl font-black">Chữ chạy (Dashboard)</h1>
<p class="text-slate-400 mt-1">Hiển thị dưới HERO.</p>

<?php if($flash): ?><div class="mt-4 rounded-2xl border border-emerald-500/25 bg-emerald-500/10 p-4 text-emerald-200 text-sm"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 rounded-2xl border border-rose-500/25 bg-rose-500/10 p-4 text-rose-200 text-sm"><?= e($err) ?></div><?php endif; ?>

<div class="card p-5 mt-6">
  <div class="font-extrabold">Thêm thông báo</div>
  <form method="post" class="mt-4 grid md:grid-cols-4 gap-3">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="create">
    <div class="md:col-span-2">
      <label>Nội dung</label>
      <input class="input" name="content" placeholder="Ví dụ: Săn sale..." required>
    </div>

    <?php if($hasLink): ?>
    <div>
      <label>Link (tuỳ chọn)</label>
      <input class="input" name="link_url" placeholder="https://...">
    </div>
    <?php endif; ?>

    <?php if($hasSort): ?>
    <div>
      <label>Sort</label>
      <input class="input" name="sort_order" type="number" value="0">
    </div>
    <?php endif; ?>

    <div class="md:col-span-4 flex items-center justify-between">
      <?php if($hasActive): ?>
      <label class="inline-flex items-center gap-2">
        <input type="checkbox" name="is_active" checked>
        <span class="text-sm text-slate-200 font-semibold">Active</span>
      </label>
      <?php else: ?><div></div><?php endif; ?>
      <button class="btn btn-primary">Thêm</button>
    </div>
  </form>
</div>

<div class="card p-5 mt-6">
  <div class="font-extrabold">Danh sách</div>
  <div class="mt-4 space-y-3">
    <?php foreach($rows as $r): ?>
      <div class="rounded-2xl border border-white/10 bg-white/5 p-4 flex items-center gap-3">
        <div class="min-w-0 flex-1">
          <div class="font-bold truncate"><?= e($r['content'] ?? '') ?></div>
          <?php if($hasLink): ?><div class="text-xs text-slate-500 mt-1 truncate"><?= e($r['link_url'] ?: '—') ?></div><?php endif; ?>
          <div class="text-xs text-slate-500 mt-1">
            <?php if($hasSort): ?>sort: <?= (int)($r['sort_order'] ?? 0) ?> •<?php endif; ?>
            <?php if($hasActive): ?><?= (int)($r['is_active'] ?? 0)===1?'ON':'OFF' ?><?php endif; ?>
          </div>
        </div>
        <form method="post" class="flex items-center gap-2">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)($r['id'] ?? 0) ?>">
          <?php if($hasActive): ?>
            <button name="action" value="toggle" class="btn btn-ghost !px-3 !py-2"><?= (int)($r['is_active'] ?? 0)===1?'Tắt':'Bật' ?></button>
          <?php endif; ?>
          <button name="action" value="delete" class="btn btn-ghost !px-3 !py-2" onclick="return confirm('Xoá thông báo?')">Xoá</button>
        </form>
      </div>
    <?php endforeach; ?>
    <?php if(!$rows): ?><div class="text-slate-500 text-sm">Chưa có thông báo.</div><?php endif; ?>
  </div>
</div>
