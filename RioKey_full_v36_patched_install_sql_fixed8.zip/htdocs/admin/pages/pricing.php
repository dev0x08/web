<?php
require_admin();
shop_ensure_schema();

$flash=null; $err=null;

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_require();
  $action = $_POST['action'] ?? '';
  try {
    if($action==='save'){
      $product_id = (int)($_POST['product_id'] ?? 0);
      $aud = (string)($_POST['audience_type'] ?? '');
      $audVal = trim((string)($_POST['audience_value'] ?? ''));
      $price = (int)($_POST['price_vnd'] ?? 0);

      if($product_id<=0) throw new Exception('Thiếu product_id');
      if(!in_array($aud,['rank','vip'],true)) throw new Exception('audience_type không hợp lệ');
      if($aud==='rank' && $audVal==='') throw new Exception('Thiếu rank slug');
      if($aud==='vip') $audVal = null;
      if($price<=0) throw new Exception('Giá phải > 0');

      $pdo = db();
      $pdo->prepare("INSERT INTO product_prices(product_id,audience_type,audience_value,price_vnd,created_at,updated_at)
        VALUES(?,?,?,?,NOW(),NOW())
        ON DUPLICATE KEY UPDATE price_vnd=VALUES(price_vnd), updated_at=NOW()")
        ->execute([$product_id,$aud,$audVal,$price]);

      audit_log((int)auth_user()['id'],'pricing_save', json_encode(['product_id'=>$product_id,'aud'=>$aud,'aud_val'=>$audVal,'price'=>$price],JSON_UNESCAPED_UNICODE));
      $flash='Đã lưu pricing.';
      redirect(admin_url('pricing',['product_id'=>$product_id]));
    }

    if($action==='delete'){
      $id = (int)($_POST['id'] ?? 0);
      db()->prepare("DELETE FROM product_prices WHERE id=?")->execute([$id]);
      audit_log((int)auth_user()['id'],'pricing_delete', json_encode(['id'=>$id],JSON_UNESCAPED_UNICODE));
      $flash='Đã xoá pricing.';
      redirect(admin_url('pricing'));
    }

  } catch (Throwable $e){ $err=$e->getMessage(); }
}

$products = db()->query("SELECT id,title,category,price_vnd FROM shop_products ORDER BY id DESC LIMIT 500")->fetchAll(PDO::FETCH_ASSOC) ?: [];
$ranks = ranks_all();

$pid = (int)($_GET['product_id'] ?? 0);
$rules = [];
if($pid>0){
  $st = db()->prepare("SELECT * FROM product_prices WHERE product_id=? ORDER BY audience_type ASC, audience_value ASC");
  $st->execute([$pid]);
  $rules = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}
?>
<div class="flex items-start justify-between gap-4">
  <div>
    <div class="text-2xl font-extrabold">Pricing theo Rank/VIP</div>
    <div class="text-sm text-slate-400 mt-1">Override giá từng sản phẩm theo rank hoặc VIP (ưu tiên VIP override).</div>
  </div>
</div>

<?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 grid lg:grid-cols-2 gap-4">
  <div class="card p-5">
    <div class="font-extrabold text-lg">Chọn sản phẩm</div>
    <form method="get" class="mt-4 flex gap-2">
      <select class="input flex-1" name="product_id">
        <option value="0">-- chọn --</option>
        <?php foreach($products as $p): ?>
          <option value="<?= (int)$p['id'] ?>" <?= ($pid===(int)$p['id'])?'selected':'' ?>>
            #<?= (int)$p['id'] ?> • <?= e($p['category']) ?> • <?= e($p['title']) ?> • <?= money_vnd((int)$p['price_vnd']) ?>
          </option>
        <?php endforeach; ?>
      </select>
      <button class="btn" type="submit">Xem</button>
    </form>

    <?php if($pid>0): ?>
      <div class="mt-6">
        <div class="font-extrabold">Thêm/Sửa rule</div>
        <form method="post" class="mt-3 space-y-3" data-once="1">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="save">
          <input type="hidden" name="product_id" value="<?= (int)$pid ?>">

          <div class="grid sm:grid-cols-2 gap-3">
            <div>
              <label class="label">Audience</label>
              <select class="input w-full" name="audience_type" id="audType">
                <option value="vip">VIP</option>
                <option value="rank">Rank</option>
              </select>
            </div>
            <div id="rankField">
              <label class="label">Rank slug</label>
              <select class="input w-full" name="audience_value">
                <?php foreach($ranks as $r): ?>
                  <option value="<?= e($r['slug'] ?? '') ?>"><?= e($r['slug'] ?? '') ?> (<?= e($r['name'] ?? '') ?>)</option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div>
            <label class="label">Giá (VNĐ)</label>
            <input class="input w-full" name="price_vnd" placeholder="Ví dụ: 49000">
          </div>

          <button class="btn w-full" type="submit">Lưu</button>
        </form>
      </div>

      <div class="mt-6">
        <div class="font-extrabold">Rules hiện tại</div>
        <div class="mt-3 space-y-2">
          <?php if(!$rules): ?>
            <div class="text-sm text-slate-500">Chưa có rule.</div>
          <?php else: foreach($rules as $r): ?>
            <div class="flex items-center justify-between p-3 rounded-2xl bg-white/5 border border-white/5">
              <div>
                <div class="font-semibold"><?= e($r['audience_type']) ?> <?= $r['audience_type']==='rank' ? ('• '.e($r['audience_value'] ?? '')) : '' ?></div>
                <div class="text-xs text-slate-500"><?= e($r['updated_at'] ?? $r['created_at'] ?? '') ?></div>
              </div>
              <div class="flex items-center gap-2">
                <div class="font-extrabold text-orange-200"><?= money_vnd((int)$r['price_vnd']) ?></div>
                <form method="post" data-once="1" onsubmit="return confirm('Xoá rule này?');">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <button class="btn btn-ghost" type="submit">Xoá</button>
                </form>
              </div>
            </div>
          <?php endforeach; endif; ?>
        </div>
      </div>
    <?php endif; ?>
  </div>

  <div class="card p-5">
    <div class="font-extrabold text-lg">Ghi chú</div>
    <div class="text-sm text-slate-300 mt-3 leading-relaxed">
      - VIP override (nếu có) sẽ dùng trước, sau đó mới tới Rank override.<br>
      - Giá override sẽ là <b>giá gốc</b>, sau đó vẫn áp dụng VIP discount + Flash Sale như bình thường.<br>
      - Dùng để tạo “giá riêng cho rank cao” hoặc “giá VIP đặc biệt”.
    </div>
  </div>
</div>

<script>
(function(){
  const aud=document.getElementById('audType');
  const rank=document.getElementById('rankField');
  function u(){ if(!aud||!rank) return; rank.classList.toggle('hidden', aud.value!=='rank'); }
  if(aud){ aud.addEventListener('change',u); u(); }
})();
</script>
