<?php
require_staff();
if (!is_admin()) { http_response_code(403); echo 'Forbidden'; return; }
shop_ensure_schema();

$aid = (int)((auth_user()['id'] ?? 0));
$err = null; $ok = null;

function riokey_valid_cat(string $c): string {
  $c = trim($c);
  $valid = ['game_key','giftcard','account'];
  return in_array($c, $valid, true) ? $c : 'game_key';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_require();
  $action = $_POST['action'] ?? '';

  try {
    if ($action === 'add_product') {
      $title = trim((string)($_POST['title'] ?? ''));
      $category = riokey_valid_cat((string)($_POST['category'] ?? 'game_key'));
      $icon = trim((string)($_POST['icon'] ?? ''));
      $image_url = trim((string)($_POST['image_url'] ?? ''));
      $price_vnd = (int)($_POST['price_vnd'] ?? 0);
      $points_price = (int)($_POST['points_price'] ?? 0);
      $desc = trim((string)($_POST['description'] ?? ''));
      $is_active = isset($_POST['is_active']) ? 1 : 0;

      if ($title === '') throw new Exception('Vui lòng nhập tên sản phẩm');
      if ($price_vnd < 0 || $points_price < 0) throw new Exception('Giá không hợp lệ');
      if ($price_vnd === 0 && $points_price === 0) throw new Exception('Phải có giá tiền hoặc giá điểm');

      $id = shop_add_product($title, $price_vnd, $points_price, $desc, $is_active, $category, $icon!==''?$icon:null, $image_url!==''?$image_url:null);
      audit_log($aid, 'shop_product_create', 'shop_products', (string)$id, ['title'=>$title,'category'=>$category]);
      $ok = 'Đã tạo sản phẩm #'.$id;

    } elseif ($action === 'update_product') {
      $id = (int)($_POST['id'] ?? 0);
      $title = trim((string)($_POST['title'] ?? ''));
      $category = riokey_valid_cat((string)($_POST['category'] ?? 'game_key'));
      $icon = trim((string)($_POST['icon'] ?? ''));
      $image_url = trim((string)($_POST['image_url'] ?? ''));
      $price_vnd = (int)($_POST['price_vnd'] ?? 0);
      $points_price = (int)($_POST['points_price'] ?? 0);
      $desc = trim((string)($_POST['description'] ?? ''));
      $is_active = isset($_POST['is_active']) ? 1 : 0;

      if ($id <= 0) throw new Exception('ID không hợp lệ');
      if ($title === '') throw new Exception('Vui lòng nhập tên sản phẩm');
      if ($price_vnd < 0 || $points_price < 0) throw new Exception('Giá không hợp lệ');
      if ($price_vnd === 0 && $points_price === 0) throw new Exception('Phải có giá tiền hoặc giá điểm');

      $slug = shop_slug($title);
      db()->prepare("UPDATE shop_products SET title=?, slug=?, category=?, icon=?, image_url=?, price_vnd=?, points_price=?, description=?, is_active=? WHERE id=?")
        ->execute([$title,$slug,$category,($icon!==''?$icon:null),($image_url!==''?$image_url:null),$price_vnd,$points_price,$desc,$is_active,$id]);

      audit_log($aid, 'shop_product_update', 'shop_products', (string)$id, ['title'=>$title,'category'=>$category]);
      $ok = 'Đã cập nhật sản phẩm #'.$id;

    } elseif ($action === 'delete_product') {
      $id = (int)($_POST['id'] ?? 0);
      if ($id <= 0) throw new Exception('ID không hợp lệ');

      $st = db()->prepare("SELECT COUNT(*) c FROM shop_keys WHERE product_id=? AND is_sold=1");
      $st->execute([$id]);
      if ((int)($st->fetchColumn() ?: 0) > 0) throw new Exception('Không thể xoá: đã có key đã bán');

      db()->prepare("DELETE FROM shop_keys WHERE product_id=?")->execute([$id]);
      db()->prepare("DELETE FROM shop_products WHERE id=?")->execute([$id]);
      audit_log($aid, 'shop_product_delete', 'shop_products', (string)$id, []);
      $ok = 'Đã xoá sản phẩm #'.$id;

    } elseif ($action === 'shop_settings') {
      $rt = trim((string)($_POST['points_rate_topup'] ?? '0'));
      $rp = trim((string)($_POST['points_rate_purchase'] ?? '0'));
      setting_set('points_rate_topup', $rt);
      setting_set('points_rate_purchase', $rp);
      $ok = 'Đã lưu cài đặt Shop.';

    } elseif ($action === 'import_keys') {
      $product_id = (int)($_POST['product_id'] ?? 0);
      $raw = (string)($_POST['keys_raw'] ?? '');
      if ($product_id <= 0) throw new Exception('Chọn sản phẩm');
      $lines = preg_split('/\r\n|\r|\n/', $raw);
      $n = shop_import_keys($product_id, $lines);
      audit_log($aid, 'shop_keys_import', 'shop_products', (string)$product_id, ['count'=>$n]);
      $ok = "Đã import {$n} key";

    } else {
      throw new Exception('Action không hợp lệ');
    }
  } catch (Throwable $e) {
    $err = $e->getMessage();
  }
}

$tab = (string)($_GET['tab'] ?? 'products');
$cat = riokey_valid_cat((string)($_GET['cat'] ?? 'game_key'));

$products = shop_products(false, $cat);

$stock = [];
$st = db()->query("SELECT product_id, SUM(CASE WHEN is_sold=0 THEN 1 ELSE 0 END) AS avail, COUNT(*) AS total FROM shop_keys GROUP BY product_id");
foreach (($st->fetchAll(PDO::FETCH_ASSOC) ?: []) as $r) $stock[(int)$r['product_id']] = $r;
?>
<div class="flex items-center justify-between gap-3">
  <div>
    <div class="text-2xl font-extrabold">Shop sản phẩm & Key</div>
    <div class="text-sm text-slate-400 mt-1">Chia theo chuyên mục: Key game / Giftcard / Tài khoản</div>
  </div>
</div>

<?php if($ok): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($ok) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 flex flex-wrap gap-2">
  <?php
    $tabs = [
      'game_key' => ['Key game','gamepad-2'],
      'giftcard' => ['Giftcard','credit-card'],
      'account'  => ['Tài khoản','user-round'],
      'settings' => ['Cài đặt','settings'],
    ];
    foreach($tabs as $k=>$v):
      $active = ($k==='settings') ? ($tab==='settings') : ($cat===$k && $tab==='products');
  ?>
    <a class="px-4 py-2 rounded-2xl border <?= $active?'border-orange-500/40 bg-orange-500/10 text-orange-200':'border-white/10 bg-white/5 text-slate-200/80 hover:bg-white/10' ?>"
       href="<?= e($k==='settings' ? admin_url('products',['tab'=>'settings']) : admin_url('products',['cat'=>$k])) ?>">
      <?= lucide_icon($v[1], 'w-4 h-4 inline-block mr-2') ?> <?= e($v[0]) ?>
    </a>
  <?php endforeach; ?>
</div>


<?php if($tab==='settings'): 
  $rate_topup = setting_get('points_rate_topup','0');
  $rate_purchase = setting_get('points_rate_purchase','0');
?>
  <div class="mt-6 card p-6 max-w-3xl">
    <div class="text-xl font-extrabold flex items-center gap-2"><?= lucide_icon('settings','w-5 h-5 text-orange-300') ?> Cài đặt Shop sản phẩm & Key</div>
    <div class="text-sm text-slate-400 mt-1">Tỷ lệ tích điểm khi nạp/mua key (đơn vị %).</div>

    <form method="post" class="mt-4 space-y-4" data-once="1">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="shop_settings">

      <div class="grid sm:grid-cols-2 gap-4">
        <div>
          <label class="text-sm text-slate-300">% điểm khi nạp tiền</label>
          <input class="input mt-1" name="points_rate_topup" value="<?= e($rate_topup) ?>" placeholder="VD: 5">
          <div class="text-xs text-slate-500 mt-1">Nạp 100.000đ với 5% = +5.000 điểm.</div>
        </div>
        <div>
          <label class="text-sm text-slate-300">% điểm khi mua key</label>
          <input class="input mt-1" name="points_rate_purchase" value="<?= e($rate_purchase) ?>" placeholder="VD: 2">
          <div class="text-xs text-slate-500 mt-1">Mua 50.000đ với 2% = +1.000 điểm.</div>
        </div>
      </div>

      <button class="btn" type="submit">Lưu cài đặt</button>
    </form>
  </div>
<?php return; endif; ?>

<div class="mt-6 grid lg:grid-cols-3 gap-4">
  <div class="card p-5 lg:col-span-1">
    <div class="font-extrabold text-lg">Thêm sản phẩm (<?= e($tabs[$cat][0] ?? '') ?>)</div>
    <form method="post" class="mt-4 space-y-3" data-once="1">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="add_product">
      <input type="hidden" name="category" value="<?= e($cat) ?>">

      <input class="input" name="title" placeholder="Tên sản phẩm">
      <div class="grid grid-cols-2 gap-3">
        <input class="input" name="price_vnd" type="number" step="1" placeholder="Giá VNĐ">
        <input class="input" name="points_price" type="number" step="1" placeholder="Giá điểm (nếu có)">
      </div>

      <input class="input" name="icon" placeholder="Icon (lucide name hoặc URL)" value="key-round">
      <input class="input" name="image_url" placeholder="Ảnh mô tả (URL)">

      <textarea class="input min-h-[120px]" name="description" placeholder="Mô tả"></textarea>
      <label class="flex items-center gap-2 text-sm text-slate-200">
        <input type="checkbox" name="is_active" checked> Kích hoạt
      </label>
      <button class="btn w-full" type="submit">Tạo sản phẩm</button>
    </form>
  </div>

  <div class="lg:col-span-2 space-y-4">
    <div class="card p-5">
      <div class="font-extrabold text-lg">Danh sách sản phẩm (<?= e($tabs[$cat][0] ?? '') ?>)</div>
      <?php if(!$products): ?>
        <div class="text-slate-400 mt-3">Chưa có sản phẩm.</div>
      <?php else: ?>
        <div class="mt-4 space-y-3">
          <?php foreach($products as $p): 
            $pid=(int)$p['id'];
            $s = $stock[$pid] ?? ['avail'=>0,'total'=>0];
          ?>
            <div class="rounded-2xl border border-white/10 bg-black/20 p-4">
              <div class="flex items-start justify-between gap-4">
                <div class="flex gap-3">
                  <div class="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 grid place-items-center overflow-hidden">
                    <?php
                      $icon = (string)($p['icon'] ?? 'key-round');
                      if ($icon && str_starts_with($icon,'http')) echo '<img class="w-6 h-6 object-contain" src="'.e($icon).'" alt="icon">';
                      else echo lucide_icon($icon?:'key-round','w-6 h-6 text-orange-300');
                    ?>
                  </div>
                  <div>
                    <div class="font-extrabold"><?= e($p['title']) ?></div>
                    <div class="text-sm text-slate-400 mt-1">
                      #<?= (int)$p['id'] ?> • <?= e((string)($p['slug'] ?? '')) ?> •
                      <span class="text-emerald-200"><?= (int)($s['avail'] ?? 0) ?></span> / <?= (int)($s['total'] ?? 0) ?> key
                      • <?= (int)($p['price_vnd'] ?? 0) ?> VNĐ • <?= (int)($p['points_price'] ?? 0) ?> điểm
                      • <?= ((int)($p['is_active'] ?? 0)===1) ? '<span class="text-emerald-200">ON</span>' : '<span class="text-rose-200">OFF</span>' ?>
                    </div>
                    <?php if(!empty($p['image_url'])): ?>
                      <div class="mt-2 text-xs text-slate-400 break-all">Ảnh: <?= e((string)$p['image_url']) ?></div>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="flex gap-2 shrink-0">
                  <form method="post" data-once="1" onsubmit="return confirm('Xoá sản phẩm này?');">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="delete_product">
                    <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                    <button class="btn btn-ghost" type="submit">Xoá</button>
                  </form>
                </div>
              </div>

              <details class="mt-4">
                <summary class="cursor-pointer text-sm text-slate-200/80 hover:text-slate-100">Sửa sản phẩm / Import key</summary>

                <div class="grid md:grid-cols-2 gap-4 mt-4">
                  <form method="post" class="space-y-3" data-once="1">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="update_product">
                    <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">

                    <input class="input" name="title" value="<?= e($p['title']) ?>">
                    <select class="input" name="category">
                      <option value="game_key" <?= ((string)($p['category'] ?? '')==='game_key')?'selected':'' ?>>Key game</option>
                      <option value="giftcard" <?= ((string)($p['category'] ?? '')==='giftcard')?'selected':'' ?>>Giftcard</option>
                      <option value="account" <?= ((string)($p['category'] ?? '')==='account')?'selected':'' ?>>Tài khoản</option>
                    </select>

                    <div class="grid grid-cols-2 gap-3">
                      <input class="input" name="price_vnd" type="number" step="1" value="<?= (int)($p['price_vnd'] ?? 0) ?>">
                      <input class="input" name="points_price" type="number" step="1" value="<?= (int)($p['points_price'] ?? 0) ?>">
                    </div>

                    <input class="input" name="icon" value="<?= e((string)($p['icon'] ?? '')) ?>" placeholder="lucide name hoặc URL">
                    <input class="input" name="image_url" value="<?= e((string)($p['image_url'] ?? '')) ?>" placeholder="Ảnh mô tả (URL)">

                    <textarea class="input min-h-[120px]" name="description"><?= e((string)($p['description'] ?? '')) ?></textarea>
                    <label class="flex items-center gap-2 text-sm text-slate-200">
                      <input type="checkbox" name="is_active" <?= ((int)($p['is_active'] ?? 0)===1)?'checked':'' ?>> Kích hoạt
                    </label>
                    <button class="btn w-full" type="submit">Lưu</button>
                  </form>

                  <form method="post" class="space-y-3" data-once="1">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="import_keys">
                    <input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>">

                    <textarea class="input min-h-[180px]" name="keys_raw" placeholder="Mỗi dòng 1 key/code"></textarea>
                    <button class="btn w-full" type="submit">Import key</button>
                  </form>
                </div>
              </details>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
