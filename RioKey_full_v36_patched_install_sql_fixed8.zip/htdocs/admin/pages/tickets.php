<?php
require_staff();
csrf_require();
support_ensure_schema();

$flash=null; $err=null;
$view_id=(int)($_GET['id'] ?? 0);

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check();
  try{
    $action=(string)($_POST['action'] ?? '');
    if($action==='set_status'){
      $id=(int)($_POST['id'] ?? 0);
      $st=(string)($_POST['status'] ?? 'open');
      $note=trim((string)($_POST['staff_note'] ?? ''));
      support_ticket_set_status($id,$st,$note);
      $flash='Đã cập nhật ticket.';
      if($view_id>0) redirect(admin_url('tickets',['id'=>$view_id]));
      redirect(admin_url('tickets'));
    }
    if($action==='reply'){
      $id=(int)($_POST['id'] ?? 0);
      $content=trim((string)($_POST['content'] ?? ''));
      if($content==='') throw new Exception('Thiếu nội dung.');
      $att = support_handle_uploads($id,'files',8);
      $staff = auth_user();
      support_ticket_add_message($id,'staff',(int)($staff['id']??0),$content,$att);
      support_ticket_set_status($id,'open', (string)($_POST['staff_note'] ?? ''));
      $flash='Đã phản hồi.';
      redirect(admin_url('tickets',['id'=>$id]));
    }
  }catch(Throwable $e){ $err=$e->getMessage(); }
}

if($view_id>0){
  $t = support_ticket_get($view_id);
  if(!$t){ http_response_code(404); echo 'Not found'; exit; }
  $msgs = support_ticket_messages($view_id);
  $user = db()->prepare("SELECT id,username,email FROM users WHERE id=? LIMIT 1");
  $user->execute([(int)$t['user_id']]);
  $usr = $user->fetch(PDO::FETCH_ASSOC) ?: null;
  ?>
  <div class="flex items-start justify-between gap-3">
    <div>
      <div class="text-2xl font-extrabold">Ticket #<?= (int)$t['id'] ?></div>
      <div class="text-sm text-slate-400 mt-1">User: <b><?= e($usr['username'] ?? ('#'.(int)$t['user_id'])) ?></b> • Status: <b><?= e($t['status']) ?></b></div>
      <?php if(!empty($t['subject'])): ?><div class="text-slate-200 mt-2"><?= e($t['subject']) ?></div><?php endif; ?>
    </div>
    <a class="btn btn-ghost" href="<?= e(admin_url('tickets')) ?>">← Danh sách</a>
  </div>

  <?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
  <?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

  <div class="mt-6 grid lg:grid-cols-3 gap-4">
    <div class="lg:col-span-2 card p-5">
      <div class="font-extrabold text-lg">Thread</div>
      <div class="mt-4 grid gap-3">
        <?php foreach($msgs as $m):
          $who=(string)($m['sender_type'] ?? 'user');
          $isU=$who==='user';
          $isS=$who==='staff';
          $bubble=$isU?'bg-white/5 border-white/10':($isS?'bg-orange-500/10 border-orange-500/20':'bg-slate-500/10 border-slate-500/20');
          $label=$isU?'User':($isS?'Staff':'System');
          $atts=[];
          if(!empty($m['attachments'])){ $tmp=json_decode((string)$m['attachments'], true); if(is_array($tmp)) $atts=$tmp; }
        ?>
          <div class="p-4 rounded-2xl border <?= $bubble ?>">
            <div class="text-xs text-slate-400 flex items-center justify-between gap-2">
              <div><?= e($label) ?></div>
              <div><?= e($m['created_at'] ?? '') ?></div>
            </div>
            <div class="mt-2 text-sm text-slate-200 whitespace-pre-line"><?= e($m['content'] ?? '') ?></div>
            <?php if($atts): ?>
              <div class="mt-3 grid sm:grid-cols-3 gap-2">
                <?php foreach($atts as $a): ?>
                  <a class="block rounded-xl overflow-hidden border border-white/10 hover:border-orange-500/30 transition" href="<?= e(base_url($a)) ?>" target="_blank" rel="noopener">
                    <img src="<?= e(base_url($a)) ?>" class="w-full h-28 object-cover" alt="attach">
                  </a>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>

      <?php if((string)$t['status']!=='closed'): ?>
        <form method="post" enctype="multipart/form-data" class="mt-5" data-once="1">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="reply">
          <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
          <textarea class="input min-h-[120px]" name="content" placeholder="Staff reply..."></textarea>
          <div class="mt-3 flex flex-col sm:flex-row gap-2 items-start sm:items-center justify-between">
            <input class="input" type="file" name="files[]" multiple accept="image/*">
            <button class="btn" type="submit">Gửi</button>
          </div>
        </form>
      <?php endif; ?>
    </div>

    <div class="card p-5">
      <div class="font-extrabold text-lg">Quản lý</div>
      <form method="post" class="mt-4 grid gap-3" data-once="1">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="set_status">
        <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
        <div>
          <div class="text-xs text-slate-500 mb-1">Status</div>
          <select class="input" name="status">
            <?php foreach(['open'=>'open','pending'=>'pending','resolved'=>'resolved','closed'=>'closed'] as $k=>$v): ?>
              <option value="<?= e($k) ?>" <?= ((string)$t['status']===$k)?'selected':'' ?>><?= e($v) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <div class="text-xs text-slate-500 mb-1">Staff note</div>
          <textarea class="input min-h-[120px]" name="staff_note"><?= e((string)($t['staff_note'] ?? '')) ?></textarea>
        </div>
        <button class="btn w-full" type="submit">Lưu</button>
      </form>
      <div class="text-xs text-slate-500 mt-4">User ID: <?= (int)$t['user_id'] ?> • Order: <?= (int)($t['order_id'] ?? 0) ?></div>
    </div>
  </div>
  <?php
  exit;
}

$status = (string)($_GET['status'] ?? 'all');
$list = support_admin_tickets($status, 300);
?>
<div class="flex items-start justify-between gap-3">
  <div>
    <div class="text-2xl font-extrabold">Tickets</div>
    <div class="text-sm text-slate-400 mt-1">Xử lý bảo hành / hỗ trợ user.</div>
  </div>
  <div class="flex gap-2">
    <a class="btn btn-ghost" href="<?= e(admin_url('tickets',['status'=>'all'])) ?>">All</a>
    <a class="btn btn-ghost" href="<?= e(admin_url('tickets',['status'=>'open'])) ?>">Open</a>
    <a class="btn btn-ghost" href="<?= e(admin_url('tickets',['status'=>'pending'])) ?>">Pending</a>
    <a class="btn btn-ghost" href="<?= e(admin_url('tickets',['status'=>'resolved'])) ?>">Resolved</a>
  </div>
</div>

<?php if($flash): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($flash) ?></div><?php endif; ?>
<?php if($err): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($err) ?></div><?php endif; ?>

<div class="mt-6 card p-5">
  <div class="font-extrabold text-lg">Danh sách</div>
  <div class="mt-4 grid gap-2">
    <?php if(!$list): ?><div class="text-sm text-slate-500">Không có ticket.</div><?php endif; ?>
    <?php foreach($list as $t): ?>
      <a class="p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-orange-500/30 transition"
         href="<?= e(admin_url('tickets',['id'=>(int)$t['id']])) ?>">
        <div class="flex items-center justify-between gap-2">
          <div class="font-extrabold">#<?= (int)$t['id'] ?> • <?= e($t['username'] ?? '') ?></div>
          <div class="text-xs text-slate-400"><?= e($t['status'] ?? '') ?></div>
        </div>
        <?php if(!empty($t['subject'])): ?><div class="text-slate-200 mt-1"><?= e($t['subject']) ?></div><?php endif; ?>
        <div class="text-xs text-slate-500 mt-2"><?= e($t['type'] ?? '') ?> • <?= e($t['created_at'] ?? '') ?></div>
      </a>
    <?php endforeach; ?>
  </div>
</div>
