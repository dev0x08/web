<?php
$admin=auth_user(); $aid=(int)($admin['id'] ?? 0);

$tbl='rewards';
$hasImage = db_has_column($tbl,'image_url');
$costCol  = db_has_column($tbl,'cost_points') ? 'cost_points' : (db_has_column($tbl,'points_cost') ? 'points_cost' : 'points_cost');

$action = $_GET['a'] ?? '';
$id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_require();
  $mode = $_POST['mode'] ?? 'save';

  if ($mode==='delete') {
    $rid=(int)($_POST['id'] ?? 0);
    db()->prepare("DELETE FROM {$tbl} WHERE id=?")->execute([$rid]);
    audit_log($aid,'reward_delete','reward',(string)$rid,[]);
    flash_set('ok','Đã xoá quà.');
    redirect(admin_url('rewards'));
  }

  $rid = (int)($_POST['id'] ?? 0);
  $title=trim((string)($_POST['title'] ?? ''));
  $desc=trim((string)($_POST['description'] ?? ''));
  $img=trim((string)($_POST['image_url'] ?? ''));
  $cost=(int)($_POST['cost_points'] ?? ($_POST['points_cost'] ?? 0));
  $stock=(int)($_POST['stock'] ?? -1);
  $sort=(int)($_POST['sort'] ?? 0);
  $active=isset($_POST['is_active'])?1:0;

  if($title==='' || $cost<=0){
    flash_set('error','Nhập title và điểm > 0');
    redirect(admin_url('rewards'));
  }

  if($rid>0){
    $cols=['title','description',$costCol,'stock','sort','is_active'];
    $vals=[$title,$desc,$cost,$stock,$sort,$active];
    if($hasImage){ $cols[]='image_url'; $vals[]=$img; }

    $set = implode(',', array_map(fn($c)=>"{$c}=?", $cols));
    $vals[]=$rid;
    db()->prepare("UPDATE {$tbl} SET {$set} WHERE id=?")->execute($vals);
    audit_log($aid,'reward_update','reward',(string)$rid,['title'=>$title]);
    flash_set('ok','Đã cập nhật quà.');
  } else {
    $cols=['title','description',$costCol,'stock','sort','is_active','created_at'];
    $vals=[$title,$desc,$cost,$stock,$sort,$active,date('Y-m-d H:i:s')];
    if($hasImage){ $cols[]='image_url'; array_splice($vals, 2, 0, [$img]); /* keep roughly after desc */ }

    $ph = implode(',', array_fill(0,count($cols),'?'));
    db()->prepare("INSERT INTO {$tbl}(".implode(',',$cols).") VALUES({$ph})")->execute($vals);
    $newId=(int)db()->lastInsertId();
    audit_log($aid,'reward_create','reward',(string)$newId,['title'=>$title]);
    flash_set('ok','Đã thêm quà.');
  }

  redirect(admin_url('rewards'));
}

$edit=null;
if($action==='edit' && $id>0){
  $st=db()->prepare("SELECT * FROM {$tbl} WHERE id=?");
  $st->execute([$id]);
  $edit=$st->fetch(PDO::FETCH_ASSOC) ?: null;
}

$order="ORDER BY sort ASC, id DESC";
if(!db_has_column($tbl,'sort')) $order="ORDER BY id DESC";
$rows=db()->query("SELECT * FROM {$tbl} {$order}")->fetchAll(PDO::FETCH_ASSOC) ?: [];
?>

<div class="max-w-5xl">
  <div class="text-2xl font-extrabold">Kho quà</div>
  <div class="text-sm text-slate-400 mt-1">Quản lý quà để người dùng đổi điểm</div>

  <?php if($m=flash_get('ok')): ?><div class="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($m) ?></div><?php endif; ?>
  <?php if($m=flash_get('error')): ?><div class="mt-4 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($m) ?></div><?php endif; ?>

  <div class="card p-6 mt-6">
    <div class="text-lg font-extrabold"><?= $edit?'Sửa quà':'Thêm quà' ?></div>
    <form method="post" class="mt-4 grid sm:grid-cols-2 gap-4">
      <?= csrf_field() ?>
      <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">

      <div class="sm:col-span-2">
        <label class="label">Title</label>
        <input class="input w-full" name="title" value="<?= e($edit['title'] ?? '') ?>" />
      </div>

      <div class="sm:col-span-2">
        <label class="label">Description</label>
        <textarea class="input w-full" name="description" rows="3"><?= e($edit['description'] ?? '') ?></textarea>
      </div>

      <?php if ($hasImage): ?>
      <div class="sm:col-span-2">
        <label class="label">Image URL (tuỳ chọn)</label>
        <input class="input w-full" name="image_url" value="<?= e($edit['image_url'] ?? '') ?>" placeholder="https://..." />
      </div>
      <?php endif; ?>

      <div>
        <label class="label">Điểm cần</label>
        <input class="input w-full" name="cost_points" type="number" value="<?= (int)($edit[$costCol] ?? 0) ?>" />
      </div>

      <div>
        <label class="label">Stock (-1 = unlimited)</label>
        <input class="input w-full" name="stock" type="number" value="<?= (int)($edit['stock'] ?? -1) ?>" />
      </div>

      <div>
        <label class="label">Sort</label>
        <input class="input w-full" name="sort" type="number" value="<?= (int)($edit['sort'] ?? 0) ?>" />
      </div>

      <div class="flex items-end gap-2">
        <label class="inline-flex items-center gap-2 text-sm">
          <input type="checkbox" name="is_active" value="1" <?= ((int)($edit['is_active'] ?? 1)===1?'checked':'') ?>>
          Active
        </label>
      </div>

      <div class="sm:col-span-2 flex gap-2">
        <button class="btn btn-primary" type="submit"><?= $edit?'Cập nhật':'Thêm' ?></button>
        <?php if($edit): ?>
          <a class="btn btn-ghost" href="<?= e(admin_url('rewards')) ?>">Huỷ</a>
        <?php endif; ?>
      </div>
    </form>
  </div>

  <div class="mt-6 card p-6">
    <div class="text-lg font-extrabold">Danh sách</div>
    <div class="mt-4 space-y-3">
      <?php foreach($rows as $r): ?>
        <div class="p-4 rounded-2xl bg-black/25 border border-white/10 flex items-center justify-between gap-3">
          <div class="min-w-0">
            <div class="font-extrabold truncate"><?= e($r['title'] ?? '') ?></div>
            <div class="text-xs text-slate-500 mt-1">
              <?= (int)($r[$costCol] ?? 0) ?> điểm • stock: <?= (int)($r['stock'] ?? 0) ?> • sort: <?= (int)($r['sort'] ?? 0) ?> • <?= (int)($r['is_active'] ?? 0)?'ON':'OFF' ?>
            </div>
          </div>
          <div class="flex gap-2">
            <a class="btn btn-ghost" href="<?= e(admin_url('rewards').'?a=edit&id='.(int)($r['id'] ?? 0)) ?>">Sửa</a>
            <form method="post" onsubmit="return confirm('Xoá quà này?')">
              <?= csrf_field() ?>
              <input type="hidden" name="mode" value="delete">
              <input type="hidden" name="id" value="<?= (int)($r['id'] ?? 0) ?>">
              <button class="btn btn-ghost text-rose-200" type="submit">Xoá</button>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
