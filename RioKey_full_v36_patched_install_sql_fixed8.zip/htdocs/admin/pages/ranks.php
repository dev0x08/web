<?php
require_admin();

function perks_to_json(string $raw): string {
  $lines = preg_split('/\r\n|\r|\n/', $raw);
  $lines = array_values(array_filter(array_map('trim',$lines), fn($x)=>$x!==''));
  return json_encode($lines, JSON_UNESCAPED_UNICODE);
}

if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_require();
  $action = $_POST['action'] ?? '';
  if ($action==='create') {
    $name = trim($_POST['name'] ?? '');
    $slug = trim($_POST['slug'] ?? '');
    $rate_normal = (int)($_POST['rate_normal'] ?? 0);
    $rate_promo  = (int)($_POST['rate_promo'] ?? 0);
    $require_orders = (int)($_POST['require_orders'] ?? 0);
    $condition_text = trim($_POST['condition_text'] ?? '');
    $icon = trim($_POST['icon'] ?? 'badge-check');
    $badge_text = trim($_POST['badge_text'] ?? '');
    $perks_json = perks_to_json($_POST['perks_raw'] ?? '');
    if ($name && $slug) {
      $st=db()->prepare("INSERT INTO ranks(name,slug,rate_normal,rate_promo,require_orders,condition_text,icon,badge_text,perks_json) VALUES(?,?,?,?,?,?,?,?,?)");
      $st->execute([$name,$slug,$rate_normal,$rate_promo,$require_orders,$condition_text,$icon,$badge_text,$perks_json]);
      flash('success','Đã thêm rank.');
    } else flash('error','Thiếu name/slug.');
  }
  if ($action==='update') {
    $id=(int)($_POST['id'] ?? 0);
    $name=trim($_POST['name'] ?? '');
    $slug=trim($_POST['slug'] ?? '');
    $rate_normal=(int)($_POST['rate_normal'] ?? 0);
    $rate_promo=(int)($_POST['rate_promo'] ?? 0);
    $require_orders=(int)($_POST['require_orders'] ?? 0);
    $condition_text=trim($_POST['condition_text'] ?? '');
    $icon=trim($_POST['icon'] ?? 'badge-check');
    $badge_text = trim($_POST['badge_text'] ?? '');
    $perks_json = perks_to_json($_POST['perks_raw'] ?? '');
    if ($id && $name && $slug) {
      $st=db()->prepare("UPDATE ranks SET name=?,slug=?,rate_normal=?,rate_promo=?,require_orders=?,condition_text=?,icon=?,badge_text=?,perks_json=? WHERE id=?");
      $st->execute([$name,$slug,$rate_normal,$rate_promo,$require_orders,$condition_text,$icon,$badge_text,$perks_json,$id]);
      flash('success','Đã cập nhật.');
    } else flash('error','Thiếu dữ liệu.');
  }
  if ($action==='delete') {
    $id=(int)($_POST['id'] ?? 0);
    if ($id>0) {
      $st=db()->prepare("DELETE FROM ranks WHERE id=?");
      $st->execute([$id]);
      flash('success','Đã xoá.');
    }
  }
  redirect(base_url('/admin/ranks'));
}

$rows = [];
try{
  $rows = db()->query("SELECT * FROM ranks ORDER BY require_orders ASC, id ASC")->fetchAll() ?: [];
}catch(Throwable $e){}
?>
<div class="grid lg:grid-cols-3 gap-4">
  <div class="card p-5">
    <div class="font-extrabold text-lg flex items-center gap-2"><?= lucide_icon('badge-percent','w-5 h-5 text-orange-300') ?> Thêm Rank</div>
    <div class="text-sm text-slate-400 mt-1">Dùng icon name theo Lucide (ví dụ: badge-check, zap, gem...)</div>
    <form method="post" class="mt-4 space-y-3">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="create">
      <label>Tên</label>
      <input class="input" name="name" placeholder="VD: VÀNG" required>
      <label>Slug</label>
      <input class="input" name="slug" placeholder="VD: vang" required>
      <div class="grid grid-cols-2 gap-3">
        <div>
          <label>% Ngày thường</label>
          <input class="input" name="rate_normal" type="number" min="0" max="100" value="0">
        </div>
        <div>
          <label>% Ngày khuyến mãi</label>
          <input class="input" name="rate_promo" type="number" min="0" max="100" value="0">
        </div>
      </div>
      <label>Điều kiện (đơn hàng)</label>
      <input class="input" name="require_orders" type="number" min="0" value="0">
      <label>Text điều kiện (tuỳ chọn)</label>
      <input class="input" name="condition_text" placeholder="VD: 10 đơn hàng thành công">
      <label>Icon (Lucide)</label>
      <input class="input" name="icon" value="badge-check">
      <label>Badge (tuỳ chọn)</label>
      <input class="input" name="badge_text" placeholder="VD: VIP / HOT">
      <label>Quyền lợi (mỗi dòng 1 mục)</label>
      <textarea class="input" name="perks_raw" rows="4" placeholder="VD:\nƯu tiên duyệt nhanh\nHoàn tiền cao hơn\nƯu đãi event"></textarea>
      <button class="btn btn-primary w-full">Thêm</button>
    </form>
  </div>

  <div class="lg:col-span-2 card p-0 overflow-hidden">
    <div class="p-5 border-b border-slate-800/60 font-extrabold flex items-center gap-2"><?= lucide_icon('list-ordered','w-5 h-5 text-orange-300') ?> Danh sách</div>
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <thead class="text-slate-400">
          <tr class="border-b border-slate-800/60">
            <th class="text-left p-4">Rank</th>
            <th class="text-left p-4">Rates</th>
            <th class="text-left p-4">Orders</th>
            <th class="text-left p-4">Icon</th>
            <th class="text-right p-4">Hành động</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach($rows as $r): ?>
          <tr class="border-b border-slate-800/40 hover:bg-slate-900/40">
            <td class="p-4 font-semibold">
              <div class="flex items-center gap-2">
                <span><?= e($r['name']) ?></span>
                <?php if(!empty($r['badge_text'])): ?><span class="px-2 py-0.5 rounded-full text-[11px] bg-orange-600/20 text-orange-300 border border-orange-500/20"><?= e($r['badge_text']) ?></span><?php endif; ?>
              </div>
              <div class="text-xs text-slate-500"><?= e($r['slug']) ?></div>
            </td>
            <td class="p-4"><?= (int)$r['rate_normal'] ?>% / <span class="text-orange-300 font-bold"><?= (int)$r['rate_promo'] ?>%</span></td>
            <td class="p-4"><?= (int)$r['require_orders'] ?></td>
            <td class="p-4 flex items-center gap-2"><?= lucide_icon($r['icon'] ?: 'badge-check','w-5 h-5 text-slate-200') ?> <span class="text-xs text-slate-400"><?= e($r['icon']) ?></span></td>
            <td class="p-4 text-right">
              <button class="btn btn-ghost !px-3 !py-2" onclick="document.getElementById('redit-<?= (int)$r['id'] ?>').showModal()"><?= lucide_icon('pencil','w-4 h-4') ?></button>
              <form class="inline" method="post" onsubmit="return confirm('Xoá rank này?')">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <button class="btn btn-ghost !px-3 !py-2 text-rose-200"><?= lucide_icon('trash-2','w-4 h-4') ?></button>
              </form>

              <dialog id="redit-<?= (int)$r['id'] ?>" class="rounded-3xl bg-slate-950 border border-slate-800/70 text-slate-100 p-0 w-[min(780px,95vw)]">
                <div class="p-5 border-b border-slate-800/60 flex items-center justify-between">
                  <div class="font-extrabold">Sửa rank</div>
                  <button class="btn btn-ghost !px-3 !py-2" onclick="this.closest('dialog').close()"><?= lucide_icon('x','w-5 h-5') ?></button>
                </div>
                <form method="post" class="p-5 space-y-3">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="update">
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <label>Tên</label>
                  <input class="input" name="name" value="<?= e($r['name']) ?>" required>
                  <label>Slug</label>
                  <input class="input" name="slug" value="<?= e($r['slug']) ?>" required>
                  <div class="grid grid-cols-2 gap-3">
                    <div>
                      <label>% Ngày thường</label>
                      <input class="input" name="rate_normal" type="number" min="0" max="100" value="<?= (int)$r['rate_normal'] ?>">
                    </div>
                    <div>
                      <label>% Ngày khuyến mãi</label>
                      <input class="input" name="rate_promo" type="number" min="0" max="100" value="<?= (int)$r['rate_promo'] ?>">
                    </div>
                  </div>
                  <label>Điều kiện (đơn hàng)</label>
                  <input class="input" name="require_orders" type="number" min="0" value="<?= (int)$r['require_orders'] ?>">
                  <label>Text điều kiện</label>
                  <input class="input" name="condition_text" value="<?= e($r['condition_text']) ?>">
                  <label>Icon (Lucide)</label>
                  <input class="input" name="icon" value="<?= e($r['icon']) ?>">
                  <label>Badge (tuỳ chọn)</label>
                  <input class="input" name="badge_text" value="<?= e($r['badge_text'] ?? '') ?>" placeholder="VD: VIP">
                  <label>Quyền lợi (mỗi dòng 1 mục)</label>
                  <textarea class="input" name="perks_raw" rows="4"><?php $pp=json_decode($r['perks_json'] ?? '[]', true) ?: []; echo e(implode("\n", $pp)); ?></textarea>
                  <div class="flex gap-2 justify-end pt-2">
                    <button type="button" class="btn btn-ghost" onclick="this.closest('dialog').close()">Huỷ</button>
                    <button class="btn btn-primary">Lưu</button>
                  </div>
                </form>
              </dialog>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
