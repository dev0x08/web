<?php
require_once __DIR__ . '/../bootstrap.php';
require_admin();

$type = $_GET['type'] ?? '';
$map = [
  'users' => ["SELECT id,username,name,email,phone,points,is_admin,created_at FROM users ORDER BY id DESC", 'users.csv'],
  'orders' => ["SELECT * FROM orders ORDER BY id DESC", 'orders.csv'],
  'points' => ["SELECT id,user_id,points,type,ref_key,note,created_at FROM point_transactions ORDER BY id DESC", 'points.csv'],
  'redemptions' => ["SELECT rr.*, u.username, r.title FROM reward_redemptions rr JOIN users u ON u.id=rr.user_id JOIN rewards r ON r.id=rr.reward_id ORDER BY rr.id DESC", 'redemptions.csv'],
  'notifications' => ["SELECT * FROM notifications ORDER BY id DESC", 'notifications.csv'],
  'audit' => ["SELECT * FROM admin_audit_logs ORDER BY id DESC", 'audit.csv'],
];

if (!isset($map[$type])) { http_response_code(400); die('Bad export type'); }
$sql = $map[$type][0]; $fname=$map[$type][1];

$st = db()->query($sql);
$rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="'.$fname.'"');

$out = fopen('php://output','w');
if ($rows) {
  fputcsv($out, array_keys($rows[0]));
  foreach($rows as $r) fputcsv($out, $r);
} else {
  fputcsv($out, ['empty']);
}
fclose($out);
exit;
