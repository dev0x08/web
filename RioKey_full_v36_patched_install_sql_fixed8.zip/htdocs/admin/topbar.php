<header class="sticky top-0 z-40 border-b border-white/10 bg-black/25 backdrop-blur">
  <div class="px-4 sm:px-6 lg:px-8 h-16 flex items-center gap-3">
    <button class="lg:hidden w-10 h-10 rounded-xl hover:bg-white/5 tap" @click="sidebarOpen=true">☰</button>
    <div class="font-extrabold">Admin</div>
    <div class="ml-auto flex items-center gap-2">
      <a class="px-3 py-2 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10"
         href="<?= e(route_url('dashboard')) ?>">Về user</a>
      <a class="px-3 py-2 rounded-2xl bg-rose-500/15 text-rose-200 border border-rose-500/20 hover:bg-rose-500/20"
         href="<?= e(base_url('/auth/logout.php')) ?>">Đăng xuất</a>
    </div>
  </div>
</header>
