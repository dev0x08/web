<?php
$route = $route ?? 'dashboard';
function a(string $r, string $cur): string {
  return $r===$cur
    ? 'bg-orange-600/20 text-orange-300 border border-orange-500/20'
    : 'text-slate-300 hover:bg-white/5 hover:text-white';
}
$isAdmin = is_admin();
?>

<!-- Mobile off-canvas sidebar (Alpine) -->
<div class="lg:hidden" x-cloak>
  <div class="fixed inset-0 z-50" x-show="sidebarOpen" x-transition.opacity>
    <div class="absolute inset-0 bg-black/65" @click="sidebarOpen=false"></div>

    <aside
      class="absolute left-0 top-0 h-full w-[280px] flex flex-col border-r border-white/10 bg-black/60 backdrop-blur"
      x-show="sidebarOpen"
      x-transition:enter="transition ease-out duration-200"
      x-transition:enter-start="-translate-x-full"
      x-transition:enter-end="translate-x-0"
      x-transition:leave="transition ease-in duration-200"
      x-transition:leave-start="translate-x-0"
      x-transition:leave-end="-translate-x-full"
      @keydown.window.escape="sidebarOpen=false"
    >
      <div class="px-6 py-5 flex items-center gap-3 border-b border-white/10">
        <div class="w-10 h-10 rounded-xl bg-orange-600 grid place-items-center font-black"><?= $isAdmin ? 'A' : 'M' ?></div>
        <div class="flex-1">
          <div class="font-extrabold tracking-wide"><?= $isAdmin ? 'Admin Panel' : 'MOD Panel' ?></div>
          <div class="text-xs text-slate-400">RioKey</div>
        </div>
        <button class="w-10 h-10 rounded-xl hover:bg-white/5 tap" type="button" @click="sidebarOpen=false">
          <?= lucide_icon('x') ?>
        </button>
      </div>

      <div class="px-4 py-4 space-y-6 overflow-y-auto" @click="sidebarOpen=false">
        <!-- NOTE: Clicking a nav item closes sidebar on mobile -->
        <div class="space-y-2">
          <div class="text-[11px] text-slate-500 font-bold tracking-widest px-2">VẬN HÀNH</div>

          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('dashboard',$route) ?>" href="<?= e(admin_url('dashboard')) ?>">
            <?= lucide_icon('layout-dashboard') ?> <span class="font-semibold">Dashboard</span>
          </a>

          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('orders',$route) ?>" href="<?= e(admin_url('orders')) ?>">
            <?= lucide_icon('receipt') ?> <span class="font-semibold">Đơn mua key</span>
          </a>

          <?php if ($isAdmin): ?>
            <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('products',$route) ?>" href="<?= e(admin_url('products')) ?>">
              <?= lucide_icon('key') ?> <span class="font-semibold">Shop sản phẩm & Key</span>
            </a>

            <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('apps',$route) ?>" href="<?= e(admin_url('apps')) ?>">
              <?= lucide_icon('smartphone') ?> <span class="font-semibold">Link tải App</span>
            </a>
            <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('pricing',$route) ?>" href="<?= e(admin_url('pricing')) ?>">
              <?= lucide_icon('tags') ?> <span class="font-semibold">Pricing</span>
            </a>
          <?php endif; ?>

          <?php if ($isAdmin): ?>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('topups',$route) ?>" href="<?= e(admin_url('topups')) ?>">
            <?= lucide_icon('qr-code') ?> <span class="font-semibold">Duyệt nạp tiền</span>
          </a>
          <?php endif; ?>

          <?php if ($isAdmin): ?>
            <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('users',$route) ?>" href="<?= e(admin_url('users')) ?>">
              <?= lucide_icon('users') ?> <span class="font-semibold">Users</span>
            </a>
            <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('contacts',$route) ?>" href="<?= e(admin_url('contacts')) ?>">
              <?= lucide_icon('contact') ?> <span class="font-semibold">Contacts</span>
            </a>
            <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('notifications',$route) ?>" href="<?= e(admin_url('notifications')) ?>">
              <?= lucide_icon('bell') ?> <span class="font-semibold">Thông báo</span>
            </a>
          <?php endif; ?>
        </div>

        
        <div class="space-y-2">
          <div class="text-[11px] text-slate-500 font-bold tracking-widest px-2">RISK & MOD</div>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('tickets',$route) ?>" href="<?= e(admin_url('tickets')) ?>">
            <?= lucide_icon('life-buoy') ?> <span class="font-semibold">Tickets</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('modqueue',$route) ?>" href="<?= e(admin_url('modqueue')) ?>">
            <?= lucide_icon('check-check') ?> <span class="font-semibold">Mod Queue</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('risk',$route) ?>" href="<?= e(admin_url('risk')) ?>">
            <?= lucide_icon('shield-alert') ?> <span class="font-semibold">Risk Center</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('ip_blocks',$route) ?>" href="<?= e(admin_url('ip_blocks')) ?>">
            <?= lucide_icon('ban') ?> <span class="font-semibold">IP Blocks</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('risk_logs',$route) ?>" href="<?= e(admin_url('risk_logs')) ?>">
            <?= lucide_icon('list-ordered') ?> <span class="font-semibold">Risk Logs</span>
          </a>
        </div>

        <?php if ($isAdmin): ?>
        <div class="space-y-2">
          <div class="text-[11px] text-slate-500 font-bold tracking-widest px-2">NỘI DUNG</div>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('community',$route) ?>" href="<?= e(admin_url('community')) ?>">
            <?= lucide_icon('messages-square') ?> <span class="font-semibold">Community</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('banners',$route) ?>" href="<?= e(admin_url('banners')) ?>">
            <?= lucide_icon('image') ?> <span class="font-semibold">Banners</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('announcements',$route) ?>" href="<?= e(admin_url('announcements')) ?>">
            <?= lucide_icon('megaphone') ?> <span class="font-semibold">Chữ chạy</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('popups',$route) ?>" href="<?= e(admin_url('popups')) ?>">
            <?= lucide_icon('layers') ?> <span class="font-semibold">Popup</span>
          </a>
        </div>

        <div class="space-y-2">
          <div class="text-[11px] text-slate-500 font-bold tracking-widest px-2">TÍNH NĂNG</div>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('missions',$route) ?>" href="<?= e(admin_url('missions')) ?>">
            <?= lucide_icon('check-circle') ?> <span class="font-semibold">Nhiệm vụ</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('mission_claims',$route) ?>" href="<?= e(admin_url('mission_claims')) ?>">
            <?= lucide_icon('shield-check') ?> <span class="font-semibold">Duyệt nhiệm vụ</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('streak',$route) ?>" href="<?= e(admin_url('streak')) ?>">
            <?= lucide_icon('calendar-check') ?> <span class="font-semibold">Reward điểm danh</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('rewards',$route) ?>" href="<?= e(admin_url('rewards')) ?>">
            <?= lucide_icon('gift') ?> <span class="font-semibold">Kho quà</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('redemptions',$route) ?>" href="<?= e(admin_url('redemptions')) ?>">
            <?= lucide_icon('clipboard-list') ?> <span class="font-semibold">Đổi quà</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('coupons',$route) ?>" href="<?= e(admin_url('coupons')) ?>">
            <?= lucide_icon('ticket') ?> <span class="font-semibold">Coupons</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('vip',$route) ?>" href="<?= e(admin_url('vip')) ?>">
            <?= lucide_icon('crown') ?> <span class="font-semibold">VIP</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('flash_sales',$route) ?>" href="<?= e(admin_url('flash_sales')) ?>">
            <?= lucide_icon('zap') ?> <span class="font-semibold">Flash Sale</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('lootbox',$route) ?>" href="<?= e(admin_url('lootbox')) ?>">
            <?= lucide_icon('box') ?> <span class="font-semibold">Lootbox</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('spin',$route) ?>" href="<?= e(admin_url('spin')) ?>">
            <?= lucide_icon('sparkles') ?> <span class="font-semibold">Vòng quay</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('referral',$route) ?>" href="<?= e(admin_url('referral')) ?>">
            <?= lucide_icon('users') ?> <span class="font-semibold">Referral</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('ranks',$route) ?>" href="<?= e(admin_url('ranks')) ?>">
            <?= lucide_icon('crown') ?> <span class="font-semibold">Ranks</span>
          </a>
        </div>

        <div class="space-y-2">
          <div class="text-[11px] text-slate-500 font-bold tracking-widest px-2">HỆ THỐNG</div>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('reports',$route) ?>" href="<?= e(admin_url('reports')) ?>">
            <?= lucide_icon('bar-chart-3') ?> <span class="font-semibold">Báo cáo</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('export',$route) ?>" href="<?= e(admin_url('export')) ?>">
            <?= lucide_icon('download') ?> <span class="font-semibold">Xuất CSV</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('audit',$route) ?>" href="<?= e(admin_url('audit')) ?>">
            <?= lucide_icon('shield-alert') ?> <span class="font-semibold">Audit log</span>
          </a>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('settings',$route) ?>" href="<?= e(admin_url('settings')) ?>">
            <?= lucide_icon('settings') ?> <span class="font-semibold">Cài đặt</span>
          </a>
        </div>
        <?php endif; ?>

        <div class="space-y-2">
          <div class="text-[11px] text-slate-500 font-bold tracking-widest px-2">TÀI KHOẢN</div>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl text-slate-300 hover:bg-white/5 hover:text-white" href="<?= e(admin_url('logout')) ?>">
            <?= lucide_icon('log-out') ?> <span class="font-semibold">Đăng xuất</span>
          </a>
        </div>
      </div>
    </aside>
  </div>
</div>

<aside class="hidden lg:flex fixed left-0 top-0 h-full w-[280px] flex-col border-r border-white/10 bg-black/30 backdrop-blur">
  <a href="<?= e(admin_url('dashboard')) ?>" class="px-6 py-5 flex items-center gap-3 border-b border-white/10 tap">
    <div class="w-10 h-10 rounded-xl bg-orange-600 grid place-items-center font-black"><?= $isAdmin ? 'A' : 'M' ?></div>
    <div>
      <div class="font-extrabold tracking-wide"><?= $isAdmin ? 'Admin Panel' : 'MOD Panel' ?></div>
      <div class="text-xs text-slate-400">RioKey</div>
    </div>
  </a>

  <div class="px-4 py-4 space-y-6 overflow-y-auto">
    <div class="space-y-2">
      <div class="text-[11px] text-slate-500 font-bold tracking-widest px-2">VẬN HÀNH</div>

      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('dashboard',$route) ?>" href="<?= e(admin_url('dashboard')) ?>">
        <?= lucide_icon('layout-dashboard') ?> <span class="font-semibold">Dashboard</span>
      </a>

      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('orders',$route) ?>" href="<?= e(admin_url('orders')) ?>">
        <?= lucide_icon('receipt') ?> <span class="font-semibold">Đơn mua key</span>
      </a>

      <?php if ($isAdmin): ?>
        <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('products',$route) ?>" href="<?= e(admin_url('products')) ?>">
          <?= lucide_icon('key') ?> <span class="font-semibold">Shop sản phẩm & Key</span>
        </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('pricing',$route) ?>" href="<?= e(admin_url('pricing')) ?>">
        <?= lucide_icon('tags') ?> <span class="font-semibold">Pricing</span>
      </a>
      <?php endif; ?>

      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('topups',$route) ?>" href="<?= e(admin_url('topups')) ?>">
        <?= lucide_icon('qr-code') ?> <span class="font-semibold">Duyệt nạp tiền</span>
      </a>

      <?php if ($isAdmin): ?>
        <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('users',$route) ?>" href="<?= e(admin_url('users')) ?>">
          <?= lucide_icon('users') ?> <span class="font-semibold">Users</span>
        </a>
        <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('contacts',$route) ?>" href="<?= e(admin_url('contacts')) ?>">
          <?= lucide_icon('contact') ?> <span class="font-semibold">Contacts</span>
        </a>
        <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('notifications',$route) ?>" href="<?= e(admin_url('notifications')) ?>">
          <?= lucide_icon('bell') ?> <span class="font-semibold">Thông báo</span>
        </a>
      <?php endif; ?>
    </div>

    
    <div class="space-y-2">
      <div class="text-[11px] text-slate-500 font-bold tracking-widest px-2">RISK & MOD</div>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('tickets',$route) ?>" href="<?= e(admin_url('tickets')) ?>">
        <?= lucide_icon('life-buoy') ?> <span class="font-semibold">Tickets</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('modqueue',$route) ?>" href="<?= e(admin_url('modqueue')) ?>">
        <?= lucide_icon('check-check') ?> <span class="font-semibold">Mod Queue</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('risk',$route) ?>" href="<?= e(admin_url('risk')) ?>">
        <?= lucide_icon('shield-alert') ?> <span class="font-semibold">Risk Center</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('ip_blocks',$route) ?>" href="<?= e(admin_url('ip_blocks')) ?>">
        <?= lucide_icon('ban') ?> <span class="font-semibold">IP Blocks</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('risk_logs',$route) ?>" href="<?= e(admin_url('risk_logs')) ?>">
        <?= lucide_icon('list-ordered') ?> <span class="font-semibold">Risk Logs</span>
      </a>
    </div>

    <?php if ($isAdmin): ?>
    <div class="space-y-2">
      <div class="text-[11px] text-slate-500 font-bold tracking-widest px-2">NỘI DUNG</div>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('community',$route) ?>" href="<?= e(admin_url('community')) ?>">
        <?= lucide_icon('messages-square') ?> <span class="font-semibold">Community</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('banners',$route) ?>" href="<?= e(admin_url('banners')) ?>">
        <?= lucide_icon('image') ?> <span class="font-semibold">Banners</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('announcements',$route) ?>" href="<?= e(admin_url('announcements')) ?>">
        <?= lucide_icon('megaphone') ?> <span class="font-semibold">Chữ chạy</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('popups',$route) ?>" href="<?= e(admin_url('popups')) ?>">
        <?= lucide_icon('layers') ?> <span class="font-semibold">Popup</span>
      </a>
    </div>

    <div class="space-y-2">
      <div class="text-[11px] text-slate-500 font-bold tracking-widest px-2">TÍNH NĂNG</div>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('missions',$route) ?>" href="<?= e(admin_url('missions')) ?>">
        <?= lucide_icon('check-circle') ?> <span class="font-semibold">Nhiệm vụ</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('streak',$route) ?>" href="<?= e(admin_url('streak')) ?>">
        <?= lucide_icon('calendar-check') ?> <span class="font-semibold">Reward điểm danh</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('rewards',$route) ?>" href="<?= e(admin_url('rewards')) ?>">
        <?= lucide_icon('gift') ?> <span class="font-semibold">Kho quà</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('redemptions',$route) ?>" href="<?= e(admin_url('redemptions')) ?>">
        <?= lucide_icon('clipboard-list') ?> <span class="font-semibold">Đổi quà</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('coupons',$route) ?>" href="<?= e(admin_url('coupons')) ?>">
        <?= lucide_icon('ticket') ?> <span class="font-semibold">Coupons</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('vip',$route) ?>" href="<?= e(admin_url('vip')) ?>">
        <?= lucide_icon('crown') ?> <span class="font-semibold">VIP</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('flash_sales',$route) ?>" href="<?= e(admin_url('flash_sales')) ?>">
        <?= lucide_icon('zap') ?> <span class="font-semibold">Flash Sale</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('lootbox',$route) ?>" href="<?= e(admin_url('lootbox')) ?>">
        <?= lucide_icon('box') ?> <span class="font-semibold">Lootbox</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('spin',$route) ?>" href="<?= e(admin_url('spin')) ?>">
        <?= lucide_icon('sparkles') ?> <span class="font-semibold">Vòng quay</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('referral',$route) ?>" href="<?= e(admin_url('referral')) ?>">
        <?= lucide_icon('users') ?> <span class="font-semibold">Referral</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('ranks',$route) ?>" href="<?= e(admin_url('ranks')) ?>">
        <?= lucide_icon('crown') ?> <span class="font-semibold">Ranks</span>
      </a>
    </div>

    <div class="space-y-2">
      <div class="text-[11px] text-slate-500 font-bold tracking-widest px-2">HỆ THỐNG</div>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('reports',$route) ?>" href="<?= e(admin_url('reports')) ?>">
        <?= lucide_icon('bar-chart-3') ?> <span class="font-semibold">Báo cáo</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('export',$route) ?>" href="<?= e(admin_url('export')) ?>">
        <?= lucide_icon('download') ?> <span class="font-semibold">Xuất CSV</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('audit',$route) ?>" href="<?= e(admin_url('audit')) ?>">
        <?= lucide_icon('shield-alert') ?> <span class="font-semibold">Audit log</span>
      </a>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl <?= a('settings',$route) ?>" href="<?= e(admin_url('settings')) ?>">
        <?= lucide_icon('settings') ?> <span class="font-semibold">Cài đặt</span>
      </a>
    </div>
    <?php endif; ?>

    <div class="space-y-2">
      <div class="text-[11px] text-slate-500 font-bold tracking-widest px-2">TÀI KHOẢN</div>
      <a class="flex items-center gap-3 px-4 py-3 rounded-2xl text-slate-300 hover:bg-white/5 hover:text-white" href="<?= e(admin_url('logout')) ?>">
        <?= lucide_icon('log-out') ?> <span class="font-semibold">Đăng xuất</span>
      </a>
    </div>

  </div>
</aside>
