<?php
$u = auth_user();
$rank = $u['rank_name'] ?? 'ĐỒNG';
$points = $u ? (int)($u['points'] ?? 0) : 0;
$balance = 0;
if ($u) { try { $w = wallet_get((int)$u['id']); $balance = (float)($w['balance'] ?? 0); } catch(Throwable $e) { $balance = 0; } }
$avatar = $u && !empty($u['avatar_url']) ? $u['avatar_url'] : 'https://i.pravatar.cc/200?img=12';
$unread = $u ? notify_unread_count((int)$u['id']) : 0;
?>
<header class="sticky top-0 z-40 border-b border-white/10 bg-black/25 backdrop-blur">
  <div class="px-4 sm:px-6 lg:px-8 h-16 flex items-center gap-3">
    <button id="btnSidebarOpen" class="lg:hidden w-10 h-10 rounded-xl hover:bg-white/5 tap" type="button">
      <?= lucide_icon('menu','w-6 h-6') ?>
    </button>

    <a href="<?= e(route_url('dashboard')) ?>" class="lg:hidden flex items-center gap-2 tap">
      <div class="w-9 h-9 rounded-xl bg-orange-600 grid place-items-center font-black">R</div>
      <div class="font-extrabold">RioKey</div>
    </a>

    <?php if($u): ?>
    <div class="ml-auto flex items-center gap-3">
      <span class="hidden sm:inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/20 text-xs font-bold">
        <?= lucide_icon('crown','w-4 h-4') ?> <?= e($rank) ?>
      </span>

      <span class="hidden sm:inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 text-emerald-200 border border-emerald-500/20 text-xs font-extrabold" title="Tiền (VNĐ) dùng để mua key. Điểm dùng để đổi key.">
        <?= lucide_icon('wallet','w-4 h-4 text-emerald-200') ?> <?= format_vnd($balance) ?>
      </span>

      <span class="hidden sm:inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 text-slate-200 border border-white/10 text-xs font-extrabold" title="Điểm dùng để đổi key (khác với tiền)">
        <?= lucide_icon('coins','w-4 h-4 text-amber-300') ?> <?= (int)$points ?> điểm
      </span>

      <a href="<?= e(route_url('notifications')) ?>" class="relative w-10 h-10 rounded-xl hover:bg-white/5 grid place-items-center tap">
        <?= lucide_icon('bell','w-5 h-5') ?>
        <?php if($unread>0): ?>
          <span class="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-orange-500 text-[11px] font-extrabold grid place-items-center">
            <?= $unread>99?'99+':$unread ?>
          </span>
        <?php endif; ?>
      </a>

      <div class="relative">
        <button id="btnUserMenu" class="flex items-center gap-3 tap" type="button">
          <div class="text-right hidden md:block">
            <div class="text-sm font-extrabold"><?= e($u['name'] ?? $u['username'] ?? '') ?></div>
            <div class="text-[11px] text-slate-400"><?= e(trim((string)($u['display_title'] ?? '')) !== '' ? (string)$u['display_title'] : 'Thành viên') ?></div>
          </div>
          <div class="w-10 h-10 rounded-full overflow-hidden border border-white/10">
            <img class="w-full h-full object-cover" src="<?= e($avatar) ?>" alt="avatar">
          </div>
          <div class="hidden sm:block opacity-70"><?= lucide_icon('chevron-down','w-5 h-5') ?></div>
        </button>

        <div id="userMenu" class="hidden absolute right-0 top-[52px] w-64 card shadow-soft p-2">
          <a class="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/5" href="<?= e(route_url('profile')) ?>">
            <?= lucide_icon('user') ?> <span class="font-semibold">Hồ sơ</span>
          </a>
          <a class="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/5" href="<?= e(route_url('rewards')) ?>">
            <?= lucide_icon('gift') ?> <span class="font-semibold">Shop đổi điểm</span>
          </a>
          <?php if(is_vendor()): ?>
          <a class="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/5" href="<?= e(route_url('wallet')) ?>">
            <?= lucide_icon('wallet') ?> <span class="font-semibold">Tài chính</span>
          </a>
          <?php endif; ?>

          <?php if(is_vendor()): ?>
            <a class="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/5" href="<?= e(base_url('/ctv')) ?>">
              <?= lucide_icon('store') ?> <span class="font-semibold">CTV Panel</span>
            </a>
          <?php endif; ?>
          <div class="h-px bg-white/10 my-2"></div>
          <?php if(is_admin()): ?>
            <a class="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/5" href="<?= e(base_url('/admin')) ?>">
              <?= lucide_icon('shield') ?> <span class="font-semibold">Admin</span>
            </a>
          <?php endif; ?>
          <a class="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-rose-500/10 text-rose-200" href="<?= e(base_url('/auth/logout.php')) ?>">
            <?= lucide_icon('log-out') ?> <span class="font-semibold">Đăng xuất</span>
          </a>
        </div>
      </div>
    </div>
    <?php endif; ?>
  </div>
</header>


<?php if($msg=flash_get('ok')): ?>
  <div class="max-w-6xl mx-auto px-4 mt-3">
    <div class="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-200"><?= e($msg) ?></div>
  </div>
<?php endif; ?>
<?php if($msg=flash_get('error')): ?>
  <div class="max-w-6xl mx-auto px-4 mt-3">
    <div class="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-200"><?= e($msg) ?></div>
  </div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', ()=>{
  const btn = document.getElementById('btnUserMenu');
  const menu = document.getElementById('userMenu');
  if(btn && menu){
    const close = ()=>menu.classList.add('hidden');
    btn.addEventListener('click', (e)=>{ e.stopPropagation(); menu.classList.toggle('hidden'); });
    document.addEventListener('click', close);
    document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') close(); });
  }
});
</script>
