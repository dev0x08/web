<?php
$u = auth_user();
$route = $route ?? 'dashboard';

$role = $u['role'] ?? '';
$isStaff = in_array($role, ['admin','mod'], true);

$nav = [
  ['dashboard','Tổng quan','layout-dashboard'],
  ['shop','Shop','shopping-bag'],
  ['my_keys','Kho key','key-round'],
  ['orders','Đơn hàng','receipt'],
  ['topup','Nạp tiền','credit-card'],
  ['redeem','Nhập mã','ticket'],
  ['referral','Referral','users'],
  ['missions','Nhiệm vụ','check-square'],
  ['lootbox','Lootbox','box'],
  ['spin','Vòng quay','sparkles'],
  ['wishlist','Wishlist','heart'],
  ['showcase','Bộ sưu tập','layout-grid'],
  ['gifts','Tặng quà','gift'],
  ['community','Cộng đồng','messages-square'],
  ['support','Hỗ trợ','life-buoy'],
  ['app','Tải App','smartphone'],
  ['guide','Hướng dẫn','book-open'],
  ['help','Trợ giúp','help-circle'],
  ['vip','VIP','crown'],
];

// Feature gating for sidebar
$featMap = [
  'wishlist'=>'wishlist_enabled',
  'lootbox'=>'lootbox_enabled',
  'spin'=>'spin_enabled',
  'vip'=>'vip_enabled',
  'gifts'=>'gifts_enabled',
  'gift'=>'gifts_enabled',
  'community'=>'community_enabled',
  'app'=>'app_enabled',
  'app_download'=>'app_enabled',
];
$nav = array_values(array_filter($nav, function($it) use ($featMap){
  $r = $it[0] ?? '';
  if(isset($featMap[$r])) return feature_enabled($featMap[$r], true);
  return true;
}));


$nav = array_values(array_filter($nav, function($it){
  return file_exists(__DIR__ . '/../pages/' . $it[0] . '.php');
}));

function nav_item(string $cur, string $route, string $label, string $icon): string {
  $active = is_active_route($cur,$route);
  $cls = $active
    ? 'bg-orange-500/10 border border-orange-500/20 text-orange-200'
    : 'bg-white/0 border border-white/0 text-slate-200/80 hover:bg-white/5 hover:border-white/10';
  $url = e(route_url($route));
  $ico = lucide_icon($icon,'w-5 h-5');
  return "<a class=\"flex items-center gap-3 px-4 py-3 rounded-2xl transition {$cls}\" href=\"{$url}\">{$ico}<span class=\"font-semibold\">{$label}</span></a>";
}
?>
<!-- Desktop fixed sidebar -->
<aside class="hidden lg:flex fixed left-0 top-0 h-full w-[280px] flex-col border-r border-white/10 bg-black/30 backdrop-blur">
  <a href="<?= e(route_url('dashboard')) ?>" class="px-6 py-5 flex items-center gap-3 border-b border-white/10 tap">
    <div class="w-10 h-10 rounded-xl bg-orange-600 grid place-items-center font-black">R</div>
    <div>
      <div class="font-extrabold tracking-wide">RioKey</div>
      <div class="text-xs text-slate-400">Shop bán key/code game</div>
    </div>
  </a>

  <div class="px-4 py-4 overflow-y-auto space-y-2">
    <?php foreach($nav as $it): ?>
      <?= nav_item($route, $it[0], $it[1], $it[2]) ?>
    <?php endforeach; ?>

    <?php if($isStaff): ?>
      <div class="pt-4">
        <div class="text-xs text-slate-500 px-2 mb-2">Quản trị</div>
        <a class="flex items-center gap-3 px-4 py-3 rounded-2xl bg-white/0 border border-white/0 text-slate-200/80 hover:bg-white/5 hover:border-white/10 transition"
           href="<?= e(base_url('/admin/')) ?>">
          <?= lucide_icon('shield','w-5 h-5') ?>
          <span class="font-semibold">Admin Panel</span>
        </a>
      </div>
    <?php endif; ?>
  </div>

  <div class="mt-auto p-4 border-t border-white/10">
    <a class="flex items-center gap-2 px-4 py-3 rounded-2xl text-rose-200 hover:bg-rose-500/10"
       href="<?= e(base_url('/auth/logout.php')) ?>">
       <?= lucide_icon('log-out','w-5 h-5') ?> <span class="font-semibold">Đăng xuất</span>
    </a>
  </div>
</aside>

<!-- Mobile offcanvas -->
<div id="mobileSidebar" class="hidden lg:hidden fixed inset-0 z-50">
  <div id="mobileSidebarBackdrop" class="absolute inset-0 bg-black/60"></div>
  <aside class="absolute left-0 top-0 h-full w-[280px] flex flex-col border-r border-white/10 bg-black/80 backdrop-blur">
    <a href="<?= e(route_url('dashboard')) ?>" class="px-6 py-5 flex items-center gap-3 border-b border-white/10 tap">
      <div class="w-10 h-10 rounded-xl bg-orange-600 grid place-items-center font-black">R</div>
      <div>
        <div class="font-extrabold tracking-wide">RioKey</div>
        <div class="text-xs text-slate-400">Shop bán key/code game</div>
      </div>
      <button class="ml-auto w-10 h-10 rounded-xl hover:bg-white/5 tap" type="button"
              onclick="document.getElementById('mobileSidebar').classList.add('hidden')">
        <?= lucide_icon('x','w-6 h-6') ?>
      </button>
    </a>

    <div class="px-4 py-4 overflow-y-auto space-y-2">
      <?php foreach($nav as $it): ?>
        <a class="flex items-center gap-3 px-4 py-3 rounded-2xl transition <?= is_active_route($route,$it[0])?'bg-orange-500/10 border border-orange-500/20 text-orange-200':'bg-white/0 border border-white/0 text-slate-200/80 hover:bg-white/5 hover:border-white/10' ?>"
           href="<?= e(route_url($it[0])) ?>"
           onclick="document.getElementById('mobileSidebar').classList.add('hidden')">
          <?= lucide_icon($it[2],'w-5 h-5') ?>
          <span class="font-semibold"><?= e($it[1]) ?></span>
        </a>
      <?php endforeach; ?>

      <?php if($isStaff): ?>
        <div class="pt-4">
          <div class="text-xs text-slate-500 px-2 mb-2">Quản trị</div>
          <a class="flex items-center gap-3 px-4 py-3 rounded-2xl bg-white/0 border border-white/0 text-slate-200/80 hover:bg-white/5 hover:border-white/10 transition"
             href="<?= e(base_url('/admin/')) ?>"
             onclick="document.getElementById('mobileSidebar').classList.add('hidden')">
            <?= lucide_icon('shield','w-5 h-5') ?>
            <span class="font-semibold">Admin Panel</span>
          </a>
        </div>
      <?php endif; ?>
    </div>

    <div class="mt-auto p-4 border-t border-white/10">
      <a class="flex items-center gap-2 px-4 py-3 rounded-2xl text-rose-200 hover:bg-rose-500/10"
         href="<?= e(base_url('/auth/logout.php')) ?>">
         <?= lucide_icon('log-out','w-5 h-5') ?> <span class="font-semibold">Đăng xuất</span>
      </a>
    </div>
  </aside>
</div>

<script>
document.addEventListener('DOMContentLoaded', ()=>{
  const wrap = document.getElementById('mobileSidebar');
  const backdrop = document.getElementById('mobileSidebarBackdrop');
  const btnOpen = document.getElementById('btnSidebarOpen');
  const close = ()=>wrap && wrap.classList.add('hidden');
  const open = ()=>wrap && wrap.classList.remove('hidden');
  if(btnOpen) btnOpen.addEventListener('click', (e)=>{ e.preventDefault(); open(); });
  if(backdrop) backdrop.addEventListener('click', close);
  document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') close(); });
});
</script>
