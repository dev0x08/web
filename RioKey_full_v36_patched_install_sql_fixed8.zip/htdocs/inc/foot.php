<?php
$route = $route ?? 'dashboard';
function tab_active($r,$cur){ return $r===$cur ? 'text-orange-300' : 'text-slate-400'; }
?>
<?php if (empty($IS_ADMIN_AREA)): ?>
<nav class="lg:hidden safe-b fixed bottom-0 left-0 right-0 z-40 bg-black/40 backdrop-blur border-t border-white/10">
  <div class="px-6 h-20 flex items-center justify-between">
    <a class="flex flex-col items-center gap-1 <?= tab_active('dashboard',$route) ?>" href="<?= e(route_url('dashboard')) ?>">
      <?= lucide_icon('layout-dashboard','w-6 h-6') ?><span class="text-[11px] font-semibold">Home</span>
    </a>
    <a class="flex flex-col items-center gap-1 <?= tab_active('missions',$route) ?>" href="<?= e(route_url('missions')) ?>">
      <?= lucide_icon('check-circle','w-6 h-6') ?><span class="text-[11px] font-semibold">Nhiệm vụ</span>
    </a>
<a class="flex flex-col items-center gap-1 <?= tab_active('rewards',$route) ?>" href="<?= e(route_url('rewards')) ?>">
      <?= lucide_icon('gift','w-6 h-6') ?><span class="text-[11px] font-semibold">Đổi quà</span>
    </a>
    <a class="flex flex-col items-center gap-1 <?= tab_active('profile',$route) ?>" href="<?= e(route_url('profile')) ?>">
      <?= lucide_icon('user','w-6 h-6') ?><span class="text-[11px] font-semibold">Hồ sơ</span>
    </a>
  </div>
</nav>
<?php endif; ?>

<?php if ($m = flash_get('ok')): ?>
  <div class="fixed top-20 right-4 z-50 px-4 py-3 rounded-2xl border border-emerald-500/20 bg-emerald-500/10 text-emerald-200 shadow-soft">
    ✅ <?= e($m) ?>
  </div>
<?php endif; ?>
<?php if ($m = flash_get('error')): ?>
  <div class="fixed top-20 right-4 z-50 px-4 py-3 rounded-2xl border border-rose-500/20 bg-rose-500/10 text-rose-200 shadow-soft">
    ⚠️ <?= e($m) ?>
  </div>
<?php endif; ?>

<?php
$popup = null;
try {
  $en = (int)setting('popup_enabled', 0);
  if ($en===1) {
    $st = db()->query("SELECT * FROM popups WHERE is_active=1 ORDER BY id DESC LIMIT 1");
    $popup = $st->fetch() ?: null;
  }
} catch (Throwable $e) { $popup = null; }
?>
<?php if ($popup): ?>
<div id="popupBackdrop" class="hidden fixed inset-0 z-[60] bg-black/70 backdrop-blur-sm"></div>
<div id="popupModal" class="hidden fixed inset-0 z-[61] grid place-items-center p-4">
  <div class="card w-full max-w-lg p-5 sm:p-6 relative">
    <button id="popupClose" class="absolute top-3 right-3 btn btn-ghost !px-3 !py-2" type="button">
      <?= lucide_icon('x','w-5 h-5') ?>
    </button>
    <div class="flex items-start gap-3">
      <div class="w-11 h-11 rounded-2xl bg-orange-500/10 border border-orange-500/20 grid place-items-center">
        <?= lucide_icon('sparkles','w-5 h-5 text-orange-300') ?>
      </div>
      <div class="flex-1">
        <div class="text-lg font-extrabold"><?= e($popup['title']) ?></div>
        <div class="text-slate-300/90 mt-1 leading-relaxed whitespace-pre-line"><?= e($popup['content']) ?></div>
      </div>
    </div>
    <div class="mt-5 flex flex-col sm:flex-row gap-3 justify-end">
      <button id="popupOk" class="btn btn-ghost" type="button">Đóng</button>
      <?php if (!empty($popup['button_url'])): ?>
        <a class="btn btn-primary" href="<?= e($popup['button_url']) ?>" target="_blank" rel="noopener">
          <?= e($popup['button_text'] ?: 'Xem ngay') ?>
        </a>
      <?php endif; ?>
    </div>
  </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', ()=>{
  try{
    const k='caff_popup_seen_'+<?= (int)$popup['id'] ?>;
    const seen = localStorage.getItem(k);
    if(!seen){
      const show = ()=>{
        document.getElementById('popupBackdrop')?.classList.remove('hidden');
        document.getElementById('popupModal')?.classList.remove('hidden');
        localStorage.setItem(k,'1');
      };
      show();
      const close = ()=>{
        document.getElementById('popupBackdrop')?.classList.add('hidden');
        document.getElementById('popupModal')?.classList.add('hidden');
      };
      document.getElementById('popupClose')?.addEventListener('click', close);
      document.getElementById('popupOk')?.addEventListener('click', close);
      document.getElementById('popupBackdrop')?.addEventListener('click', close);
      document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') close(); });
    }
  }catch(e){
    // fallback show once
  }
});
</script>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function(){
  if (window.lucide && typeof lucide.createIcons === 'function') {
    lucide.createIcons();
  }
});
</script>

<script>
document.addEventListener('DOMContentLoaded', function(){
  document.querySelectorAll('form[data-once="1"]').forEach(function(form){
    form.addEventListener('submit', function(e){
      if (form.hasAttribute('data-confirm') && form.dataset.confirmed !== '1') { return; }
      if (form.dataset.submitted === '1') { e.preventDefault(); return false; }
      form.dataset.submitted = '1';
      const btn = form.querySelector('button[type="submit"]');
      if (btn) {
        btn.disabled = true;
        btn.classList.add('opacity-60','cursor-not-allowed');
        btn.innerHTML = '<span class="inline-flex items-center gap-2"><span class="w-4 h-4 rounded-full border border-white/40 border-t-transparent animate-spin"></span> Đang xử lý...</span>';
      }
    });
  });
});
</script>


<!-- RioKey Modal (confirm/alert/loading) -->
<div id="riokeyModal" class="fixed inset-0 z-[9999] hidden items-center justify-center p-4">
  <div class="absolute inset-0 bg-black/70"></div>
  <div class="relative w-full max-w-md rounded-3xl border border-white/10 bg-slate-950/90 backdrop-blur p-5 shadow-2xl">
    <div class="flex items-start justify-between gap-3">
      <div>
        <div id="riokeyModalTitle" class="text-lg font-black">Xác nhận</div>
        <div id="riokeyModalDesc" class="text-slate-300 mt-1 text-sm"></div>
      </div>
      <button id="riokeyModalClose" class="p-2 rounded-xl hover:bg-white/5">✕</button>
    </div>
    <div id="riokeyModalBody" class="mt-4"></div>
    <div id="riokeyModalActions" class="mt-5 flex justify-end gap-2">
      <button id="riokeyModalCancel" class="px-4 py-2 rounded-2xl border border-white/10 hover:bg-white/5">Hủy</button>
      <button id="riokeyModalOk" class="px-4 py-2 rounded-2xl bg-orange-500/90 hover:bg-orange-500 text-black font-bold">OK</button>
    </div>
  </div>
</div>
<script>
(function(){
  const el = document.getElementById('riokeyModal');
  const title = document.getElementById('riokeyModalTitle');
  const desc = document.getElementById('riokeyModalDesc');
  const body = document.getElementById('riokeyModalBody');
  const btnOk = document.getElementById('riokeyModalOk');
  const btnCancel = document.getElementById('riokeyModalCancel');
  const btnClose = document.getElementById('riokeyModalClose');

  function openModal({t='Xác nhận', d='', okText='OK', cancelText='Hủy', showCancel=true, onOk=null, onCancel=null, contentHTML=''}) {
    title.textContent = t;
    desc.textContent = d;
    body.innerHTML = contentHTML || '';
    btnOk.textContent = okText;
    btnCancel.textContent = cancelText;
    btnCancel.style.display = showCancel ? '' : 'none';
    el.classList.remove('hidden'); el.classList.add('flex');

    const close = () => { el.classList.add('hidden'); el.classList.remove('flex'); cleanup(); };
    const cleanup = () => {
      btnOk.onclick = null; btnCancel.onclick = null; btnClose.onclick = null;
      el.onclick = null;
    };


  // expose globally for pages needing richer UX (spin/lootbox/vip...)
  window.RioKeyModal = {
    alert: function(titleText, descText){
      openModal({t: titleText || 'Thông báo', d: descText || '', showCancel:false, okText:'OK'});
    },
    confirm: function(titleText, descText, onOk){
      openModal({t: titleText || 'Xác nhận', d: descText || '', showCancel:true, okText:'OK', cancelText:'Hủy', onOk: onOk});
    },
    prompt: function(titleText, placeholderText){
      return new Promise((resolve) => {
        const ph = placeholderText || '';
        openModal({
          t: titleText || 'Nhập thông tin',
          showCancel:true,
          okText:'Xác nhận',
          cancelText:'Hủy',
          contentHTML: '<div class="py-2"><input id="rkPromptInput" class="input w-full" placeholder="'+String(ph).replace(/"/g,'&quot;')+'" autocomplete="off"></div>',
          onOk: function(){
            const v = (document.getElementById('rkPromptInput')||{}).value || '';
            resolve(v);
          },
          onCancel: function(){ resolve(''); }
        });
        setTimeout(()=>{ try{ document.getElementById('rkPromptInput')?.focus(); }catch(e){} }, 30);
      });
    },
    toast: function(msg){
      try{
        const d=document.createElement('div');
        d.className='fixed bottom-4 left-1/2 -translate-x-1/2 px-4 py-2 rounded-xl bg-black/80 border border-white/10 text-sm z-[9999]';
        d.textContent=msg||'';
        document.body.appendChild(d);
        setTimeout(()=>{ d.classList.add('opacity-0'); }, 1300);
        setTimeout(()=>d.remove(), 1600);
      }catch(e){}
    },

    loading: function(titleText, descText){
      openModal({t: titleText || 'Đang xử lý', d: descText || '', showCancel:false, okText:'Đang chạy...', contentHTML:'<div class="py-2 text-slate-300 text-sm flex items-center gap-2"><span class="w-4 h-4 rounded-full border border-white/30 border-t-transparent animate-spin"></span> Vui lòng chờ...</div>'});
      // disable ok button tap while loading
      btnOk.disabled = true; btnOk.classList.add('opacity-60','cursor-not-allowed');
      return { close: function(){ btnOk.disabled=false; btnOk.classList.remove('opacity-60','cursor-not-allowed'); el.classList.add('hidden'); el.classList.remove('flex'); } };
    }
  };


    btnOk.onclick = () => { try{ onOk && onOk(); } finally { close(); } };
    btnCancel.onclick = () => { try{ onCancel && onCancel(); } finally { close(); } };
    btnClose.onclick = () => { try{ onCancel && onCancel(); } finally { close(); } };
    el.onclick = (e) => { if(e.target===el || e.target.classList.contains('bg-black/70')) { try{ onCancel && onCancel(); } finally { close(); } } };
  }

  window.riokeyConfirm = function(message, onYes){
    openModal({t:'Xác nhận', d: message || 'Bạn chắc chứ?', onOk:onYes});
  };
  window.riokeyAlert = function(message){
    openModal({t:'Thông báo', d: message || '', showCancel:false});
  };
  window.riokeyLoading = function(message){
    openModal({t:'Đang xử lý...', d: message || 'Vui lòng chờ...', showCancel:false, contentHTML:'<div class="mt-2 flex items-center gap-3 text-slate-300"><span class="w-5 h-5 rounded-full border border-white/30 border-t-transparent animate-spin"></span><span>Đang xử lý...</span></div>'});
  };

  // Intercept forms with data-confirm to show modal (replaces ugly browser confirm)
  document.addEventListener('submit', function(e){
    const form = e.target;
    if(!(form instanceof HTMLFormElement)) return;
    const msg = form.getAttribute('data-confirm');
    if(msg && form.dataset.confirmed!=='1'){
      e.preventDefault();
      riokeyConfirm(msg.replace(/^['"]|['"]$/g,''), function(){
        form.dataset.confirmed='1';
        // show loading if data-loading
        const lmsg = form.getAttribute('data-loading');
        if(lmsg) { riokeyLoading(lmsg); setTimeout(()=>form.submit(), 150); }
        else { form.submit(); }
      });
    }
  }, true);
})();
</script>

</body></html>


<!-- RioKey Modal Confirm + Activity Toast -->
<div id="rkModal" class="fixed inset-0 z-[80] hidden items-center justify-center p-4">
  <div class="absolute inset-0 bg-black/60" onclick="window.riokeyConfirmClose(false)"></div>
  <div class="relative w-full max-w-md rounded-2xl border border-white/10 bg-slate-950/95 p-5 shadow-2xl">
    <div class="flex items-start justify-between gap-3">
      <div>
        <div class="text-lg font-extrabold" id="rkModalTitle">Xác nhận</div>
        <div class="text-sm text-slate-400 mt-1" id="rkModalMsg"></div>
      </div>
      <button class="btn btn-ghost px-3 py-2" onclick="window.riokeyConfirmClose(false)">✕</button>
    </div>
    <div class="mt-5 flex gap-2 justify-end">
      <button class="btn btn-ghost" id="rkModalCancel" onclick="window.riokeyConfirmClose(false)">Hủy</button>
      <button class="btn" id="rkModalOk" onclick="window.riokeyConfirmClose(true)">OK</button>
    </div>
  </div>
</div>

<div id="rkToastWrap" class="fixed z-[70] right-4 bottom-24 lg:bottom-8 space-y-2"></div>

<script>
(function(){
  let _rkResolve = null;
  window.riokeyConfirm = function(message, title){
    document.getElementById('rkModalCancel').style.display = '';
    document.getElementById('rkModalTitle').textContent = title || 'Xác nhận';
    document.getElementById('rkModalMsg').textContent = message || '';
    const m = document.getElementById('rkModal');
    m.classList.remove('hidden'); m.classList.add('flex');
    return new Promise(res => { _rkResolve = res; });
  };
  window.riokeyConfirmClose = function(val){
    const m = document.getElementById('rkModal');
    m.classList.add('hidden'); m.classList.remove('flex');
    document.getElementById('rkModalCancel').style.display = '';
    if(_rkResolve){ _rkResolve(!!val); _rkResolve=null; }
  };

  window.riokeyAlert = function(message, title){
    document.getElementById('rkModalTitle').textContent = title || 'Thông báo';
    document.getElementById('rkModalMsg').textContent = message || '';
    // hide cancel for alert
    document.getElementById('rkModalCancel').style.display = 'none';
    const m = document.getElementById('rkModal');
    m.classList.remove('hidden'); m.classList.add('flex');
    return new Promise(res => { _rkResolve = (v)=>res(true); });
  };

  window.riokeyRevealAndCopy = async function(btn){
    try{
      const inp = btn.parentElement.querySelector('[data-key]');
      if(!inp) return;
      const key = inp.getAttribute('data-key') || '';
      if(!key) return;
      inp.value = key;
      inp.select(); inp.setSelectionRange(0,99999);
      await navigator.clipboard.writeText(key);
      await window.riokeyAlert('Đã copy key vào clipboard.\n\nLưu ý: Nếu đây là tài khoản, bạn nên đăng nhập và đổi mật khẩu ngay. Nếu là key game/giftcard, hãy redeem sớm để tránh phát sinh lỗi/trùng.', 'Copy thành công');
      // mask back after 8s
      setTimeout(()=>{ inp.value='••••••••••••••••'; }, 8000);
    }catch(e){}
  };


  // Activity toast (disable in admin)
  const isAdmin = window.location.pathname.includes('/admin');
  if(isAdmin) return;
  let since = 0;
  const wrap = document.getElementById('rkToastWrap');
  function toast(html){
    const el = document.createElement('div');
    el.className = 'card px-4 py-3 border border-white/10 bg-slate-950/90 backdrop-blur';
    el.innerHTML = html;
    wrap.appendChild(el);
    setTimeout(()=>{ el.style.opacity='0'; el.style.transform='translateY(6px)'; }, 5200);
    setTimeout(()=>{ el.remove(); }, 6200);
  }
  async function poll(){
    try{
      const url = `index.php?route=activity_feed&since=${since}`;
      const r = await fetch(url, {credentials:'same-origin'});
      const j = await r.json();
      if(j && j.ok && Array.isArray(j.items)){
        j.items.forEach(it=>{
          since = Math.max(since, it.id||0);
          const amt = (it.amount_vnd||0).toLocaleString('vi-VN') + ' đ';
          toast(`<div class="text-sm text-slate-200"><b>Ai đó</b> vừa mua <b>${it.title}</b> (${amt})</div><div class="text-xs text-slate-500 mt-1">Vừa xong</div>`);
        });
      }
    }catch(e){}
    setTimeout(poll, 8000);
  }
  setTimeout(poll, 3000);
})();
</script>



<script>
document.addEventListener('submit', async function(e){
  const f = e.target;
  if(!f || !f.getAttribute) return;
  const msg = f.getAttribute('data-confirm');
  if(f.dataset.confirmed==='1') return;
  if(!msg) return;
  e.preventDefault();
  const ok = await window.riokeyConfirm(msg.replace(/^['"]|['"]$/g,''), 'Xác nhận');
  if(ok){ f.dataset.confirmed='1'; if(f.requestSubmit){ f.requestSubmit(); } else { f.submit(); } }
}, true);
</script>


<script>
document.addEventListener('click', async function(e){
  const el = e.target.closest && e.target.closest('[data-alert]');
  if(!el) return;
  e.preventDefault();
  const msg = el.getAttribute('data-alert') || '';
  await window.riokeyAlert(msg.replace(/^['"]|['"]$/g,''), el.getAttribute('data-alert-title')||'Thông báo');
}, true);
</script>
