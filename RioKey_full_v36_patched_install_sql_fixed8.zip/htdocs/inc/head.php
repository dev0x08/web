<?php
// head.php
$title = $title ?? app_cfg()['app']['name'];
?>
<!doctype html>
<html lang="vi">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
  <title><?= e($title) ?></title>

  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
  <script defer src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
  <script defer src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<style>
    :root { color-scheme: dark; }
    html,body{font-family:'Space Grotesk',system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;}
    body{
      background:
        radial-gradient(1200px 650px at 20% -10%, rgba(255,140,0,.18), transparent 55%),
        radial-gradient(1100px 650px at 80% 0%, rgba(59,130,246,.12), transparent 55%),
        #0b0f14;
    }
    .card{
      border:1px solid rgba(148,163,184,.15);
      border-radius:18px;
      background: linear-gradient(180deg, rgba(255,255,255,.06), rgba(255,255,255,.03));
      backdrop-filter: blur(10px);
    }
    .shadow-soft{ box-shadow: 0 18px 45px rgba(0,0,0,.35); }
    .tap{-webkit-tap-highlight-color:transparent}
    .safe-b{padding-bottom:env(safe-area-inset-bottom)}
    [x-cloak]{display:none !important;}
  
/* ---------- Form system ---------- */

.input, .textarea, .select{
  width:100%;
  background: rgba(2,6,23,.55) !important;
  border:1px solid rgba(148,163,184,.18) !important;
  border-radius:16px !important;
  padding:12px 14px !important;
  color: rgba(226,232,240,.95) !important;
  outline:none !important;
}

label{
  display:block;
  margin-bottom:6px;
  font-size:12px;
  font-weight:800;
  letter-spacing:.08em;
  text-transform:uppercase;
  color: rgba(148,163,184,.9);
}
input, select, textarea{
  width:100%;
  background: rgba(2,6,23,.55);
  border:1px solid rgba(148,163,184,.18);
  border-radius:16px;
  padding:12px 14px;
  color: rgba(226,232,240,.95);
  outline: none;
}
input::placeholder, textarea::placeholder{ color: rgba(148,163,184,.55); }
input:focus, select:focus, textarea:focus{
  border-color: rgba(249,115,22,.55);
  box-shadow: 0 0 0 4px rgba(249,115,22,.12);
}
select{ appearance:none; background-image: linear-gradient(45deg, transparent 50%, rgba(148,163,184,.7) 50%), linear-gradient(135deg, rgba(148,163,184,.7) 50%, transparent 50%); background-position: calc(100% - 18px) 18px, calc(100% - 12px) 18px; background-size: 6px 6px, 6px 6px; background-repeat:no-repeat; padding-right:36px; }
.form-actions{ display:flex; gap:10px; justify-content:flex-end; }

/* Buttons */
.btn{
  display:inline-flex; align-items:center; justify-content:center; gap:10px;
  padding:10px 14px;
  border-radius:16px;
  border:1px solid rgba(255,255,255,.10);
  background: rgba(255,255,255,.06);
  color: rgba(226,232,240,.95);
  font-weight:800;
  letter-spacing:.01em;
}
.btn:hover{ background: rgba(255,255,255,.10); }
.btn:active{ transform: translateY(1px); }
.btn-primary{
  background: linear-gradient(135deg, rgba(249,115,22,.95), rgba(234,88,12,.92));
  border-color: rgba(249,115,22,.45);
  color: #0b0f19;
}
.btn-primary:hover{ filter: brightness(1.05); }
.btn-ghost{ background: rgba(15,23,42,.18); border-color: rgba(148,163,184,.16); }

/* Dropdown */
.dropdown-panel{
  background: rgba(2,6,23,.92);
  border: 1px solid rgba(148,163,184,.16);
  border-radius: 18px;
  box-shadow: 0 24px 60px rgba(0,0,0,.55);
  backdrop-filter: blur(18px);
}


/* Marquee */
.marquee{overflow:hidden;border:1px solid rgba(148,163,184,.14);border-radius:16px;background:rgba(2,6,23,.35);}
.marquee-track{display:flex;gap:28px;white-space:nowrap;animation:marquee 22s linear infinite;padding:10px 14px;}
.marquee-item{color:rgba(226,232,240,.92);font-weight:700}
@keyframes marquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}
.hero-img{width:100%;height:170px;object-fit:cover;border-radius:18px;border:1px solid rgba(255,255,255,.10)}

.line-clamp-2{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}

/* Modal */
.modal{position:fixed;inset:0;z-index:60;display:grid;place-items:center;padding:18px;}
.modal.hidden{display:none;}
.modal-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.65);backdrop-filter:blur(6px);}
.modal-panel{position:relative;z-index:1;width:min(560px, 92vw);background:rgba(2,6,23,.92);border:1px solid rgba(148,163,184,.16);border-radius:22px;box-shadow:0 30px 80px rgba(0,0,0,.55);overflow:hidden;}
.modal-head{display:flex;align-items:center;justify-content:space-between;padding:14px 16px;border-bottom:1px solid rgba(148,163,184,.12);}


/* Switch */
.switch{position:relative;display:inline-block;width:54px;height:30px}
.switch input{opacity:0;width:0;height:0}
.slider{position:absolute;cursor:pointer;inset:0;background:rgba(148,163,184,.25);transition:.2s;border-radius:999px;border:1px solid rgba(148,163,184,.25)}
.slider:before{position:absolute;content:"";height:24px;width:24px;left:3px;top:3px;background:white;transition:.2s;border-radius:999px}
.switch input:checked + .slider{background:rgba(249,115,22,.35);border-color:rgba(249,115,22,.35)}
.switch input:checked + .slider:before{transform:translateX(24px);background:rgba(253,186,116,1)}

</style>
</head>
<body class="text-slate-100">
