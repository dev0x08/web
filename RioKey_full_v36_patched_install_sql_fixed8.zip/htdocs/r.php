<?php
require_once __DIR__.'/bootstrap.php';
// Legacy short link kept for compatibility. Referral system has been removed.
redirect(base_url('/auth/register.php'));
