<?php
// RioKey Installer (MariaDB/MySQL) - delete /install after done!
error_reporting(E_ALL);
ini_set('display_errors','1');

$root = realpath(__DIR__ . '/..');
$configFile = $root . '/config.php';
$sqlFile = $root . '/data/riokey_full_clean_v35.sql';
$lockFile = __DIR__ . '/installed.lock';

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

if (file_exists($lockFile)) {
  echo '<!doctype html><meta charset="utf-8"><title>Installed</title><style>body{font-family:system-ui;background:#0b0b10;color:#fff;display:grid;place-items:center;min-height:100vh;margin:0} .box{max-width:760px;padding:28px;border:1px solid rgba(255,255,255,.12);border-radius:18px;background:rgba(255,255,255,.04)} code{color:#fb923c}</style><div class="box"><h2>✅ Đã cài đặt</h2><p>Vì bảo mật, hãy <b>xoá thư mục <code>/install</code></b> khỏi hosting. Sau đó truy cập trang chủ.</p></div>';
  exit;
}

$err = '';
$ok = '';
$values = [
  'db_host' => $_POST['db_host'] ?? '127.0.0.1',
  'db_name' => $_POST['db_name'] ?? 'riokey',
  'db_user' => $_POST['db_user'] ?? 'root',
  'db_pass' => $_POST['db_pass'] ?? '',
  'app_url' => $_POST['app_url'] ?? ( (isset($_SERVER['HTTPS'])?'https':'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') ),
];

function split_sql($sql){
  $out = [];
  $buf = '';
  $inS = false; $inD = false; $inB = false; // single/double/backtick
  $len = strlen($sql);
  for($i=0;$i<$len;$i++){
    $ch = $sql[$i];
    $n1 = $i+1<$len ? $sql[$i+1] : '';
    // handle comments -- and #
    if(!$inS && !$inD && !$inB){
      if($ch==='-' && $n1==='-'){
        // skip until newline
        while($i<$len && $sql[$i]!="\n") $i++;
        continue;
      }
      if($ch==='#'){
        while($i<$len && $sql[$i]!="\n") $i++;
        continue;
      }
    }
    if($ch==="'" && !$inD && !$inB){
      $inS = !$inS;
    } elseif($ch=='"' && !$inS && !$inB){
      $inD = !$inD;
    } elseif($ch=='`' && !$inS && !$inD){
      $inB = !$inB;
    }
    if($ch===';' && !$inS && !$inD && !$inB){
      $stmt = trim($buf);
      $buf = '';
      if($stmt!=='') $out[] = $stmt;
      continue;
    }
    $buf .= $ch;
  }
  $stmt = trim($buf);
  if($stmt!=='') $out[] = $stmt;
  return $out;
}

if ($_SERVER['REQUEST_METHOD']==='POST') {
  try{
    if (!file_exists($sqlFile)) throw new Exception('Không tìm thấy file SQL: ' . $sqlFile);

    $host = trim((string)$values['db_host']);
    $name = trim((string)$values['db_name']);
    $user = trim((string)$values['db_user']);
    $pass = (string)$values['db_pass'];

    if($host=='' || $name=='' || $user=='') throw new Exception('Vui lòng nhập đầy đủ thông tin DB.');

    $pdo = new PDO("mysql:host={$host};charset=utf8mb4", $user, $pass, [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    // prepare SQL: swap db name in seed file
    $sql = file_get_contents($sqlFile);
    $sql = preg_replace('/DROP DATABASE IF EXISTS\s+`?riokey`?/i', 'DROP DATABASE IF EXISTS `' . addslashes($name) . '`', $sql);
    $sql = preg_replace('/CREATE DATABASE\s+`?riokey`?/i', 'CREATE DATABASE `' . addslashes($name) . '`', $sql);
    $sql = preg_replace('/USE\s+`?riokey`?/i', 'USE `' . addslashes($name) . '`', $sql);

    $stmts = split_sql($sql);
    foreach($stmts as $st){
      $trim = ltrim($st);
      if (preg_match('/^(SELECT|SHOW|DESCRIBE|EXPLAIN)/i', $trim)) {
        $q = $pdo->query($st);
        if ($q) { $q->closeCursor(); }
      } else {
        $pdo->exec($st);
      }
    }

    // write config.php
    $cfg = "<?php\nreturn [\n  'app' => [\n    'name' => 'RioKey',\n    'url'  => " . var_export((string)$values['app_url'], true) . ",\n  ],\n  'db' => [\n    'host' => " . var_export($host, true) . ",\n    'name' => " . var_export($name, true) . ",\n    'user' => " . var_export($user, true) . ",\n    'pass' => " . var_export($pass, true) . ",\n    'charset' => 'utf8mb4',\n  ],\n];\n";
    file_put_contents($configFile, $cfg);

    // lock
    file_put_contents($lockFile, date('c'));

    $ok = 'Cài đặt thành công! Vì bảo mật, hãy xoá thư mục /install rồi truy cập trang chủ.';
  } catch(Throwable $e){
    $err = $e->getMessage();
  }
}

?>
<!doctype html>
<meta charset="utf-8">
<title>RioKey Install</title>
<style>
  body{font-family:system-ui;background:#0b0b10;color:#fff;margin:0;min-height:100vh;display:grid;place-items:center}
  .box{max-width:820px;width:92vw;padding:28px;border:1px solid rgba(255,255,255,.12);border-radius:18px;background:rgba(255,255,255,.04)}
  h1{margin:0 0 8px}
  .muted{color:rgba(255,255,255,.72);font-size:14px}
  label{display:block;font-weight:700;margin-top:14px}
  input{width:100%;padding:12px 14px;border-radius:14px;border:1px solid rgba(255,255,255,.14);background:rgba(0,0,0,.25);color:#fff}
  button{margin-top:18px;padding:12px 16px;border-radius:14px;border:1px solid rgba(251,146,60,.35);background:rgba(251,146,60,.15);color:#fff;font-weight:900;cursor:pointer}
  .err{margin-top:14px;padding:12px;border-radius:14px;border:1px solid rgba(244,63,94,.35);background:rgba(244,63,94,.12)}
  .ok{margin-top:14px;padding:12px;border-radius:14px;border:1px solid rgba(34,197,94,.35);background:rgba(34,197,94,.12)}
  code{color:#fb923c}
</style>
<div class="box">
  <h1>RioKey Installer</h1>
  <div class="muted">Nhập thông tin DB để tự import dữ liệu. Sau khi xong, hệ thống sẽ yêu cầu bạn xoá thư mục <code>/install</code>.</div>

  <?php if($err): ?><div class="err">❌ <?= h($err) ?></div><?php endif; ?>
  <?php if($ok): ?><div class="ok">✅ <?= h($ok) ?></div><?php endif; ?>

  <form method="post">
    <label>DB Host</label>
    <input name="db_host" value="<?= h($values['db_host']) ?>" placeholder="127.0.0.1">

    <label>DB Name</label>
    <input name="db_name" value="<?= h($values['db_name']) ?>" placeholder="riokey">

    <label>DB User</label>
    <input name="db_user" value="<?= h($values['db_user']) ?>" placeholder="root">

    <label>DB Pass</label>
    <input name="db_pass" value="<?= h($values['db_pass']) ?>" placeholder="">

    <label>App URL</label>
    <input name="app_url" value="<?= h($values['app_url']) ?>" placeholder="https://domain.com">

    <button type="submit">Install + Import DB</button>
  </form>

  <div class="muted" style="margin-top:14px">
    File SQL: <code><?= h($sqlFile) ?></code><br>
    Config sẽ tạo tại: <code><?= h($configFile) ?></code>
  </div>
</div>
