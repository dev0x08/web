<?php
require_once __DIR__ . '/../bootstrap.php';
logout();
flash_set('success','Đã đăng xuất.');
redirect(base_url('/auth/login.php'));
