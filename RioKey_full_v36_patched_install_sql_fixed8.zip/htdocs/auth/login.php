<?php
require_once __DIR__ . '/../bootstrap.php';

if (auth_user()) redirect(base_url('/dashboard'));

$err = null;
$captcha_on = setting_get('captcha_login_enabled', false);
$google_on = setting_get('google_login_enabled', false);
$google_client = trim((string)setting_get('google_client_id',''));

if ($captcha_on && empty($_SESSION['captcha_q_login'])) {
  $a = random_int(2, 9);
  $b = random_int(1, 9);
  $_SESSION['captcha_q_login'] = "{$a}+{$b}";
  $_SESSION['captcha_a_login'] = (string)($a+$b);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_require();
  $email = strtolower(trim($_POST['email'] ?? ''));
  $pass  = (string)($_POST['password'] ?? '');
  $captcha = trim($_POST['captcha'] ?? '');

  if ($captcha_on) {
    $ans = $_SESSION['captcha_a_login'] ?? '';
    if ($captcha === '' || $captcha !== $ans) {
      $err = 'Captcha không đúng.';
    }
  }

  if (!$err) {
    if (login($email, $pass)) {
      unset($_SESSION['captcha_q_login'], $_SESSION['captcha_a_login']);
      redirect(base_url('/dashboard'));
    }
    $err = 'Email hoặc mật khẩu không đúng.';
  }
}

$title = "Đăng nhập";
include __DIR__ . '/../inc/head.php';
?>
<div class="min-h-screen grid place-items-center px-4">
  <div class="w-full max-w-md card p-7">
    <div class="text-2xl font-black">Đăng nhập</div>
    <div class="text-slate-400 mt-1">Chào mừng quay lại 👋</div><?php if($google_on && $google_client !== ''): ?>
  <a href="<?= base_url('/auth/google.php') ?>" class="mt-5 btn w-full justify-center gap-2 border border-white/10 bg-white/5 hover:bg-white/10">
    <?= lucide_icon('chrome','w-5 h-5') ?>
    <span>Đăng nhập bằng Google</span>
  </a>
  <div class="mt-4 flex items-center gap-3">
    <div class="h-px flex-1 bg-white/10"></div>
    <div class="text-xs text-slate-500">hoặc</div>
    <div class="h-px flex-1 bg-white/10"></div>
  </div>
<?php endif; ?>

    <?php if($err): ?>
      <div class="mt-4 rounded-2xl border border-rose-500/25 bg-rose-500/10 p-4 text-rose-200 text-sm"><?= e($err) ?></div>
    <?php endif; ?>

    <form method="post" class="mt-5 space-y-3">
      <?= csrf_field() ?>
      <label>Email</label>
      <input class="input" name="email" type="email" placeholder="you@email.com" required>

      <label>Mật khẩu</label>
      <input class="input" name="password" type="password" placeholder="••••••••" required>

      <?php if($captcha_on): ?>
        <label>Captcha: <?= e($_SESSION['captcha_q_login'] ?? '') ?> = ?</label>
        <input class="input" name="captcha" placeholder="Nhập kết quả" required>
      <?php endif; ?>

      <button class="btn btn-primary w-full mt-2">Đăng nhập</button>
      <a class="btn btn-ghost w-full" href="<?= e(base_url('/auth/register.php')) ?>">Tạo tài khoản</a>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../inc/foot.php'; ?>
