<?php
require_once __DIR__ . '/../bootstrap.php';

if (auth_user()) redirect(base_url('/dashboard'));

$enabled = setting_get('google_login_enabled', false);
$client_id = trim((string)setting_get('google_client_id',''));
if (!$enabled || $client_id==='') {
  redirect(base_url('/auth/login.php'));
}

$state = bin2hex(random_bytes(16));
$_SESSION['google_oauth_state'] = $state;

// Keep ref cookie as-is (set by /r/...), nothing else needed.

$redirect_uri = base_url('/auth/google-callback.php');
$scope = urlencode('openid email profile');
$auth_url = 'https://accounts.google.com/o/oauth2/v2/auth'
  . '?client_id=' . urlencode($client_id)
  . '&redirect_uri=' . urlencode($redirect_uri)
  . '&response_type=code'
  . '&scope=' . $scope
  . '&state=' . urlencode($state)
  . '&prompt=select_account';

redirect($auth_url);
