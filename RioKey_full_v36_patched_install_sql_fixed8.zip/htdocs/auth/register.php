<?php
require_once __DIR__ . '/../bootstrap.php';

if (auth_user()) redirect(route_url('dashboard'));

$err = null;
$ok = null;
$captcha_on = setting_get('captcha_enabled', true);
$ref_in = trim((string)($_GET['ref'] ?? ($_POST['ref'] ?? '')));
$ref_in = strtoupper(preg_replace('/[^a-zA-Z0-9]/','',$ref_in));

$google_on = setting_get('google_login_enabled', false);
$google_client = trim((string)setting_get('google_client_id',''));

if ($captcha_on && empty($_SESSION['captcha_q'])) {
  $a = random_int(2, 9);
  $b = random_int(1, 9);
  $_SESSION['captcha_q'] = "{$a}+{$b}";
  $_SESSION['captcha_a'] = (string)($a+$b);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_require();

  // Register rate limit per IP
  $ip = client_ip();
  $rlim = (int)setting('register_req_limit', 6);   // per window
  $rwin = (int)setting('register_req_window', 600); // seconds
  if ($rlim > 0 && $rwin > 0 && rate_limit_exceeded('regip:'.$ip, $rlim, $rwin)) {
    ip_block($ip, 'Auto block: register rate limit', (int)setting('register_block_minutes', 10), null);
    $err = 'Bạn thao tác quá nhanh. Vui lòng thử lại sau.';
  }
  $name = trim($_POST['name'] ?? '');
  $email = strtolower(trim($_POST['email'] ?? ''));
  $phone = trim($_POST['phone'] ?? '');
  $pass = (string)($_POST['password'] ?? '');
  $pass2 = (string)($_POST['password2'] ?? '');
  $captcha = trim($_POST['captcha'] ?? '');

  if ($name === '' || $email === '' || $pass === '') $err = 'Vui lòng nhập đầy đủ thông tin.';
  elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $err = 'Email không hợp lệ.';
  elseif (strlen($pass) < 6) $err = 'Mật khẩu tối thiểu 6 ký tự.';
  elseif ($pass !== $pass2) $err = 'Nhập lại mật khẩu không khớp.';
  elseif ($captcha_on) {
    $ans = $_SESSION['captcha_a'] ?? '';
    if ($captcha === '' || $captcha !== $ans) $err = 'Captcha không đúng.';
  }

  if (!$err) {
    try {
      $hash = password_hash($pass, PASSWORD_DEFAULT);
      $ref = substr(bin2hex(random_bytes(6)), 0, 10);
      // RioKey: bỏ referral/cookie. Vẫn tạo ref_code cho tương thích DB.
      db()->prepare("INSERT INTO users (name,email,password_hash,phone,ref_code,is_admin,referred_by,referred_at) VALUES (?,?,?,?,?,0,NULL,NULL)")
        ->execute([$name,$email,$hash,$phone,$ref]);
      $newId = (int)db()->lastInsertId();
      security_log($newId, 'register', ['email'=>$email]);
      // Referral: if user came with ?ref=CODE then bind referrer
      if ($ref_in !== '') {
        referral_set_referred_by_on_register($ref_in, ['id'=>$newId]);
      }

      unset($_SESSION['captcha_q'], $_SESSION['captcha_a']);
      $ok = 'Đăng ký thành công. Bạn có thể đăng nhập ngay.';
      // legacy cookie (nếu có) bỏ qua
    } catch (Throwable $e) {
      $err = 'Email đã tồn tại hoặc có lỗi hệ thống.';
    }
  }

  if ($captcha_on) {
    $a = random_int(2, 9);
    $b = random_int(1, 9);
    $_SESSION['captcha_q'] = "{$a}+{$b}";
    $_SESSION['captcha_a'] = (string)($a+$b);
  }
}
?>
<?php include __DIR__ . '/../inc/head.php'; ?>
<body class="bg-slate-950 text-slate-100 min-h-screen">
  <div class="min-h-screen grid place-items-center p-4">
    <div class="card w-full max-w-md p-6 sm:p-7">
      <div class="flex items-center gap-3">
        <div class="w-12 h-12 rounded-2xl bg-orange-500 grid place-items-center shadow-lg shadow-orange-500/20">
          <span class="font-black text-black text-xl">R</span>
        </div>
        <div>
          <div class="text-xl font-extrabold">RioKey</div>
          <div class="text-xs text-slate-400">Shop bán key/code game</div>
        </div>
      </div>

      <h1 class="text-2xl font-black mt-5">Tạo tài khoản</h1>
      <p class="text-slate-400 mt-1">Đăng ký để mua/đổi key game</p>

      <?php if ($err): ?>
        <div class="mt-4 rounded-2xl border border-rose-500/30 bg-rose-500/10 p-4 text-rose-200 text-sm">
          <?= e($err) ?>
        </div>
      <?php endif; ?>
      <?php if ($ok): ?>
        <div class="mt-4 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-4 text-emerald-200 text-sm">
          <?= e($ok) ?>
        </div>
      <?php endif; ?>

      

<?php if($google_on && $google_client !== ''): ?>
  <a href="<?= base_url('/auth/google.php') ?>" class="mt-5 btn w-full justify-center gap-2 border border-white/10 bg-white/5 hover:bg-white/10">
    <?= lucide_icon('chrome','w-5 h-5') ?>
    <span>Đăng ký / Đăng nhập bằng Google</span>
  </a>
  <div class="mt-4 flex items-center gap-3">
    <div class="h-px flex-1 bg-white/10"></div>
    <div class="text-xs text-slate-500">hoặc</div>
    <div class="h-px flex-1 bg-white/10"></div>
  </div>
<?php endif; ?>

<form class="mt-5 space-y-4" method="post">
        <?= csrf_field() ?>
        <div>
          <label>Họ và tên</label>
          <input name="name" required class="input" value="<?= e($_POST['name'] ?? '') ?>" placeholder="Anh Nguyễn" />
        </div>
        <div>
          <label>Email</label>
          <input type="email" name="email" required class="input" value="<?= e($_POST['email'] ?? '') ?>" placeholder="you@gmail.com" />
        </div>
        <div>
          <label>Số điện thoại</label>
          <input name="phone" class="input" value="<?= e($_POST['phone'] ?? '') ?>" placeholder="09xxxxxxxx" />
        </div>
        <div>
          <label>Mật khẩu</label>
          <input type="password" name="password" required class="input" placeholder="••••••••" />
        </div>
        <div>
          <label>Nhập lại mật khẩu</label>
          <input type="password" name="password2" required class="input" placeholder="••••••••" />
        </div>

        <?php if ($captcha_on): ?>
        <div>
          <label>Captcha: <?= e($_SESSION['captcha_q'] ?? '') ?> = ?</label>
          <input name="captcha" required class="input" placeholder="Nhập kết quả" />
        </div>
        <?php endif; ?>

        <button class="btn btn-primary w-full">Đăng ký</button>

        <div class="text-sm text-slate-400 text-center">
          Đã có tài khoản?
          <a class="text-orange-300 hover:underline" href="<?= e(base_url('/auth/login.php')) ?>">Đăng nhập</a>
        </div>
      </form>
    </div>
  </div>
<?php include __DIR__ . '/../inc/foot.php'; ?>
