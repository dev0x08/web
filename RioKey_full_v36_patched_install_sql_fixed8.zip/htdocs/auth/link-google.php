<?php
require_once __DIR__ . '/../bootstrap.php';

if (auth_user()) redirect(base_url('/dashboard'));

$pending = $_SESSION['pending_google_link'] ?? null;
if (!$pending || empty($pending['user_id']) || empty($pending['sub'])) {
  redirect(base_url('/auth/login.php'));
}

$err = null;
if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_require();
  $password = (string)($_POST['password'] ?? '');
  if ($password==='') $err = 'Vui lòng nhập mật khẩu tài khoản của bạn.';
  else {
    try {
      $st = db()->prepare("SELECT id,password_hash FROM users WHERE id=? LIMIT 1");
      $st->execute([(int)$pending['user_id']]);
      $u = $st->fetch();
      if (!$u || !password_verify($password, $u['password_hash'])) {
        $err = 'Mật khẩu không đúng.';
      } else {
        db()->prepare("UPDATE users SET google_id=?, email_verified=1, avatar_url=COALESCE(NULLIF(avatar_url,''), ?) WHERE id=?")
          ->execute([$pending['sub'], $pending['picture'] ?? null, (int)$pending['user_id']]);
        login_user_id((int)$pending['user_id']);
        unset($_SESSION['pending_google_link']);
        redirect(base_url('/dashboard'));
      }
    } catch (Throwable $e) {
      $err = 'Không thể liên kết Google lúc này.';
    }
  }
}

$title="Liên kết Google";
include __DIR__ . '/../inc/head.php';
?>
<body class="bg-slate-950 text-slate-100 min-h-screen">
<div class="min-h-screen grid place-items-center p-4">
  <div class="card w-full max-w-md p-6 sm:p-7">
    <div class="text-2xl font-black">Xác nhận liên kết Google</div>
    <div class="text-slate-400 mt-1 text-sm">
      Email Google <b><?= e($pending['email']) ?></b> trùng với tài khoản hiện có. Nhập mật khẩu để liên kết an toàn.
    </div>

    <?php if($err): ?>
      <div class="mt-4 rounded-2xl border border-rose-500/25 bg-rose-500/10 p-4 text-rose-200 text-sm"><?= e($err) ?></div>
    <?php endif; ?>

    <form method="post" class="mt-5 space-y-3">
      <?= csrf_field() ?>
      <label>Mật khẩu</label>
      <input class="input" name="password" type="password" placeholder="••••••••" required>
      <button class="btn btn-primary w-full mt-2" type="submit">Liên kết</button>
      <a class="btn w-full mt-2 bg-white/5 hover:bg-white/10 border border-white/10" href="<?= base_url('/auth/login.php') ?>">Quay lại đăng nhập</a>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../inc/foot.php'; ?>
