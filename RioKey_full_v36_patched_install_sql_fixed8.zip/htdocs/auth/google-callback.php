<?php
require_once __DIR__ . '/../bootstrap.php';

if (auth_user()) redirect(base_url('/dashboard'));

$enabled = setting_get('google_login_enabled', false);
$client_id = trim((string)setting_get('google_client_id',''));
$client_secret = trim((string)setting_get('google_client_secret',''));

if (!$enabled || $client_id==='' || $client_secret==='') {
  redirect(base_url('/auth/login.php'));
}

$state = $_GET['state'] ?? '';
$code  = $_GET['code'] ?? '';

if ($state==='' || $code==='' || empty($_SESSION['google_oauth_state']) || !hash_equals($_SESSION['google_oauth_state'], $state)) {
  unset($_SESSION['google_oauth_state']);
  redirect(base_url('/auth/login.php?err=oauth_state'));
}
unset($_SESSION['google_oauth_state']);

$redirect_uri = base_url('/auth/google-callback.php');

// Exchange code for tokens
$token_url = 'https://oauth2.googleapis.com/token';
$post = http_build_query([
  'code' => $code,
  'client_id' => $client_id,
  'client_secret' => $client_secret,
  'redirect_uri' => $redirect_uri,
  'grant_type' => 'authorization_code'
]);

$ch = curl_init($token_url);
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_POST => true,
  CURLOPT_POSTFIELDS => $post,
  CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
  CURLOPT_TIMEOUT => 15,
]);
$resp = curl_exec($ch);
$http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($http < 200 || $http >= 300 || !$resp) {
  redirect(base_url('/auth/login.php?err=oauth_token'));
}

$data = json_decode($resp, true);
$access = $data['access_token'] ?? '';
if ($access==='') redirect(base_url('/auth/login.php?err=oauth_token2'));

// Get userinfo
$ui_url = 'https://openidconnect.googleapis.com/v1/userinfo';
$ch = curl_init($ui_url);
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HTTPHEADER => ['Authorization: Bearer '.$access],
  CURLOPT_TIMEOUT => 15,
]);
$ui = curl_exec($ch);
$http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($http < 200 || $http >= 300 || !$ui) redirect(base_url('/auth/login.php?err=oauth_userinfo'));

$info = json_decode($ui, true);
$sub = (string)($info['sub'] ?? '');
$email = strtolower(trim((string)($info['email'] ?? '')));
$name  = trim((string)($info['name'] ?? ''));
$picture = trim((string)($info['picture'] ?? ''));

if ($sub==='' || $email==='') redirect(base_url('/auth/login.php?err=oauth_profile'));

try {
  // 1) Existing by google_id
  $st = db()->prepare("SELECT id FROM users WHERE google_id=? LIMIT 1");
  $st->execute([$sub]);
  $row = $st->fetch();
  if ($row) {
    login_user_id((int)$row['id']);
    redirect(base_url('/dashboard'));
  }

  // 2) Existing by email => require linking
  $st = db()->prepare("SELECT id,password_hash,google_id FROM users WHERE email=? LIMIT 1");
  $st->execute([$email]);
  $u = $st->fetch();
  if ($u) {
    // If already linked to another google_id (shouldn't happen) block
    if (!empty($u['google_id'])) {
      redirect(base_url('/auth/login.php?err=google_already_linked'));
    }
    $_SESSION['pending_google_link'] = [
      'sub' => $sub,
      'email' => $email,
      'name' => $name,
      'picture' => $picture,
      'user_id' => (int)$u['id'],
    ];
    redirect(base_url('/auth/link-google.php'));
  }

  // 3) Create new user
  $ref = substr(bin2hex(random_bytes(6)), 0, 10);
  $randPass = bin2hex(random_bytes(16));
  $hash = password_hash($randPass, PASSWORD_DEFAULT);

  // RioKey: bỏ referral/cookie, và tương thích schema users (không cần email_verified)
  db()->prepare("INSERT INTO users (name,email,password_hash,phone,avatar_url,ref_code,is_admin,google_id,referred_by,referred_at)
                 VALUES (?,?,?,?,?,?,0,?,NULL,NULL)")
     ->execute([$name!==''?$name:'Google User', $email, $hash, null, $picture?:null, $ref, $sub]);

  $newId = (int)db()->lastInsertId();

  login_user_id($newId);
  redirect(base_url('/dashboard'));

} catch (Throwable $e) {
  redirect(base_url('/auth/login.php?err=oauth_db'));
}
