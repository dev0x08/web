// assets/js/api.js

// API Client
class ApiClient {
    constructor(baseUrl) {
        this.baseUrl = baseUrl;
        this.token = localStorage.getItem('api_token');
    }

    setToken(token) {
        this.token = token;
        localStorage.setItem('api_token', token);
    }

    removeToken() {
        this.token = null;
        localStorage.removeItem('api_token');
    }

    async request(endpoint, options = {}) {
        const url = this.baseUrl + endpoint;
        const headers = {
            'Content-Type': 'application/json',
            ...options.headers
        };

        if (this.token) {
            headers['Authorization'] = `Bearer ${this.token}`;
        }

        const config = {
            ...options,
            headers
        };

        try {
            const response = await fetch(url, config);
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || 'API request failed');
            }

            return data;
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    }

    async get(endpoint, params = {}) {
        const url = new URL(endpoint, this.baseUrl);
        Object.keys(params).forEach(key =>
            url.searchParams.append(key, params[key])
        );

        return this.request(url.pathname + url.search, {
            method: 'GET'
        });
    }

    async post(endpoint, data = {}) {
        return this.request(endpoint, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }

    async put(endpoint, data = {}) {
        return this.request(endpoint, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    }

    async delete(endpoint) {
        return this.request(endpoint, {
            method: 'DELETE'
        });
    }
}

// Key Manager API
class KeyManagerApi {
    constructor(client) {
        this.client = client;
    }

    async verifyKey(key) {
        return this.client.get('/api/keyadmin.php', { action: 'verify', key });
    }

    async listKeys() {
        return this.client.get('/api/keyadmin.php', { action: 'list' });
    }

    async generateKey(name) {
        return this.client.get('/api/keyadmin.php', { action: 'generate', name });
    }

    async disableKey(id) {
        return this.client.get('/api/keyadmin.php', { action: 'disable', id });
    }

    async enableKey(id) {
        return this.client.get('/api/keyadmin.php', { action: 'enable', id });
    }

    async deleteKey(id) {
        return this.client.get('/api/keyadmin.php', { action: 'delete', id });
    }

    async renewKey(id, days) {
        return this.client.get('/api/keyadmin.php', { action: 'renew', id, days });
    }
}

// API Manager API
class ApiManagerApi {
    constructor(client) {
        this.client = client;
    }

    async listApis() {
        return this.client.get('/api/api_manager.php', { action: 'list' });
    }

    async getActiveApis() {
        return this.client.get('/api/api_manager.php', { action: 'active' });
    }

    async getApi(id) {
        return this.client.get('/api/api_manager.php', { action: 'get', id });
    }

    async addApi(data) {
        return this.client.post('/api/api_manager.php?action=add', data);
    }

    async updateApi(id, data) {
        return this.client.post(`/api/api_manager.php?action=update&id=${id}`, data);
    }

    async deleteApi(id) {
        return this.client.get('/api/api_manager.php', { action: 'delete', id });
    }

    async toggleApi(id) {
        return this.client.get('/api/api_manager.php', { action: 'toggle', id });
    }

    async testApi(id, phone) {
        return this.client.get('/api/api_manager.php', { action: 'test', id, phone });
    }
}

// User API
class UserApi {
    constructor(client) {
        this.client = client;
    }

    async login(username, password) {
        const data = await this.client.post('/api/user_api.php?action=login', {
            username, password
        });

        if (data.success && data.token) {
            this.client.setToken(data.token);
        }

        return data;
    }

    async logout() {
        const data = await this.client.get('/api/user_api.php?action=logout');
        this.client.removeToken();
        return data;
    }

    async validateToken() {
        return this.client.get('/api/user_api.php?action=validate');
    }

    async validateKey(key) {
        return this.client.get('/api/user_api.php', { action: 'validate_key', key });
    }

    async register(userData) {
        return this.client.post('/api/user_api.php?action=register', userData);
    }

    async getStats() {
        return this.client.get('/api/user_api.php?action=stats');
    }
}

// Spam API
class SpamApi {
    constructor(client) {
        this.client = client;
    }

    async sendSms(phone, loop = 1, delay = 0, features = {}, apiKey) {
        const response = await fetch('/process.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WusTeam': apiKey
            },
            body: JSON.stringify({
                sdt: phone,
                loop,
                delay,
                features,
                api_key: apiKey
            })
        });

        return response.json();
    }
}

// Initialize API client
const apiClient = new ApiClient(window.location.origin);
const keyManager = new KeyManagerApi(apiClient);
const apiManager = new ApiManagerApi(apiClient);
const userApi = new UserApi(apiClient);
const spamApi = new SpamApi(apiClient);