<?php
// config/constants.php

// Đường dẫn
define('ROOT_PATH', dirname(__DIR__) . '/');
define('INCLUDES_PATH', ROOT_PATH . 'includes/');
define('API_PATH', ROOT_PATH . 'api/');
define('ADMIN_PATH', ROOT_PATH . 'admin/');
define('LOGS_PATH', ROOT_PATH . 'logs/');
define('ASSETS_PATH', ROOT_PATH . 'assets/');

// URL - Fix cho XAMPP
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
$dirName = dirname($scriptName);
$basePath = $dirName == '/' || $dirName == '\\' ? '' : $dirName;

define('BASE_URL', $protocol . $host . $basePath . '/');
define('API_URL', BASE_URL . 'api/');
define('ADMIN_URL', BASE_URL . 'admin/');

// File paths
define('KEYS_FILE', ROOT_PATH . 'keys.json');
define('APIS_FILE', ROOT_PATH . 'apis.json');
define('LOG_FILE_API', LOGS_PATH . 'api_manager.log');
define('LOG_FILE_KEY', LOGS_PATH . 'keyadmin.log');
define('LOG_FILE_USER', LOGS_PATH . 'user_manager.log');

// Thời gian
define('SESSION_LIFETIME', 7 * 24 * 3600); // 7 days
define('KEY_EXPIRY_DAYS', 30);
define('RATE_LIMIT', 10);
define('RATE_LIMIT_WINDOW', 3600);

// API Settings
define('CURL_TIMEOUT', 30);
define('MAX_REDIRECTS', 10);
define('USER_AGENT', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');

// Debug
define('DEBUG_MODE', false);
define('LOG_LEVEL', 'INFO');