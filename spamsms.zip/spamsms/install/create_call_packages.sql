-- Tạo bảng call_packages
CREATE TABLE IF NOT EXISTS `call_packages` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `description` VARCHAR(255) DEFAULT '',
    `price` INT NOT NULL DEFAULT 0,
    `duration` INT NOT NULL DEFAULT 0,
    `duration_hours` INT NOT NULL DEFAULT 0,
    `max_uses` INT NOT NULL DEFAULT 0,
    `sort_order` INT DEFAULT 0,
    `status` ENUM('on','off') DEFAULT 'on',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed dữ liệu mặc định (sẽ bỏ qua nếu đã có data)
INSERT INTO `call_packages` (`name`, `description`, `price`, `duration`, `duration_hours`, `max_uses`, `sort_order`, `status`)
SELECT * FROM (SELECT 'Gói 1 Giờ', 'Dùng thử 1 tiếng, max 50 lượt', COALESCE((SELECT CAST(value AS UNSIGNED) FROM settings WHERE name='price_call_1h'), 5000), 0, 1, 50, 1, 'on') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM call_packages LIMIT 1);

INSERT INTO `call_packages` (`name`, `description`, `price`, `duration`, `duration_hours`, `max_uses`, `sort_order`, `status`)
SELECT * FROM (SELECT 'Gói 24 Giờ', 'Dùng 1 ngày, max 500 lượt', COALESCE((SELECT CAST(value AS UNSIGNED) FROM settings WHERE name='price_call_24h'), 20000), 1, 0, 500, 2, 'on') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM call_packages WHERE name='Gói 24 Giờ');

INSERT INTO `call_packages` (`name`, `description`, `price`, `duration`, `duration_hours`, `max_uses`, `sort_order`, `status`)
SELECT * FROM (SELECT 'Gói 7 Ngày', 'Siêu tiết kiệm, max 3000 lượt', COALESCE((SELECT CAST(value AS UNSIGNED) FROM settings WHERE name='price_call_7d'), 100000), 7, 0, 3000, 3, 'on') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM call_packages WHERE name='Gói 7 Ngày');

INSERT INTO `call_packages` (`name`, `description`, `price`, `duration`, `duration_hours`, `max_uses`, `sort_order`, `status`)
SELECT * FROM (SELECT 'Gói 1 Tháng', 'Gói phổ biến, max 10.000 lượt', COALESCE((SELECT CAST(value AS UNSIGNED) FROM settings WHERE name='price_call_30d'), 300000), 30, 0, 10000, 4, 'on') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM call_packages WHERE name='Gói 1 Tháng');

INSERT INTO `call_packages` (`name`, `description`, `price`, `duration`, `duration_hours`, `max_uses`, `sort_order`, `status`)
SELECT * FROM (SELECT 'Gói Vĩnh Viễn', 'Mua một lần, dùng mãi mãi', COALESCE((SELECT CAST(value AS UNSIGNED) FROM settings WHERE name='call_key_price'), 500000), 9999, 0, 0, 5, 'on') AS tmp
WHERE NOT EXISTS (SELECT 1 FROM call_packages WHERE name='Gói Vĩnh Viễn');
