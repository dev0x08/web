<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card-modern">
            <h3 class="fw-bold mb-5 text-center">Nạp tiền vào tài khoản</h3>
            
            <div class="row g-4 mb-5">
                <div class="col-md-6">
                    <div class="p-4 rounded-4 border bg-lightest h-100">
                        <div class="d-flex align-items-center mb-4">
                            <img src="https://upload.wikimedia.org/wikipedia/vi/f/fe/MoMo_Logo.png" width="48" class="rounded-3 me-3">
                            <div>
                                <h6 class="fw-bold mb-0">Ví MOMO</h6>
                                <p class="text-muted small mb-0">SĐT chính chủ</p>
                            </div>
                        </div>
                        <div class="mb-3">
                            <div class="text-muted small">SỐ ĐIỆN THOẠI</div>
                            <div class="fw-bold h5 mb-0 text-indigo"><?= $settings['momo_number'] ?></div>
                        </div>
                        <div class="mb-4">
                            <div class="text-muted small">CHỦ TÀI KHOẢN</div>
                            <div class="fw-bold text-uppercase"><?= $settings['account_name'] ?></div>
                        </div>
                        <button class="btn btn-sm btn-white border w-100 fw-bold py-2" onclick="copyToClipboard('<?= $settings['momo_number'] ?>')">Copy SĐT <i class="fa fa-copy ms-1"></i></button>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="p-4 rounded-4 border bg-primary bg-opacity-10 h-100">
                        <div class="d-flex align-items-center mb-4">
                            <div class="bg-primary text-white p-2 rounded-3 me-3"><i class="fa fa-university fa-lg"></i></div>
                            <div>
                                <h6 class="fw-bold mb-0">Quét mã QR</h6>
                                <p class="text-muted small mb-0">Chuyển khoản nhanh</p>
                            </div>
                        </div>
                        <div class="text-center">
                            <img src="https://img.vietqr.io/image/MB-<?= $settings['bank_number'] ?>-compact.png?amount=50000&addInfo=NAP%20<?= $u['username'] ?>&accountName=<?= urlencode($settings['account_name']) ?>" class="img-fluid rounded-3 border" style="max-height: 180px;">
                        </div>
                    </div>
                </div>
            </div>

            <div class="p-4 rounded-4 bg-lightest border border-dashed text-center">
                <p class="text-muted mb-2">Nội dung chuyển khoản bắt buộc:</p>
                <div class="d-inline-block px-4 py-2 bg-white border rounded-pill fw-bold h4 mb-3" style="cursor:pointer;" onclick="copyToClipboard('NAP <?= $u['username'] ?>')">
                    NAP <?= $u['username'] ?>
                </div>
                <div class="small text-muted">Hệ thống sẽ cộng tiền tự động sau 1-5 phút.</div>
            </div>
        </div>
    </div>
</div>
