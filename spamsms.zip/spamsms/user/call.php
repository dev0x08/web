<?php
// Safe defaults
$has_call_access = false;
$is_forever = false;
$is_expired = false;

if (!empty($u)) {
    $is_forever = (isset($u['vip_level']) && $u['vip_level'] == 'forever') || (isset($u['role']) && $u['role'] == 'admin');
    $has_call_access = $is_forever;

    // Kiểm tra hạn dùng
    $is_expired = (!empty($u['call_expiry']) && strtotime($u['call_expiry']) < time());
    if (!$has_call_access && !empty($u['call_expiry']) && !$is_expired) {
        $has_call_access = true;
    }

    // Kiểm tra số lượt còn lại
    if (!$has_call_access && !empty($u['call_hits_balance']) && $u['call_hits_balance'] > 0) {
        $has_call_access = true;
    }
}

$cooldown = isset($u['cooldown']) ? intval($u['cooldown']) : 300;
$api_limit = isset($u['api_limit']) ? intval($u['api_limit']) : 1;

if (isset($u['role']) && $u['role'] == 'admin') {
    $cooldown = 0; $api_limit = 50;
}

// Fetch Call APIs
$stmt = $pdo->prepare("SELECT * FROM apis WHERE type = 'call' AND status = 'on'");
$stmt->execute();
$call_apis = $stmt->fetchAll();
$api_count = min(count($call_apis), $api_limit);
?>

<div class="row g-4">
    <div class="col-md-5">
        <?php if (!$has_call_access): ?>
            <!-- Giao diện Khóa khi chưa kích hoạt -->
            <div class="card-modern border-0 shadow-sm overflow-hidden text-center p-0">
                <div class="bg-indigo p-5 text-white">
                    <div class="display-4 mb-3 opacity-75"><i class="fa fa-lock"></i></div>
                    <h4 class="fw-bold mb-0">CHƯA KÍCH HOẠT</h4>
                </div>
                
                <div class="p-4">
                    <p class="text-muted small mb-4">Tính năng <b>Spam Call Pro</b> yêu cầu mã kích hoạt hoặc quyền VIP cao cấp để sử dụng.</p>
                    
                    <div id="key_msg"></div>
                    
                    <form id="keyForm" class="mb-4">
                        <div class="mb-3">
                            <label class="form-label x-small fw-bold text-muted text-uppercase">Mã kích hoạt của bạn</label>
                            <input type="text" id="call_key" class="form-control form-control-lg bg-light border-0 rounded-4 text-center fw-bold text-indigo" placeholder="CALL-XXXXXXXXXX" style="letter-spacing: 2px;">
                        </div>
                        <button type="submit" class="btn btn-indigo w-100 py-3 rounded-pill fw-bold shadow-indigo">
                            KÍCH HOẠT NGAY <i class="fa fa-bolt ms-1"></i>
                        </button>
                    </form>

                    <div class="d-flex flex-column gap-2">
                        <a href="?page=buy_key" class="btn btn-lightest w-100 py-2 rounded-pill small fw-bold text-indigo border">
                            Mua mã Key tự động <i class="fa fa-shopping-cart ms-1"></i>
                        </a>
                        <a href="<?= $settings['telegram_link'] ?>" target="_blank" class="small text-muted text-decoration-none mt-2">
                            Hoặc liên hệ Admin hỗ trợ <i class="fa fa-external-link-alt ms-1"></i>
                        </a>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <!-- Giao diện Bắn Call khi đã có quyền -->
            <div class="card-modern border-indigo border-top border-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h5 class="fw-bold m-0 text-indigo">📞 SPAM CALL PRO</h5>
                    <span class="badge bg-indigo bg-opacity-10 text-indigo text-uppercase">Unlimited</span>
                </div>
                
                <div class="bg-indigo bg-opacity-10 d-inline-block p-4 rounded-circle mb-3 position-relative">
                <i class="fa fa-phone fa-3x text-indigo"></i>
                <?php if(!$is_forever): ?>
                    <div class="position-absolute top-100 start-50 translate-middle w-100 mt-2">
                        <?php if($u['call_expiry'] && !$is_expired): ?>
                            <span class="badge bg-success small shadow-sm">Hạn: <?= date('d/m', strtotime($u['call_expiry'])) ?></span>
                        <?php endif; ?>
                        <?php if($u['call_hits_balance'] > 0): ?>
                            <span class="badge bg-indigo small shadow-sm"><?= number_format($u['call_hits_balance']) ?> lượt</span>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="position-absolute top-100 start-50 translate-middle w-100 mt-2">
                        <span class="badge bg-warning text-dark small shadow-sm">VĨNH VIỄN</span>
                    </div>
                <?php endif; ?>
            </div>
            <h4 class="fw-bold mt-3">Spam Call Pro (VIP)</h4>
                <div class="p-3 bg-lightest border rounded-4 mb-4">
                    <div class="row g-2 text-center">
                        <div class="col-4 border-end">
                            <div class="x-small text-muted">Quyền lợi</div>
                            <div class="fw-bold text-success" style="font-size: 11px;">TRỌN ĐỜI</div>
                        </div>
                        <div class="col-4 border-end">
                            <div class="x-small text-muted">Cổng Call</div>
                            <div class="fw-bold text-indigo"><?= count($call_apis) ?></div>
                        </div>
                        <div class="col-4">
                            <div class="x-small text-muted">Giới hạn</div>
                            <div class="fw-bold text-danger"><?= $api_limit ?>/lượt</div>
                        </div>
                    </div>
                </div>

                <div id="spam_msg"></div>

                <form id="spamForm">
                    <div class="mb-4">
                        <label class="form-label small fw-bold">Số điện thoại nạn nhân</label>
                        <div class="input-group input-group-lg shadow-sm rounded-4 overflow-hidden">
                            <span class="input-group-text bg-white border-end-0 text-muted ps-4"><i class="fa fa-phone-volume"></i></span>
                            <input type="text" id="phone" name="phone" class="form-control border-start-0 py-3" placeholder="0xxxxxxxxx" style="font-size: 1.1rem; letter-spacing: 2px;">
                        </div>
                    </div>

                    <button type="submit" id="btnRun" class="btn btn-indigo w-100 py-3 rounded-4 fw-bold shadow-indigo">
                        <i class="fa fa-phone-slash me-2"></i> KHỞI CHẠY CUỘC GỌI
                    </button>
                </form>
            </div>
        <?php endif; ?>
    </div>

    <div class="col-md-7">
        <div class="card-modern h-100" id="progress_container" style="display: none;">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h6 class="fw-bold m-0"><i class="fa fa-satellite-dish me-2"></i> Trạm phát sóng Call</h6>
                <span id="percent_text" class="badge bg-indigo">0%</span>
            </div>

            <div class="progress mb-4 rounded-pill" style="height: 12px; background-color: #f1f5f9;">
                <div id="progress_bar" class="progress-bar progress-bar-striped progress-bar-animated bg-indigo" style="width: 0%"></div>
            </div>

            <div class="p-3 bg-dark text-success rounded-4 border overflow-auto shadow-inner" id="spam_logs" style="max-height: 350px; font-family: 'Consolas', monospace; font-size: 0.8rem;">
                <div class="text-muted small italic">Cỗ máy đang chờ lệnh...</div>
            </div>
        </div>
    </div>
</div>

<script>
// Logic kích hoạt Key
if (document.getElementById('keyForm')) {
    document.getElementById('keyForm').onsubmit = function(e) {
        e.preventDefault();
        const key = document.getElementById('call_key').value;
        const msg = document.getElementById('key_msg');
        
        if (!key) return;

        fetch('<?= BASE_URL ?>ajax/activate_call.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'key=' + key
        })
        .then(res => res.json())
        .then(data => {
            if (data.status == 'ok') {
                msg.innerHTML = '<div class="alert alert-success">' + data.message + '. Đang tải lại...</div>';
                setTimeout(() => location.reload(), 1500);
            } else {
                msg.innerHTML = '<div class="alert alert-danger">' + data.message + '</div>';
            }
        });
    };
}

// Logic Bắn Call
if (document.getElementById('spamForm')) {
    document.getElementById('spamForm').onsubmit = function(e) {
        e.preventDefault();
        const phone = document.getElementById('phone').value;
        const btn = document.getElementById('btnRun');
        const msg = document.getElementById('spam_msg');
        
        if (!/^0[0-9]{9}$/.test(phone)) {
            msg.innerHTML = '<div class="alert alert-danger py-2">SĐT không hợp lệ</div>';
            return;
        }

        btn.disabled = true;
        btn.innerHTML = '<i class="fa fa-spinner fa-spin me-2"></i>ĐANG KẾT NỐI...';

        fetch('<?= BASE_URL ?>api/init_spam.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'phone=' + phone + '&type=call'
        })
        .then(res => res.json())
        .then(initData => {
            if (initData.status != 'ok') {
                msg.innerHTML = '<div class="alert alert-warning py-2">' + initData.message + '</div>';
                btn.disabled = false;
                btn.innerHTML = '<i class="fa fa-phone-slash me-2"></i> KHỞI CHẠY CUỘC GỌI';
                return;
            }

            const apisToRun = initData.data.apis;
            document.getElementById('progress_container').style.display = 'block';
            const logs = document.getElementById('spam_logs');
            logs.innerHTML = '<div class="text-white border-bottom border-secondary mb-2 pb-1">[SERVER] BẮT ĐẦU PHÁT SÓNG TỚI: ' + phone + '</div>';

            let completed = 0;
            const total = apisToRun.length;

            apisToRun.forEach((api, index) => {
                setTimeout(() => {
                    fetch('<?= BASE_URL ?>api/execute_spam.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: 'phone=' + phone + '&api_id=' + api.id
                    })
                    .then(res => res.json())
                    .then(data => {
                        completed++;
                        updateProgress(completed, total);
                        if (data.status == 'ok') {
                            appendLog('<span class="text-success">[SUCCESS] Đã phát cuộc gọi qua cổng: ' + api.name + '</span>');
                        } else {
                            appendLog('<span class="text-danger">[FAILED] Lỗi cổng ' + api.name + ': ' + data.message + '</span>');
                        }

                        if (completed == total) {
                            appendLog('<div class="text-warning mt-2 fw-bold">>>> TẤT CẢ CUỘC GỌI ĐÃ ĐƯỢC PHÁT ĐI <<<</div>');
                            btn.disabled = false;
                            btn.innerHTML = '<i class="fa fa-phone-slash me-2"></i> TIẾP TỤC BẮN';
                        }
                    });
                }, index * 1000); // Call nên chậm hơn SMS một chút
            });
        });
    };
}

function appendLog(text) {
    const logs = document.getElementById('spam_logs');
    logs.innerHTML += '<div>' + text + '</div>';
    logs.scrollTop = logs.scrollHeight;
}

function updateProgress(done, total) {
    const p = Math.round((done / total) * 100);
    document.getElementById('progress_bar').style.width = p + '%';
    document.getElementById('percent_text').innerText = p + '%';
}
</script>

<style>
.bg-dark { background-color: #1e293b !important; }
.card-modern { transition: transform 0.2s; }
.card-modern:hover { transform: translateY(-2px); }
.shadow-indigo { box-shadow: 0 10px 15px -3px rgba(79, 70, 229, 0.2); }
</style>
