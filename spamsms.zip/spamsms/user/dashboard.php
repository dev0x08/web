<?php
// Thống kê người dùng
$stmt = $pdo->prepare("SELECT count(*) FROM logs WHERE user_id = ? AND target = 'SPAM'");
$stmt->execute([$u['id']]);
$total_spam = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT * FROM logs WHERE user_id = ? ORDER BY id DESC LIMIT 5");
$stmt->execute([$u['id']]);
$recent_logs = $stmt->fetchAll();
?>

<div class="row g-4">
    <div class="col-md-4">
        <div class="card-modern">
            <div class="text-muted small mb-1 fw-bold">SỐ DƯ HIỆN TẠI</div>
            <h2 class="fw-bold text-success m-0"><?= number_format($u['balance']) ?>đ</h2>
            <a href="<?= BASE_URL ?>?page=topup" class="btn btn-sm btn-indigo mt-3 w-100">Nạp thêm ngay</a>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card-modern">
            <div class="text-muted small mb-1 fw-bold">TỔNG LƯỢT SPAM</div>
            <h2 class="fw-bold text-primary m-0"><?= number_format($total_spam) ?></h2>
            <div class="small text-muted mt-3">Sẵn sàng thực thi</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card-modern">
            <div class="text-muted small mb-1 fw-bold">RANK TÀI KHOẢN</div>
            <?php if(isVIP()): ?>
                <h2 class="fw-bold text-warning m-0"><i class="fa fa-crown"></i> VIP PRO</h2>
                <div class="small text-muted mt-3">Hết hạn: <?= date('d/m/Y', strtotime($u['vip_expiry'])) ?></div>
            <?php else: ?>
                <h2 class="fw-bold text-muted m-0">NORMAL</h2>
                <a href="<?= BASE_URL ?>?page=vip_store" class="btn btn-sm btn-outline-warning mt-3 w-100 fw-bold border-2">Mua VIP ✨</a>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="col-12">
        <div class="card-modern">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="fw-bold m-0"><i class="fa fa-history me-2 text-indigo"></i> Hoạt động gần đây</h5>
                <a href="<?= BASE_URL ?>?page=logs" class="small text-decoration-none">Xem tất cả</a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Thời gian</th>
                            <th>Mục tiêu</th>
                            <th>Nội dung thực thi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($recent_logs as $log): ?>
                        <tr>
                            <td class="small text-muted"><?= timeAgo(strtotime($log['created_at'])) ?></td>
                            <td><span class="badge badge-indigo"><?= $log['target'] ?></span></td>
                            <td class="small">
                                <?php 
                                    if ($log['target'] == 'SPAM' && preg_match('/\d{10}/', $log['status'], $matches)) {
                                        echo str_replace($matches[0], '*******' . substr($matches[0], -3), $log['status']);
                                    } else {
                                        echo $log['status'];
                                    }
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($recent_logs)): ?>
                        <tr><td colspan="3" class="text-center text-muted py-4">Chưa có hoạt động nào</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
