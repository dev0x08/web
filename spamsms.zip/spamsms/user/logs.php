<?php
$limit = 15;
$page_num = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
$offset = ($page_num - 1) * $limit;

$stmt = $pdo->prepare("SELECT count(*) FROM logs WHERE user_id = ?");
$stmt->execute([$u['id']]);
$total = $stmt->fetchColumn();
$total_pages = ceil($total / $limit);

$stmt = $pdo->prepare("SELECT * FROM logs WHERE user_id = ? ORDER BY id DESC LIMIT ? OFFSET ?");
$stmt->bindValue(1, $u['id'], PDO::PARAM_INT);
$stmt->bindValue(2, $limit, PDO::PARAM_INT);
$stmt->bindValue(3, $offset, PDO::PARAM_INT);
$stmt->execute();
$logs = $stmt->fetchAll();
?>

<div class="card-modern">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="fw-bold mb-0">Lịch sử hoạt động</h5>
        <div class="dropdown">
            <button class="btn btn-sm btn-outline-danger px-3 rounded-pill dropdown-toggle" type="button" data-bs-toggle="dropdown">
                <i class="fa fa-trash-alt me-1"></i> Dọn dẹp
            </button>
            <ul class="dropdown-menu shadow border-0 small">
                <li><a class="dropdown-item py-2 text-danger fw-bold" href="#" onclick="confirmUserClean(0, 'Tất cả lịch sử')">Xóa tất cả</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item py-2" href="#" onclick="confirmUserClean(1, 'hơn 1 ngày trước')">Cũ hơn 1 ngày</a></li>
                <li><a class="dropdown-item py-2" href="#" onclick="confirmUserClean(7, 'hơn 7 ngày trước')">Cũ hơn 7 ngày</a></li>
                <li><a class="dropdown-item py-2" href="#" onclick="confirmUserClean(30, 'hơn 30 ngày trước')">Cũ hơn 30 ngày</a></li>
            </ul>
        </div>
    </div>
    
    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>Thời gian</th>
                    <th>Loại</th>
                    <th>Nội dung thực thi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($logs as $log): ?>
                <tr>
                    <td class="small text-muted" style="width: 200px;"><?= $log['created_at'] ?></td>
                    <td style="width: 120px;"><span class="badge badge-indigo text-uppercase" style="font-size: 10px;"><?= $log['target'] ?></span></td>
                    <td>
                        <?php 
                            if ($log['target'] == 'SPAM' && preg_match('/\d{10}/', $log['status'], $matches)) {
                                echo str_replace($matches[0], '*******' . substr($matches[0], -3), $log['status']);
                            } else {
                                echo $log['status'];
                            }
                        ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($logs)): ?>
                <tr><td colspan="3" class="text-center text-muted py-5">Bạn chưa có dữ liệu hoạt động.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($total_pages > 1): ?>
    <nav class="mt-4">
        <ul class="pagination pagination-sm justify-content-center">
            <?php for($i=1; $i<=$total_pages; $i++): ?>
            <li class="page-item <?= $i == $page_num ? 'active' : '' ?>">
                <a class="page-link border mx-1 rounded-2" href="<?= BASE_URL ?>?page=logs&p=<?= $i ?>"><?= $i ?></a>
            </li>
            <?php endfor; ?>
        </ul>
    </nav>
    <?php endif; ?>
</div>

<!-- Modal Xác nhận -->
<div class="modal fade" id="cleanLogsModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header border-0 pb-0">
                <h6 class="modal-title fw-bold">Xác nhận</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body py-3 text-center">
                <div class="mb-3 text-warning">
                    <i class="fa fa-clock-rotate-left fa-3x"></i>
                </div>
                <p class="mb-0">Dọn dẹp các nhật ký</p>
                <div class="fw-bold text-danger" id="clean_time_label"></div>
                <small class="text-muted mt-2 d-block">Dữ liệu sau khi xóa sẽ không thể khôi phục.</small>
            </div>
            <div class="modal-footer border-0 pt-0 gap-2">
                <button type="button" class="btn btn-light btn-sm flex-grow-1 py-2 border" data-bs-dismiss="modal">HỦY</button>
                <button type="button" id="clean_confirm_btn" class="btn btn-danger btn-sm flex-grow-1 py-2 shadow-sm">XÁC NHẬN</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal Thông báo -->
<div class="modal fade" id="ajaxStatusModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-body py-4 text-center">
                <div class="mb-3 text-success" id="ajax_status_icon">
                    <i class="fa fa-check-circle fa-3x"></i>
                </div>
                <h6 class="fw-bold" id="ajax_status_title">Thành công</h6>
                <p class="mb-0 text-muted small" id="ajax_status_message"></p>
                <div class="mt-4">
                    <button type="button" class="btn btn-indigo btn-sm px-4 py-2 rounded-pill shadow-sm" onclick="location.reload()">ĐÓNG & TẢI LẠI</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function confirmUserClean(days, label) {
    document.getElementById('clean_time_label').innerText = label;
    document.getElementById('clean_confirm_btn').onclick = function() {
        const btn = this;
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
        
        const action = (days === 0) ? 'clear_all' : 'clean_logs';
        const formData = new FormData();
        formData.append('action', action);
        formData.append('days', days);
        
        fetch('<?= BASE_URL ?>ajax/logs_action.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            bootstrap.Modal.getInstance(document.getElementById('cleanLogsModal')).hide();
            if(data.status === 'success') {
                document.getElementById('ajax_status_icon').innerHTML = '<i class="fa fa-check-circle fa-3x text-success"></i>';
                document.getElementById('ajax_status_title').innerText = 'Thành công';
                document.getElementById('ajax_status_message').innerText = data.message;
            } else {
                document.getElementById('ajax_status_icon').innerHTML = '<i class="fa fa-exclamation-triangle fa-3x text-danger"></i>';
                document.getElementById('ajax_status_title').innerText = 'Thất bại';
                document.getElementById('ajax_status_message').innerText = data.message;
            }
            new bootstrap.Modal(document.getElementById('ajaxStatusModal')).show();
        })
        .catch(err => alert('Lỗi hệ thống!'))
        .finally(() => {
            btn.disabled = false;
            btn.innerHTML = 'XÁC NHẬN';
        });
    };
    new bootstrap.Modal(document.getElementById('cleanLogsModal')).show();
}
</script>
