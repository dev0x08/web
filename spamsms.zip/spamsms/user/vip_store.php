<?php
$packages = $pdo->query("SELECT * FROM vip_packages ORDER BY price ASC")->fetchAll();

$msg = '';

// Calculate remaining VIP time
$vip_remaining = '';
$is_forever_owned = false;
if (isVIP() && $u['vip_expiry']) {
    $diff = strtotime($u['vip_expiry']) - time();
    if ($diff > 0) {
        $days = floor($diff / 86400);
        $hours = floor(($diff % 86400) / 3600);
        if ($days > 900) {
            $vip_remaining = 'Vĩnh viễn';
            $is_forever_owned = true;
        } else {
            $vip_remaining = "$days ngày $hours giờ";
        }
    }
}

if (isset($_POST['buy_vip'])) {
    $pkg_id = $_POST['package_id'];
    $stmt = $pdo->prepare("SELECT * FROM vip_packages WHERE id = ?");
    $stmt->execute([$pkg_id]);
    $pkg = $stmt->fetch();
    
    if ($pkg) {
        if ($is_forever_owned) {
            $msg = ["danger", "Bạn đã sở hữu gói Vĩnh Viễn, không thể mua thêm gói thấp hơn!"];
        } elseif ($u['balance'] < $pkg['price']) {
            $msg = ["danger", "Số dư không đủ!"];
        } else {
            $current_expiry = ($u['is_vip'] && $u['vip_expiry']) ? strtotime($u['vip_expiry']) : time();
            if ($current_expiry < time()) $current_expiry = time();
            
            $new_expiry_ts = $current_expiry + ($pkg['duration_days'] * 86400);
            $new_expiry = date('Y-m-d H:i:s', $new_expiry_ts);
            
            // Cập nhật Quyền hạn từ Gói vào User
            $pdo->prepare("UPDATE users SET balance = balance - ?, is_vip = 1, vip_expiry = ?, cooldown = ?, api_limit = ?, vip_level = ? WHERE id = ?")
                ->execute([$pkg['price'], $new_expiry, $pkg['cooldown'], $pkg['api_limit'], $pkg['api_level'], $u['id']]);
            
            $pdo->prepare("INSERT INTO logs (user_id, target, status) VALUES (?, 'VIP', 'Mua gói: {$pkg['name']}')")
                ->execute([$u['id']]);
            
            // Refresh user session data
            $u['balance'] -= $pkg['price'];
            $u['is_vip'] = 1;
            $u['vip_expiry'] = $new_expiry;
            $u['cooldown'] = $pkg['cooldown'];
            $u['api_limit'] = $pkg['api_limit'];
            $u['vip_level'] = $pkg['api_level'];
            
            $msg = ["success", "Đã kích hoạt thành công gói " . $pkg['name']];
            
            // Recalculate remaining time for UI
            $diff = strtotime($new_expiry) - time();
            $days = floor($diff / 86400);
            $hours = floor(($diff % 86400) / 3600);
            $vip_remaining = ($days > 900) ? 'Vĩnh viễn' : "$days ngày $hours giờ";
            if ($days > 900) $is_forever_owned = true;
        }
    }
}
?>

<?php if($msg): ?>
    <div class="alert alert-<?= $msg[0] ?> alert-dismissible fade show mb-4 shadow-sm border-0 py-3 rounded-4" role="alert">
        <div class="d-flex align-items-center">
            <div class="bg-<?= $msg[0] ?> bg-opacity-10 p-2 rounded-circle me-3">
                <i class="fa <?= $msg[0]=='success'?'fa-check-circle':'fa-exclamation-triangle' ?> text-<?= $msg[0] ?> fs-5"></i>
            </div>
            <div>
                <strong class="d-block text-<?= $msg[0] ?>"><?= $msg[0]=='success'?'Thành công!':'Thất bại!' ?></strong>
                <span class="small opacity-75"><?= $msg[1] ?></span>
            </div>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <script>window.scrollTo({top: 0, behavior: 'smooth'});</script>
<?php endif; ?>

<div class="text-center mb-5">
    <h2 class="fw-bold">Nâng cấp tài khoản VIP</h2>
    <p class="text-muted">Gói VIP giúp bạn bỏ qua thời gian chờ và sử dụng nhiều cổng API cùng lúc</p>
    <?php if ($vip_remaining): ?>
        <div class="d-inline-block px-4 py-2 bg-indigo bg-opacity-10 border border-indigo border-opacity-25 rounded-pill text-indigo fw-bold">
            <i class="fa fa-clock me-2"></i> Thời gian VIP còn lại: <?= $vip_remaining ?>
        </div>
    <?php endif; ?>
</div>

<div class="row g-4 justify-content-center">
    <?php foreach($packages as $pkg): ?>
    <?php 
        $is_pkg_owned = false;
        if ($is_forever_owned) {
            $is_pkg_owned = true;
        }
        
        $btn_disabled = $is_pkg_owned;
        $btn_text = $is_pkg_owned ? 'Đang sử dụng' : 'Mua ngay';
        $is_pkg_forever = ($pkg['duration_days'] > 3650);
    ?>
    <div class="col-md-4">
        <div class="card-modern h-100 d-flex flex-column text-center <?= $is_pkg_forever ? 'border-primary shadow-indigo' : '' ?>">
            <h4 class="fw-bold mb-1"><?= $pkg['name'] ?></h4>
            <div class="text-indigo display-6 fw-bold my-4"><?= number_format($pkg['price']) ?><small style="font-size: 1rem;">đ</small></div>
            
            <p class="text-muted flex-grow-1"><?= nl2br($pkg['description']) ?></p>
            
            <hr class="my-4 opacity-50">
            <ul class="list-unstyled text-start mb-4">
                <li class="mb-2"><i class="fa fa-check-circle text-success me-2"></i> Thời hạn <?= $is_pkg_forever ? 'Vĩnh viễn' : $pkg['duration_days'] . ' ngày' ?></li>
                <li class="mb-2"><i class="fa fa-layer-group text-primary me-2"></i> Cấp API: <b class="text-uppercase"><?= $pkg['api_level'] ?></b></li>
                <li class="mb-2"><i class="fa fa-bolt text-warning me-2"></i> Chờ: <b><?= $pkg['cooldown'] ?> giây</b></li>
                <li class="mb-2"><i class="fa fa-server text-info me-2"></i> Chạy <b><?= $pkg['api_limit'] ?> cổng</b> cùng lúc</li>
            </ul>

            <form method="POST" id="buyVipForm">
                <input type="hidden" name="package_id" value="<?= $pkg['id'] ?>">
                <input type="hidden" name="buy_vip" value="1">
                <button type="submit" class="btn btn-indigo w-100 py-2 rounded-3 fw-bold" <?= $btn_disabled ? 'disabled' : '' ?> onclick="this.innerHTML='<i class=\'fa fa-spinner fa-spin\'></i> Đang xử lý...';">
                    <?= $btn_text ?>
                </button>
            </form>
        </div>
    </div>
    <?php endforeach; ?>
</div>
