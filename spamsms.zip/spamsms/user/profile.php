<?php
$msg = '';
if (isset($_POST['change_pass'])) {
    $old = $_POST['old_pass'];
    $new = $_POST['new_pass'];
    $conf = $_POST['conf_pass'];
    
    if (!password_verify($old, $u['password'])) {
        $msg = "danger:Mật khẩu cũ không chính xác!";
    } elseif ($new != $conf) {
        $msg = "danger:Mật khẩu mới không khớp!";
    } else {
        $hash = password_hash($new, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hash, $u['id']]);
        $pdo->prepare("INSERT INTO logs (user_id, target, status) VALUES (?, 'PROFILE', 'Đổi mật khẩu thành công')")->execute([$u['id']]);
        $msg = "success:Đã đổi mật khẩu thành công!";
    }
}

$msg_email = '';
if (isset($_POST['update_email'])) {
    $email = trim($_POST['email']);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) && !empty($email)) {
        $msg_email = "danger:Định dạng email không hợp lệ!";
    } else {
        $pdo->prepare("UPDATE users SET email = ? WHERE id = ?")->execute([$email, $u['id']]);
        $pdo->prepare("INSERT INTO logs (user_id, target, status) VALUES (?, 'PROFILE', 'Cập nhật Email')")->execute([$u['id']]);
        $u['email'] = $email; // Update current session info
        $msg_email = "success:Cập nhật email thành công!";
    }
}

if (isset($_POST['delete_account'])) {
    $pass = $_POST['del_pass'];
    if (!password_verify($pass, $u['password'])) {
        $msg_del = "danger:Mật khẩu không chính xác. Hủy thao tác xóa.";
    } else {
        $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$u['id']]);
        // Bảng logs, api_keys, call_keys tự động xóa do ON DELETE CASCADE, nếu có
        session_destroy();
        header("Location: " . BASE_URL . "login.php"); exit;
    }
}
?>

<div class="row g-4">
    <div class="col-md-4">
        <div class="card-modern text-center p-5">
            <img src="https://ui-avatars.com/api/?name=<?= $u['username'] ?>&size=128&background=4f46e5&color=fff" class="rounded-circle mb-4 shadow-sm border border-2 border-white">
            <h4 class="fw-bold mb-1"><?= $u['username'] ?></h4>
            <div class="badge badge-indigo text-uppercase mb-3"><?= $u['role'] ?></div>
            
            <?php if(isVIP()): ?>
                <div class="d-block mt-1">
                    <span class="badge badge-vip"><i class="fa fa-crown me-1"></i> VIP PRO</span>
                </div>
            <?php endif; ?>

            <div class="mt-4 pt-4 border-top text-start">
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted small">Tên tài khoản:</span>
                    <span class="small fw-bold"><?= $u['username'] ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted small">Email:</span>
                    <span class="small fw-bold"><?= !empty($u['email']) ? htmlspecialchars($u['email']) : '<i class="text-muted">Chưa cập nhật</i>' ?></span>
                </div>
                <div class="d-flex justify-content-between">
                    <span class="text-muted small">Ngày tham gia:</span>
                    <span class="small fw-bold"><?= date('d/m/Y', strtotime($u['created_at'])) ?></span>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card-modern">
            <div class="card-modern mb-4">
                <h5 class="fw-bold mb-4">Thông tin cá nhân</h5>
                <?php if($msg_email): ?>
                    <?php $m = explode(':', $msg_email); ?>
                    <div class="alert alert-<?= $m[0] ?> small mb-4"><?= $m[1] ?></div>
                <?php endif; ?>
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Địa chỉ Email</label>
                        <input type="email" name="email" class="form-control" placeholder="vidu@email.com" value="<?= htmlspecialchars($u['email'] ?? '') ?>">
                        <div class="form-text small">Dùng để khôi phục tài khoản khi cần (Tùy chọn)</div>
                    </div>
                    <button type="submit" name="update_email" class="btn btn-indigo px-4">Lưu Email</button>
                </form>
            </div>

            <div class="card-modern mb-4">
                <h5 class="fw-bold mb-4">Cài đặt bảo mật</h5>
                
                <?php if($msg): ?>
                    <?php $m = explode(':', $msg); ?>
                    <div class="alert alert-<?= $m[0] ?> small mb-4"><?= $m[1] ?></div>
                <?php endif; ?>

                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Mật khẩu hiện tại</label>
                        <input type="password" name="old_pass" class="form-control" placeholder="••••••••" required>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-6 mb-3">
                            <label class="form-label small fw-bold">Mật khẩu mới</label>
                            <input type="password" name="new_pass" class="form-control" placeholder="••••••••" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label small fw-bold">Xác nhận mật khẩu</label>
                            <input type="password" name="conf_pass" class="form-control" placeholder="••••••••" required>
                        </div>
                    </div>
                    <button type="submit" name="change_pass" class="btn btn-indigo px-5 mt-2">Đổi mật khẩu</button>
                </form>
            </div>

            <div class="card-modern border-danger" style="border-width: 2px;">
                <h5 class="fw-bold text-danger mb-2"><i class="fa fa-exclamation-triangle me-2"></i>XÓA TÀI KHOẢN VĨNH VIỄN</h5>
                <p class="text-muted small mb-4">Một khi bạn xóa tài khoản, toàn bộ dữ liệu (số dư, gói VIP, lịch sử) sẽ bị xóa **VĨNH VIỄN** và không thể khôi phục. Hãy cân nhắc kỹ trước khi thực hiện.</p>
                
                <?php if(isset($msg_del)): ?>
                    <?php $m = explode(':', $msg_del); ?>
                    <div class="alert alert-<?= $m[0] ?> small mb-4"><?= $m[1] ?></div>
                <?php endif; ?>

                <button class="btn btn-danger px-4" data-bs-toggle="modal" data-bs-target="#deleteAccountModal">Xóa tài khoản của tôi</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal Xác nhận Xóa Tài Khoản -->
<div class="modal fade" id="deleteAccountModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content border-0 shadow-lg" method="POST">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold text-danger">Xác nhận xóa tài khoản</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body py-4">
                <p class="mb-4">Bạn đang yêu cầu xóa tài khoản <strong class="text-indigo"><?= $u['username'] ?></strong>. Hành động này không thể hoàn tác!</p>
                <div class="mb-0">
                    <label class="form-label small fw-bold">Nhập mật khẩu để xác nhận:</label>
                    <input type="password" name="del_pass" class="form-control" placeholder="••••••••" required autocomplete="new-password">
                </div>
            </div>
            <div class="modal-footer border-0 pt-0 gap-2">
                <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Hủy bỏ</button>
                <button type="submit" name="delete_account" class="btn btn-danger px-4">XÓA VĨNH VIỄN</button>
            </div>
        </form>
    </div>
    </div>
</div>
