<?php
// Lấy danh sách gói từ DB
$packages = $pdo->query("SELECT * FROM call_packages WHERE status = 'on' ORDER BY sort_order, price ASC")->fetchAll();

// Lấy lịch sử Key của user
$stmt = $pdo->prepare("SELECT * FROM call_keys WHERE user_id = ? ORDER BY id DESC");
$stmt->execute([$u['id']]);
$my_keys = $stmt->fetchAll();
?>

<div class="row g-4">
    <div class="col-md-5">
        <div class="card-modern border-0 shadow-sm overflow-hidden mb-4">
            <div class="bg-indigo p-4 text-white text-center">
                <i class="fa fa-shopping-basket fa-3x mb-3 opacity-75"></i>
                <h4 class="fw-bold mb-0">CHỌN GÓI BẮN CALL</h4>
            </div>
            
            <div class="p-4">
                <?php if(empty($packages)): ?>
                    <div class="text-center py-4 text-muted">
                        <i class="fa fa-box-open fa-2x mb-3 opacity-25"></i>
                        <p class="small">Chưa có gói nào. Liên hệ Admin để được hỗ trợ.</p>
                    </div>
                <?php else: ?>
                <div id="packages_list" class="d-flex flex-column gap-3 mb-4">
                    <?php foreach($packages as $idx => $p): ?>
                    <label class="package-item border rounded-4 p-3 d-flex align-items-center justify-content-between cursor-pointer transition-all">
                        <div class="d-flex align-items-center">
                            <input type="radio" name="package_select"
                                value="<?= $p['id'] ?>"
                                data-price="<?= $p['price'] ?>"
                                data-name="<?= htmlspecialchars($p['name'], ENT_QUOTES) ?>"
                                class="form-check-input me-3"
                                <?= $idx === 0 ? 'checked' : '' ?>>
                            <div>
                                <div class="fw-bold text-dark fs-6"><?= htmlspecialchars($p['name']) ?></div>
                                <div class="x-small text-muted"><?= htmlspecialchars($p['description']) ?></div>
                            </div>
                        </div>
                        <div class="text-end">
                            <span class="fw-bold text-indigo"><?= number_format($p['price']) ?>đ</span>
                        </div>
                    </label>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <div id="buy_msg"></div>

                <button type="button" class="btn btn-indigo w-100 py-3 rounded-pill fw-bold shadow-indigo" onclick="preBuyKey()" <?= empty($packages) ? 'disabled' : '' ?>>
                    <i class="fa fa-shopping-cart me-2"></i> MUA MÃ KÍCH HOẠT
                </button>
            </div>
        </div>
    </div>

    <div class="col-md-7">
        <div class="card-modern border-0 shadow-sm">
            <div class="p-4 border-bottom d-flex justify-content-between align-items-center">
                <h5 class="fw-bold m-0"><i class="fa fa-history me-2 text-indigo"></i> Lịch sử Key đã mua</h5>
                <span class="badge bg-lightest text-muted border px-3 rounded-pill"><?= count($my_keys) ?> Key</span>
            </div>
            
            <div class="table-responsive p-2">
                <table class="table table-hover align-middle border-0">
                    <thead class="bg-lightest text-muted x-small text-uppercase">
                        <tr>
                            <th class="ps-3 border-0">Mã kích hoạt</th>
                            <th class="border-0">Gói</th>
                            <th class="border-0">Trạng thái</th>
                            <th class="border-0">Ngày mua</th>
                        </tr>
                    </thead>
                    <tbody id="keys_tbody">
                        <?php foreach($my_keys as $key): ?>
                        <tr class="border-bottom border-light">
                            <td class="ps-3"><code class="fw-bold text-indigo bg-indigo bg-opacity-10 px-2 py-1 rounded" style="font-size: 1rem;"><?= $key['key_code'] ?></code></td>
                            <td>
                                <span class="small text-muted">
                                    <?php
                                        $dur = intval($key['duration'] ?? 0);
                                        if ($dur == 9999) echo '<span class="badge bg-warning text-dark">Vĩnh viễn</span>';
                                        elseif ($dur > 0) echo $dur . ' Ngày';
                                        else echo '1 Giờ';
                                    ?>
                                </span>
                            </td>
                            <td>
                                <?php if($key['status'] == 'unused'): ?>
                                    <span class="badge bg-success bg-opacity-10 text-success rounded-pill px-3">Sẵn sàng</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary bg-opacity-10 text-muted rounded-pill px-3">Đã dùng</span>
                                <?php endif; ?>
                            </td>
                            <td class="x-small text-muted"><?= date('d/m/Y H:i', strtotime($key['created_at'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($my_keys)): ?>
                        <tr><td colspan="4" class="text-center py-5 text-muted small">Bạn chưa mua key nào</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Xác nhận Thanh toán -->
<div class="modal fade" id="confirmBuyModal" tabindex="-1">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-body p-4 text-center">
                <div class="bg-indigo bg-opacity-10 text-indigo d-inline-block p-4 rounded-circle mb-3">
                    <i class="fa fa-shopping-cart fa-2x"></i>
                </div>
                <h5 class="fw-bold">Xác nhận thanh toán</h5>
                <p class="text-muted small">Bạn có chắc muốn mua <span id="confirm_package_name" class="text-dark fw-bold"></span> với giá <span id="confirm_package_price" class="text-indigo fw-bold"></span>?</p>
                
                <div class="d-flex gap-2 mt-4">
                    <button type="button" class="btn btn-light w-100 py-2 rounded-pill fw-bold" data-bs-dismiss="modal">Hủy</button>
                    <button type="button" id="btnConfirmBuy" class="btn btn-indigo w-100 py-2 rounded-pill fw-bold shadow-indigo" onclick="buyCallKey()">Xác nhận</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let selectedPackage = null;

function preBuyKey() {
    const checked = document.querySelector('input[name="package_select"]:checked');
    if (!checked) return alert('Vui lòng chọn một gói!');
    
    selectedPackage = {
        id: checked.value,                              // package_id (DB id)
        name: checked.getAttribute('data-name'),
        price: checked.getAttribute('data-price')
    };
    
    document.getElementById('confirm_package_name').innerText = selectedPackage.name;
    document.getElementById('confirm_package_price').innerText = new Intl.NumberFormat().format(selectedPackage.price) + 'đ';
    
    new bootstrap.Modal(document.getElementById('confirmBuyModal')).show();
}

async function buyCallKey() {
    const btn = document.getElementById('btnConfirmBuy');
    const msg = document.getElementById('buy_msg');
    const modalElement = document.getElementById('confirmBuyModal');
    const modal = bootstrap.Modal.getInstance(modalElement);

    btn.disabled = true;
    btn.innerHTML = '<i class="fa fa-spinner fa-spin me-2"></i> ...';

    try {
        // Gửi package_id thay vì package string
        const res = await apiCall('<?= BASE_URL ?>ajax/buy_key.php', 'POST', { package_id: selectedPackage.id });
        modal.hide();
        
        if (res.status == 'ok') {
            msg.innerHTML = '<div class="alert alert-success border-0 shadow-sm rounded-4 py-3"><i class="fa fa-check-circle me-2 fs-5"></i> ' + res.message + '</div>';
            
            // Thêm dòng mới vào bảng lịch sử
            const tbody = document.getElementById('keys_tbody');
            const newRow = `<tr>
                <td class="ps-3"><code class="fw-bold text-indigo bg-indigo bg-opacity-10 px-2 py-1 rounded" style="font-size: 1rem;">${res.data.key}</code></td>
                <td><span class="small text-muted">${selectedPackage.name}</span></td>
                <td><span class="badge bg-success bg-opacity-10 text-success rounded-pill px-3">Sẵn sàng</span></td>
                <td class="x-small text-muted">Vừa xong</td>
            </tr>`;
            if (tbody.innerHTML.includes('chưa mua key nào')) tbody.innerHTML = '';
            tbody.innerHTML = newRow + tbody.innerHTML;
        } else {
            msg.innerHTML = '<div class="alert alert-danger border-0 shadow-sm rounded-4 py-3"><i class="fa fa-exclamation-triangle me-2 fs-5"></i> ' + res.message + '</div>';
        }
    } catch (e) {
        msg.innerHTML = '<div class="alert alert-danger border-0 shadow-sm rounded-4 py-3">Lỗi: ' + e.message + '</div>';
    } finally {
        btn.disabled = false;
        btn.innerHTML = 'Xác nhận';
    }
}
</script>

<style>
.package-item { transition: all 0.2s; border-color: #eee !important; cursor: pointer; }
.package-item:hover { border-color: #4f46e5 !important; background: #fbfbff; }
.package-item input:checked + div { color: #4f46e5; }
.package-item input:checked { border-color: #4f46e5; background-color: #4f46e5; }
.cursor-pointer { cursor: pointer; }
.shadow-indigo { box-shadow: 0 10px 15px -3px rgba(79, 70, 229, 0.2); }
.bg-lightest { background-color: #f8f9fa; }
.border-light { border-color: rgba(0,0,0,0.05) !important; }
.x-small { font-size: 0.75rem; }
</style>
