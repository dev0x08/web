<?php
$now = time();

// Get User-specific Privileges (From Users Table)
$cooldown = isset($u['cooldown']) ? intval($u['cooldown']) : 300;
$api_limit = isset($u['api_limit']) ? intval($u['api_limit']) : 1;
$user_levels = explode(',', ($u['vip_level'] ?? 'normal'));

if ($u['role'] == 'admin') {
    $user_levels = ['normal', 'vip', 'forever'];
    $cooldown = 0; $api_limit = 50;
} elseif (!$u['is_vip']) {
    $user_levels = ['normal'];
}

// Fetch APIs to count matches
$stmt = $pdo->prepare("SELECT level FROM apis WHERE status = 'on'");
$stmt->execute();
$all_apis = $stmt->fetchAll();
$matches = 0;
foreach($all_apis as $api) {
    $api_lvls = explode(',', $api['level']);
    if (array_intersect($api_lvls, $user_levels)) {
        $matches++;
    }
}
$api_count = min($matches, $api_limit);
?>

<div class="row g-4">
    <div class="col-md-5">
        <div class="card-modern">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="fw-bold m-0">💥 SMS/OTP Bomber</h5>
                <div class="d-flex gap-1">
                    <?php foreach($user_levels as $l): ?>
                        <span class="badge bg-indigo bg-opacity-10 text-indigo text-uppercase" style="font-size: 8px;"><?= $l ?></span>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div id="info_alert" class="p-3 bg-lightest border rounded-4 mb-4">
                <div class="row g-2 text-center">
                    <div class="col-4 border-end">
                        <div class="x-small text-muted">Trạng thái</div>
                        <div class="fw-bold text-indigo" style="font-size: 11px;">
                            <?= $u['is_vip'] ? 'ĐÃ KÍCH HOẠT' : 'THÀNH VIÊN' ?>
                        </div>
                    </div>
                    <div class="col-4 border-end">
                        <div class="x-small text-muted">Số cổng</div>
                        <div class="fw-bold text-success"><?= $api_count ?></div>
                    </div>
                    <div class="col-4">
                        <div class="x-small text-muted">Thời gian chờ</div>
                        <div class="fw-bold text-danger"><?= $cooldown ?>s</div>
                    </div>
                </div>
            </div>

            <div id="spam_msg"></div>

            <form id="spamForm">
                <div class="mb-4">
                    <label class="form-label small fw-bold">Số điện thoại mục tiêu</label>
                    <div class="input-group input-group-lg shadow-sm rounded-4 overflow-hidden">
                        <span class="input-group-text bg-white border-end-0 text-muted ps-4"><i class="fa fa-phone"></i></span>
                        <input type="text" id="phone" name="phone" class="form-control border-start-0 py-3" placeholder="0xxxxxxxxx" style="font-size: 1.1rem; letter-spacing: 2px;">
                    </div>
                    <div class="form-text mt-2 small text-muted">Gói của bạn cho phép chạy tối đa <?= $api_limit ?> cổng.</div>
                </div>

                <button type="submit" id="btnRun" class="btn btn-indigo w-100 py-3 rounded-4 fw-bold shadow-indigo">
                    <i class="fa fa-bolt me-2"></i> BẮT ĐẦU TẤN CÔNG
                </button>
            </form>
        </div>
    </div>

    <div class="col-md-7">
        <div class="card-modern h-100" id="progress_container" style="display: none;">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h6 class="fw-bold m-0"><i class="fa fa-tasks me-2"></i> Tiến trình thực thi</h6>
                <span id="percent_text" class="badge bg-indigo">0%</span>
            </div>

            <!-- Progress Bar -->
            <div class="progress mb-4 rounded-pill shadow-sm" style="height: 12px; background-color: #f1f5f9;">
                <div id="progress_bar" class="progress-bar progress-bar-striped progress-bar-animated bg-indigo" style="width: 0%"></div>
            </div>

            <!-- Execution Logs -->
            <div class="p-3 bg-lightest rounded-4 border overflow-auto" id="spam_logs" style="max-height: 250px; font-family: 'Courier New', Courier, monospace; font-size: 0.85rem;">
                <div class="text-muted italic">Đang chờ khởi tạo...</div>
            </div>
        </div>

        <!-- Placeholder when not running -->
    </div>
</div>

<script>
document.getElementById('spamForm').onsubmit = function(e) {
    e.preventDefault();
    const phone = document.getElementById('phone').value;
    const btn = document.getElementById('btnRun');
    const msg = document.getElementById('spam_msg');
    
    if (!/^0[0-9]{9}$/.test(phone)) {
        msg.innerHTML = '<div class="alert alert-danger small py-2">SĐT không hợp lệ (10 số, bắt đầu bằng 0)</div>';
        return;
    }

    btn.disabled = true;
    btn.innerHTML = '<i class="fa fa-spinner fa-spin me-2"></i>ĐANG KHỞI TẠO...';

    fetch('<?= BASE_URL ?>api/init_spam.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'phone=' + phone
    })
    .then(res => res.json())
    .then(initData => {
        if (initData.status != 'ok') {
            msg.innerHTML = '<div class="alert alert-warning small py-2">' + initData.message + '</div>';
            btn.disabled = false;
            btn.innerHTML = '<i class="fa fa-bolt me-2"></i> BẮT ĐẦU TẤN CÔNG';
            return;
        }

        const apisToRun = initData.data.apis;
        
        btn.innerHTML = '<i class="fa fa-spinner fa-spin me-2"></i>ĐANG TẤN CÔNG...';
        document.getElementById('progress_container').style.display = 'block';
        const logs = document.getElementById('spam_logs');
        const bar = document.getElementById('progress_bar');
        const percent = document.getElementById('percent_text');
        logs.innerHTML = '<b>🚀 Khởi động tấn công tới: ' + phone + '</b><br>';

        let completed = 0;
        const total = apisToRun.length;

        apisToRun.forEach((api, index) => {
            setTimeout(() => {
                appendLog('📡 Đang gửi cổng: ' + api.name + '...');
                
                fetch('<?= BASE_URL ?>api/execute_spam.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'phone=' + phone + '&api_id=' + api.id
                })
                .then(res => res.json())
                .then(data => {
                    completed++;
                    updateProgress(completed, total);
                    if (data.status == 'ok') {
                        appendLog('<span class="text-success">✅ Thành công [' + api.name + ']</span>');
                    } else {
                        appendLog('<span class="text-danger">❌ Thất bại [' + api.name + ']: ' + data.message + '</span>');
                    }

                    if (completed == total) {
                        appendLog('<br><b>🏁 HOÀN THÀNH TẤN CÔNG!</b>');
                        btn.innerHTML = '<i class="fa fa-check me-2"></i> Xong!';
                    }
                });
            }, index * 300);
        });
    })
    .catch(err => {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa fa-bolt me-2"></i> BẮT ĐẦU TẤN CÔNG';
        appendLog('<span class="text-danger">❌ Lỗi hệ thống: ' + err.message + '</span>');
    });
};

function appendLog(text) {
    const logs = document.getElementById('spam_logs');
    logs.innerHTML += '<div>' + text + '</div>';
    logs.scrollTop = logs.scrollHeight;
}

function updateProgress(done, total) {
    const p = Math.round((done / total) * 100);
    document.getElementById('progress_bar').style.width = p + '%';
    document.getElementById('percent_text').innerText = p + '%';
}
</script>

<style>
.border-dashed { border: 2px dashed #e2e8f0; }
#spam_logs div { margin-bottom: 4px; border-bottom: 1px solid rgba(0,0,0,0.02); padding-bottom: 2px; }
</style>
