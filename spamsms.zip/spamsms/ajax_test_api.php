<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

$id = $_POST['id'] ?? null;
$phone = $_POST['phone'] ?? '0987654321';

if (!$id) responseJson('error', 'Thiếu ID API');

$stmt = $pdo->prepare("SELECT * FROM apis WHERE id = ?");
$stmt->execute([$id]);
$api = $stmt->fetch();

if (!$api) responseJson('error', 'API không tồn tại');

$finalUrl = str_replace('{{phone}}', $phone, $api['url']);
$finalBody = str_replace('{{phone}}', $phone, $api['body'] ?? '');

$res = sendRequest($finalUrl, $api['method'], $api['headers'], $finalBody);

responseJson('ok', 'Kết nối thành công tới: ' . $api['name'], ['response' => $res]);
