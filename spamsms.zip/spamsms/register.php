<?php
require_once 'includes/config.php';

if ($u) { header("Location: " . BASE_URL . "index.php"); exit; }

$error = ''; $success = '';
if (isset($_POST['register'])) {
    $user = $_POST['username'];
    $pass = $_POST['password'];
    $conf = $_POST['confirm_password'];
    
    if (strlen($user) < 5) {
        $error = "Tên tài khoản phải từ 5 ký tự!";
    } elseif ($pass != $conf) {
        $error = "Mật khẩu xác nhận không khớp!";
    } else {
        $check = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $check->execute([$user]);
        if ($check->fetch()) {
            $error = "Tên tài khoản này đã tồn tại!";
        } else {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password, role, balance, cooldown, api_limit) VALUES (?, ?, 'user', 0, 300, 1)");
            if ($stmt->execute([$user, $hash])) {
                $new_id = $pdo->lastInsertId();
                $pdo->prepare("INSERT INTO logs (user_id, target, status) VALUES (?, 'SYSTEM', 'Đăng ký tài khoản mới')")->execute([$new_id]);
                $success = "Đăng ký thành công! Đang chuyển hướng...";
                echo "<script>setTimeout(()=>window.location='" . BASE_URL . "login.php', 2000);</script>";
            } else {
                $error = "Có lỗi xảy ra, vui lòng thử lại!";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tham gia - <?= $settings['title'] ?? 'Panel' ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
    <?php if(($settings['cloudflare_turnstile'] ?? 'off') == 'on' && !empty($settings['cloudflare_site_key'])): ?>
        <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
    <?php elseif(($settings['google_recaptcha'] ?? 'off') == 'on' && !empty($settings['recaptcha_site_key'])): ?>
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <?php endif; ?>
    <style>
        body { display: flex; align-items: center; justify-content: center; height: 100vh; background-color: #f8fafc; }
        .login-card { width: 100%; max-width: 420px; border-radius: 16px; border: 1px solid #e2e8f0; background: white; padding: 2.5rem; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05); }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="text-center mb-4">
            <h3 class="fw-bold">Tạo tài khoản</h3>
            <p class="text-muted small">Trở thành thành viên của WusTeam</p>
        </div>
        
        <?php if($error): ?>
            <div class="alert alert-danger p-2 small"><?= $error ?></div>
        <?php endif; ?>
        <?php if($success): ?>
            <div class="alert alert-success p-2 small"><?= $success ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="mb-3">
                <label class="form-label small fw-semibold">Tên tài khoản</label>
                <input type="text" name="username" class="form-control" placeholder="Tối thiểu 5 ký tự" required>
            </div>
            <div class="mb-3">
                <label class="form-label small fw-semibold">Mật khẩu</label>
                <input type="password" name="password" class="form-control" placeholder="••••••••" required>
            </div>
            <div class="mb-4">
                <label class="form-label small fw-semibold">Xác nhận mật khẩu</label>
                <input type="password" name="confirm_password" class="form-control" placeholder="••••••••" required>
            </div>
            
            <?php if(($settings['cloudflare_turnstile'] ?? 'off') == 'on' && !empty($settings['cloudflare_site_key'])): ?>
                <div class="mb-3 d-flex justify-content-center">
                    <div class="cf-turnstile" data-sitekey="<?= $settings['cloudflare_site_key'] ?>"></div>
                </div>
            <?php elseif(($settings['google_recaptcha'] ?? 'off') == 'on' && !empty($settings['recaptcha_site_key'])): ?>
                <div class="mb-3 d-flex justify-content-center">
                    <div class="g-recaptcha" data-sitekey="<?= $settings['recaptcha_site_key'] ?>"></div>
                </div>
            <?php endif; ?>

            <button type="submit" name="register" class="btn btn-indigo w-100 mb-3 py-2">Tạo tài khoản ngay</button>
            <div class="text-center small text-muted">
                Đã có tài khoản? <a href="<?= BASE_URL ?>login.php" class="text-primary text-decoration-none fw-bold">Đăng nhập</a>
            </div>
        </form>
    </div>
</body>
</html>