<div class="d-flex align-items-center justify-content-center" style="min-height: 70vh;">
    <div class="text-center">
        <h1 class="display-1 fw-bold text-indigo mb-0" style="font-size: 8rem; text-shadow: 2px 2px 0px rgba(79, 70, 229, 0.2);">404</h1>
        <h3 class="fw-bold mb-3">Không tìm thấy trang</h3>
        <p class="text-muted mb-5">Đường dẫn bạn yêu cầu không tồn tại hoặc đã bị di dời.<br>Vui lòng kiểm tra lại đường dẫn và thử lại.</p>
        <a href="<?= BASE_URL ?>index.php" class="btn btn-indigo px-5 py-2 rounded-pill shadow-sm">
            <i class="fa fa-home me-2"></i> VỀ TRANG CHỦ
        </a>
    </div>
</div>
