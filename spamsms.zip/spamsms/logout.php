<?php
session_start();
require_once 'includes/config.php'; // For BASE_URL
session_destroy();
header("Location: " . BASE_URL . "login.php");
exit;
