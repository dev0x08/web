<?php
// Xử lý Thêm/Sửa API
if (isset($_POST['save_api'])) {
    $id = $_POST['id'] ?? null;
    $name = $_POST['name'];
    $url = $_POST['url'];
    $method = $_POST['method'];
    $headers = $_POST['headers'];
    $body = $_POST['body'];
    $status = $_POST['status'];
    $type = $_POST['type'] ?? 'sms';
    // Xử lý Checkboxes Level
    $levels = isset($_POST['levels']) ? implode(',', $_POST['levels']) : 'normal';

    if ($id) {
        $stmt = $pdo->prepare("UPDATE apis SET name=?, url=?, method=?, headers=?, body=?, status=?, level=?, type=? WHERE id=?");
        $stmt->execute([$name, $url, $method, $headers, $body, $status, $levels, $type, $id]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO apis (name, url, method, headers, body, status, level, type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $url, $method, $headers, $body, $status, $levels, $type]);
    }
    header("Location: " . BASE_URL . "?page=admin_apis&success=1"); exit;
}

// Xử lý Xóa API
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM apis WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: " . BASE_URL . "?page=admin_apis&success=deleted"); exit;
}

if (isset($_GET['toggle'])) {
    $pdo->prepare("UPDATE apis SET status = IF(status='on','off','on') WHERE id = ?")->execute([$_GET['toggle']]);
    header("Location: " . BASE_URL . "?page=admin_apis"); exit;
}

// Thống kê nhanh
$total_apis = $pdo->query("SELECT count(*) FROM apis")->fetchColumn();
$on_apis = $pdo->query("SELECT count(*) FROM apis WHERE status = 'on'")->fetchColumn();
$off_apis = $pdo->query("SELECT count(*) FROM apis WHERE status = 'off'")->fetchColumn();

// Xử lý tìm kiếm
$search = $_GET['search'] ?? '';
$where = $search ? "WHERE name LIKE :search OR url LIKE :search" : "";
$stmt = $pdo->prepare("SELECT * FROM apis $where ORDER BY id DESC");
if ($search) $stmt->bindValue(':search', "%$search%");
$stmt->execute();
$apis = $stmt->fetchAll();
?>

<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="card-modern p-4 text-center border-indigo border-opacity-10">
            <div class="small text-muted fw-bold mb-1">TỔNG CỔNG API</div>
            <div class="h2 fw-bold text-indigo mb-0"><?= $total_apis ?></div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card-modern p-4 text-center border-success border-opacity-10">
            <div class="small text-muted fw-bold mb-1">ĐANG HOẠT ĐỘNG</div>
            <div class="h2 fw-bold text-success mb-0"><?= $on_apis ?></div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card-modern p-4 text-center border-danger border-opacity-10">
            <div class="small text-muted fw-bold mb-1">ĐANG TẠM DỪNG</div>
            <div class="h2 fw-bold text-danger mb-0"><?= $off_apis ?></div>
        </div>
    </div>
</div>

<div class="card-modern border-0 shadow-sm overflow-hidden">
    <div class="bg-indigo p-4">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="text-white fw-bold m-0"><i class="fa fa-server me-2"></i> QUẢN LÝ CỔNG API</h4>
            <button class="btn btn-white btn-sm px-4 rounded-pill shadow-sm fw-bold" data-bs-toggle="modal" data-bs-target="#apiModal" onclick="resetForm()">
                Thêm API mới <i class="fa fa-plus ms-1"></i>
            </button>
        </div>
    </div>

    <div class="p-4">
        <?php if(isset($_GET['success'])): ?>
            <div class="alert alert-success border-0 shadow-sm rounded-4 mb-4 py-3 d-flex align-items-center">
                <i class="fa fa-check-circle fs-4 me-3"></i>
                <div class="fw-bold">Thao tác thành công!</div>
            </div>
        <?php endif; ?>

        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
            <h5 class="fw-bold m-0">Danh sách cổng API</h5>
            <div class="d-flex gap-2">
                <form class="d-flex">
                    <input type="hidden" name="page" value="admin_apis">
                    <div class="input-group input-group-sm rounded-pill overflow-hidden border">
                        <span class="input-group-text bg-white border-0"><i class="fa fa-search text-muted"></i></span>
                        <input type="text" name="search" class="form-control border-0 px-1" placeholder="Tìm kiếm..." value="<?= htmlspecialchars($search) ?>">
                        <?php if($search): ?>
                            <a href="<?= BASE_URL ?>?page=admin_apis" class="btn btn-white border-0"><i class="fa fa-times text-muted"></i></a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th class="ps-3" style="width: 50px;">ID</th>
                        <th>Loại</th>
                        <th>Cổng API</th>
                        <th>URL Endpoint</th>
                        <th>Quyền (Levels)</th>
                        <th>Trạng thái</th>
                        <th class="text-end pe-3">Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($apis as $api): ?>
                    <tr>
                        <td class="ps-3 small text-muted">#<?= $api['id'] ?></td>
                        <td>
                            <?php if($api['type'] == 'call'): ?>
                                <span class="badge bg-danger bg-opacity-10 text-danger border-danger border-opacity-25 px-2 py-1"><i class="fa fa-phone me-1"></i> CALL</span>
                            <?php else: ?>
                                <span class="badge bg-indigo bg-opacity-10 text-indigo border-indigo border-opacity-25 px-2 py-1"><i class="fa fa-envelope me-1"></i> SMS</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="fw-bold"><?= $api['name'] ?></div>
                            <span class="badge bg-lightest text-dark border x-small"><?= $api['method'] ?></span>
                        </td>
                        <td class="small text-muted text-truncate" style="max-width: 250px;" title="<?= $api['url'] ?>"><?= $api['url'] ?></td>
                        <td>
                            <?php 
                                $lvls = explode(',', $api['level']);
                                foreach($lvls as $l):
                                    $lvl_class = 'bg-secondary';
                                    if($l == 'vip') $lvl_class = 'bg-warning text-dark';
                                    if($l == 'forever') $lvl_class = 'bg-danger text-white';
                                    if($l == 'normal') $lvl_class = 'bg-info text-white';
                            ?>
                                <span class="badge <?= $lvl_class ?> text-uppercase me-1" style="font-size: 8px;"><?= $l ?></span>
                            <?php endforeach; ?>
                        </td>
                        <td>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" <?= $api['status']=='on'?'checked':'' ?> 
                                       onchange="window.location='<?= BASE_URL ?>?page=admin_apis&toggle=<?= $api['id'] ?>'">
                            </div>
                        </td>
                        <td class="text-end pe-3">
                            <div class="d-flex justify-content-end gap-1">
                                <button class="btn btn-sm btn-white border-0 py-1 px-3" onclick="openTestModal(<?= $api['id'] ?>, '<?= $api['name'] ?>')" title="Test API">
                                    <i class="fa fa-flask text-indigo"></i>
                                </button>
                                <button class="btn btn-sm btn-white border-0 py-1 px-3" onclick='editApi(<?= htmlspecialchars(json_encode($api), ENT_QUOTES) ?>)' data-bs-toggle="modal" data-bs-target="#apiModal">
                                    <i class="fa fa-edit text-primary"></i>
                                </button>
                                <button class="btn btn-sm btn-white border-0 py-1 px-3 text-danger" onclick="confirmDelete(<?= $api['id'] ?>)">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($apis)): ?>
                        <tr><td colspan="7" class="text-center py-5 text-muted small">Không tìm thấy cổng API nào.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Thêm/Sửa API -->
<div class="modal fade" id="apiModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <form class="modal-content border-0 shadow-lg rounded-4 overflow-hidden" method="POST">
            <div class="modal-header bg-indigo text-white border-0 py-3 px-4">
                <h5 class="modal-title fw-bold" id="apiModalLabel">Cấu hình Cổng API</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <input type="hidden" name="id" id="api_id">
                <div class="row g-4">
                    <div class="col-md-4">
                        <label class="form-label x-small fw-bold text-muted text-uppercase">Tên cổng API</label>
                        <input type="text" name="name" id="api_name" class="form-control bg-light border-0 py-2" placeholder="VD: TV360, Viettel..." required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label x-small fw-bold text-muted text-uppercase">Loại dịch vụ</label>
                        <select name="type" id="api_type" class="form-select bg-light border-0 py-2">
                            <option value="sms">SMS / OTP</option>
                            <option value="call">SPAM CALL</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label x-small fw-bold text-muted text-uppercase">Trạng thái</label>
                        <select name="status" id="api_status" class="form-select bg-light border-0 py-2">
                            <option value="on">Hoạt động</option>
                            <option value="off">Tạm dừng</option>
                        </select>
                    </div>

                    <div class="col-md-9">
                        <label class="form-label x-small fw-bold text-muted text-uppercase">URL Endpoint</label>
                        <input type="url" name="url" id="api_url" class="form-control bg-light border-0 py-2" placeholder="https://api.example.com/v1/..." required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label x-small fw-bold text-muted text-uppercase">Method</label>
                        <select name="method" id="api_method" class="form-select bg-light border-0 py-2">
                            <option value="GET">GET</option>
                            <option value="POST">POST</option>
                        </select>
                    </div>

                    <div class="col-12">
                        <label class="form-label x-small fw-bold text-muted text-uppercase">Quyền tiếp cận (Levels)</label>
                        <div class="d-flex gap-4 p-3 bg-light rounded-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="levels[]" value="normal" id="lvl_normal">
                                <label class="form-check-label small" for="lvl_normal">Normal</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="levels[]" value="vip" id="lvl_vip">
                                <label class="form-check-label small" for="lvl_vip">VIP</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="levels[]" value="forever" id="lvl_forever">
                                <label class="form-check-label small" for="lvl_forever">Forever</label>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label x-small fw-bold text-muted text-uppercase">Custom Headers (JSON)</label>
                        <textarea name="headers" id="api_headers" class="form-control bg-light border-0 font-monospace small" rows="4" placeholder='{"Content-Type": "application/json"}'></textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label x-small fw-bold text-muted text-uppercase">Custom Body (JSON/Query)</label>
                        <textarea name="body" id="api_body" class="form-control bg-light border-0 font-monospace small" rows="4" placeholder='{"phone": "{{phone}}"}'></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-0 p-4 pt-0">
                <button type="submit" name="save_api" class="btn btn-indigo w-100 py-3 rounded-4 fw-bold shadow-indigo text-uppercase">Lưu thông tin cổng</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Xác nhận Xóa -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-body p-4 text-center">
                <div class="bg-danger bg-opacity-10 text-danger d-inline-block p-3 rounded-circle mb-3">
                    <i class="fa fa-trash-alt fa-2x"></i>
                </div>
                <h5 class="fw-bold">Xác nhận xóa?</h5>
                <p class="text-muted small">Hành động này không thể hoàn tác. Bạn có chắc chắn muốn xóa cổng API này?</p>
                <div class="d-flex gap-2 mt-4">
                    <button type="button" class="btn btn-light w-100 py-2 rounded-3 fw-bold" data-bs-dismiss="modal">Hủy</button>
                    <a href="" id="confirmDeleteBtn" class="btn btn-danger w-100 py-2 rounded-3 fw-bold">Xóa ngay</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Test API -->
<div class="modal fade" id="testModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header border-0 pb-0">
                <h6 class="modal-title fw-bold">Test Cổng API: <span id="test_api_name" class="text-indigo"></span></h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body py-4">
                <input type="hidden" id="test_api_id">
                <div class="mb-3">
                    <label class="form-label small fw-bold">Số điện thoại Test</label>
                    <input type="text" id="test_phone" class="form-control" value="0987654321" placeholder="0xxxxxxxxx">
                </div>
                <div id="test_result" class="p-3 bg-lightest rounded-3 border small" style="display:none; max-height: 200px; overflow: auto;">
                    <div class="fw-bold mb-1">Kết quả:</div>
                    <pre id="test_response" class="m-0 text-wrap" style="font-size: 11px;"></pre>
                </div>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" id="btnRunTest" class="btn btn-indigo w-100 py-2 rounded-pill fw-bold" onclick="runApiTest()">
                    <i class="fa fa-play me-2"></i> CHẠY THỬ NGHIỆM
                </button>
            </div>
        </div>
    </div>
</div>

<script>
function resetForm() {
    document.getElementById('apiModalLabel').innerText = 'Thêm cổng API mới';
    document.getElementById('api_id').value = '';
    document.getElementById('api_name').value = '';
    document.getElementById('api_url').value = '';
    document.getElementById('api_method').value = 'POST';
    document.getElementById('api_headers').value = '';
    document.getElementById('api_body').value = '';
    document.getElementById('api_status').value = 'on';
    document.getElementById('api_type').value = 'sms';
    document.querySelectorAll('input[name="levels[]"]').forEach(cb => cb.checked = true);
}

function editApi(api) {
    document.getElementById('apiModalLabel').innerText = 'Chỉnh sửa: ' + api.name;
    document.getElementById('api_id').value = api.id;
    document.getElementById('api_name').value = api.name;
    document.getElementById('api_url').value = api.url;
    document.getElementById('api_method').value = api.method;
    document.getElementById('api_headers').value = api.headers;
    document.getElementById('api_body').value = api.body;
    document.getElementById('api_status').value = api.status;
    document.getElementById('api_type').value = api.type || 'sms';
    
    // Check checkboxes
    const levels = (api.level || '').split(',');
    document.querySelectorAll('input[name="levels[]"]').forEach(cb => {
        cb.checked = levels.includes(cb.value);
    });
}

function confirmDelete(id) {
    document.getElementById('confirmDeleteBtn').href = '<?= BASE_URL ?>?page=admin_apis&delete=' + id;
    const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
    modal.show();
}

function openTestModal(id, name) {
    document.getElementById('test_api_id').value = id;
    document.getElementById('test_api_name').innerText = name;
    document.getElementById('test_result').style.display = 'none';
    document.getElementById('btnRunTest').disabled = false;
    document.getElementById('btnRunTest').innerHTML = '<i class="fa fa-play me-2"></i> CHẠY THỬ NGHIỆM';
    
    var myModal = new bootstrap.Modal(document.getElementById('testModal'));
    myModal.show();
}

async function runApiTest() {
    const id = document.getElementById('test_api_id').value;
    const phone = document.getElementById('test_phone').value;
    const btn = document.getElementById('btnRunTest');
    const resultDiv = document.getElementById('test_result');
    const responsePre = document.getElementById('test_response');

    if(!/^0[0-9]{9}$/.test(phone)) {
        alert('SĐT không hợp lệ!'); return;
    }

    btn.disabled = true;
    btn.innerHTML = '<i class="fa fa-spinner fa-spin me-2"></i> ĐANG GỬI...';
    
    try {
        const res = await apiCall('<?= BASE_URL ?>ajax_test_api.php', 'POST', { id, phone });
        resultDiv.style.display = 'block';
        if (res.status == 'ok') {
            responsePre.className = 'm-0 text-wrap text-success';
            responsePre.innerText = JSON.stringify(res.data.response, null, 2);
        } else {
            responsePre.className = 'm-0 text-wrap text-danger';
            responsePre.innerText = res.message;
        }
    } catch (e) {
        resultDiv.style.display = 'block';
        responsePre.className = 'm-0 text-wrap text-danger';
        responsePre.innerText = 'Lỗi kết nối: ' + e.message;
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa fa-play me-2"></i> CHẠY LẠI';
    }
}
</script>
