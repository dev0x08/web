<?php
// Xử lý lưu cài đặt
if (isset($_POST['save_settings'])) {
    foreach ($_POST['s'] as $key => $value) {
        $stmt = $pdo->prepare("UPDATE settings SET value = ? WHERE name = ?");
        $stmt->execute([$value, $key]);
    }
    header("Location: " . BASE_URL . "?page=admin_settings&success=1"); exit;
}
?>

<div class="card-modern">
    <h5 class="fw-bold mb-4">Cài đặt hệ thống</h5>
    
    <?php if(isset($_GET['success'])): ?>
        <div class="alert alert-success border-0 bg-success bg-opacity-10 text-success small mb-4">Lưu cấu hình thành công!</div>
    <?php endif; ?>

    <form method="POST">
        <div class="row g-4">
            <!-- Cấu hình chung -->
            <div class="col-md-6">
                <div class="p-4 rounded-4 bg-lightest border h-100">
                    <h6 class="fw-bold mb-4 text-indigo"><i class="fa fa-sliders-h me-2"></i> Cấu hình chung</h6>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Tên ứng dụng</label>
                        <input type="text" name="s[title]" class="form-control" value="<?= $settings['title'] ?>" required>
                    </div>
                    <div class="row">
                        <div class="col-6 mb-3">
                            <label class="form-label small fw-semibold">Phí / lượt (đ)</label>
                            <input type="number" name="s[cost]" class="form-control" value="<?= $settings['cost'] ?>" required>
                        </div>
                        <div class="col-6 mb-3">
                            <label class="form-label small fw-semibold">Lượt miễn phí / ngày</label>
                            <input type="number" name="s[max_daily_spam_free]" class="form-control" value="<?= $settings['max_daily_spam_free'] ?>" required>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Cổng nạp tiền -->
            <div class="col-md-6">
                <div class="p-4 rounded-4 bg-lightest border h-100">
                    <h6 class="fw-bold mb-4 text-success"><i class="fa fa-wallet me-2"></i> Cổng nạp tiền</h6>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Tên chủ tài khoản</label>
                        <input type="text" name="s[account_name]" class="form-control" value="<?= $settings['account_name'] ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Số MOMO</label>
                        <input type="text" name="s[momo_number]" class="form-control" value="<?= $settings['momo_number'] ?>" required>
                    </div>
                    <div class="mb-0">
                        <label class="form-label small fw-semibold">Số tài khoản Bank (MB)</label>
                        <input type="text" name="s[bank_number]" class="form-control" value="<?= $settings['bank_number'] ?>" required>
                    </div>
                </div>
            </div>

            <!-- Mạng xã hội -->
            <div class="col-md-6">
                <div class="p-4 rounded-4 bg-lightest border h-100">
                    <h6 class="fw-bold mb-4 text-primary"><i class="fa fa-share-alt me-2"></i> Mạng xã hội & Hỗ trợ</h6>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Telegram Link</label>
                        <input type="text" name="s[telegram_link]" class="form-control" value="<?= $settings['telegram_link'] ?? '' ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Zalo Link</label>
                        <input type="text" name="s[zalo_link]" class="form-control" value="<?= $settings['zalo_link'] ?? '' ?>">
                    </div>
                    <div class="mb-0">
                        <label class="form-label small fw-semibold">Discord Link</label>
                        <input type="text" name="s[discord_link]" class="form-control" value="<?= $settings['discord_link'] ?? '' ?>">
                    </div>
                </div>
            </div>

            <!-- Bảo mật & Hệ thống -->
            <div class="col-md-6">
                <div class="p-4 rounded-4 bg-lightest border h-100">
                    <h6 class="fw-bold mb-4 text-danger"><i class="fa fa-shield-alt me-2"></i> Bảo mật & Nâng cao</h6>
                    
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Trạng thái Website (Bảo trì)</label>
                        <select name="s[maintenance_mode]" class="form-select">
                            <option value="off" <?= ($settings['maintenance_mode'] ?? 'off') == 'off' ? 'selected' : '' ?>>Hoạt động bình thường</option>
                            <option value="on" <?= ($settings['maintenance_mode'] ?? 'off') == 'on' ? 'selected' : '' ?>>Đang bảo trì (Chặn Users)</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Cloudflare Turnstile</label>
                        <select name="s[cloudflare_turnstile]" class="form-select mb-2">
                            <option value="off" <?= ($settings['cloudflare_turnstile'] ?? 'off') == 'off' ? 'selected' : '' ?>>Tắt</option>
                            <option value="on" <?= ($settings['cloudflare_turnstile'] ?? 'off') == 'on' ? 'selected' : '' ?>>Bật</option>
                        </select>
                        <div class="row g-2">
                            <div class="col-6"><input type="text" name="s[cloudflare_site_key]" class="form-control form-control-sm" placeholder="Site Key" value="<?= $settings['cloudflare_site_key'] ?? '' ?>"></div>
                            <div class="col-6"><input type="text" name="s[cloudflare_secret_key]" class="form-control form-control-sm" placeholder="Secret Key" value="<?= $settings['cloudflare_secret_key'] ?? '' ?>"></div>
                        </div>
                    </div>

                    <div class="mb-0">
                        <label class="form-label small fw-semibold">Google reCAPTCHA v2</label>
                        <select name="s[google_recaptcha]" class="form-select mb-2">
                            <option value="off" <?= ($settings['google_recaptcha'] ?? 'off') == 'off' ? 'selected' : '' ?>>Tắt</option>
                            <option value="on" <?= ($settings['google_recaptcha'] ?? 'off') == 'on' ? 'selected' : '' ?>>Bật</option>
                        </select>
                        <div class="row g-2">
                            <div class="col-6"><input type="text" name="s[recaptcha_site_key]" class="form-control form-control-sm" placeholder="Site Key" value="<?= $settings['recaptcha_site_key'] ?? '' ?>"></div>
                            <div class="col-6"><input type="text" name="s[recaptcha_secret_key]" class="form-control form-control-sm" placeholder="Secret Key" value="<?= $settings['recaptcha_secret_key'] ?? '' ?>"></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-12 text-center mt-5">
                <button type="submit" name="save_settings" class="btn btn-indigo px-5 py-2 fw-bold shadow-sm">
                    <i class="fa fa-save me-2"></i> LƯU THAY ĐỔI
                </button>
            </div>
        </div>
    </form>
</div>
