<?php
// Stats
$total_users = $pdo->query("SELECT count(*) FROM users")->fetchColumn();
$total_apis = $pdo->query("SELECT count(*) FROM apis")->fetchColumn();
$total_spam = $pdo->query("SELECT count(*) FROM logs WHERE target = 'SPAM'")->fetchColumn();
$total_whitelist = $pdo->query("SELECT count(*) FROM whitelist")->fetchColumn();

// Paginate Logs
$limit = 10;
$page_num = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
$offset = ($page_num - 1) * $limit;

$total_logs = $pdo->query("SELECT count(*) FROM logs")->fetchColumn();
$total_pages = ceil($total_logs / $limit);

$stmt = $pdo->prepare("SELECT l.*, u.username FROM logs l JOIN users u ON l.user_id = u.id ORDER BY l.id DESC LIMIT ? OFFSET ?");
$stmt->bindValue(1, $limit, PDO::PARAM_INT);
$stmt->bindValue(2, $offset, PDO::PARAM_INT);
$stmt->execute();
$system_logs = $stmt->fetchAll();
?>

<div class="row g-4 mb-4">
    <div class="col-md-3">
        <div class="card-modern border-start border-4 border-primary">
            <div class="d-flex align-items-center">
                <div class="flex-grow-1">
                    <div class="text-muted small fw-bold">NGƯỜI DÙNG</div>
                    <h3 class="fw-bold mb-0 mt-1"><?= number_format($total_users) ?></h3>
                </div>
                <div class="bg-primary bg-opacity-10 text-primary p-3 rounded-circle"><i class="fa fa-users"></i></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card-modern border-start border-4 border-info">
            <div class="d-flex align-items-center">
                <div class="flex-grow-1">
                    <div class="text-muted small fw-bold">CỔNG API</div>
                    <h3 class="fw-bold mb-0 mt-1"><?= number_format($total_apis) ?></h3>
                </div>
                <div class="bg-info bg-opacity-10 text-info p-3 rounded-circle"><i class="fa fa-server"></i></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card-modern border-start border-4 border-success">
            <div class="d-flex align-items-center">
                <div class="flex-grow-1">
                    <div class="text-muted small fw-bold">TỔNG LƯỢT CHẠY</div>
                    <h3 class="fw-bold mb-0 mt-1"><?= number_format($total_spam) ?></h3>
                </div>
                <div class="bg-success bg-opacity-10 text-success p-3 rounded-circle"><i class="fa fa-bolt"></i></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card-modern border-start border-4 border-danger">
            <div class="d-flex align-items-center">
                <div class="flex-grow-1">
                    <div class="text-muted small fw-bold">WHITELIST</div>
                    <h3 class="fw-bold mb-0 mt-1"><?= number_format($total_whitelist) ?></h3>
                </div>
                <div class="bg-danger bg-opacity-10 text-danger p-3 rounded-circle"><i class="fa fa-shield-alt"></i></div>
            </div>
        </div>
    </div>
</div>

<div class="card-modern">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="fw-bold mb-0">Hoạt động toàn hệ thống</h5>
        <div class="dropdown">
            <button class="btn btn-sm btn-outline-secondary dropdown-toggle px-3 rounded-pill" type="button" data-bs-toggle="dropdown">
                <i class="fa fa-broom me-1"></i> Dọn dẹp
            </button>
            <ul class="dropdown-menu shadow border-0 small">
                <li><a class="dropdown-item py-2 text-danger fw-bold" href="#" onclick="confirmAction('clear_all', 0, 'Xóa TOÀN BỘ nhật ký', 'Hệ thống')">Xóa toàn bộ</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item py-2" href="#" onclick="confirmAction('clean_logs', 1, 'Dọn dẹp các nhật ký', 'hơn 1 ngày trước')">Cũ hơn 1 ngày</a></li>
                <li><a class="dropdown-item py-2" href="#" onclick="confirmAction('clean_logs', 7, 'Dọn dẹp các nhật ký', 'hơn 7 ngày trước')">Cũ hơn 7 ngày</a></li>
                <li><a class="dropdown-item py-2" href="#" onclick="confirmAction('clean_logs', 30, 'Dọn dẹp các nhật ký', 'hơn 30 ngày trước')">Cũ hơn 30 ngày</a></li>
            </ul>
        </div>
    </div>
    
    <div class="table-responsive">
        <table class="table table-striped table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>Người dùng</th>
                    <th>Hành động</th>
                    <th>Nội dung</th>
                    <th>Thời gian</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($system_logs as $log): ?>
                <tr>
                    <td class="fw-bold text-indigo"><?= $log['username'] ?></td>
                    <td><span class="badge badge-indigo text-uppercase" style="font-size: 10px;"><?= $log['target'] ?></span></td>
                    <td class="small">
                        <?php 
                            if ($log['target'] == 'SPAM' && preg_match('/\d{10}/', $log['status'], $matches)) {
                                echo str_replace($matches[0], '*******' . substr($matches[0], -3), $log['status']);
                            } else {
                                echo $log['status'];
                            }
                        ?>
                    </td>
                    <td class="text-muted small"><?= timeAgo(strtotime($log['created_at'])) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($system_logs)): ?>
                <tr><td colspan="4" class="text-center text-muted py-5">Chưa có hoạt động nào được ghi lại.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($total_pages > 1): ?>
    <nav class="mt-4">
        <ul class="pagination pagination-sm justify-content-center">
            <?php for($i=1; $i<=$total_pages; $i++): ?>
                <?php if($i == 1 || $i == $total_pages || ($i >= $page_num - 2 && $i <= $page_num + 2)): ?>
                    <li class="page-item <?= $i == $page_num ? 'active' : '' ?>">
                        <a class="page-link border mx-1 rounded-2" href="<?= BASE_URL ?>?page=admin_dashboard&p=<?= $i ?>"><?= $i ?></a>
                    </li>
                <?php elseif($i == $page_num - 3 || $i == $page_num + 3): ?>
                    <li class="page-item disabled"><span class="page-link border mx-1 rounded-2">...</span></li>
                <?php endif; ?>
            <?php endfor; ?>
        </ul>
    </nav>
    <?php endif; ?>
</div>

<!-- Modal Xác nhận Dọn dẹp -->
<div class="modal fade" id="cleanLogsModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header border-0 pb-0">
                <h6 class="modal-title fw-bold">Xác nhận</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body py-3 text-center">
                <div class="mb-3 text-warning">
                    <i class="fa fa-clock-rotate-left fa-3x"></i>
                </div>
                <p class="mb-0" id="clean_desc">Xác nhận dọn dẹp</p>
                <div class="fw-bold text-danger" id="clean_time_label"></div>
                <small class="text-muted mt-2 d-block">Dữ liệu sau khi xóa sẽ không thể khôi phục.</small>
            </div>
            <div class="modal-footer border-0 pt-0 gap-2">
                <button type="button" class="btn btn-light btn-sm flex-grow-1 py-2 border" data-bs-dismiss="modal">HỦY</button>
                <button type="button" id="clean_confirm_btn" class="btn btn-danger btn-sm flex-grow-1 py-2 shadow-sm">XÁC NHẬN</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal Thông báo thành công -->
<div class="modal fade" id="ajaxStatusModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-body py-4 text-center">
                <div class="mb-3 text-success" id="ajax_status_icon">
                    <i class="fa fa-check-circle fa-3x"></i>
                </div>
                <h6 class="fw-bold" id="ajax_status_title">Thành công</h6>
                <p class="mb-0 text-muted small" id="ajax_status_message"></p>
                <div class="mt-4">
                    <button type="button" class="btn btn-indigo btn-sm px-4 py-2 rounded-pill shadow-sm" onclick="location.reload()">ĐÓNG & TẢI LẠI</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function confirmAction(action, days, desc, label) {
    document.getElementById('clean_desc').innerText = desc;
    document.getElementById('clean_time_label').innerText = label;
    document.getElementById('clean_confirm_btn').onclick = function() {
        const btn = this;
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Đang xử lý...';
        
        const formData = new FormData();
        formData.append('action', action);
        formData.append('days', days);
        
        fetch('<?= BASE_URL ?>ajax/logs_action.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            bootstrap.Modal.getInstance(document.getElementById('cleanLogsModal')).hide();
            if(data.status === 'success') {
                document.getElementById('ajax_status_icon').innerHTML = '<i class="fa fa-check-circle fa-3x text-success"></i>';
                document.getElementById('ajax_status_title').innerText = 'Thành công';
                document.getElementById('ajax_status_message').innerText = data.message;
                new bootstrap.Modal(document.getElementById('ajaxStatusModal')).show();
            } else {
                document.getElementById('ajax_status_icon').innerHTML = '<i class="fa fa-exclamation-triangle fa-3x text-danger"></i>';
                document.getElementById('ajax_status_title').innerText = 'Thất bại';
                document.getElementById('ajax_status_message').innerText = data.message;
                new bootstrap.Modal(document.getElementById('ajaxStatusModal')).show();
            }
        })
        .catch(err => {
            bootstrap.Modal.getInstance(document.getElementById('cleanLogsModal')).hide();
            alert('Lỗi kết nối máy chủ!');
        })
        .finally(() => {
            btn.disabled = false;
            btn.innerHTML = 'XÁC NHẬN';
        });
    };
    new bootstrap.Modal(document.getElementById('cleanLogsModal')).show();
}
</script>
