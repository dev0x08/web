<?php
$current_tab = $_GET['tab'] ?? 'list';

// Xử lý Lưu/Sửa Gói giá
if (isset($_POST['save_package'])) {
    $pkg_id   = intval($_POST['pkg_id'] ?? 0);
    $name     = trim($_POST['name']);
    $desc     = trim($_POST['description'] ?? '');
    $price    = intval($_POST['price']);
    $duration = intval($_POST['duration']);
    $dur_h    = intval($_POST['duration_hours'] ?? 0);
    $max_uses = intval($_POST['max_uses']);
    $sort     = intval($_POST['sort_order'] ?? 0);
    $status   = $_POST['status'] ?? 'on';

    if ($pkg_id) {
        $pdo->prepare("UPDATE call_packages SET name=?, description=?, price=?, duration=?, duration_hours=?, max_uses=?, sort_order=?, status=? WHERE id=?")
            ->execute([$name, $desc, $price, $duration, $dur_h, $max_uses, $sort, $status, $pkg_id]);
    } else {
        $pdo->prepare("INSERT INTO call_packages (name, description, price, duration, duration_hours, max_uses, sort_order, status) VALUES (?,?,?,?,?,?,?,?)")
            ->execute([$name, $desc, $price, $duration, $dur_h, $max_uses, $sort, $status]);
    }
    header("Location: " . BASE_URL . "?page=admin_keys&tab=settings&success=1"); exit;
}

// Xử lý Xóa Gói giá
if (isset($_GET['delete_pkg'])) {
    $pdo->prepare("DELETE FROM call_packages WHERE id = ?")->execute([$_GET['delete_pkg']]);
    header("Location: " . BASE_URL . "?page=admin_keys&tab=settings&success=deleted"); exit;
}


// Xử lý Xóa Key
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM call_keys WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: " . BASE_URL . "?page=admin_keys&success=deleted"); exit;
}

// Xử lý Thêm/Sửa Key
if (isset($_POST['save_key'])) {
    $id = $_POST['id'] ?? null;
    $key_code = $_POST['key_code'];
    $status = $_POST['status'];
    $duration = intval($_POST['duration'] ?? 0);
    $max_uses = intval($_POST['max_uses'] ?? 0);
    $restricted_username = trim($_POST['restricted_to'] ?? '');
    $restricted_id = null;

    if ($restricted_username) {
        $stmt_u = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt_u->execute([$restricted_username]);
        $restricted_id = $stmt_u->fetchColumn() ?: null;
    }
    
    if ($id) {
        $pdo->prepare("UPDATE call_keys SET key_code = ?, status = ?, duration = ?, max_uses = ?, restricted_user_id = ? WHERE id = ?")
            ->execute([$key_code, $status, $duration, $max_uses, $restricted_id, $id]);
    } else {
        $pdo->prepare("INSERT INTO call_keys (key_code, status, duration, max_uses, restricted_user_id) VALUES (?, ?, ?, ?, ?)")
            ->execute([$key_code, $status, $duration, $max_uses, $restricted_id]);
    }
    header("Location: " . BASE_URL . "?page=admin_keys&success=1"); exit;
}

// Lấy danh sách Key kèm thông tin User
$stmt = $pdo->query("
    SELECT k.*, 
           u.username as owner_name, 
           u2.username as user_name,
           u3.username as restricted_name 
    FROM call_keys k
    LEFT JOIN users u ON k.user_id = u.id
    LEFT JOIN users u2 ON k.used_by = u2.id
    LEFT JOIN users u3 ON k.restricted_user_id = u3.id
    ORDER BY k.id DESC
");
$keys = $stmt->fetchAll();
?>

<div class="card-modern border-0 shadow-sm overflow-hidden">
    <div class="bg-indigo p-4">
        <div class="d-flex justify-content-between align-items-center">
            <h4 class="text-white fw-bold m-0"><i class="fa fa-key me-2"></i> QUẢN LÝ KEY SPAM CALL</h4>
            <div class="btn-group p-1 bg-white bg-opacity-25 rounded-pill">
                <a href="?page=admin_keys&tab=list" class="btn btn-sm px-4 rounded-pill <?= $current_tab == 'list' ? 'bg-white text-indigo shadow-sm' : 'text-white' ?>">Danh sách Key</a>
                <a href="?page=admin_keys&tab=settings" class="btn btn-sm px-4 rounded-pill <?= $current_tab == 'settings' ? 'bg-white text-indigo shadow-sm' : 'text-white' ?>">Cấu hình giá</a>
            </div>
        </div>
    </div>

    <div class="p-4">
        <?php if(isset($_GET['success'])): ?>
            <div class="alert alert-success border-0 shadow-sm rounded-4 mb-4 py-3 d-flex align-items-center">
                <i class="fa fa-check-circle fs-4 me-3"></i>
                <div class="fw-bold">Thao tác thành công!</div>
            </div>
        <?php endif; ?>

        <?php if($current_tab == 'list'): ?>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="fw-bold m-0 text-indigo">Tất cả mã Key</h5>
                <button class="btn btn-indigo btn-sm px-4 rounded-pill shadow-indigo" data-bs-toggle="modal" data-bs-target="#keyModal" onclick="resetKeyForm()">
                    Tạo Key mới <i class="fa fa-plus ms-1"></i>
                </button>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle border-0">
                    <thead class="bg-lightest text-muted x-small text-uppercase">
                        <tr>
                            <th class="ps-3 border-0">ID</th>
                            <th class="border-0">Mã Key</th>
                            <th class="border-0">Thông số</th>
                            <th class="border-0">Trạng thái</th>
                            <th class="border-0">Người mua / Dùng</th>
                            <th class="border-0">Ngày tạo</th>
                            <th class="text-end pe-3 border-0">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($keys as $k): ?>
                        <tr class="border-bottom border-light">
                            <td class="ps-3 small text-muted">#<?= $k['id'] ?></td>
                            <td><code class="fw-bold text-indigo fs-6 bg-indigo bg-opacity-10 px-2 py-1 rounded"><?= $k['key_code'] ?></code></td>
                            <td>
                                <?php 
                                    $dur = intval($k['duration'] ?? 0);
                                    $uses = intval($k['max_uses'] ?? 0);
                                ?>
                                <div class="small fw-medium"><i class="fa fa-clock me-1 text-muted opacity-50"></i> <?= $dur == 9999 ? '<span class="text-warning">Vĩnh viễn</span>' : ($dur > 0 ? $dur . ' ngày' : '<span class="text-muted">N/A</span>') ?></div>
                                <div class="x-small text-muted"><i class="fa fa-bolt me-1 opacity-50"></i> <?= $uses > 0 ? $uses . ' lượt' : 'Không giới hạn' ?></div>
                                <?php if($k['restricted_name']): ?>
                                    <div class="x-small text-danger fw-bold mt-1"><i class="fa fa-user-lock me-1"></i> <?= $k['restricted_name'] ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($k['status'] == 'unused'): ?>
                                    <span class="badge bg-success bg-opacity-10 text-success px-3 py-1 rounded-pill">Chưa dùng</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary bg-opacity-10 text-muted px-3 py-1 rounded-pill">Đã dùng</span>
                                <?php endif; ?>
                            </td>
                            <td class="small">
                                <div class="fw-bold"><?= $k['owner_name'] ?? '<span class="text-muted opacity-50 italic">Admin</span>' ?></div>
                                <div class="text-muted x-small"><?= $k['user_name'] ? '<i class="fa fa-arrow-right me-1 opacity-50"></i>' . $k['user_name'] : '---' ?></div>
                            </td>
                            <td class="x-small text-muted"><?= date('d/m/Y H:i', strtotime($k['created_at'])) ?></td>
                            <td class="text-end pe-3">
                                <div class="btn-group shadow-sm rounded-3 overflow-hidden">
                                    <button class="btn btn-sm btn-white border-0 py-1 px-3" onclick='editKey(<?= htmlspecialchars(json_encode($k), ENT_QUOTES) ?>)' data-bs-toggle="modal" data-bs-target="#keyModal">
                                        <i class="fa fa-edit text-primary"></i>
                                    </button>
                                    <button class="btn btn-sm btn-white border-0 py-1 px-3 text-danger" onclick="confirmDelete(<?= $k['id'] ?>)">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($keys)): ?>
                            <tr><td colspan="7" class="text-center py-5 text-muted small">Chưa có mã Key nào trong hệ thống.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <!-- Tab Cấu hình giá -->
            <?php
                $call_pkgs = $pdo->query("SELECT * FROM call_packages ORDER BY sort_order, price ASC")->fetchAll();
            ?>
            <div class="py-3">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h5 class="fw-bold m-0 text-indigo"><i class="fa fa-tags me-2"></i> Thiết lập giá bán tự động</h5>
                        <p class="text-muted small mb-0 mt-1">Các gói giá này hiển thị ở trang mua Key của người dùng.</p>
                    </div>
                    <button class="btn btn-indigo btn-sm px-4 rounded-pill shadow-indigo" data-bs-toggle="modal" data-bs-target="#pkgPriceModal" onclick="resetPkgPriceForm()">
                        <i class="fa fa-plus me-1"></i> Thêm gói mới
                    </button>
                </div>

                <?php if(empty($call_pkgs)): ?>
                    <div class="text-center py-5 text-muted">
                        <i class="fa fa-box-open fa-3x mb-3 opacity-25"></i>
                        <p>Chưa có gói giá nào. Bấm "Thêm gói mới" để bắt đầu.</p>
                    </div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle border-0">
                        <thead class="bg-lightest text-muted x-small text-uppercase">
                            <tr>
                                <th class="ps-3 border-0">Tên gói</th>
                                <th class="border-0">Giá</th>
                                <th class="border-0">Thời hạn</th>
                                <th class="border-0">Lượt dùng</th>
                                <th class="border-0">Thứ tự</th>
                                <th class="border-0">Trạng thái</th>
                                <th class="text-end pe-3 border-0">Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach($call_pkgs as $cp): ?>
                            <tr class="border-bottom border-light">
                                <td class="ps-3">
                                    <div class="fw-bold text-dark"><?= htmlspecialchars($cp['name']) ?></div>
                                    <div class="x-small text-muted"><?= htmlspecialchars($cp['description']) ?></div>
                                </td>
                                <td class="fw-bold text-success"><?= number_format($cp['price']) ?>đ</td>
                                <td class="small">
                                    <?php
                                        if ($cp['duration'] == 9999) echo '<span class="badge bg-warning text-dark">Vĩnh viễn</span>';
                                        elseif ($cp['duration'] > 0) echo $cp['duration'] . ' ngày';
                                        elseif ($cp['duration_hours'] > 0) echo $cp['duration_hours'] . ' giờ';
                                        else echo '<span class="text-muted">—</span>';
                                    ?>
                                </td>
                                <td class="small text-muted"><?= $cp['max_uses'] > 0 ? number_format($cp['max_uses']) . ' lượt' : 'Không giới hạn' ?></td>
                                <td class="small text-muted"><?= $cp['sort_order'] ?></td>
                                <td>
                                    <?php if($cp['status'] == 'on'): ?>
                                        <span class="badge bg-success bg-opacity-10 text-success rounded-pill px-3">Hiển thị</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary bg-opacity-10 text-muted rounded-pill px-3">Ẩn</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end pe-3">
                                    <div class="btn-group shadow-sm rounded-3 overflow-hidden">
                                        <button class="btn btn-sm btn-white border-0 py-1 px-3"
                                            onclick='editPkgPrice(<?= htmlspecialchars(json_encode($cp), ENT_QUOTES) ?>)'
                                            data-bs-toggle="modal" data-bs-target="#pkgPriceModal">
                                            <i class="fa fa-edit text-primary"></i>
                                        </button>
                                        <button class="btn btn-sm btn-white border-0 py-1 px-3 text-danger"
                                            onclick="confirmDeletePkg(<?= $cp['id'] ?>, '<?= htmlspecialchars($cp['name'], ENT_QUOTES) ?>')">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        <?php endif; // end if($current_tab == 'list') ?>

    </div>
</div>

<!-- Modal Thêm/Sửa Gói Giá -->
<div class="modal fade" id="pkgPriceModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content border-0 shadow-lg rounded-4 overflow-hidden" method="POST">
            <div class="modal-header bg-indigo text-white border-0 py-3">
                <h5 class="modal-title fw-bold" id="pkgPriceModalLabel">Thêm gói giá</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <input type="hidden" name="pkg_id" id="pp_id">
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted text-uppercase">Tên gói</label>
                    <input type="text" name="name" id="pp_name" class="form-control bg-light border-0 py-2" placeholder="VD: Gói 3 Ngày" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted text-uppercase">Mô tả ngắn</label>
                    <input type="text" name="description" id="pp_desc" class="form-control bg-light border-0 py-2" placeholder="VD: Dùng thử 3 ngày">
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-6">
                        <label class="form-label small fw-bold text-muted text-uppercase">Giá (đồng)</label>
                        <input type="number" name="price" id="pp_price" class="form-control bg-light border-0 py-2" placeholder="50000" required>
                    </div>
                    <div class="col-3">
                        <label class="form-label small fw-bold text-muted text-uppercase">Số ngày</label>
                        <input type="number" name="duration" id="pp_duration" class="form-control bg-light border-0 py-2" value="0">
                        <div class="x-small text-muted mt-1">9999 = Vĩnh viễn</div>
                    </div>
                    <div class="col-3">
                        <label class="form-label small fw-bold text-muted text-uppercase">Số giờ</label>
                        <input type="number" name="duration_hours" id="pp_hours" class="form-control bg-light border-0 py-2" value="0">
                        <div class="x-small text-muted mt-1">Khi ngày = 0</div>
                    </div>
                </div>
                <div class="row g-2 mb-3">
                    <div class="col-6">
                        <label class="form-label small fw-bold text-muted text-uppercase">Lượt dùng tối đa</label>
                        <input type="number" name="max_uses" id="pp_max_uses" class="form-control bg-light border-0 py-2" value="0">
                        <div class="x-small text-muted mt-1">0 = Không giới hạn</div>
                    </div>
                    <div class="col-3">
                        <label class="form-label small fw-bold text-muted text-uppercase">Thứ tự</label>
                        <input type="number" name="sort_order" id="pp_sort" class="form-control bg-light border-0 py-2" value="0">
                    </div>
                    <div class="col-3">
                        <label class="form-label small fw-bold text-muted text-uppercase">Trạng thái</label>
                        <select name="status" id="pp_status" class="form-select bg-light border-0 py-2">
                            <option value="on">Hiện</option>
                            <option value="off">Ẩn</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-0 p-4 pt-0">
                <button type="submit" name="save_package" class="btn btn-indigo w-100 py-2 rounded-4 fw-bold shadow-indigo">LƯU GÓI</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Xác nhận Xóa Gói Giá -->
<div class="modal fade" id="deletePkgModal" tabindex="-1">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-body p-4 text-center">
                <div class="bg-danger bg-opacity-10 text-danger d-inline-block p-3 rounded-circle mb-3">
                    <i class="fa fa-trash-alt fa-2x"></i>
                </div>
                <h5 class="fw-bold">Xóa gói giá?</h5>
                <p class="text-muted small" id="deletePkgName"></p>
                <div class="d-flex gap-2 mt-4">
                    <button type="button" class="btn btn-light w-100 py-2 rounded-3 fw-bold" data-bs-dismiss="modal">Hủy</button>
                    <a href="" id="confirmDeletePkgBtn" class="btn btn-danger w-100 py-2 rounded-3 fw-bold">Xóa ngay</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Thêm/Sửa Key -->
<div class="modal fade" id="keyModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <form class="modal-content border-0 shadow-lg rounded-4 overflow-hidden" method="POST">
            <div class="modal-header bg-indigo text-white border-0 py-3">
                <h5 class="modal-title fw-bold" id="keyModalLabel">Cấu hình Key Call</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <input type="hidden" name="id" id="key_id">
                <div class="mb-4">
                    <label class="form-label small fw-bold text-muted text-uppercase">Mã kích hoạt</label>
                    <div class="input-group shadow-sm rounded-3 overflow-hidden">
                        <input type="text" name="key_code" id="key_code" class="form-control border-0 bg-light py-3 fw-bold text-indigo" required style="letter-spacing: 1px;">
                        <button class="btn btn-light border-0 px-3" type="button" onclick="generateRandomKey()" title="Random mã"><i class="fa fa-random"></i></button>
                    </div>
                </div>
                <div class="row g-3 mb-4">
                    <div class="col-6">
                        <label class="form-label small fw-bold text-muted text-uppercase">Thời hạn (Ngày)</label>
                        <input type="number" name="duration" id="key_duration" class="form-control bg-light border-0 py-3" value="30" placeholder="9999 = Vĩnh viễn">
                    </div>
                    <div class="col-6">
                        <label class="form-label small fw-bold text-muted text-uppercase">Số lượt dùng</label>
                        <input type="number" name="max_uses" id="key_max_uses" class="form-control bg-light border-0 py-3" value="0" placeholder="0 = Không giới hạn">
                    </div>
                </div>
                <div class="mb-4">
                    <label class="form-label small fw-bold text-muted text-uppercase">Khóa cho Username</label>
                    <input type="text" name="restricted_to" id="key_restricted_to" class="form-control bg-light border-0 py-3" placeholder="Để trống nếu ai cũng dùng được">
                </div>
                <div class="mb-0">
                    <label class="form-label small fw-bold text-muted text-uppercase">Trạng thái mã</label>
                    <select name="status" id="key_status" class="form-select bg-light border-0 py-3">
                        <option value="unused">Chưa sử dụng</option>
                        <option value="used">Đã sử dụng</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer border-0 p-4 pt-0">
                <button type="submit" name="save_key" class="btn btn-indigo w-100 py-3 rounded-4 fw-bold shadow-indigo text-uppercase">Lưu thông tin Key</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Xác nhận Xóa -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-body p-4 text-center">
                <div class="bg-danger bg-opacity-10 text-danger d-inline-block p-3 rounded-circle mb-3">
                    <i class="fa fa-trash-alt fa-2x"></i>
                </div>
                <h5 class="fw-bold">Xác nhận xóa?</h5>
                <p class="text-muted small">Hành động này không thể hoàn tác. Bạn có chắc chắn muốn xóa mã Key này?</p>
                <div class="d-flex gap-2 mt-4">
                    <button type="button" class="btn btn-light w-100 py-2 rounded-3 fw-bold" data-bs-dismiss="modal">Hủy</button>
                    <a href="" id="confirmDeleteBtn" class="btn btn-danger w-100 py-2 rounded-3 fw-bold">Xóa ngay</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function resetKeyForm() {
    document.getElementById('keyModalLabel').innerText = 'Tạo Key mới';
    document.getElementById('key_id').value = '';
    document.getElementById('key_code').value = '';
    document.getElementById('key_duration').value = '30';
    document.getElementById('key_max_uses').value = '500';
    document.getElementById('key_restricted_to').value = '';
    document.getElementById('key_status').value = 'unused';
    generateRandomKey();
}

function editKey(data) {
    document.getElementById('keyModalLabel').innerText = 'Chỉnh sửa Key #' + data.id;
    document.getElementById('key_id').value = data.id;
    document.getElementById('key_code').value = data.key_code;
    document.getElementById('key_duration').value = data.duration;
    document.getElementById('key_max_uses').value = data.max_uses;
    document.getElementById('key_restricted_to').value = data.restricted_name || '';
    document.getElementById('key_status').value = data.status;
}

function generateRandomKey() {
    const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let result = 'CALL-';
    for (let i = 0; i < 10; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    document.getElementById('key_code').value = result;
}

function confirmDelete(id) {
    document.getElementById('confirmDeleteBtn').href = '<?= BASE_URL ?>?page=admin_keys&delete=' + id;
    const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
    modal.show();
}

// === Gói Giá ===
function resetPkgPriceForm() {
    document.getElementById('pkgPriceModalLabel').innerText = 'Thêm gói giá mới';
    document.getElementById('pp_id').value = '';
    document.getElementById('pp_name').value = '';
    document.getElementById('pp_desc').value = '';
    document.getElementById('pp_price').value = '';
    document.getElementById('pp_duration').value = '0';
    document.getElementById('pp_hours').value = '0';
    document.getElementById('pp_max_uses').value = '0';
    document.getElementById('pp_sort').value = '0';
    document.getElementById('pp_status').value = 'on';
}

function editPkgPrice(pkg) {
    document.getElementById('pkgPriceModalLabel').innerText = 'Sửa: ' + pkg.name;
    document.getElementById('pp_id').value = pkg.id;
    document.getElementById('pp_name').value = pkg.name;
    document.getElementById('pp_desc').value = pkg.description || '';
    document.getElementById('pp_price').value = pkg.price;
    document.getElementById('pp_duration').value = pkg.duration;
    document.getElementById('pp_hours').value = pkg.duration_hours;
    document.getElementById('pp_max_uses').value = pkg.max_uses;
    document.getElementById('pp_sort').value = pkg.sort_order;
    document.getElementById('pp_status').value = pkg.status;
}

function confirmDeletePkg(id, name) {
    document.getElementById('deletePkgName').innerText = 'Bạn có chắc muốn xóa gói "' + name + '"? Hành động này không thể hoàn tác.';
    document.getElementById('confirmDeletePkgBtn').href = '<?= BASE_URL ?>?page=admin_keys&tab=settings&delete_pkg=' + id;
    const modal = new bootstrap.Modal(document.getElementById('deletePkgModal'));
    modal.show();
}
</script>

<style>
.bg-lightest { background-color: #f8f9fa; }
.shadow-indigo { box-shadow: 0 10px 15px -3px rgba(79, 70, 229, 0.2); }
.border-light { border-color: rgba(0,0,0,0.05) !important; }
.btn-white { background: white; color: #666; }
.btn-white:hover { background: #f8f9fa; color: #333; }
</style>
