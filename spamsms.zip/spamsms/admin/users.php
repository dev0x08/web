<?php
// Xử lý nạp tiền & Hành động (Chuyển lên đầu để tránh lỗi Headers already sent)
if (isset($_POST['add_balance'])) {
    $uid = $_POST['user_id'];
    $amt = intval($_POST['amount']);
    $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$amt, $uid]);
    $pdo->prepare("INSERT INTO logs (user_id, target, status) VALUES (?, 'NẠP', 'Admin cộng +".number_format($amt)."đ')")->execute([$uid]);
    header("Location: " . BASE_URL . "?page=admin_users&msg=topup_success&amt=$amt"); exit;
}

if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    switch($_GET['action']) {
        case 'block': 
            if ($id != 1) {
                $pdo->prepare("UPDATE users SET status = 'locked' WHERE id = ?")->execute([$id]); 
                $pdo->prepare("INSERT INTO logs (user_id, target, status) VALUES (?, 'ADMIN', 'Khóa tài khoản')")->execute([$id]);
            }
            break;
        case 'unblock': 
            $pdo->prepare("UPDATE users SET status = 'active' WHERE id = ?")->execute([$id]); 
            $pdo->prepare("INSERT INTO logs (user_id, target, status) VALUES (?, 'ADMIN', 'Mở khóa tài khoản')")->execute([$id]);
            break;
        case 'set_admin': 
            $pdo->prepare("UPDATE users SET role = 'admin' WHERE id = ?")->execute([$id]); 
            $pdo->prepare("INSERT INTO logs (user_id, target, status) VALUES (?, 'ADMIN', 'Nâng quyền Admin')")->execute([$id]);
            break;
        case 'set_user': 
            if ($id != 1) {
                $pdo->prepare("UPDATE users SET role = 'user' WHERE id = ?")->execute([$id]); 
                $pdo->prepare("INSERT INTO logs (user_id, target, status) VALUES (?, 'ADMIN', 'Hạ quyền User')")->execute([$id]);
            }
            break;

    }
    header("Location: " . BASE_URL . "?page=admin_users"); exit;
}

if (isset($_POST['update_vip'])) {
    $id = $_POST['user_id'];
    $action = $_POST['vip_action']; // 'add' or 'remove'
    
    $stmt = $pdo->prepare("SELECT username, is_vip, vip_expiry FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $user_data = $stmt->fetch();
    
    if ($user_data) {
        if ($action == 'add') {
            $days = intval($_POST['vip_days'] ?? 0);
            if ($days > 0) {
                // If already VIP, add to current expiry. If not, from current time.
                if ($user_data['is_vip'] && strtotime($user_data['vip_expiry']) > time()) {
                    $new_expiry = date('Y-m-d H:i:s', strtotime($user_data['vip_expiry']) + ($days * 86400));
                } else {
                    $new_expiry = date('Y-m-d H:i:s', time() + ($days * 86400));
                }
                
                $pdo->prepare("UPDATE users SET is_vip = 1, vip_expiry = ?, vip_level = 'normal,vip', cooldown = 60, api_limit = 10 WHERE id = ?")
                    ->execute([$new_expiry, $id]);
                $pdo->prepare("INSERT INTO logs (user_id, target, status) VALUES (?, 'ADMIN', 'Cấp VIP ($days ngày)')")->execute([$id]);
                header("Location: " . BASE_URL . "?page=admin_users&msg=vip_added&days=$days"); exit;
            }
        } elseif ($action == 'remove') {
            $pdo->prepare("UPDATE users SET is_vip = 0, vip_expiry = NULL WHERE id = ?")->execute([$id]);
            $pdo->prepare("INSERT INTO logs (user_id, target, status) VALUES (?, 'ADMIN', 'Hạ/Tháo VIP')")->execute([$id]);
            header("Location: " . BASE_URL . "?page=admin_users&msg=vip_removed"); exit;
        }
    }
    header("Location: " . BASE_URL . "?page=admin_users"); exit;
}

if (isset($_POST['update_spam_stats'])) {
    $id = $_POST['user_id'];
    $daily_hits = intval($_POST['daily_hits']);
    $call_balance = intval($_POST['call_balance']);
    $call_expiry = !empty($_POST['call_expiry']) ? $_POST['call_expiry'] : NULL;
    
    $pdo->prepare("UPDATE users SET daily_hits = ?, call_hits_balance = ?, call_expiry = ? WHERE id = ?")
        ->execute([$daily_hits, $call_balance, $call_expiry, $id]);
    $pdo->prepare("INSERT INTO logs (user_id, target, status) VALUES (?, 'ADMIN', 'Cập nhật thông số Spam SMS/Call')")->execute([$id]);
    header("Location: " . BASE_URL . "?page=admin_users&msg=spam_updated"); exit;
}

if (isset($_POST['block_user'])) {
    $id = $_POST['user_id'];
    if ($id == 1) {
        header("Location: " . BASE_URL . "?page=admin_users&msg=error_id1"); exit;
    }
    $reason = $_POST['ban_reason'] ?? 'Vi phạm điều khoản';
    $pdo->prepare("UPDATE users SET status = 'locked', ban_reason = ? WHERE id = ?")->execute([$reason, $id]);
    $pdo->prepare("INSERT INTO logs (user_id, target, status) VALUES (?, 'ADMIN', 'Khóa: $reason')")->execute([$id]);
    header("Location: " . BASE_URL . "?page=admin_users&msg=blocked"); exit;
}

$search = $_GET['q'] ?? '';
if ($search) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username LIKE ? OR id = ? ORDER BY id DESC");
    $stmt->execute(["%$search%", $search]);
} else {
    $stmt = $pdo->query("SELECT * FROM users ORDER BY id DESC");
}
$users = $stmt->fetchAll();

$msg_text = '';
if (isset($_GET['msg']) && $_GET['msg'] == 'topup_success') {
    $msg_text = '<div class="alert alert-success small mb-4">Đã cộng ' . number_format($_GET['amt']) . 'đ thành công!</div>';
} elseif (isset($_GET['msg']) && $_GET['msg'] == 'blocked') {
    $msg_text = '<div class="alert alert-warning small mb-4">Đã khóa tài khoản thành công!</div>';
} elseif (isset($_GET['msg']) && $_GET['msg'] == 'error_id1') {
    $msg_text = '<div class="alert alert-danger small mb-4">Không thể thao tác trên Admin chính (ID 1)!</div>';
} elseif (isset($_GET['msg']) && $_GET['msg'] == 'vip_added') {
    $msg_text = '<div class="alert alert-success small mb-4">Đã cấp VIP thêm ' . intval($_GET['days']) . ' ngày thành công!</div>';
} elseif (isset($_GET['msg']) && $_GET['msg'] == 'vip_removed') {
    $msg_text = '<div class="alert alert-warning small mb-4">Đã hạ xếp hạng từ VIP xuống người dùng thường!</div>';
} elseif (isset($_GET['msg']) && $_GET['msg'] == 'spam_updated') {
    $msg_text = '<div class="alert alert-success small mb-4">Đã cập nhật thông số Spam SMS/Call!</div>';
}
?>

<div class="card-modern">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="fw-bold m-0">Danh sách người dùng</h5>
        <form class="d-flex" style="max-width: 320px;">
            <input type="hidden" name="page" value="admin_users">
            <div class="input-group input-group-sm">
                <input type="text" name="q" class="form-control" placeholder="Tên user hoặc ID..." value="<?= $search ?>">
                <button class="btn btn-indigo" type="submit"><i class="fa fa-search"></i></button>
            </div>
        </form>
    </div>

    <?= $msg_text ?>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th class="ps-3">ID</th>
                    <th>Thông tin người dùng</th>
                    <th>Spam / Call</th>
                    <th>Số dư</th>
                    <th>Vai trò</th>
                    <th class="text-end pe-3">Thao tác nhanh</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($users as $user): ?>
                <tr>
                    <td class="ps-3 text-muted">#<?= $user['id'] ?></td>
                    <td>
                        <div class="fw-bold"><?= $user['username'] ?></div>
                        <?php if($user['is_vip']): ?>
                            <span class="badge badge-vip x-small">VIP PRO</span>
                            <div class="x-small text-muted mt-1">Hạn: <?= date('d/m/Y', strtotime($user['vip_expiry'])) ?></div>
                        <?php endif; ?>
                        <?php if($user['status'] == 'locked' && $user['ban_reason']): ?>
                            <div class="x-small text-danger mt-1"><strong>Lý do khóa:</strong> <?= $user['ban_reason'] ?></div>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="small mb-1"><i class="fa fa-envelope text-primary me-1"></i> SMS Hôm nay: <strong class="<?= $user['daily_hits'] > 0 ? 'text-danger' : 'text-success' ?>"><?= number_format($user['daily_hits']) ?></strong></div>
                        <div class="small mb-1"><i class="fa fa-phone text-success me-1"></i> Số dư Call: <strong><?= number_format($user['call_hits_balance']) ?></strong></div>
                        <?php if($user['call_expiry']): ?>
                            <div class="x-small text-muted"><i class="fa fa-clock me-1"></i> Hết hạn: <?= date('d/m/Y H:i', strtotime($user['call_expiry'])) ?></div>
                        <?php endif; ?>
                    </td>
                    <td class="fw-bold text-success"><?= number_format($user['balance']) ?>đ</td>
                    <td>
                        <span class="badge <?= $user['role']=='admin'?'bg-danger':'bg-secondary' ?> text-uppercase" style="font-size: 9px;">
                            <?= $user['role'] ?>
                        </span>
                    </td>
                    <td class="text-end pe-3">
                        <div class="d-flex justify-content-end gap-1">
                            <!-- Nạp tiền -->
                            <button class="btn btn-sm btn-light border py-1" onclick="openTopupModal(<?= $user['id'] ?>, '<?= $user['username'] ?>')" title="Cộng tiền">
                                <i class="fa fa-wallet text-indigo"></i>
                            </button>
                            
                            <!-- VIP Management -->
                            <button class="btn btn-sm btn-light border py-1" onclick="openVipModal(<?= $user['id'] ?>, '<?= $user['username'] ?>', <?= $user['is_vip'] ? 1 : 0 ?>)" title="Quản lý VIP">
                                <i class="fa <?= $user['is_vip']?'fa-crown text-warning':'fa-gem text-muted' ?>"></i>
                            </button>

                            <!-- Spam Settings -->
                            <button class="btn btn-sm btn-light border py-1" onclick="openSpamModal(<?= $user['id'] ?>, '<?= $user['username'] ?>', <?= $user['daily_hits'] ?>, <?= $user['call_hits_balance'] ?>, '<?= $user['call_expiry'] ? date('Y-m-d\TH:i', strtotime($user['call_expiry'])) : '' ?>')" title="Cài đặt Spam/Call">
                                <i class="fa fa-sliders-h text-primary"></i>
                            </button>

                            <!-- Lock/Unlock -->
                            <?php if($user['id'] != 1): ?>
                                <?php if($user['status']=='active'): ?>
                                    <button class="btn btn-sm btn-light border py-1" onclick="openLockModal(<?= $user['id'] ?>, '<?= $user['username'] ?>')" title="Khóa tài khoản">
                                        <i class="fa fa-lock text-danger"></i>
                                    </button>
                                <?php else: ?>
                                    <a href="<?= BASE_URL ?>?page=admin_users&action=unblock&id=<?= $user['id'] ?>" class="btn btn-sm btn-light border py-1" title="Mở khóa">
                                        <i class="fa fa-lock-open text-success"></i>
                                    </a>
                                <?php endif; ?>
                            <?php else: ?>
                                <button class="btn btn-sm btn-light border py-1 disabled" title="Không thể khóa Admin chính">
                                    <i class="fa fa-shield text-muted"></i>
                                </button>
                            <?php endif; ?>

                            <!-- Promote/Demote -->
                            <?php if($user['id'] != 1): ?>
                                <?php if($user['role']=='user'): ?>
                                    <button class="btn btn-sm btn-light border py-1" title="Gán Admin"
                                            onclick="openRoleModal(<?= $user['id'] ?>, '<?= $user['username'] ?>', 'admin')">
                                        <i class="fa fa-user-shield text-primary"></i>
                                    </button>
                                <?php else: ?>
                                    <button class="btn btn-sm btn-light border py-1" title="Hạ User"
                                            onclick="openRoleModal(<?= $user['id'] ?>, '<?= $user['username'] ?>', 'user')">
                                        <i class="fa fa-user text-muted"></i>
                                    </button>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Cộng Tiền (Tách biệt để fix lỗi Input) -->
<div class="modal fade" id="topupModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <form class="modal-content border-0 shadow-lg" method="POST" id="topupForm">
            <div class="modal-header border-0 pb-0">
                <h6 class="modal-title fw-bold">Cộng tiền: <span id="topup_username"></span></h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body py-3">
                <input type="hidden" name="user_id" id="topup_user_id">
                <div class="mb-0">
                    <label class="form-label small text-muted fw-semibold">Số tiền muốn cộng (+)</label>
                    <input type="number" name="amount" class="form-control" placeholder="VD: 50000" id="topup_amount" required>
                </div>
            </div>
            <div class="modal-footer border-0 pt-0 gap-2">
                <button type="button" class="btn btn-light btn-sm flex-grow-1 py-2 border" data-bs-dismiss="modal">HỦY</button>
                <button type="submit" name="add_balance" class="btn btn-indigo btn-sm flex-grow-1 py-2 shadow-sm">XÁC NHẬN</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Khóa Tài Khoản -->
<div class="modal fade" id="lockModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <form class="modal-content border-0 shadow-lg" method="POST" action="<?= BASE_URL ?>?page=admin_users">
            <div class="modal-header border-0 pb-0">
                <h6 class="modal-title fw-bold">Khóa: <span id="lock_username"></span></h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body py-3">
                <input type="hidden" name="user_id" id="lock_user_id">
                <div class="mb-0">
                    <label class="form-label small text-muted fw-semibold">Lý do khóa</label>
                    <textarea name="ban_reason" class="form-control" placeholder="VD: Spam quá giới hạn, Vi phạm điều khoản..." required></textarea>
                </div>
            </div>
            <div class="modal-footer border-0 pt-0 gap-2">
                <button type="button" class="btn btn-light btn-sm flex-grow-1 py-2 border" data-bs-dismiss="modal">HỦY</button>
                <button type="submit" name="block_user" class="btn btn-danger btn-sm flex-grow-1 py-2 shadow-sm">KHÓA NGAY</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Quản lý VIP -->
<div class="modal fade" id="vipModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <form class="modal-content border-0 shadow-lg" method="POST" action="<?= BASE_URL ?>?page=admin_users">
            <div class="modal-header border-0 pb-0">
                <h6 class="modal-title fw-bold">Quản lý VIP: <span id="vip_username"></span></h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body py-3">
                <input type="hidden" name="user_id" id="vip_user_id">
                
                <div class="mb-3">
                    <label class="form-label small text-muted fw-semibold">Hành động</label>
                    <select name="vip_action" id="vip_action_select" class="form-select text-sm" onchange="toggleVipDays(this.value)">
                        <option value="add">Nâng VIP / Thêm ngày</option>
                        <option value="remove">Hạ VIP / Tháo VIP</option>
                    </select>
                </div>

                <div class="mb-0" id="vip_days_wrapper">
                    <label class="form-label small text-muted fw-semibold">Số ngày cấp</label>
                    <input type="number" name="vip_days" id="vip_days_input" class="form-control" placeholder="VD: 30" min="1" value="30">
                </div>
            </div>
            <div class="modal-footer border-0 pt-0 gap-2">
                <button type="button" class="btn btn-light btn-sm flex-grow-1 py-2 border" data-bs-dismiss="modal">HỦY</button>
                <button type="submit" name="update_vip" class="btn btn-warning btn-sm flex-grow-1 py-2 shadow-sm fw-bold">CẬP NHẬT VIP</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Quản lý Spam / Call -->
<div class="modal fade" id="spamModal" tabindex="-1">
    <div class="modal-dialog">
        <form class="modal-content border-0 shadow-lg" method="POST" action="<?= BASE_URL ?>?page=admin_users">
            <div class="modal-header border-0 pb-0">
                <h6 class="modal-title fw-bold">Thông số Spam: <span id="spam_username" class="text-primary"></span></h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body py-3">
                <input type="hidden" name="user_id" id="spam_user_id">
                
                <div class="mb-3">
                    <label class="form-label small fw-semibold text-primary"><i class="fa fa-envelope me-1"></i> SMS Spam (Hôm nay)</label>
                    <input type="number" name="daily_hits" id="spam_daily_hits" class="form-control" min="0">
                    <div class="form-text small">Reset về 0 nếu muốn thu hồi giới hạn spam trong ngày của người này.</div>
                </div>

                <div class="row">
                    <div class="col-6 mb-3">
                        <label class="form-label small fw-semibold text-success"><i class="fa fa-phone me-1"></i> Số dư Call</label>
                        <input type="number" name="call_balance" id="spam_call_balance" class="form-control" min="0">
                    </div>
                    <div class="col-6 mb-3">
                        <label class="form-label small fw-semibold text-muted"><i class="fa fa-clock me-1"></i> Gọi Hết Hạn Tới</label>
                        <input type="datetime-local" name="call_expiry" id="spam_call_expiry" class="form-control">
                    </div>
                </div>
            </div>
            <div class="modal-footer border-0 pt-0 gap-2">
                <button type="button" class="btn btn-light px-4 border" data-bs-dismiss="modal">ĐÓNG</button>
                <button type="submit" name="update_spam_stats" class="btn btn-primary px-4 shadow-sm fw-bold">LƯU CÀI ĐẶT CỨNG</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Xác nhận Quyền hạn -->
<div class="modal fade" id="roleModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header border-0 pb-0">
                <h6 class="modal-title fw-bold">Xác nhận thay đổi</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body py-3 text-center">
                <div class="mb-3">
                    <i id="role_icon" class="fa fa-exclamation-triangle fa-3x text-warning"></i>
                </div>
                <p class="mb-0" id="role_message"></p>
                <div class="fw-bold mt-1 text-primary" id="role_target_name"></div>
            </div>
            <div class="modal-footer border-0 pt-0 gap-2">
                <button type="button" class="btn btn-light btn-sm flex-grow-1 py-2 border" data-bs-dismiss="modal">HỦY</button>
                <a id="role_confirm_btn" href="#" class="btn btn-indigo btn-sm flex-grow-1 py-2 shadow-sm">XÁC NHẬN</a>
            </div>
        </div>
    </div>
</div>

<script>
function openTopupModal(id, username) {
    document.getElementById('topup_user_id').value = id;
    document.getElementById('topup_username').innerText = username;
    document.getElementById('topup_amount').value = '';
    
    // Đảm bảo Form Action chính xác
    document.getElementById('topupForm').action = '<?= BASE_URL ?>?page=admin_users';
    
    // Mở modal chuyên nghiệp qua JS
    var myModal = new bootstrap.Modal(document.getElementById('topupModal'));
    myModal.show();
    
    // Auto focus vào input sau khi modal hiện
    setTimeout(() => {
        document.getElementById('topup_amount').focus();
    }, 500);
}

function openLockModal(id, username) {
    document.getElementById('lock_user_id').value = id;
    document.getElementById('lock_username').innerText = username;
    var myModal = new bootstrap.Modal(document.getElementById('lockModal'));
    myModal.show();
}

function openRoleModal(id, username, targetRole) {
    const icon = document.getElementById('role_icon');
    const message = document.getElementById('role_message');
    const targetName = document.getElementById('role_target_name');
    const confirmBtn = document.getElementById('role_confirm_btn');
    
    targetName.innerText = username;
    
    if (targetRole === 'admin') {
        icon.className = 'fa fa-user-shield fa-3x text-primary';
        message.innerText = 'Bạn có chắc chắn muốn nâng cấp người dùng này lên quyền QUẢN TRỊ VIÊN?';
        confirmBtn.href = `<?= BASE_URL ?>?page=admin_users&action=set_admin&id=${id}`;
        confirmBtn.className = 'btn btn-primary btn-sm flex-grow-1 py-2 shadow-sm';
    } else {
        icon.className = 'fa fa-user fa-3x text-muted';
        message.innerText = 'Bạn có chắc chắn muốn hạ quyền người dùng này xuống THÀNH VIÊN thường?';
        confirmBtn.href = `<?= BASE_URL ?>?page=admin_users&action=set_user&id=${id}`;
        confirmBtn.className = 'btn btn-secondary btn-sm flex-grow-1 py-2 shadow-sm';
    }
    
    var myModal = new bootstrap.Modal(document.getElementById('roleModal'));
    myModal.show();
}

function openVipModal(id, username, isVip) {
    document.getElementById('vip_user_id').value = id;
    document.getElementById('vip_username').innerText = username;
    
    // Nếu đang là VIP thì mặc định chọn "Thêm ngày", ngược lại "Nâng VIP"
    const actionSelect = document.getElementById('vip_action_select');
    if (isVip) {
        actionSelect.value = 'add';
    } else {
        actionSelect.value = 'add'; 
    }
    toggleVipDays('add'); // Show input by default
    
    var myModal = new bootstrap.Modal(document.getElementById('vipModal'));
    myModal.show();
}

function toggleVipDays(action) {
    const daysWrapper = document.getElementById('vip_days_wrapper');
    const daysInput = document.getElementById('vip_days_input');
    if (action === 'remove') {
        daysWrapper.style.display = 'none';
        daysInput.removeAttribute('required');
    } else {
        daysWrapper.style.display = 'block';
        daysInput.setAttribute('required', 'required');
    }
}

function openSpamModal(id, username, dailyHits, callBalance, callExpiry) {
    document.getElementById('spam_user_id').value = id;
    document.getElementById('spam_username').innerText = username;
    document.getElementById('spam_daily_hits').value = dailyHits;
    document.getElementById('spam_call_balance').value = callBalance;
    document.getElementById('spam_call_expiry').value = callExpiry;
    
    var myModal = new bootstrap.Modal(document.getElementById('spamModal'));
    myModal.show();
}
</script>
