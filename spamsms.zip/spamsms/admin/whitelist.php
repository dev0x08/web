<?php
// Không cần require các file includes vì index.php đã xử lý
?>

<div class="container-fluid">
    <div class="row">
        <?php require_once 'includes/sidebar.php'; ?>
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Quản lý Whitelist</h1>
            </div>

            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h5 class="card-title">Thêm số điện thoại vào Whitelist (Số không thể spam)</h5>
                    <form id="addWhitelistForm" class="row g-3">
                        <div class="col-md-6">
                            <input type="text" class="form-control" id="phone_number" placeholder="Số điện thoại (ví dụ: 0987654321)" required>
                        </div>
                        <div class="col-md-4">
                            <input type="text" class="form-control" id="reason" placeholder="Lý do (không bắt buộc)">
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100 shadow-sm">Thêm</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Số điện thoại</th>
                            <th>Lý do</th>
                            <th>Ngày thêm</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody id="whitelistTableBody">
                        <!-- Content will be loaded via AJAX -->
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</div>

<!-- Modal Xác nhận Xóa -->
<div class="modal fade" id="deleteConfirmModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header border-0 pb-0">
                <h6 class="modal-title fw-bold">Xác nhận xóa</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body py-3 text-center">
                <div class="mb-3 text-danger">
                    <i class="fa fa-trash-alt fa-3x"></i>
                </div>
                <p class="mb-0">Bạn có chắc chắn muốn xóa số điện thoại này khỏi Whitelist?</p>
                <div class="fw-bold mt-1 text-primary" id="delete_phone_display"></div>
            </div>
            <div class="modal-footer border-0 pt-0 gap-2">
                <button type="button" class="btn btn-light btn-sm flex-grow-1 py-2 border" data-bs-dismiss="modal">HỦY</button>
                <button type="button" id="confirm_delete_btn" class="btn btn-danger btn-sm flex-grow-1 py-2 shadow-sm">XÓA NGAY</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal Thông báo Trạng thái -->
<div class="modal fade" id="statusModal" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-body py-4 text-center">
                <div class="mb-3" id="status_icon_container">
                    <i id="status_icon" class="fa fa-check-circle fa-3x"></i>
                </div>
                <h6 class="fw-bold" id="status_title">Thông báo</h6>
                <p class="mb-0 text-muted small" id="status_message"></p>
                <div class="mt-4">
                    <button type="button" class="btn btn-indigo btn-sm px-4 py-2 rounded-pill shadow-sm" data-bs-dismiss="modal">ĐÓNG</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let deleteTargetId = null;

document.addEventListener('DOMContentLoaded', function() {
    loadWhitelist();

    document.getElementById('addWhitelistForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const phone = document.getElementById('phone_number').value;
        const reason = document.getElementById('reason').value;

        fetch('ajax/whitelist_action.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=add&phone_number=${phone}&reason=${reason}`
        })
        .then(response => response.json())
        .then(data => {
            if(data.status === 'success') {
                showStatusModal('Thành công', 'Đã thêm số điện thoại vào Whitelist thành công!', 'success');
                document.getElementById('addWhitelistForm').reset();
                loadWhitelist();
            } else {
                showStatusModal('Lỗi', data.message, 'error');
            }
        })
        .catch(err => {
            showStatusModal('Lỗi hệ thống', 'Không thể kết nối với máy chủ.', 'error');
        });
    });

    document.getElementById('confirm_delete_btn').addEventListener('click', function() {
        if (!deleteTargetId) return;
        
        fetch('ajax/whitelist_action.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=delete&id=${deleteTargetId}`
        })
        .then(response => response.json())
        .then(data => {
            const modal = bootstrap.Modal.getInstance(document.getElementById('deleteConfirmModal'));
            modal.hide();
            
            if(data.status === 'success') {
                showStatusModal('Thành công', 'Đã xóa số khỏi danh sách bảo vệ.', 'success');
                loadWhitelist();
            } else {
                showStatusModal('Lỗi', data.message, 'error');
            }
        });
    });
});

function loadWhitelist() {
    fetch('ajax/whitelist_action.php?action=list')
    .then(response => response.json())
    .then(data => {
        const tbody = document.getElementById('whitelistTableBody');
        tbody.innerHTML = '';
        data.forEach(item => {
            tbody.innerHTML += `
                <tr>
                    <td class="small text-muted">${item.id}</td>
                    <td class="fw-bold">${item.phone_number}</td>
                    <td><span class="text-muted small">${item.reason || '-'}</span></td>
                    <td class="small">${item.created_at}</td>
                    <td>
                        <button class="btn btn-sm btn-light border py-1" onclick="openDeleteModal(${item.id}, '${item.phone_number}')" title="Xóa khỏi Whitelist">
                            <i class="fa fa-trash-alt text-danger"></i>
                        </button>
                    </td>
                </tr>
            `;
        });
    });
}

function openDeleteModal(id, phone) {
    deleteTargetId = id;
    document.getElementById('delete_phone_display').innerText = phone;
    var myModal = new bootstrap.Modal(document.getElementById('deleteConfirmModal'));
    myModal.show();
}

function showStatusModal(title, message, type) {
    const icon = document.getElementById('status_icon');
    const titleEl = document.getElementById('status_title');
    const messageEl = document.getElementById('status_message');
    const iconContainer = document.getElementById('status_icon_container');
    
    titleEl.innerText = title;
    messageEl.innerText = message;
    
    if (type === 'success') {
        icon.className = 'fa fa-check-circle fa-3x text-success';
        iconContainer.className = 'mb-3 animate__animated animate__bounceIn';
    } else {
        icon.className = 'fa fa-times-circle fa-3x text-danger';
        iconContainer.className = 'mb-3 animate__animated animate__shakeX';
    }
    
    var myModal = new bootstrap.Modal(document.getElementById('statusModal'));
    myModal.show();
}
</script>

<?php // Footer đã được index.php handle ?>
