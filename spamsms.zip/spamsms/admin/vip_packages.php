<?php
// Xử lý Thêm/Sửa Gói
if (isset($_POST['save_pkg'])) {
    $id = $_POST['id'] ?? null;
    $name = $_POST['name'];
    $price = intval($_POST['price']);
    $days = intval($_POST['days']);
    $cooldown = intval($_POST['cooldown']);
    $api_limit = intval($_POST['api_limit']);
    // Xử lý Checkboxes Level
    $api_levels = isset($_POST['api_levels']) ? implode(',', $_POST['api_levels']) : 'normal';
    $desc = $_POST['description'];

    if ($id) {
        $stmt = $pdo->prepare("UPDATE vip_packages SET name=?, price=?, duration_days=?, cooldown=?, api_limit=?, api_level=?, description=? WHERE id=?");
        $stmt->execute([$name, $price, $days, $cooldown, $api_limit, $api_levels, $desc, $id]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO vip_packages (name, price, duration_days, cooldown, api_limit, api_level, description) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $price, $days, $cooldown, $api_limit, $api_levels, $desc]);
    }
    header("Location: " . BASE_URL . "?page=admin_vip_packages"); exit;
}

if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM vip_packages WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: " . BASE_URL . "?page=admin_vip_packages"); exit;
}

$pkgs = $pdo->query("SELECT * FROM vip_packages ORDER BY price ASC")->fetchAll();
?>

<div class="card-modern">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="fw-bold m-0 text-indigo">Gói cước VIP</h5>
        <button class="btn btn-indigo btn-sm px-3" data-bs-toggle="modal" data-bs-target="#pkgModal" onclick="resetPkgForm()">
            Tạo gói mới <i class="fa fa-plus ms-1"></i>
        </button>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th class="ps-3">Tên gói</th>
                    <th>Giá bán</th>
                    <th>Thời hạn</th>
                    <th>Đặc quyền</th>
                    <th class="text-end pe-3">Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($pkgs as $p): ?>
                <tr>
                    <td class="ps-3"><div class="fw-bold text-indigo"><?= $p['name'] ?></div></td>
                    <td class="fw-bold text-success"><?= number_format($p['price']) ?>đ</td>
                    <td><?= $p['duration_days'] ?> ngày</td>
                    <td>
                        <div class="x-small text-muted mb-1">
                            <?php 
                                $lvls = explode(',', $p['api_level'] ?? 'normal');
                                foreach($lvls as $l):
                            ?>
                                <span class="badge bg-indigo bg-opacity-10 text-indigo text-uppercase me-1" style="font-size: 7px;"><?= $l ?></span>
                            <?php endforeach; ?>
                        </div>
                        <div class="x-small text-muted">
                            <i class="fa fa-clock me-1"></i> Chờ: <b><?= $p['cooldown'] ?>s</b> | 
                            <i class="fa fa-server me-1"></i> Cổng: <b><?= $p['api_limit'] ?></b>
                        </div>
                    </td>
                    <td class="text-end pe-3">
                        <button class="btn btn-sm btn-light border py-1" onclick='editPkg(<?= htmlspecialchars(json_encode($p), ENT_QUOTES) ?>)' data-bs-toggle="modal" data-bs-target="#pkgModal">
                            <i class="fa fa-edit text-primary"></i>
                        </button>
                        <a href="<?= BASE_URL ?>?page=admin_vip_packages&delete=<?= $p['id'] ?>" class="btn btn-sm btn-light border py-1 text-danger" onclick="return confirm('Xóa?')">
                            <i class="fa fa-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="pkgModal" tabindex="-1">
    <div class="modal-dialog modal-md">
        <form class="modal-content border-0 shadow-lg" method="POST">
            <div class="modal-header border-0 pb-0"><h6 class="modal-title fw-bold" id="pkgModalLabel">Cấu hình Gói VIP</h6></div>
            <div class="modal-body py-3">
                <input type="hidden" name="id" id="pkg_id">
                
                <div class="mb-3">
                    <label class="form-label small fw-bold">Tên gói</label>
                    <input type="text" name="name" id="pkg_name" class="form-control" placeholder="VD: GÓI TUẦN VIP" required>
                </div>

                <div class="row g-2">
                    <div class="col-7 mb-3">
                        <label class="form-label small fw-bold">Giá bán</label>
                        <input type="number" name="price" id="pkg_price" class="form-control" required>
                    </div>
                    <div class="col-5 mb-3">
                        <label class="form-label small fw-bold">Ngày sử dụng</label>
                        <input type="number" name="days" id="pkg_days" class="form-control" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-bold d-block">Quyền truy cập API (Levels)</label>
                    <div class="d-flex gap-3 p-2 bg-lightest rounded-3 border">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="api_levels[]" value="normal" id="pkg_lvl_normal">
                            <label class="form-check-label small" for="pkg_lvl_normal">NORMAL</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="api_levels[]" value="vip" id="pkg_lvl_vip">
                            <label class="form-check-label small" for="pkg_lvl_vip">VIP</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="api_levels[]" value="forever" id="pkg_lvl_forever">
                            <label class="form-check-label small" for="pkg_lvl_forever">FOREVER</label>
                        </div>
                    </div>
                </div>

                <div class="row g-2">
                    <div class="col-6 mb-3">
                        <label class="form-label small fw-bold">Cooldown (s)</label>
                        <input type="number" name="cooldown" id="pkg_cooldown" class="form-control" placeholder="60" required>
                    </div>
                    <div class="col-6 mb-3">
                        <label class="form-label small fw-bold">Số cổng (Slots)</label>
                        <input type="number" name="api_limit" id="pkg_api_limit" class="form-control" placeholder="10" required>
                    </div>
                </div>

                <div class="mb-0">
                    <label class="form-label small fw-bold">Mô tả gói</label>
                    <textarea name="description" id="pkg_desc" class="form-control" rows="2"></textarea>
                </div>
            </div>
            <div class="modal-footer border-0">
                <button type="submit" name="save_pkg" class="btn btn-indigo btn-sm w-100 py-2">LƯU CẤU HÌNH</button>
            </div>
        </form>
    </div>
</div>

<script>
function resetPkgForm() {
    document.getElementById('pkgModalLabel').innerText = 'Tạo gói mới';
    document.getElementById('pkg_id').value = '';
    document.getElementById('pkg_name').value = '';
    document.getElementById('pkg_price').value = '';
    document.getElementById('pkg_days').value = '';
    document.getElementById('pkg_cooldown').value = '60';
    document.getElementById('pkg_api_limit').value = '10';
    document.getElementById('pkg_desc').value = '';
    document.querySelectorAll('input[name="api_levels[]"]').forEach(cb => cb.checked = false);
}

function editPkg(p) {
    document.getElementById('pkgModalLabel').innerText = 'Chỉnh sửa: ' + p.name;
    document.getElementById('pkg_id').value = p.id;
    document.getElementById('pkg_name').value = p.name;
    document.getElementById('pkg_price').value = p.price;
    document.getElementById('pkg_days').value = p.duration_days;
    document.getElementById('pkg_cooldown').value = p.cooldown;
    document.getElementById('pkg_api_limit').value = p.api_limit;
    document.getElementById('pkg_desc').value = p.description;

    // Check checkboxes
    const levels = (p.api_level || 'normal').split(',');
    document.querySelectorAll('input[name="api_levels[]"]').forEach(cb => {
        cb.checked = levels.includes(cb.value);
    });
}
</script>
