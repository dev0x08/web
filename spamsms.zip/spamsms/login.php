<?php
require_once 'includes/config.php';

if ($u) { header("Location: " . BASE_URL . "index.php"); exit; }

$error = '';
if (isset($_POST['login'])) {
    $user = $_POST['username'];
    $pass = $_POST['password'];
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$user]);
    $user_data = $stmt->fetch();
    
    if ($user_data && password_verify($pass, $user_data['password'])) {
        if ($user_data['status'] == 'locked') {
            $reason = !empty($user_data['ban_reason']) ? $user_data['ban_reason'] : "Không có lý do cụ thể";
            $error = "Tài khoản của bạn đã bị khóa!<br><small>Lý do: $reason</small>";
        } else {
            $_SESSION['user_id'] = $user_data['id'];
            $pdo->prepare("INSERT INTO logs (user_id, target, status) VALUES (?, 'SYSTEM', 'Đăng nhập thành công')")->execute([$user_data['id']]);
            header("Location: " . BASE_URL . "index.php"); exit;
        }
    } else {
        $error = "Tài khoản hoặc mật khẩu không chính xác!";
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập - <?= $settings['title'] ?? 'Panel' ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
    <?php if(($settings['cloudflare_turnstile'] ?? 'off') == 'on' && !empty($settings['cloudflare_site_key'])): ?>
        <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
    <?php elseif(($settings['google_recaptcha'] ?? 'off') == 'on' && !empty($settings['recaptcha_site_key'])): ?>
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <?php endif; ?>
    <style>
        body { display: flex; align-items: center; justify-content: center; height: 100vh; background-color: #f8fafc; }
        .login-card { width: 100%; max-width: 420px; border-radius: 16px; border: 1px solid #e2e8f0; background: white; padding: 2.5rem; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05); }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="text-center mb-4">
            <div class="d-inline-flex align-items-center justify-content-center bg-primary bg-opacity-10 text-primary rounded-circle mb-3" style="width: 60px; height: 60px;">
                <i class="fa fa-bolt h3 mb-0"></i>
            </div>
            <h3 class="fw-bold">Đăng nhập</h3>
            <p class="text-muted small">Vui lòng nhập thông tin tài khoản của bạn</p>
        </div>
        
        <?php if($error): ?>
            <div class="alert alert-danger p-2 small"><?= $error ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="mb-3">
                <label class="form-label small fw-semibold">Tên tài khoản</label>
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0"><i class="fa fa-user text-muted small"></i></span>
                    <input type="text" name="username" class="form-control border-start-0 ps-0" placeholder="Username" required>
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label small fw-semibold">Mật khẩu</label>
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0"><i class="fa fa-lock text-muted small"></i></span>
                    <input type="password" name="password" class="form-control border-start-0 ps-0" placeholder="••••••••" required>
                </div>
            </div>
            
            <?php if(($settings['cloudflare_turnstile'] ?? 'off') == 'on' && !empty($settings['cloudflare_site_key'])): ?>
                <div class="mb-3 d-flex justify-content-center">
                    <div class="cf-turnstile" data-sitekey="<?= $settings['cloudflare_site_key'] ?>"></div>
                </div>
            <?php elseif(($settings['google_recaptcha'] ?? 'off') == 'on' && !empty($settings['recaptcha_site_key'])): ?>
                <div class="mb-3 d-flex justify-content-center">
                    <div class="g-recaptcha" data-sitekey="<?= $settings['recaptcha_site_key'] ?>"></div>
                </div>
            <?php endif; ?>

            <button type="submit" name="login" class="btn btn-indigo w-100 mb-3 py-2">Đăng nhập ngay</button>
            <div class="text-center small text-muted">
                Chưa có tài khoản? <a href="<?= BASE_URL ?>register.php" class="text-primary text-decoration-none fw-bold">Tham gia ngay</a>
            </div>
        </form>
    </div>
</body>
</html>