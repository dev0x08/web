<?php
require_once '../includes/config.php';

// Đảm bảo trả về JSON
header('Content-Type: application/json');

// Kiểm tra đăng nhập
if (!$u) {
    echo json_encode(['status' => 'error', 'message' => 'Bạn cần đăng nhập!']);
    exit;
}

$action = $_POST['action'] ?? '';
$days = isset($_POST['days']) ? floatval($_POST['days']) : 0; // Chấp nhận cả số thập phân (ví dụ 0.0417 cho 1 giờ)

try {
    if ($action === 'clear_all' || $action === 'clean_logs') {
        // Admin có quyền xóa bất kỳ log nào
        if ($u['role'] === 'admin') {
            if ($action === 'clear_all') {
                $pdo->exec("DELETE FROM logs");
                echo json_encode(['status' => 'success', 'message' => 'Đã xóa TOÀN BỘ nhật ký hệ thống thành công!']);
            } else {
                // Tính toán mốc thời gian bằng PHP để an toàn tuyệt đối
                // $days có thể là 1 (ngày), 30 (ngày) hoặc 0.0417 (1 giờ)
                $seconds = $days * 24 * 60 * 60;
                $cutoff = date('Y-m-d H:i:s', time() - $seconds);
                
                $stmt = $pdo->prepare("DELETE FROM logs WHERE created_at < ?");
                $stmt->execute([$cutoff]);
                $count = $stmt->rowCount();
                
                $label = ($days < 1) ? (round($days * 24) . ' giờ') : ($days . ' ngày');
                if ($days == 180) $label = "6 tháng";
                
                if ($count > 0) {
                    echo json_encode(['status' => 'success', 'message' => "Đã dọn dẹp $count bản ghi cũ hơn $label!"]);
                } else {
                    echo json_encode(['status' => 'success', 'message' => "Không có bản ghi nào cũ hơn $label để xóa."]);
                }
            }
        } 
        // User chỉ có quyền xóa log của mình
        else {
            if ($action === 'clear_all' || ($action === 'clear' || $days === 0)) {
                $stmt = $pdo->prepare("DELETE FROM logs WHERE user_id = ?");
                $stmt->execute([$u['id']]);
                echo json_encode(['status' => 'success', 'message' => 'Đã xóa toàn bộ nhật ký của bạn!']);
            } else {
                $seconds = $days * 24 * 60 * 60;
                $cutoff = date('Y-m-d H:i:s', time() - $seconds);
                
                $stmt = $pdo->prepare("DELETE FROM logs WHERE user_id = ? AND created_at < ?");
                $stmt->execute([$u['id'], $cutoff]);
                $count = $stmt->rowCount();
                
                $label = ($days < 1) ? (round($days * 24) . ' giờ') : ($days . ' ngày');
                
                if ($count > 0) {
                    echo json_encode(['status' => 'success', 'message' => "Đã dọn dẹp $count bản ghi cũ của bạn!"]);
                } else {
                    echo json_encode(['status' => 'success', 'message' => "Bạn không có bản ghi nào cũ hơn $label."]);
                }
            }
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Hành động không hợp lệ!']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Lỗi SQL: ' . $e->getMessage()]);
}
?>
