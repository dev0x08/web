<?php
require_once '../includes/auth.php';

if (!$u) responseJson('error', 'Chưa đăng nhập!');

// Generate Key: CALL- + 10 random Alphanumeric
function generateKey($length = 10) {
    $chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $key = '';
    for ($i = 0; $i < $length; $i++) {
        $key .= $chars[rand(0, strlen($chars) - 1)];
    }
    return 'CALL-' . $key;
}

$new_key = generateKey();

// Lấy gói từ DB theo package_id
$pkg_id = intval($_POST['package_id'] ?? 0);
if (!$pkg_id) responseJson('error', 'Vui lòng chọn một gói hợp lệ!');

$stmt = $pdo->prepare("SELECT * FROM call_packages WHERE id = ? AND status = 'on'");
$stmt->execute([$pkg_id]);
$package = $stmt->fetch();
if (!$package) responseJson('error', 'Gói không tồn tại hoặc đã bị tắt!');

$price    = intval($package['price']);
$duration = intval($package['duration']);
$dur_h    = intval($package['duration_hours']);
$max_uses = intval($package['max_uses']);
$label    = $package['name'];

// Gói 1 giờ: duration=0, duration_hours>0
// Gói vĩnh viễn: duration=9999
// Gói ngày thường: duration>0

if ($u['balance'] < $price) {
    responseJson('error', 'Số dư không đủ! Bạn cần ' . number_format($price) . 'đ để mua gói này.');
}

// Transaction logic
try {
    $pdo->beginTransaction();

    // Trừ tiền
    $pdo->prepare("UPDATE users SET balance = balance - ? WHERE id = ?")
        ->execute([$price, $u['id']]);

    // Tạo Key
    $pdo->prepare("INSERT INTO call_keys (user_id, key_code, duration, max_uses, status) VALUES (?, ?, ?, ?, 'unused')")
        ->execute([$u['id'], $new_key, $duration, $max_uses]);

    // Log giao dịch
    $pdo->prepare("INSERT INTO logs (user_id, target, status) VALUES (?, 'PURCHASE', ?)")
        ->execute([$u['id'], "Mua $label: $new_key (-" . number_format($price) . "đ)"]);

    $pdo->commit();
    responseJson('ok', 'Mua Key thành công!', ['key' => $new_key, 'package_name' => $label]);

} catch (Exception $e) {
    $pdo->rollBack();
    responseJson('error', 'Lỗi hệ thống: ' . $e->getMessage());
}
?>
