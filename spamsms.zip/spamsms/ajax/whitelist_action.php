<?php
require_once '../includes/auth.php';
require_once '../includes/Database.php';

header('Content-Type: application/json');

$pdo = Database::getInstance();
$conn = $pdo; 

$action = $_REQUEST['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'add') {
        $phone = $_POST['phone_number'] ?? '';
        $reason = $_POST['reason'] ?? '';

        if (empty($phone)) {
            echo json_encode(['status' => 'error', 'message' => 'Vui lòng nhập số điện thoại']);
            exit;
        }

        $stmt = $conn->prepare("INSERT INTO whitelist (phone_number, reason) VALUES (?, ?)");
        try {
            $stmt->execute([$phone, $reason]);
            echo json_encode(['status' => 'success']);
        } catch (PDOException $e) {
            echo json_encode(['status' => 'error', 'message' => 'Số điện thoại đã tồn tại trong whitelist hoặc lỗi hệ thống']);
        }
    } elseif ($action === 'delete') {
        $id = $_POST['id'] ?? 0;
        $stmt = $conn->prepare("DELETE FROM whitelist WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(['status' => 'success']);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if ($action === 'list') {
        $stmt = $conn->query("SELECT * FROM whitelist ORDER BY created_at DESC");
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($results);
    }
}
