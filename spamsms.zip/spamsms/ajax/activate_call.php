<?php
require_once '../includes/auth.php';

if (!$u) responseJson('error', 'Chưa đăng nhập!');

$key = trim($_POST['key'] ?? '');

if (!$key) responseJson('error', 'Vui lòng nhập Key!');

$stmt = $pdo->prepare("SELECT * FROM call_keys WHERE key_code = ? AND status = 'unused'");
$stmt->execute([$key]);
$key_data = $stmt->fetch();

if (!$key_data) responseJson('error', 'Mã kích hoạt không tồn tại hoặc đã được sử dụng!');

// Kiểm tra chỉ định User
if (!empty($key_data['restricted_user_id']) && $key_data['restricted_user_id'] != $u['id']) {
    responseJson('error', 'Mã Key này đã được khóa cho một người dùng khác. Bạn không thể sử dụng!');
}

// Tính toán hạn dùng
$new_expiry = null;
if ($key_data['duration'] == 9999) {
    $new_expiry = '2099-12-31 23:59:59';
} elseif ($key_data['duration'] > 0) {
    $current_expiry = ($u['call_expiry'] && strtotime($u['call_expiry']) > time()) ? strtotime($u['call_expiry']) : time();
    $new_expiry = date('Y-m-d H:i:s', $current_expiry + ($key_data['duration'] * 86400));
} elseif (isset($key_data['duration']) && $key_data['duration'] === 0) {
    // Gói 1 giờ
    $current_expiry = ($u['call_expiry'] && strtotime($u['call_expiry']) > time()) ? strtotime($u['call_expiry']) : time();
    $new_expiry = date('Y-m-d H:i:s', $current_expiry + 3600);
}

// Cập nhật key đã dùng
$pdo->prepare("UPDATE call_keys SET status = 'used', used_by = ? WHERE id = ?")
    ->execute([$u['id'], $key_data['id']]);

// Cập nhật User
$sql = "UPDATE users SET call_hits_balance = call_hits_balance + ?";
$params = [$key_data['max_uses']];
if ($new_expiry) {
    $sql .= ", call_expiry = ?";
    $params[] = $new_expiry;
}
$sql .= " WHERE id = ?";
$params[] = $u['id'];

$pdo->prepare($sql)->execute($params);

// Ghi log
$pdo->prepare("INSERT INTO logs (user_id, status, target) VALUES (?, ?, 'AUTH')")
    ->execute([$u['id'], "Kích hoạt Key Call: $key (" . ($key_data['duration'] > 0 ? "Hạn: " . $key_data['duration'] . " ngày" : "") . ($key_data['max_uses'] > 0 ? ", Lượt: " . $key_data['max_uses'] : "") . ")"]);

responseJson('ok', 'Kích hoạt tính năng Bắn Call thành công!');
?>
