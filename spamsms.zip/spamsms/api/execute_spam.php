<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Kiểm tra đăng nhập qua session (file này gọi qua AJAX)
if (!$u) responseJson('error', 'Chưa đăng nhập!');

$phone = trim($_POST['phone'] ?? '');
$api_id = intval($_POST['api_id'] ?? 0);

if (!$phone || !preg_match('/^0[0-9]{9}$/', $phone)) {
    responseJson('error', 'Số điện thoại không hợp lệ!');
}

// Lấy thông tin API
$stmt = $pdo->prepare("SELECT * FROM apis WHERE id = ? AND status = 'on'");
$stmt->execute([$api_id]);
$api = $stmt->fetch();

if (!$api) responseJson('error', 'API không khả dụng!');

// Xử lý nạp dữ liệu vào URL/Body
$finalUrl = str_replace('{{phone}}', $phone, $api['url']);
$finalBody = str_replace('{{phone}}', $phone, $api['body'] ?? '');

$res = sendRequest($finalUrl, $api['method'], $api['headers'], $finalBody);

// Log activity (Only log if successful or important)
$pdo->prepare("INSERT INTO logs (user_id, target, status) VALUES (?, 'SPAM', ?)")
    ->execute([$u['id'], "Bắn SMS qua cổng [{$api['name']}] tới: $phone"]);

responseJson('ok', "Đã gửi qua cổng [{$api['name']}]", ['response' => $res]);
