<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';

if (!$u) responseJson('error', 'Chưa đăng nhập!');

$phone = trim($_POST['phone'] ?? '');

if (!$phone || !preg_match('/^0[0-9]{9}$/', $phone)) {
    responseJson('error', 'Số điện thoại không hợp lệ!');
}

// 1. Get User-specific Privileges (From Users Table)
$cooldown = isset($u['cooldown']) ? intval($u['cooldown']) : 300;
$api_limit = isset($u['api_limit']) ? intval($u['api_limit']) : 1;
$user_levels = explode(',', ($u['vip_level'] ?? 'normal'));

// Admin override
if ($u['role'] == 'admin') {
    $user_levels = ['normal', 'vip', 'forever'];
    $cooldown = 0; 
    $api_limit = 50;
}

// Reset levels if VIP expired
if (!$u['is_vip'] && $u['role'] != 'admin') {
    $user_levels = ['normal'];
}

// 2. Check Cooldown (Server-side)
$now = time();
if ($u['role'] != 'admin' && ($now - ($u['last_spam'] ?? 0)) < $cooldown) {
    $wait = $cooldown - ($now - $u['last_spam']);
    responseJson('error', "Bạn đang trong thời gian chờ (còn $wait giây)!");
}

// 3. Check Daily Limits (For Normal users)
if (!$u['is_vip'] && $u['daily_hits'] >= $settings['max_daily_spam_free']) {
    responseJson('error', "Bạn đã hết lượt miễn phí hôm nay (" . $settings['max_daily_spam_free'] . " lượt). Hãy nâng cấp VIP!");
}

// 4. Update Stats & Log Activity
$type = $_POST['type'] ?? 'sms';
if (!in_array($type, ['sms', 'call'])) $type = 'sms';

$is_forever = ($u['vip_level'] == 'forever' || $u['role'] == 'admin');

if ($type == 'call' && !$is_forever) {
    $has_time = ($u['call_expiry'] && strtotime($u['call_expiry']) > time());
    $has_hits = ($u['call_hits_balance'] > 0);

    if (!$has_time && !$has_hits) {
        responseJson('error', 'Bạn không có quyền sử dụng tính năng Bắn Call hoặc đã hết hạn/lượt dùng. Vui lòng mua thêm Key!');
    }

    // Nếu không có hạn dùng theo thời gian thì mới trừ lượt
    if (!$has_time && $has_hits) {
        $pdo->prepare("UPDATE users SET call_hits_balance = call_hits_balance - 1 WHERE id = ?")
            ->execute([$u['id']]);
    }
}

$pdo->prepare("UPDATE users SET last_spam = ?, daily_hits = daily_hits + 1 WHERE id = ?")
    ->execute([$now, $u['id']]);

$pdo->prepare("INSERT INTO logs (user_id, target, status, type) VALUES (?, 'SPAM', ?, ?)")
    ->execute([$u['id'], "Khởi tạo $type tới: " . $phone, $type]);

// 5. Fetch ALL active APIs of specific type
$stmt = $pdo->prepare("SELECT id, name, level FROM apis WHERE status = 'on' AND type = ? ORDER BY RAND()");
$stmt->execute([$type]);
$all_apis = $stmt->fetchAll();

// Filter APIs by Intersection of Levels
$allowed_apis = [];
foreach ($all_apis as $api) {
    $api_lvls = explode(',', $api['level']);
    // Check if any API level exists in User levels
    if (array_intersect($api_lvls, $user_levels)) {
        $allowed_apis[] = [
            'id' => $api['id'],
            'name' => $api['name']
        ];
    }
}

// Apply API limit
$apis = array_slice($allowed_apis, 0, $api_limit);

if (empty($apis)) {
    responseJson('error', 'Gói của bạn hiện chưa có quyền tiếp cận cổng API nào. Vui lòng liên hệ Admin!');
}

responseJson('ok', 'Khởi tạo thành công', [
    'apis' => $apis,
    'vip_level' => implode(', ', $user_levels),
    'cooldown' => $cooldown,
    'api_limit' => $api_limit,
    'count' => count($apis)
]);
