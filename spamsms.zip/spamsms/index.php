<?php
ob_start();
require_once 'includes/auth.php';

$page = $_GET['page'] ?? 'dashboard';

// Security: Check if user is logged in for protected pages
$public_pages = ['login', 'register'];
if (!in_array($page, $public_pages)) {
    requireLogin();
}

// Router Logic
$page_file = '';
$page_title = '';

switch($page) {
    case 'dashboard':
        $page_file = ($u['role'] == 'admin') ? 'admin/dashboard.php' : 'user/dashboard.php';
        $page_title = 'Bảng điều khiển';
        break;
    case 'spam':
        $page_file = 'user/spam.php'; $page_title = 'Spam SMS/OTP';
        break;
    case 'call':
        $page_file = 'user/call.php'; $page_title = 'Spam Call PRO';
        break;
    case 'vip_store':
        $page_file = 'user/vip_store.php'; $page_title = 'Cửa hàng VIP';
        break;
    case 'topup':
        $page_file = 'user/topup.php'; $page_title = 'Nạp tiền';
        break;
    case 'profile':
        $page_file = 'user/profile.php'; $page_title = 'Hồ sơ cá nhân';
        break;
    case 'logs':
        $page_file = 'user/logs.php'; $page_title = 'Lịch sử hoạt động';
        break;
    case 'buy_key':
        $page_file = 'user/buy_key.php'; $page_title = 'Mua Key Bắn Call';
        break;
        
    // Admin Pages
    case 'admin_dashboard':
        requireAdmin(); $page_file = 'admin/dashboard.php'; $page_title = 'Thống kê';
        break;
    case 'admin_users':
        requireAdmin(); $page_file = 'admin/users.php'; $page_title = 'Quản lý người dùng';
        break;
    case 'admin_apis':
        requireAdmin(); $page_file = 'admin/apis.php'; $page_title = 'Quản lý API';
        break;
    case 'admin_vip_packages':
        requireAdmin(); $page_file = 'admin/vip_packages.php'; $page_title = 'Gói cước VIP';
        break;
    case 'admin_settings':
        requireAdmin(); $page_file = 'admin/settings.php'; $page_title = 'Cài đặt hệ thống';
        break;
    case 'admin_whitelist':
        requireAdmin(); $page_file = 'admin/whitelist.php'; $page_title = 'Whitelist';
        break;
    case 'admin_logs':
        requireAdmin(); $page_file = 'admin/logs.php'; $page_title = 'Nhật ký hệ thống';
        break;
    case 'admin_keys':
        requireAdmin(); $page_file = 'admin/call_keys.php'; $page_title = 'Quản lý Key Call';
        break;
        
    default:
        $page_file = ($u['role'] == 'admin') ? 'admin/dashboard.php' : 'user/dashboard.php';
        $page_title = 'Trang chủ';
        break;
}

include 'includes/header.php';
if (file_exists($page_file)) {
    include $page_file;
} else {
    include '404.php';
}
include 'includes/footer.php';