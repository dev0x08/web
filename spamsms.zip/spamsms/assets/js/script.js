document.addEventListener('DOMContentLoaded', function () {
    // Tooltips initialization
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        }
    });

    // Auto-hide alerts
    setTimeout(() => {
        document.querySelectorAll('.alert').forEach(el => {
            try {
                if (typeof bootstrap !== 'undefined' && bootstrap.Alert) {
                    bootstrap.Alert.getOrCreateInstance(el).close();
                } else {
                    el.style.display = 'none';
                }
            } catch (e) { }
        });
    }, 5000);

    // Mobile Sidebar Toggle Logic (Aggressive Fix)
    const mainSidebar = document.getElementById('mainSidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    const sidebarToggle = document.getElementById('sidebarToggle');

    function openSidebar() {
        if (mainSidebar) {
            mainSidebar.classList.add('open');
            mainSidebar.style.transform = 'translateX(0)'; // Force style
        }
        if (sidebarOverlay) {
            sidebarOverlay.classList.add('active');
            sidebarOverlay.style.display = 'block'; // Force style
        }
        document.body.style.overflow = 'hidden';
    }

    function closeSidebar() {
        if (mainSidebar) {
            mainSidebar.classList.remove('open');
            mainSidebar.style.transform = ''; // Reset to CSS default
        }
        if (sidebarOverlay) {
            sidebarOverlay.classList.remove('active');
            sidebarOverlay.style.display = 'none'; // Force style
        }
        document.body.style.overflow = '';
    }

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            openSidebar();
        });
    }

    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', function (e) {
            e.preventDefault();
            closeSidebar();
        });
    }

    // Close sidebar on Esc key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeSidebar();
    });
});

// Utility: Copy to Clipboard
function copyToClipboard(text) {
    const el = document.createElement('textarea');
    el.value = text;
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
    alert('Đã sao chép: ' + text);
}

// Global AJAX helper
async function apiCall(endpoint, method = 'GET', data = null) {
    const options = {
        method,
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    };
    if (data) {
        options.body = new URLSearchParams(data);
    }
    const response = await fetch(endpoint, options);
    return await response.json();
}
