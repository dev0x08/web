<div class="top-nav">
    <div class="d-flex align-items-center gap-2">
        <button class="btn btn-light d-lg-none" id="sidebarToggle">
            <i class="fa fa-bars"></i>
        </button>
        <h4 class="m-0 fw-bold"><?= strtoupper($page_title ?? 'Dashboard') ?></h4>
    </div>
    <div class="d-none d-xl-block flex-grow-1 px-4">
        <div class="card bg-light border-0 py-1 px-3 mb-0">
            <div class="d-flex justify-content-between align-items-center small text-muted">
                <span>
                    <i class="fa fa-calendar-alt me-1 text-primary"></i>
                    <?php 
                        $days = ["Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"];
                        echo $days[date('w')] . ", " . date('d/m/Y - H:i');
                    ?>
                </span>
                <span>
                    <i class="fa fa-network-wired me-1 text-primary"></i>
                    IP: <span class="text-dark fw-medium"><?= $_SERVER['REMOTE_ADDR'] ?></span>
                </span>
                <span>
                    <i class="fa fa-laptop me-1 text-primary"></i>
                    Browser: <span class="text-dark fw-medium"><?= getBrowser() ?></span>
                </span>
            </div>
        </div>
    </div>
    <div class="d-flex align-items-center gap-3">
        <div class="text-end d-none d-md-block">
            <div class="small text-muted">Số dư hiện tại</div>
            <div class="fw-bold text-success"><?= number_format($u['balance'] ?? 0) ?>đ</div>
        </div>
        <div class="dropdown">
            <button class="btn border-0 p-0 position-relative" data-bs-toggle="dropdown">
                <img src="https://ui-avatars.com/api/?name=<?= $u['username'] ?>&background=4f46e5&color=fff" width="40" height="40" class="rounded-circle border border-2 <?= isVIP() ? 'border-warning' : 'border-indigo' ?>">
                <?php if(isVIP()): ?>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-warning border border-white" style="padding: 3px; margin-left: -5px; margin-top: 5px;">
                        <i class="fa fa-crown text-white" style="font-size: 8px;"></i>
                    </span>
                <?php endif; ?>
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow-sm border mt-2">
                <li><a class="dropdown-item" href="<?= BASE_URL ?>?page=profile"><i class="fa fa-user-circle me-2"></i>Trang cá nhân</a></li>
                <li><a class="dropdown-item" href="<?= BASE_URL ?>?page=topup"><i class="fa fa-wallet me-2"></i>Nạp tiền</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>logout.php"><i class="fa fa-sign-out-alt me-2"></i>Đăng xuất</a></li>
            </ul>
        </div>
    </div>
</div>
