<?php
require_once __DIR__ . '/Database.php';

session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');

$pdo = Database::getInstance();

// Auto-detect BASE_URL for subdirectory hosting
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$host = $_SERVER['HTTP_HOST'];
$script = $_SERVER['SCRIPT_NAME'];
$dir = str_replace('\\', '/', dirname($script));
$base_url = $protocol . "://" . $host . ($dir == '/' ? '' : $dir) . "/";
define('BASE_URL', $base_url);

// Initialize Tables
$pdo->exec("CREATE TABLE IF NOT EXISTS settings (
    name VARCHAR(100) PRIMARY KEY,
    value TEXT
)");

$pdo->exec("CREATE TABLE IF NOT EXISTS call_keys (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL,
    key_code VARCHAR(50) UNIQUE NOT NULL,
    duration INT DEFAULT 0,
    max_uses INT DEFAULT 0,
    status ENUM('unused', 'used') DEFAULT 'unused',
    used_by INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// Đảm bảo bảng call_keys đã tồn tại có đầy đủ cột (cho các bản cập nhật)
try {
    $pdo->exec("ALTER TABLE call_keys ADD COLUMN IF NOT EXISTS duration INT DEFAULT 0");
    $pdo->exec("ALTER TABLE call_keys ADD COLUMN IF NOT EXISTS max_uses INT DEFAULT 0");
    $pdo->exec("ALTER TABLE call_keys ADD COLUMN IF NOT EXISTS restricted_user_id INT DEFAULT NULL");
} catch (Exception $e) {}

$pdo->exec("CREATE TABLE IF NOT EXISTS vip_packages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    price INT DEFAULT 0,
    duration_days INT DEFAULT 0,
    description TEXT
)");

$pdo->exec("CREATE TABLE IF NOT EXISTS call_packages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description VARCHAR(255) DEFAULT '',
    price INT NOT NULL DEFAULT 0,
    duration INT NOT NULL DEFAULT 0,
    duration_hours INT NOT NULL DEFAULT 0,
    max_uses INT NOT NULL DEFAULT 0,
    sort_order INT DEFAULT 0,
    status ENUM('on','off') DEFAULT 'on',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// Cập nhật cấu trúc apis và logs
try {
    $pdo->exec("ALTER TABLE apis ADD COLUMN IF NOT EXISTS type ENUM('sms', 'call') DEFAULT 'sms'");
    $pdo->exec("ALTER TABLE logs ADD COLUMN IF NOT EXISTS type ENUM('sms', 'call') DEFAULT 'sms'");
} catch (Exception $e) {}

// Auto-seed default VIP packages if empty
$count = $pdo->query("SELECT count(*) FROM vip_packages")->fetchColumn();
if ($count == 0) {
    $pdo->exec("INSERT INTO vip_packages (name, price, duration_days, description) VALUES
    ('GÓI NGÀY', 10000, 1, 'Trải nghiệm tính năng VIP trong 24 giờ.'),
    ('GÓI 3 NGÀY', 25000, 3, 'Gói dùng thử ngắn hạn hiệu quả.'),
    ('GÓI TUẦN', 50000, 7, 'Trải nghiệm đầy đủ tính năng trong 1 tuần.\nKhông giới hạn lượt spam.'),
    ('GÓI THÁNG', 150000, 30, 'Tiết kiệm hơn với gói 30 ngày.\nƯu tiên băng thông cao nhất.'),
    ('GÓI VĨNH VIỄN', 500000, 9999, 'Sở hữu quyền năng VIP mãi mãi.\nHỗ trợ kỹ thuật 24/7.')");
}

// Auto-seed default Call Packages if empty
$cp_count = $pdo->query("SELECT COUNT(*) FROM call_packages")->fetchColumn();
if ($cp_count == 0) {
    $p1h  = $settings['price_call_1h']  ?? 5000;
    $p24h = $settings['price_call_24h'] ?? 20000;
    $p7d  = $settings['price_call_7d']  ?? 100000;
    $p30d = $settings['price_call_30d'] ?? 300000;
    $pForever = $settings['call_key_price'] ?? 500000;
    $pdo->prepare("INSERT INTO call_packages (name, description, price, duration, duration_hours, max_uses, sort_order) VALUES
        (?, 'Dùng thử 1 tiếng, max 50 lượt',    ?, 0,    1, 50,    1),
        (?, 'Dùng 1 ngày, max 500 lượt',         ?, 1,    0, 500,   2),
        (?, 'Siêu tiết kiệm, max 3000 lượt',     ?, 7,    0, 3000,  3),
        (?, 'Gói phổ biến, max 10.000 lượt',     ?, 30,   0, 10000, 4),
        (?, 'Mua một lần, dùng mãi mãi',         ?, 9999, 0, 0,     5)")
        ->execute(['Gói 1 Giờ', $p1h, 'Gói 24 Giờ', $p24h, 'Gói 7 Ngày', $p7d, 'Gói 1 Tháng', $p30d, 'Gói Vĩnh Viễn', $pForever]);
}

try {
    $pdo->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS is_vip TINYINT DEFAULT 0");
    $pdo->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS daily_hits INT DEFAULT 0");
    $pdo->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS last_hit_date DATE DEFAULT NULL");
    $pdo->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS vip_expiry DATETIME DEFAULT NULL");
    $pdo->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS call_expiry DATETIME DEFAULT NULL");
    $pdo->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS call_hits_balance INT DEFAULT 0");
    $pdo->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS last_spam INT DEFAULT 0");
    $pdo->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS ban_reason TEXT DEFAULT NULL");
} catch (Exception $e) {}

// Load Settings
$stmt = $pdo->query("SELECT * FROM settings");
$settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

$defaults = [
    'title' => 'WusTeam Panel',
    'cost' => 1000,
    'cooldown' => 60,
    'max_daily_spam_free' => 3,
    'momo_number' => '0987654321',
    'bank_number' => '12345678910',
    'account_name' => 'NGUYEN VAN A',
    'telegram_link' => 'https://t.me/yourname',
    'zalo_link' => 'https://zalo.me/yournumber',
    'discord_link' => 'https://discord.gg/yourlink',
    'cooldown_normal' => 300,
    'cooldown_vip' => 60,
    'api_limit_normal' => 3,
    'api_limit_vip' => 10,
    'api_limit_forever' => 30,
    'call_key_price' => 50000,
    'price_call_1h' => 5000,
    'price_call_24h' => 20000,
    'price_call_7d' => 100000,
    'price_call_30d' => 300000,
    'maintenance_mode' => 'off',
    'cloudflare_turnstile' => 'off',
    'google_recaptcha' => 'off',
    'cloudflare_site_key' => '',
    'cloudflare_secret_key' => '',
    'recaptcha_site_key' => '',
    'recaptcha_secret_key' => ''
];

foreach ($defaults as $k => $v) {
    if (!isset($settings[$k])) {
        $pdo->prepare("INSERT INTO settings (name, value) VALUES (?, ?)")->execute([$k, $v]);
        $settings[$k] = $v;
    }
}

// Global User Object
$u = null;
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $u = $stmt->fetch();

    if (!$u || $u['status'] == 'locked') {
        session_destroy();
        header("Location: " . BASE_URL . "login.php"); exit;
    }

    // VIP Expiry Check
    if ($u['is_vip'] && $u['vip_expiry'] && strtotime($u['vip_expiry']) < time()) {
        $pdo->prepare("UPDATE users SET is_vip = 0 WHERE id = ?")->execute([$u['id']]);
        $u['is_vip'] = 0;
    }

    // Daily Hits Reset
    $today = date('Y-m-d');
    if ($u['last_hit_date'] != $today) {
        $pdo->prepare("UPDATE users SET daily_hits = 0, last_hit_date = ? WHERE id = ?")->execute([$today, $u['id']]);
        $u['daily_hits'] = 0;
        $u['last_hit_date'] = $today;
    }
}

// Maintenance Mode Global Check
if (isset($settings['maintenance_mode']) && $settings['maintenance_mode'] == 'on') {
    // Skip checking on logic routes and admin page
    $current_script = basename($_SERVER['PHP_SELF']);
    $page = $_GET['page'] ?? '';
    $is_admin = ($u && $u['role'] == 'admin');
    
    // Only block if not admin, and not on login page
    if (!$is_admin && $current_script != 'login.php' && mb_strpos($current_script, 'ajax/') === false && mb_strpos($current_script, 'api/') === false) {
        die('<!DOCTYPE html><html lang="vi"><head><meta charset="UTF-8"><title>Hệ thống đang bảo trì</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet"><style>body{font-family:"Inter",sans-serif;height:100vh;display:flex;align-items:center;justify-content:center;background:#f8fafc;}</style></head><body><div class="text-center"><i class="fa fa-tools text-indigo text-primary fa-5x mb-4"></i><h1 class="fw-bold text-dark">Hệ thống đang bảo trì!</h1><p class="text-muted mt-3">Chúng tôi đang nâng cấp hệ thống để mang lại trải nghiệm tốt nhất.<br>Vui lòng quay lại sau ít phút, xin cảm ơn!</p></div></body></html>');
    }
}

function responseJson($status, $msg, $data = []) {
    header('Content-Type: application/json');
    echo json_encode(['status' => $status, 'message' => $msg, 'data' => $data]);
    exit;
}
