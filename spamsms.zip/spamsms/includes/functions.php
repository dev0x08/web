<?php
function sendRequest($url, $method = 'GET', $headers = [], $body = '') {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
    if (is_string($headers)) {
        $headers = json_decode($headers, true) ?: [];
    }

    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if (is_array($body) || is_object($body)) {
            $body = json_encode($body);
        }
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }

    if (!empty($headers)) {
        $curlHeaders = [];
        foreach ($headers as $key => $val) {
            if (is_numeric($key)) {
                $curlHeaders[] = $val;
            } else {
                $curlHeaders[] = $key . ": " . $val;
            }
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $curlHeaders);
    }

    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

function timeAgo($timestamp) {
    if (!$timestamp) return "N/A";
    $time = time() - $timestamp;
    if ($time < 1) return 'vừa xong';
    $tokens = [
        31536000 => 'năm',
        2592000 => 'tháng',
        604800 => 'tuần',
        86400 => 'ngày',
        3600 => 'giờ',
        60 => 'phút',
        1 => 'giây'
    ];
    foreach ($tokens as $unit => $text) {
        if ($time < $unit) continue;
        $numberOfUnits = floor($time / $unit);
        return $numberOfUnits.' '.$text.' trước';
    }
}

function checkVIP($user) {
    if (!$user) return false;
    if ($user['role'] == 'admin') return true;
    return (bool)$user['is_vip'];
}
function getBrowser() {
    $u_agent = $_SERVER['HTTP_USER_AGENT'];
    $bname = 'Unknown';
    $platform = 'Unknown';

    // First get the platform
    if (preg_match('/linux/i', $u_agent)) {
        $platform = 'Linux';
    } elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
        $platform = 'Mac';
    } elseif (preg_match('/windows|win32/i', $u_agent)) {
        $platform = 'Windows';
    }

    // Next get the name of the useragent yes seperately and for good reason
    if(preg_match('/MSIE/i',$u_agent) && !preg_match('/Opera/i',$u_agent)) {
        $bname = 'Internet Explorer';
    } elseif(preg_match('/Firefox/i',$u_agent)) {
        $bname = 'Mozilla Firefox';
    } elseif(preg_match('/Chrome/i',$u_agent)) {
        $bname = 'Google Chrome';
    } elseif(preg_match('/Safari/i',$u_agent)) {
        $bname = 'Apple Safari';
    } elseif(preg_match('/Opera/i',$u_agent)) {
        $bname = 'Opera';
    } elseif(preg_match('/Netscape/i',$u_agent)) {
        $bname = 'Netscape';
    }

    return $bname . " (" . $platform . ")";
}
