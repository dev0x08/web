<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

function requireLogin() {
    global $u;
    if (!$u) {
        header("Location: " . BASE_URL . "login.php"); exit;
    }
}

function requireAdmin() {
    global $u;
    if (!$u || $u['role'] != 'admin') {
        die("Truy cập bị từ chối!");
    }
}

function isVIP() {
    global $u;
    return checkVIP($u);
}
