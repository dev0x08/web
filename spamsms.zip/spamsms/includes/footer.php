</div> <!-- End main-content -->
</div> <!-- End d-flex -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/script.js?v=<?= time() ?>"></script>
</body>
</html>
