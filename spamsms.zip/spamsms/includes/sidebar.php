<div class="sidebar d-flex flex-column" id="mainSidebar">
    <a href="<?= BASE_URL ?>" class="sidebar-brand">
        <i class="fa fa-bolt me-2"></i> 0x08Team
    </a>
    
    <nav class="nav flex-column flex-grow-1 overflow-auto">
        <a href="<?= BASE_URL ?>index.php" class="nav-link <?= !isset($_GET['page']) ? 'active' : '' ?>">
            <i class="fa fa-th-large"></i> Dashboard
        </a>
        <a href="<?= BASE_URL ?>?page=spam" class="nav-link <?= ($_GET['page'] ?? '') == 'spam' ? 'active' : '' ?>">
            <i class="fa fa-paper-plane"></i> Bắn SMS/OTP
        </a>
        <a href="<?= BASE_URL ?>?page=call" class="nav-link <?= ($_GET['page'] ?? '') == 'call' ? 'active' : '' ?>">
            <i class="fa fa-phone"></i> Bắn Call
        </a>
        <a href="<?= BASE_URL ?>?page=vip_store" class="nav-link <?= ($_GET['page'] ?? '') == 'vip_store' ? 'active' : '' ?>">
            <i class="fa fa-gem"></i> Cửa hàng VIP
        </a>
        <a href="<?= BASE_URL ?>?page=buy_key" class="nav-link <?= ($_GET['page'] ?? '') == 'buy_key' ? 'active' : '' ?>">
            <i class="fa fa-key"></i> Mua Key
        </a>
        <a href="<?= BASE_URL ?>?page=logs" class="nav-link <?= ($_GET['page'] ?? '') == 'logs' ? 'active' : '' ?>">
            <i class="fa fa-history"></i> Lịch sử
        </a>

        <?php if($u['role'] == 'admin'): ?>
            <div class="mt-3 mb-1 px-3 small text-uppercase text-muted fw-bold" style="letter-spacing: 1px; font-size: 10px;">Quản trị</div>
            <a href="<?= BASE_URL ?>?page=admin_dashboard" class="nav-link <?= ($_GET['page'] ?? '') == 'admin_dashboard' ? 'active' : '' ?>">
                <i class="fa fa-chart-line"></i> Thống kê hệ thống
            </a>
            <a href="<?= BASE_URL ?>?page=admin_users" class="nav-link <?= ($_GET['page'] ?? '') == 'admin_users' ? 'active' : '' ?>">
                <i class="fa fa-users"></i> Người dùng
            </a>
            <a href="<?= BASE_URL ?>?page=admin_apis" class="nav-link <?= ($_GET['page'] ?? '') == 'admin_apis' ? 'active' : '' ?>">
                <i class="fa fa-server"></i> Cổng API
            </a>
            <a href="<?= BASE_URL ?>?page=admin_vip_packages" class="nav-link <?= ($_GET['page'] ?? '') == 'admin_vip_packages' ? 'active' : '' ?>">
                <i class="fa fa-tags"></i> Gói cước VIP
            </a>
            <a href="<?= BASE_URL ?>?page=admin_keys" class="nav-link <?= ($_GET['page'] ?? '') == 'admin_keys' ? 'active' : '' ?>">
                <i class="fa fa-key"></i> Quản lý Key Call
            </a>
            <a href="<?= BASE_URL ?>?page=admin_whitelist" class="nav-link <?= ($_GET['page'] ?? '') == 'admin_whitelist' ? 'active' : '' ?>">
                <i class="fa fa-shield-alt"></i> Whitelist
            </a>
            <a href="<?= BASE_URL ?>?page=admin_settings" class="nav-link <?= ($_GET['page'] ?? '') == 'admin_settings' ? 'active' : '' ?>">
                <i class="fa fa-cog"></i> Cài đặt
            </a>
            
        <?php endif; ?>
    </nav>
    
    <div class="sidebar-bottom mt-auto">
        <!-- Social Links -->
        <div class="sidebar-footer p-3 border-top bg-lightest bg-opacity-50">
            <div class="d-flex justify-content-center gap-3">
                <?php if(!empty($settings['telegram_link'])): ?>
                    <a href="<?= $settings['telegram_link'] ?>" target="_blank" class="text-muted" title="Telegram"><i class="fab fa-telegram fa-lg"></i></a>
                <?php endif; ?>
                <?php if(!empty($settings['zalo_link'])): ?>
                    <a href="<?= $settings['zalo_link'] ?>" target="_blank" class="text-muted" title="Zalo"><i class="fa fa-comment fa-lg"></i></a>
                <?php endif; ?>
                <?php if(!empty($settings['discord_link'])): ?>
                    <a href="<?= $settings['discord_link'] ?>" target="_blank" class="text-muted" title="Discord"><i class="fab fa-discord fa-lg"></i></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
