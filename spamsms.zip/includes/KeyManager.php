<?php
// includes/KeyManager.php
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/functions.php';

class KeyManager {
    private $db;
    private $keysFile;
    private $logFile;
    
    public function __construct() {
        $this->db = DatabaseConnection::getInstance();
        $this->keysFile = KEYS_FILE;
        $this->logFile = LOG_FILE_KEY;
        $this->migrateKeysToDB();
    }
    
    /**
     * Migrate keys từ JSON sang database
     */
    private function migrateKeysToDB() {
        if (file_exists($this->keysFile) && !file_exists(ROOT_PATH . '.migrated_keys')) {
            $content = file_get_contents($this->keysFile);
            $keys = json_decode($content, true);
            
            if (is_array($keys)) {
                foreach ($keys as $keyData) {
                    if (isset($keyData['key'])) {
                        $this->saveKeyToDB($keyData);
                    }
                }
                file_put_contents(ROOT_PATH . '.migrated_keys', date('Y-m-d H:i:s'));
            }
        }
    }
    
    private function saveKeyToDB($keyData) {
        try {
            // Tìm user admin mặc định
            $admin = $this->db->get('users', ['role', '=', 'admin'])->first();
            $userId = $admin ? $admin->id : null;
            
            $expires = isset($keyData['expiry']) ? $keyData['expiry'] : date('Y-m-d H:i:s', strtotime('+30 days'));
            
            $this->db->insert('api_keys', [
                'user_id' => $userId,
                'api_key' => $keyData['key'],
                'name' => $keyData['note'] ?? 'Imported Key',
                'status' => $keyData['status'] ?? 'active',
                'usage_count' => $keyData['usage'] ?? 0,
                'last_used' => $keyData['last_used'] ?? null,
                'expires_at' => $expires,
                'created_at' => $keyData['created'] ?? date('Y-m-d H:i:s')
            ]);
            
        } catch (Exception $e) {
            $this->log("Error migrating key: " . $e->getMessage());
        }
    }
    
    /**
     * Validate key
     */
    public function validateKey($key) {
        try {
            $keyData = $this->db->get('api_keys', ['api_key', '=', $key])->first();
            
            if ($keyData) {
                if ($keyData->status !== 'active') {
                    return [
                        'status' => 403,
                        'valid' => false,
                        'message' => 'Key đã bị vô hiệu hóa'
                    ];
                }
                
                if ($keyData->expires_at && strtotime($keyData->expires_at) < time()) {
                    return [
                        'status' => 403,
                        'valid' => false,
                        'message' => 'Key đã hết hạn'
                    ];
                }
                
                // Kiểm tra user
                if ($keyData->user_id) {
                    $user = $this->db->get('users', ['id', '=', $keyData->user_id])->first();
                    if (!$user || $user->status !== 'active') {
                        return [
                            'status' => 403,
                            'valid' => false,
                            'message' => 'User không hợp lệ'
                        ];
                    }
                }
                
                // Cập nhật usage
                $this->db->query("UPDATE api_keys SET usage_count = usage_count + 1, last_used = NOW() WHERE id = ?", [$keyData->id]);
                
                return [
                    'status' => 200,
                    'valid' => true,
                    'message' => 'Key hợp lệ',
                    'data' => $keyData
                ];
            }
        } catch (Exception $e) {
            $this->log("DB error: " . $e->getMessage());
        }
        
        // Fallback sang JSON
        return $this->validateKeyFromJSON($key);
    }
    
    private function validateKeyFromJSON($key) {
        if (file_exists($this->keysFile)) {
            $content = file_get_contents($this->keysFile);
            $keys = json_decode($content, true) ?? [];
            
            foreach ($keys as $id => $data) {
                if ($data['key'] === $key) {
                    if ($data['status'] !== 'active') {
                        return [
                            'status' => 403,
                            'valid' => false,
                            'message' => 'Key đã bị vô hiệu hóa'
                        ];
                    }
                    
                    if (isset($data['expiry']) && strtotime($data['expiry']) < time()) {
                        return [
                            'status' => 403,
                            'valid' => false,
                            'message' => 'Key đã hết hạn'
                        ];
                    }
                    
                    return [
                        'status' => 200,
                        'valid' => true,
                        'message' => 'Key hợp lệ',
                        'data' => $data
                    ];
                }
            }
        }
        
        return [
            'status' => 404,
            'valid' => false,
            'message' => 'Key không tồn tại'
        ];
    }
    
    /**
     * Lấy danh sách keys
     */
    public function getKeysList() {
        try {
            $keys = $this->db->query("
                SELECT k.*, u.username as owner 
                FROM api_keys k
                LEFT JOIN users u ON k.user_id = u.id
                ORDER BY k.created_at DESC
            ")->results();
            
            return $keys;
        } catch (Exception $e) {
            $this->log("DB error: " . $e->getMessage());
            return $this->getKeysListFromJSON();
        }
    }
    
    private function getKeysListFromJSON() {
        if (file_exists($this->keysFile)) {
            $content = file_get_contents($this->keysFile);
            $keys = json_decode($content, true) ?? [];
            
            $list = [];
            foreach ($keys as $id => $data) {
                $list[] = (object)[
                    'id' => $id,
                    'api_key' => $data['key'],
                    'name' => $data['note'] ?? '',
                    'status' => $data['status'] ?? 'active',
                    'usage_count' => $data['usage'] ?? 0,
                    'last_used' => $data['last_used'] ?? null,
                    'expires_at' => $data['expiry'] ?? null,
                    'created_at' => $data['created'] ?? null,
                    'owner' => 'JSON Import'
                ];
            }
            return $list;
        }
        
        return [];
    }
    
    /**
     * Lấy key theo ID
     */
    public function getKeyById($id) {
        try {
            return $this->db->get('api_keys', ['id', '=', $id])->first();
        } catch (Exception $e) {
            $this->log("DB error: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Tạo key mới
     */
    public function generateKey($userId = null, $name = '', $days = KEY_EXPIRY_DAYS) {
        $apiKey = strtoupper(bin2hex(random_bytes(16)));
        $expires = date('Y-m-d H:i:s', strtotime("+$days days"));
        
        try {
            $id = $this->db->insert('api_keys', [
                'user_id' => $userId,
                'api_key' => $apiKey,
                'name' => $name ?: 'API Key ' . date('Y-m-d'),
                'expires_at' => $expires
            ]);
            
            if ($id) {
                $this->log("Generated new key: " . substr($apiKey, 0, 10) . "... for user $userId");
                return $apiKey;
            }
            
        } catch (Exception $e) {
            $this->log("DB error: " . $e->getMessage());
        }
        
        // Fallback sang JSON
        return $this->generateKeyJSON($name, $days);
    }
    
    private function generateKeyJSON($note = '', $days = KEY_EXPIRY_DAYS) {
        $newKey = $this->generateRandomKey();
        $id = 'key_' . uniqid();
        
        $keys = [];
        if (file_exists($this->keysFile)) {
            $content = file_get_contents($this->keysFile);
            $keys = json_decode($content, true) ?? [];
        }
        
        $keys[$id] = [
            'key' => $newKey,
            'status' => 'active',
            'created' => date('Y-m-d H:i:s'),
            'expiry' => date('Y-m-d H:i:s', strtotime("+{$days} days")),
            'usage' => 0,
            'last_used' => null,
            'note' => $note ?: 'Generated Key'
        ];
        
        file_put_contents($this->keysFile, json_encode($keys, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        
        return $newKey;
    }
    
    private function generateRandomKey($length = 16) {
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $key = '';
        for ($i = 0; $i < $length; $i++) {
            $key .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $key;
    }
    
    /**
     * Vô hiệu hóa key
     */
    public function disableKey($id) {
        try {
            $this->db->query("UPDATE api_keys SET status = 'inactive' WHERE id = ?", [$id]);
            $this->log("Disabled key ID: $id");
            return true;
        } catch (Exception $e) {
            $this->log("DB error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Kích hoạt key
     */
    public function enableKey($id) {
        try {
            $this->db->query("UPDATE api_keys SET status = 'active' WHERE id = ?", [$id]);
            $this->log("Enabled key ID: $id");
            return true;
        } catch (Exception $e) {
            $this->log("DB error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Xóa key
     */
    public function deleteKey($id) {
        try {
            $this->db->delete('api_keys', ['id', '=', $id]);
            $this->log("Deleted key ID: $id");
            return true;
        } catch (Exception $e) {
            $this->log("DB error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Gia hạn key
     */
    public function renewKey($id, $days = KEY_EXPIRY_DAYS) {
        try {
            $expires = date('Y-m-d H:i:s', strtotime("+$days days"));
            $this->db->query("UPDATE api_keys SET expires_at = ?, status = 'active' WHERE id = ?", [$expires, $id]);
            $this->log("Renewed key ID: $id for $days days");
            return true;
        } catch (Exception $e) {
            $this->log("DB error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Ghi log
     */
    private function log($message) {
        $logEntry = date('[Y-m-d H:i:s]') . " " . get_client_ip() . " - " . $message . PHP_EOL;
        file_put_contents($this->logFile, $logEntry, FILE_APPEND);
    }
}