<?php
// includes/UserManager.php
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/functions.php';

class UserManager {
    private $db;
    private $logFile;
    
    public function __construct() {
        $this->db = DatabaseConnection::getInstance();
        $this->logFile = LOGS_PATH . 'user_manager.log';
    }
    
    /**
     * Xác thực user
     */
    public function authenticate($username, $password) {
        try {
            $user = $this->db->get('users', ['username', '=', $username])->first();
            
            if ($user && password_verify($password, $user->password)) {
                if ($user->status !== 'active') {
                    return ['success' => false, 'message' => 'Tài khoản đã bị khóa'];
                }
                
                // Cập nhật last login
                $this->db->query("UPDATE users SET last_login = NOW() WHERE id = ?", [$user->id]);
                
                // Tạo session token
                $token = bin2hex(random_bytes(32));
                $expires = date('Y-m-d H:i:s', time() + SESSION_LIFETIME);
                $ip = get_client_ip();
                $ua = get_user_agent();
                
                $this->db->insert('user_sessions', [
                    'user_id' => $user->id,
                    'session_token' => $token,
                    'ip_address' => $ip,
                    'user_agent' => $ua,
                    'expires_at' => $expires
                ]);
                
                $this->logActivity($user->id, 'login', 'Đăng nhập thành công từ IP: ' . $ip);
                
                return [
                    'success' => true,
                    'user' => [
                        'id' => $user->id,
                        'username' => $user->username,
                        'email' => $user->email,
                        'full_name' => $user->full_name,
                        'role' => $user->role
                    ],
                    'token' => $token
                ];
            }
            
            $this->logActivity(null, 'login_failed', "Đăng nhập thất bại: $username từ IP: " . get_client_ip());
            return ['success' => false, 'message' => 'Sai tên đăng nhập hoặc mật khẩu'];
            
        } catch (Exception $e) {
            $this->logError($e->getMessage());
            return ['success' => false, 'message' => 'Lỗi hệ thống'];
        }
    }
    
    /**
     * Xác thực token
     */
    public function validateToken($token) {
        try {
            $session = $this->db->get('user_sessions', ['session_token', '=', $token])->first();
            
            if (!$session) {
                return ['valid' => false];
            }
            
            // Kiểm tra hết hạn
            if (strtotime($session->expires_at) < time()) {
                $this->db->delete('user_sessions', ['session_token', '=', $token]);
                return ['valid' => false];
            }
            
            // Lấy thông tin user
            $user = $this->db->get('users', ['id', '=', $session->user_id])->first();
            
            if (!$user || $user->status !== 'active') {
                return ['valid' => false];
            }
            
            return [
                'valid' => true,
                'user_id' => $user->id,
                'username' => $user->username,
                'role' => $user->role,
                'email' => $user->email,
                'full_name' => $user->full_name
            ];
            
        } catch (Exception $e) {
            $this->logError($e->getMessage());
            return ['valid' => false];
        }
    }
    
    /**
     * Đăng xuất
     */
    public function logout($token) {
        try {
            $this->db->delete('user_sessions', ['session_token', '=', $token]);
            return true;
        } catch (Exception $e) {
            $this->logError($e->getMessage());
            return false;
        }
    }
    
    /**
     * Tạo user mới
     */
    public function createUser($data) {
        try {
            // Kiểm tra username đã tồn tại
            $exists = $this->db->get('users', ['username', '=', $data['username']])->first();
            if ($exists) {
                return ['success' => false, 'message' => 'Username đã tồn tại'];
            }
            
            // Kiểm tra email đã tồn tại
            $exists = $this->db->get('users', ['email', '=', $data['email']])->first();
            if ($exists) {
                return ['success' => false, 'message' => 'Email đã tồn tại'];
            }
            
            // Hash password
            $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
            
            $userId = $this->db->insert('users', [
                'username' => $data['username'],
                'password' => $hashedPassword,
                'email' => $data['email'],
                'full_name' => $data['full_name'] ?? '',
                'role' => $data['role'] ?? 'user',
                'status' => 'active'
            ]);
            
            if ($userId) {
                // Tạo API key mặc định
                $this->generateApiKey($userId, 'Default Key');
                
                $this->logActivity($userId, 'user_created', "Tạo user: {$data['username']}");
                
                return ['success' => true, 'user_id' => $userId];
            }
            
            return ['success' => false, 'message' => 'Không thể tạo user'];
            
        } catch (Exception $e) {
            $this->logError($e->getMessage());
            return ['success' => false, 'message' => 'Lỗi tạo user: ' . $e->getMessage()];
        }
    }
    
    /**
     * Tạo API key cho user
     */
    public function generateApiKey($userId, $name = '') {
        try {
            $apiKey = strtoupper(bin2hex(random_bytes(16)));
            $expires = date('Y-m-d H:i:s', strtotime('+' . KEY_EXPIRY_DAYS . ' days'));
            
            $keyId = $this->db->insert('api_keys', [
                'user_id' => $userId,
                'api_key' => $apiKey,
                'name' => $name,
                'expires_at' => $expires
            ]);
            
            if ($keyId) {
                $this->logActivity($userId, 'key_generated', "Tạo API key: $apiKey");
                return $apiKey;
            }
            
            return false;
            
        } catch (Exception $e) {
            $this->logError($e->getMessage());
            return false;
        }
    }
    
    /**
     * Kiểm tra API key
     */
    public function validateApiKey($apiKey) {
        try {
            $key = $this->db->get('api_keys', ['api_key', '=', $apiKey])->first();
            
            if (!$key) {
                return ['valid' => false, 'message' => 'API key không tồn tại'];
            }
            
            if ($key->status !== 'active') {
                return ['valid' => false, 'message' => 'API key đã bị vô hiệu hóa'];
            }
            
            if ($key->expires_at && strtotime($key->expires_at) < time()) {
                return ['valid' => false, 'message' => 'API key đã hết hạn'];
            }
            
            // Kiểm tra user
            $user = $this->db->get('users', ['id', '=', $key->user_id])->first();
            if (!$user || $user->status !== 'active') {
                return ['valid' => false, 'message' => 'User không hợp lệ'];
            }
            
            // Cập nhật usage
            $this->db->query("UPDATE api_keys SET usage_count = usage_count + 1, last_used = NOW() WHERE id = ?", [$key->id]);
            
            return [
                'valid' => true,
                'key_id' => $key->id,
                'user_id' => $key->user_id,
                'username' => $user->username,
                'role' => $user->role,
                'key_name' => $key->name
            ];
            
        } catch (Exception $e) {
            $this->logError($e->getMessage());
            return ['valid' => false, 'message' => 'Lỗi hệ thống'];
        }
    }
    
    /**
     * Ghi log hoạt động
     */
    public function logActivity($userId, $action, $details = '') {
        try {
            $ip = get_client_ip();
            $ua = get_user_agent();
            
            $this->db->insert('activity_logs', [
                'user_id' => $userId,
                'action' => $action,
                'details' => $details,
                'ip_address' => $ip,
                'user_agent' => $ua
            ]);
            
        } catch (Exception $e) {
            $this->logError($e->getMessage());
        }
    }
    
    /**
     * Lấy danh sách users
     */
    public function getUsers($limit = null, $offset = 0) {
        try {
            if ($limit) {
                $users = $this->db->query("SELECT * FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?", [$limit, $offset])->results();
            } else {
                $users = $this->db->query("SELECT * FROM users ORDER BY created_at DESC")->results();
            }
            
            return $users;
        } catch (Exception $e) {
            $this->logError($e->getMessage());
            return [];
        }
    }
    
    /**
     * Lấy thông tin user theo ID
     */
    public function getUserById($id) {
        try {
            return $this->db->get('users', ['id', '=', $id])->first();
        } catch (Exception $e) {
            $this->logError($e->getMessage());
            return null;
        }
    }
    
    /**
     * Cập nhật user
     */
    public function updateUser($id, $data) {
        try {
            $updateData = [];
            
            if (isset($data['email'])) $updateData['email'] = $data['email'];
            if (isset($data['full_name'])) $updateData['full_name'] = $data['full_name'];
            if (isset($data['role'])) $updateData['role'] = $data['role'];
            if (isset($data['status'])) $updateData['status'] = $data['status'];
            
            if (isset($data['password']) && !empty($data['password'])) {
                $updateData['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
            }
            
            if (!empty($updateData)) {
                $this->db->update('users', $id, $updateData);
                $this->logActivity($id, 'user_updated', "Cập nhật thông tin user");
            }
            
            return true;
            
        } catch (Exception $e) {
            $this->logError($e->getMessage());
            return false;
        }
    }
    
    /**
     * Xóa user
     */
    public function deleteUser($id) {
        try {
            $this->db->delete('users', ['id', '=', $id]);
            $this->logActivity($id, 'user_deleted', "Xóa user ID: $id");
            return true;
        } catch (Exception $e) {
            $this->logError($e->getMessage());
            return false;
        }
    }
    
    /**
     * Lấy danh sách API keys
     */
    public function getApiKeys($userId = null) {
        try {
            if ($userId) {
                return $this->db->query("SELECT k.*, u.username FROM api_keys k LEFT JOIN users u ON k.user_id = u.id WHERE k.user_id = ? ORDER BY k.created_at DESC", [$userId])->results();
            } else {
                return $this->db->query("SELECT k.*, u.username FROM api_keys k LEFT JOIN users u ON k.user_id = u.id ORDER BY k.created_at DESC")->results();
            }
        } catch (Exception $e) {
            $this->logError($e->getMessage());
            return [];
        }
    }
    
    /**
     * Vô hiệu hóa API key
     */
    public function disableApiKey($keyId) {
        try {
            $this->db->query("UPDATE api_keys SET status = 'inactive' WHERE id = ?", [$keyId]);
            return true;
        } catch (Exception $e) {
            $this->logError($e->getMessage());
            return false;
        }
    }
    
    /**
     * Kích hoạt API key
     */
    public function enableApiKey($keyId) {
        try {
            $this->db->query("UPDATE api_keys SET status = 'active' WHERE id = ?", [$keyId]);
            return true;
        } catch (Exception $e) {
            $this->logError($e->getMessage());
            return false;
        }
    }
    
    /**
     * Lấy thống kê
     */
    // Trong file includes/UserManager.php, sửa method getStats
public function getStats() {
    try {
        $stats = [];
        
        // Tổng users
        $result = $this->db->query("SELECT COUNT(*) as count FROM users")->first();
        $stats['total_users'] = $result ? $result->count : 0;
        
        // Users active
        $result = $this->db->query("SELECT COUNT(*) as count FROM users WHERE status = 'active'")->first();
        $stats['active_users'] = $result ? $result->count : 0;
        
        // Tổng API keys
        $result = $this->db->query("SELECT COUNT(*) as count FROM api_keys")->first();
        $stats['total_keys'] = $result ? $result->count : 0;
        
        // Keys active
        $result = $this->db->query("SELECT COUNT(*) as count FROM api_keys WHERE status = 'active'")->first();
        $stats['active_keys'] = $result ? $result->count : 0;
        
        // Spam hôm nay
        $result = $this->db->query("SELECT COUNT(*) as count FROM spam_history WHERE DATE(created_at) = CURDATE()")->first();
        $stats['today_spam'] = $result ? $result->count : 0;
        
        // Spam tuần này
        $result = $this->db->query("SELECT COUNT(*) as count FROM spam_history WHERE YEARWEEK(created_at, 1) = YEARWEEK(CURDATE(), 1)")->first();
        $stats['week_spam'] = $result ? $result->count : 0;
        
        // Spam tháng này
        $result = $this->db->query("SELECT COUNT(*) as count FROM spam_history WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())")->first();
        $stats['month_spam'] = $result ? $result->count : 0;
        
        // Tổng spam
        $result = $this->db->query("SELECT COUNT(*) as count FROM spam_history")->first();
        $stats['total_spam'] = $result ? $result->count : 0;
        
        // Top users
        $stats['top_users'] = $this->db->query("
            SELECT u.username, COUNT(s.id) as spam_count 
            FROM spam_history s 
            JOIN users u ON s.user_id = u.id 
            GROUP BY s.user_id 
            ORDER BY spam_count DESC 
            LIMIT 5
        ")->results();
        
        // Hoạt động gần đây
        $stats['recent_activities'] = $this->db->query("
            SELECT l.*, u.username 
            FROM activity_logs l 
            LEFT JOIN users u ON l.user_id = u.id 
            ORDER BY l.created_at DESC 
            LIMIT 10
        ")->results();
        
        return $stats;
        
    } catch (Exception $e) {
        $this->logError($e->getMessage());
        return [
            'total_users' => 0,
            'active_users' => 0,
            'total_keys' => 0,
            'active_keys' => 0,
            'today_spam' => 0,
            'week_spam' => 0,
            'month_spam' => 0,
            'total_spam' => 0,
            'top_users' => [],
            'recent_activities' => []
        ];
    }
}
    
    /**
     * Lưu lịch sử spam
     */
    public function saveSpamHistory($userId, $data) {
        try {
            $details = json_encode($data['details'] ?? []);
            
            $id = $this->db->insert('spam_history', [
                'user_id' => $userId,
                'phone_number' => $data['phone'],
                'loops' => $data['loops'],
                'delay' => $data['delay'],
                'total_requests' => $data['total_requests'],
                'success_count' => $data['success_count'],
                'failed_count' => $data['failed_count'],
                'success_rate' => $data['success_rate'],
                'details' => $details,
                'ip_address' => get_client_ip()
            ]);
            
            $this->logActivity($userId, 'spam_sent', "Gửi SMS đến {$data['phone']}: {$data['success_count']}/{$data['total_requests']} thành công");
            
            return $id;
            
        } catch (Exception $e) {
            $this->logError($e->getMessage());
            return false;
        }
    }
    
    /**
     * Lấy lịch sử spam
     */
    public function getSpamHistory($userId = null, $limit = 50) {
        try {
            if ($userId) {
                return $this->db->query("
                    SELECT * FROM spam_history 
                    WHERE user_id = ? 
                    ORDER BY created_at DESC 
                    LIMIT ?
                ", [$userId, $limit])->results();
            } else {
                return $this->db->query("
                    SELECT s.*, u.username 
                    FROM spam_history s 
                    JOIN users u ON s.user_id = u.id 
                    ORDER BY s.created_at DESC 
                    LIMIT ?
                ", [$limit])->results();
            }
        } catch (Exception $e) {
            $this->logError($e->getMessage());
            return [];
        }
    }
    
    /**
     * Ghi log lỗi
     */
    private function logError($message) {
        $log = date('[Y-m-d H:i:s]') . " ERROR: " . $message . PHP_EOL;
        file_put_contents($this->logFile, $log, FILE_APPEND);
    }
}