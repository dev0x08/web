<?php
// includes/Database.php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/constants.php';

class DatabaseConnection {
    private static $instance = null;
    private $pdo;
    private $query;
    private $error;
    private $results;
    private $count = 0;
    
    private function __construct() {
        try {
            if (!defined('DB_PORT')) {
                define('DB_PORT', 3306);
            }
            
            $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET
            ];
            
            $this->pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            error_log("DatabaseConnection failed: " . $e->getMessage());
            throw new Exception("Database connection failed: " . $e->getMessage());
        }
    }
    
    public static function getInstance() {
        if (!self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function query($sql, $params = []) {
        $this->error = false;
        
        try {
            if ($this->query = $this->pdo->prepare($sql)) {
                $x = 1;
                if (count($params)) {
                    foreach ($params as $param) {
                        $this->query->bindValue($x, $param);
                        $x++;
                    }
                }
                
                if ($this->query->execute()) {
                    $this->results = $this->query->fetchAll();
                    $this->count = $this->query->rowCount();
                } else {
                    $this->error = true;
                }
            }
        } catch (PDOException $e) {
            $this->error = true;
            error_log("Query error: " . $e->getMessage() . " SQL: " . $sql);
        }
        
        return $this;
    }
    
    public function results() {
        return $this->results ?: [];
    }
    
    public function first() {
        return !empty($this->results) ? $this->results[0] : null;
    }
    
    public function count() {
        return $this->count;
    }
    
    public function error() {
        return $this->error;
    }
    
    public function getPDO() {
        return $this->pdo;
    }
}