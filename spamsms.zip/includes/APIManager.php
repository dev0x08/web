<?php
// includes/APIManager.php
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/functions.php';

class APIManager {
    private $db;
    private $apisFile;
    private $logFile;
    
    public function __construct() {
        $this->db = DatabaseConnection::getInstance();
        $this->apisFile = APIS_FILE;
        $this->logFile = LOG_FILE_API;
        $this->migrateAPIsToDB();
    }
    
    /**
     * Migrate APIs từ JSON sang database
     */
    private function migrateAPIsToDB() {
        if (file_exists($this->apisFile) && !file_exists(ROOT_PATH . '.migrated_apis')) {
            $content = file_get_contents($this->apisFile);
            $apis = json_decode($content, true);
            
            if (is_array($apis)) {
                foreach ($apis as $api) {
                    $this->saveAPIToDB($api);
                }
                file_put_contents(ROOT_PATH . '.migrated_apis', date('Y-m-d H:i:s'));
            }
        }
    }
    
    private function saveAPIToDB($api) {
        try {
            $headers = isset($api['headers']) ? json_encode($api['headers']) : '[]';
            
            $this->db->insert('api_endpoints', [
                'name' => $api['name'] ?? '',
                'url' => $api['url'] ?? '',
                'method' => $api['method'] ?? 'GET',
                'headers' => $headers,
                'body' => $api['body'] ?? null,
                'body_type' => $api['body_type'] ?? 'json',
                'params' => $api['params'] ?? null,
                'status' => $api['status'] ?? 'active',
                'success_rate' => $api['success_rate'] ?? 0,
                'total_requests' => $api['total_requests'] ?? 0,
                'last_check' => $api['last_check'] ?? null,
                'note' => $api['note'] ?? null,
                'created_at' => $api['created_at'] ?? date('Y-m-d H:i:s')
            ]);
            
        } catch (Exception $e) {
            $this->log("Error migrating API: " . $e->getMessage());
        }
    }
    
    /**
     * Lấy tất cả APIs
     */
    public function getAllAPIs() {
        try {
            $apis = $this->db->query("SELECT * FROM api_endpoints ORDER BY created_at DESC")->results();
            
            // Parse headers
            foreach ($apis as $api) {
                $api->headers = json_decode($api->headers, true) ?? [];
            }
            
            return $apis;
        } catch (Exception $e) {
            $this->log("DB error: " . $e->getMessage());
            return $this->getAllAPIsFromJSON();
        }
    }
    
    private function getAllAPIsFromJSON() {
        if (file_exists($this->apisFile)) {
            $content = file_get_contents($this->apisFile);
            return json_decode($content, true) ?? [];
        }
        return [];
    }
    
    /**
     * Lấy API đang hoạt động
     */
    public function getActiveAPIs() {
        try {
            $apis = $this->db->query("SELECT * FROM api_endpoints WHERE status = 'active' ORDER BY created_at DESC")->results();
            
            foreach ($apis as $api) {
                $api->headers = json_decode($api->headers, true) ?? [];
            }
            
            return $apis;
        } catch (Exception $e) {
            $this->log("DB error: " . $e->getMessage());
            
            // Fallback
            $all = $this->getAllAPIsFromJSON();
            $active = [];
            foreach ($all as $api) {
                if (($api['status'] ?? '') === 'active') {
                    $active[] = (object)$api;
                }
            }
            return $active;
        }
    }
    
    /**
     * Lấy API theo ID
     */
    public function getAPI($id) {
        try {
            $api = $this->db->get('api_endpoints', ['id', '=', $id])->first();
            
            if ($api) {
                $api->headers = json_decode($api->headers, true) ?? [];
            }
            
            return $api;
        } catch (Exception $e) {
            $this->log("DB error: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Thêm API mới
     */
    public function addAPI($data, $userId = null) {
        try {
            $headers = isset($data['headers']) ? json_encode(explode("\n", trim($data['headers']))) : '[]';
            
            $id = $this->db->insert('api_endpoints', [
                'name' => $data['name'],
                'url' => $data['url'],
                'method' => $data['method'],
                'headers' => $headers,
                'body' => $data['body'] ?? null,
                'body_type' => $data['body_type'] ?? 'json',
                'params' => $data['params'] ?? null,
                'status' => isset($data['status']) ? 'active' : 'inactive',
                'note' => $data['note'] ?? '',
                'created_by' => $userId
            ]);
            
            $this->log("Added new API: " . $data['name'] . " (ID: $id)");
            
            return $id;
            
        } catch (Exception $e) {
            $this->log("DB error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Cập nhật API
     */
    public function updateAPI($id, $data) {
        try {
            $headers = isset($data['headers']) ? json_encode(explode("\n", trim($data['headers']))) : '[]';
            
            $this->db->update('api_endpoints', $id, [
                'name' => $data['name'],
                'url' => $data['url'],
                'method' => $data['method'],
                'headers' => $headers,
                'body' => $data['body'] ?? null,
                'body_type' => $data['body_type'] ?? 'json',
                'params' => $data['params'] ?? null,
                'status' => isset($data['status']) ? 'active' : 'inactive',
                'note' => $data['note'] ?? '',
                'updated_at' => date('Y-m-d H:i:s')
            ]);
            
            $this->log("Updated API ID: $id");
            return true;
            
        } catch (Exception $e) {
            $this->log("DB error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Xóa API
     */
    public function deleteAPI($id) {
        try {
            $this->db->delete('api_endpoints', ['id', '=', $id]);
            $this->log("Deleted API ID: $id");
            return true;
        } catch (Exception $e) {
            $this->log("DB error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Bật/tắt API
     */
    public function toggleAPI($id) {
        try {
            $api = $this->getAPI($id);
            if (!$api) return false;
            
            $newStatus = $api->status === 'active' ? 'inactive' : 'active';
            
            $this->db->query("UPDATE api_endpoints SET status = ? WHERE id = ?", [$newStatus, $id]);
            $this->log("Toggled API ID: $id to $newStatus");
            
            return $newStatus;
            
        } catch (Exception $e) {
            $this->log("DB error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Cập nhật thống kê API
     */
    public function updateAPIStats($apiId, $success) {
        try {
            $api = $this->getAPI($apiId);
            if (!$api) return;
            
            $totalRequests = $api->total_requests + 1;
            $currentRate = $api->success_rate;
            
            // Tính success rate mới
            if ($success) {
                $newRate = ($currentRate * $api->total_requests + 100) / $totalRequests;
            } else {
                $newRate = ($currentRate * $api->total_requests) / $totalRequests;
            }
            
            $this->db->query("
                UPDATE api_endpoints 
                SET total_requests = ?, 
                    success_rate = ?,
                    last_check = NOW() 
                WHERE id = ?
            ", [$totalRequests, round($newRate, 2), $apiId]);
            
        } catch (Exception $e) {
            $this->log("DB error: " . $e->getMessage());
        }
    }
    
    /**
     * Test API
     */
    public function testAPI($id, $phone = '0987654321') {
        $api = $this->getAPI($id);
        if (!$api) {
            return ['success' => false, 'message' => 'API not found'];
        }
        
        // Chuẩn bị URL và body
        $url = $api->url;
        $body = $api->body;
        
        // Thay thế params
        if (!empty($api->params)) {
            $params = str_replace('{{phone}}', $phone, $api->params);
            $params = str_replace('{{phone_raw}}', $phone, $params);
            $params = str_replace('{{time}}', time(), $params);
            $params = str_replace('{{random}}', rand(1000, 9999), $params);
            
            if (strpos($url, '?') === false) {
                $url .= '?' . $params;
            } else {
                $url .= '&' . $params;
            }
        }
        
        // Thay thế trong body
        if ($body) {
            $body = str_replace('{{phone}}', $phone, $body);
            $body = str_replace('{{phone_raw}}', $phone, $body);
            $body = str_replace('{{time}}', time(), $body);
            $body = str_replace('{{random}}', rand(1000, 9999), $body);
        }
        
        // Headers
        $headers = $api->headers ?? [];
        if ($api->body_type === 'json' && $body) {
            $headers[] = 'Content-Length: ' . strlen($body);
        }
        
        // Thực hiện request
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => MAX_REDIRECTS,
            CURLOPT_TIMEOUT => CURL_TIMEOUT,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => $api->method,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_USERAGENT => USER_AGENT
        ]);
        
        if ($body && $api->method !== 'GET') {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);
        
        $success = ($httpCode >= 200 && $httpCode < 300 && !$error);
        
        // Cập nhật thống kê
        $this->updateAPIStats($id, $success);
        
        return [
            'success' => $success,
            'http_code' => $httpCode,
            'response' => substr($response, 0, 1000),
            'response_length' => strlen($response),
            'error' => $error,
            'url' => $url,
            'body' => $body,
            'headers' => $headers,
            'info' => $info
        ];
    }
    
    /**
     * Import APIs từ file
     */
    public function importAPIs($file, $userId = null) {
        try {
            $content = file_get_contents($file);
            $imported = json_decode($content, true);
            
            if (!is_array($imported)) {
                return false;
            }
            
            $count = 0;
            foreach ($imported as $api) {
                $this->addAPI($api, $userId);
                $count++;
            }
            
            $this->log("Imported $count APIs");
            return $count;
            
        } catch (Exception $e) {
            $this->log("Import error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Export APIs ra file
     */
    public function exportAPIs() {
        return $this->getAllAPIs();
    }
    
    /**
     * Ghi log
     */
    private function log($message) {
        $logEntry = date('[Y-m-d H:i:s]') . " " . get_client_ip() . " - " . $message . PHP_EOL;
        file_put_contents($this->logFile, $logEntry, FILE_APPEND);
    }
}