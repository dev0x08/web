<?php
// install.php
session_start();

// Kiểm tra đã cài đặt chưa
if (file_exists(__DIR__ . '/.installed')) {
    die('Hệ thống đã được cài đặt. Vui lòng xóa file .installed để cài đặt lại.');
}

// Xử lý cài đặt
$step = $_GET['step'] ?? 1;
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step == 1) {
        // Kiểm tra kết nối database
        $host = $_POST['db_host'] ?? 'localhost';
        $name = $_POST['db_name'] ?? 'spamsms';
        $user = $_POST['db_user'] ?? 'root';
        $pass = $_POST['db_pass'] ?? '';
        
        try {
            // Tạo file cấu hình
            $config = "<?php\n";
            $config .= "// config/database.php\n";
            $config .= "define('DB_HOST', '" . addslashes($host) . "');\n";
            $config .= "define('DB_NAME', '" . addslashes($name) . "');\n";
            $config .= "define('DB_USER', '" . addslashes($user) . "');\n";
            $config .= "define('DB_PASS', '" . addslashes($pass) . "');\n";
            $config .= "define('DB_CHARSET', 'utf8mb4');\n\n";
            $config .= "class Database {\n";
            $config .= "    private static \$instance = null;\n";
            $config .= "    private \$pdo;\n\n";
            $config .= "    private function __construct() {\n";
            $config .= "        try {\n";
            $config .= "            \$dsn = \"mysql:host=\" . DB_HOST . \";dbname=\" . DB_NAME . \";charset=\" . DB_CHARSET;\n";
            $config .= "            \$this->pdo = new PDO(\$dsn, DB_USER, DB_PASS);\n";
            $config .= "            \$this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);\n";
            $config .= "            \$this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);\n";
            $config .= "        } catch (PDOException \$e) {\n";
            $config .= "            die(\"Connection failed: \" . \$e->getMessage());\n";
            $config .= "        }\n";
            $config .= "    }\n\n";
            $config .= "    public static function getInstance() {\n";
            $config .= "        if (self::\$instance === null) {\n";
            $config .= "            self::\$instance = new self();\n";
            $config .= "        }\n";
            $config .= "        return self::\$instance->pdo;\n";
            $config .= "    }\n";
            $config .= "}\n";
            
            // Tạo thư mục config nếu chưa có
            if (!is_dir(__DIR__ . '/config')) {
                mkdir(__DIR__ . '/config', 0755, true);
            }
            
            file_put_contents(__DIR__ . '/config/database.php', $config);
            
            // Test kết nối
            $pdo = new PDO("mysql:host=$host", $user, $pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // Tạo database
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE `$name`");
            
            // Tạo bảng users
            $sql = "CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                full_name VARCHAR(100),
                role ENUM('admin', 'user') DEFAULT 'user',
                status ENUM('active', 'inactive') DEFAULT 'active',
                last_login DATETIME,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_username (username),
                INDEX idx_email (email)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
            $pdo->exec($sql);
            
            // Tạo bảng sessions
            $sql = "CREATE TABLE IF NOT EXISTS user_sessions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                session_token VARCHAR(255) UNIQUE NOT NULL,
                ip_address VARCHAR(45),
                user_agent TEXT,
                expires_at DATETIME NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                INDEX idx_token (session_token),
                INDEX idx_expires (expires_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
            $pdo->exec($sql);
            
            // Tạo bảng activity_logs
            $sql = "CREATE TABLE IF NOT EXISTS activity_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT,
                action VARCHAR(50) NOT NULL,
                details TEXT,
                ip_address VARCHAR(45),
                user_agent TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
                INDEX idx_user (user_id),
                INDEX idx_action (action),
                INDEX idx_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
            $pdo->exec($sql);
            
            // Tạo bảng api_keys
            $sql = "CREATE TABLE IF NOT EXISTS api_keys (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                api_key VARCHAR(64) UNIQUE NOT NULL,
                name VARCHAR(100),
                status ENUM('active', 'inactive') DEFAULT 'active',
                usage_count INT DEFAULT 0,
                last_used DATETIME,
                expires_at DATETIME,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                INDEX idx_key (api_key),
                INDEX idx_user (user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
            $pdo->exec($sql);
            
            // Tạo bảng api_endpoints
            $sql = "CREATE TABLE IF NOT EXISTS api_endpoints (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                url TEXT NOT NULL,
                method VARCHAR(10) NOT NULL,
                headers TEXT,
                body TEXT,
                body_type VARCHAR(20) DEFAULT 'json',
                params TEXT,
                status ENUM('active', 'inactive') DEFAULT 'active',
                success_rate DECIMAL(5,2) DEFAULT 0,
                total_requests INT DEFAULT 0,
                last_check DATETIME,
                note TEXT,
                created_by INT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
                INDEX idx_status (status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
            $pdo->exec($sql);
            
            // Tạo bảng spam_history
            $sql = "CREATE TABLE IF NOT EXISTS spam_history (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                phone_number VARCHAR(15) NOT NULL,
                loops INT DEFAULT 1,
                delay INT DEFAULT 0,
                total_requests INT DEFAULT 0,
                success_count INT DEFAULT 0,
                failed_count INT DEFAULT 0,
                success_rate DECIMAL(5,2) DEFAULT 0,
                details JSON,
                ip_address VARCHAR(45),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                INDEX idx_user (user_id),
                INDEX idx_phone (phone_number),
                INDEX idx_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
            $pdo->exec($sql);
            
            // Tạo admin user
            $adminPass = password_hash('admin123', PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password, email, full_name, role) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute(['admin', $adminPass, 'admin@localhost', 'Administrator', 'admin']);
            
            // Tạo demo user
            $demoPass = password_hash('user123', PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password, email, full_name, role) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute(['demo', $demoPass, 'demo@localhost', 'Demo User', 'user']);
            
            // Tạo API key mặc định
            $apiKey = bin2hex(random_bytes(16));
            $stmt = $pdo->prepare("INSERT INTO api_keys (user_id, api_key, name, expires_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY))");
            $stmt->execute([1, $apiKey, 'Default API Key']);
            
            // Tạo thư mục logs
            if (!is_dir(__DIR__ . '/logs')) {
                mkdir(__DIR__ . '/logs', 0777, true);
            }
            
            // Tạo file .installed
            file_put_contents(__DIR__ . '/.installed', date('Y-m-d H:i:s'));
            
            $_SESSION['install_success'] = true;
            header('Location: install.php?step=3');
            exit;
            
        } catch (PDOException $e) {
            $error = 'Lỗi kết nối database: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cài đặt WusTeam SpamSMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .install-box {
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 30px 60px rgba(0,0,0,0.3);
            max-width: 600px;
            width: 100%;
        }
        .step-indicator {
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
            position: relative;
        }
        .step {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e9ecef;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            position: relative;
            z-index: 2;
        }
        .step.active {
            background: #667eea;
            color: white;
        }
        .step-line {
            position: absolute;
            top: 20px;
            left: 0;
            right: 0;
            height: 2px;
            background: #e9ecef;
            z-index: 1;
        }
    </style>
</head>
<body>
    <div class="install-box">
        <h2 class="text-center mb-4">Cài đặt WusTeam SpamSMS</h2>
        
        <div class="step-indicator">
            <div class="step <?php echo $step >= 1 ? 'active' : ''; ?>">1</div>
            <div class="step <?php echo $step >= 2 ? 'active' : ''; ?>">2</div>
            <div class="step <?php echo $step >= 3 ? 'active' : ''; ?>">3</div>
            <div class="step-line"></div>
        </div>
        
        <?php if ($step == 1): ?>
            <h4 class="mb-3">Thông tin database</h4>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Database Host</label>
                    <input type="text" name="db_host" class="form-control" value="localhost" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Database Name</label>
                    <input type="text" name="db_name" class="form-control" value="spamsms" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Database User</label>
                    <input type="text" name="db_user" class="form-control" value="root" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Database Password</label>
                    <input type="password" name="db_pass" class="form-control">
                </div>
                
                <button type="submit" class="btn btn-primary w-100">Cài đặt</button>
            </form>
            
        <?php elseif ($step == 2): ?>
            <div class="text-center">
                <div class="spinner-border text-primary mb-3" role="status">
                    <span class="visually-hidden">Đang cài đặt...</span>
                </div>
                <p>Đang cài đặt database...</p>
            </div>
            
            <script>
                setTimeout(function() {
                    window.location.href = 'install.php?step=3';
                }, 3000);
            </script>
            
        <?php elseif ($step == 3): ?>
            <div class="text-center">
                <div class="mb-4">
                    <i class="fas fa-check-circle text-success" style="font-size: 64px;"></i>
                </div>
                
                <h4 class="mb-3">Cài đặt thành công!</h4>
                
                <div class="alert alert-info text-start">
                    <p><strong>Thông tin đăng nhập:</strong></p>
                    <p><strong>Admin:</strong> admin / admin123</p>
                    <p><strong>User:</strong> demo / user123</p>
                    <p><strong>API Key mặc định:</strong> Đã tạo trong database</p>
                </div>
                
                <div class="mt-4">
                    <a href="index.php" class="btn btn-primary">Đến trang chủ</a>
                    <a href="admin/login.php" class="btn btn-success">Đến trang Admin</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <script src="https://kit.fontawesome.com/your-kit.js" crossorigin="anonymous"></script>
</body>
</html>