<?php
// api/keyadmin.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

try {
    // Log all errors
    set_error_handler(function($errno, $errstr, $errfile, $errline) {
        throw new ErrorException($errstr, 0, $errno, $errfile, $errline);
    });
    
    // Define base path
    define('BASE_PATH', __DIR__ . '/../');
    
    // Check and include files
    $required_files = [
        'config/database.php',
        'config/constants.php',
        'includes/Database.php',
        'includes/KeyManager.php',
        'includes/UserManager.php',
        'includes/functions.php'
    ];
    
    foreach ($required_files as $file) {
        $full_path = BASE_PATH . $file;
        if (!file_exists($full_path)) {
            throw new Exception("Required file not found: " . $file . " at " . $full_path);
        }
        require_once $full_path;
    }
    
    // Initialize classes
    if (!class_exists('KeyManager')) {
        throw new Exception("KeyManager class not found");
    }
    
    $keyManager = new KeyManager();
    $userManager = new UserManager();
    
    // Get action
    $action = $_GET['action'] ?? '';
    
    switch ($action) {
        case 'stats':
            $stats = $userManager->getStats();
            echo json_encode([
                'status' => 'success',
                'stats' => $stats
            ]);
            break;
            
        case 'verify':
            $key = $_GET['key'] ?? '';
            if (empty($key)) {
                echo json_encode(['status' => 400, 'message' => 'Missing key']);
                break;
            }
            $result = $keyManager->validateKey($key);
            echo json_encode($result);
            break;
            
        default:
            echo json_encode([
                'status' => 'error',
                'message' => 'Invalid action',
                'available' => ['stats', 'verify']
            ]);
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine(),
        'trace' => $e->getTraceAsString()
    ]);
}