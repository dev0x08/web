<?php
// api/api_manager.php
header('Content-Type: application/json');
error_reporting(0);
ini_set('display_errors', 0);

try {
    require_once __DIR__ . '/../config/database.php';
    require_once __DIR__ . '/../config/constants.php';
    require_once __DIR__ . '/../includes/Database.php';
    require_once __DIR__ . '/../includes/APIManager.php';
    require_once __DIR__ . '/../includes/UserManager.php';
    require_once __DIR__ . '/../includes/functions.php';
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Lỗi include file: ' . $e->getMessage()]);
    exit;
}

$apiManager = new APIManager();
$userManager = new UserManager();

// Xác thực user (nếu cần)
$token = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
$token = str_replace('Bearer ', '', $token);
$user = $userManager->validateToken($token);

// Xử lý action
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'list':
        echo json_encode([
            'status' => 'success',
            'apis' => $apiManager->getAllAPIs()
        ]);
        break;
        
    case 'active':
        echo json_encode([
            'status' => 'success',
            'apis' => $apiManager->getActiveAPIs()
        ]);
        break;
        
    case 'get':
        $id = $_GET['id'] ?? '';
        $api = $apiManager->getAPI($id);
        if ($api) {
            echo json_encode([
                'status' => 'success',
                'api' => $api
            ]);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'API not found'
            ]);
        }
        break;
        
    case 'add':
        if (!$user['valid']) {
            echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
            break;
        }
        
        $data = json_decode(file_get_contents('php://input'), true);
        if ($data) {
            $id = $apiManager->addAPI($data, $user['user_id']);
            echo json_encode([
                'status' => 'success',
                'id' => $id,
                'message' => 'API added successfully'
            ]);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Invalid data'
            ]);
        }
        break;
        
    case 'update':
        if (!$user['valid']) {
            echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
            break;
        }
        
        $id = $_GET['id'] ?? '';
        $data = json_decode(file_get_contents('php://input'), true);
        if ($id && $data) {
            if ($apiManager->updateAPI($id, $data)) {
                echo json_encode([
                    'status' => 'success',
                    'message' => 'API updated successfully'
                ]);
            } else {
                echo json_encode([
                    'status' => 'error',
                    'message' => 'API not found'
                ]);
            }
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Invalid data'
            ]);
        }
        break;
        
    case 'delete':
        if (!$user['valid'] || $user['role'] !== 'admin') {
            echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
            break;
        }
        
        $id = $_GET['id'] ?? '';
        if ($apiManager->deleteAPI($id)) {
            echo json_encode([
                'status' => 'success',
                'message' => 'API deleted successfully'
            ]);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'API not found'
            ]);
        }
        break;
        
    case 'toggle':
        if (!$user['valid']) {
            echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
            break;
        }
        
        $id = $_GET['id'] ?? '';
        $status = $apiManager->toggleAPI($id);
        if ($status) {
            echo json_encode([
                'status' => 'success',
                'new_status' => $status,
                'message' => 'API toggled successfully'
            ]);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'API not found'
            ]);
        }
        break;
        
    case 'test':
        $id = $_GET['id'] ?? '';
        $phone = $_GET['phone'] ?? '0987654321';
        $result = $apiManager->testAPI($id, $phone);
        echo json_encode([
            'status' => $result['success'] ? 'success' : 'error',
            'result' => $result
        ]);
        break;
        
    case 'export':
        $apis = $apiManager->exportAPIs();
        header('Content-Disposition: attachment; filename="apis_export_' . date('Y-m-d') . '.json"');
        echo json_encode($apis, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        break;
        
    default:
        echo json_encode([
            'status' => 'error',
            'message' => 'Invalid action'
        ]);
        break;
}