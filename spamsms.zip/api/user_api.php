<?php
// api/user_api.php
header('Content-Type: application/json');
error_reporting(0);
ini_set('display_errors', 0);

try {
    require_once __DIR__ . '/../config/database.php';
    require_once __DIR__ . '/../config/constants.php';
    require_once __DIR__ . '/../includes/Database.php';
    require_once __DIR__ . '/../includes/UserManager.php';
    require_once __DIR__ . '/../includes/functions.php';
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Lỗi include file: ' . $e->getMessage()]);
    exit;
}

$userManager = new UserManager();
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'login':
        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data) {
            echo json_encode(['success' => false, 'message' => 'Invalid data']);
            break;
        }
        
        $result = $userManager->authenticate($data['username'], $data['password']);
        echo json_encode($result);
        break;
        
    case 'logout':
        $token = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        $token = str_replace('Bearer ', '', $token);
        $result = $userManager->logout($token);
        echo json_encode(['success' => $result]);
        break;
        
    case 'validate':
        $token = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        $token = str_replace('Bearer ', '', $token);
        $result = $userManager->validateToken($token);
        echo json_encode($result);
        break;
        
    case 'validate_key':
        $apiKey = $_GET['key'] ?? $_SERVER['HTTP_X_API_KEY'] ?? '';
        $result = $userManager->validateApiKey($apiKey);
        echo json_encode($result);
        break;
        
    case 'register':
        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data) {
            echo json_encode(['success' => false, 'message' => 'Invalid data']);
            break;
        }
        
        $result = $userManager->createUser($data);
        echo json_encode($result);
        break;
        
    case 'stats':
        $stats = $userManager->getStats();
        echo json_encode(['success' => true, 'stats' => $stats]);
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        break;
}