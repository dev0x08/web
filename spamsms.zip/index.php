<?php
// index.php
session_start();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WusTeam - Spam SMS Tool</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            position: relative;
            overflow-x: hidden;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="40" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="1"/></svg>') repeat;
            pointer-events: none;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            position: relative;
            z-index: 1;
        }

        /* Header */
        .header {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 30px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #ff6b6b, #ff8e8e);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 30px;
            color: white;
            transform: rotate(10deg);
            transition: transform 0.3s;
        }

        .logo-icon:hover {
            transform: rotate(0deg) scale(1.1);
        }

        .logo-text h1 {
            color: white;
            font-size: 32px;
            font-weight: 700;
            margin: 0;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }

        .logo-text p {
            color: rgba(255,255,255,0.8);
            margin: 5px 0 0;
            font-size: 14px;
        }

        .stats {
            display: flex;
            gap: 20px;
            justify-content: flex-end;
        }

        .stat-item {
            background: rgba(255,255,255,0.1);
            border-radius: 15px;
            padding: 15px 25px;
            text-align: center;
            color: white;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255,255,255,0.1);
        }

        .stat-value {
            font-size: 28px;
            font-weight: 700;
            line-height: 1;
        }

        .stat-label {
            font-size: 12px;
            opacity: 0.8;
            margin-top: 5px;
        }

        /* Main Card */
        .main-card {
            background: white;
            border-radius: 30px;
            overflow: hidden;
            box-shadow: 0 30px 60px rgba(0,0,0,0.3);
            animation: slideIn 0.6s ease;
            margin-bottom: 30px;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .card-header {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 30px;
            border-bottom: 1px solid #dee2e6;
            position: relative;
            overflow: hidden;
        }

        .card-header::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(102,126,234,0.1) 0%, transparent 70%);
            animation: rotate 20s linear infinite;
        }

        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        .card-header h2 {
            margin: 0;
            color: #333;
            font-weight: 700;
            position: relative;
            z-index: 1;
        }

        .card-header p {
            color: #666;
            margin: 10px 0 0;
            position: relative;
            z-index: 1;
        }

        .card-body {
            padding: 40px;
        }

        /* Form */
        .auth-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            color: white;
            box-shadow: 0 10px 30px rgba(102,126,234,0.4);
        }

        .auth-section h3 {
            margin: 0 0 10px;
            font-weight: 600;
        }

        .auth-section p {
            margin: 0 0 20px;
            opacity: 0.9;
        }

        .key-input-group {
            display: flex;
            gap: 10px;
            background: rgba(255,255,255,0.2);
            padding: 5px;
            border-radius: 15px;
            backdrop-filter: blur(5px);
        }

        .key-input {
            flex: 1;
            padding: 15px 20px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            background: white;
            transition: all 0.3s;
        }

        .key-input:focus {
            outline: none;
            box-shadow: 0 0 0 3px rgba(255,255,255,0.3);
        }

        .key-input.error {
            border: 2px solid #dc3545;
            animation: shake 0.3s ease;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-10px); }
            75% { transform: translateX(10px); }
        }

        .verify-btn {
            padding: 15px 40px;
            border: none;
            border-radius: 12px;
            background: white;
            color: #667eea;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .verify-btn:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
        }

        .verify-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .key-status {
            margin-top: 15px;
            padding: 10px;
            border-radius: 10px;
            display: none;
        }

        .key-status.success {
            display: block;
            background: rgba(40, 167, 69, 0.2);
            color: #28a745;
            border: 1px solid #28a745;
        }

        .key-status.error {
            display: block;
            background: rgba(220, 53, 69, 0.2);
            color: #dc3545;
            border: 1px solid #dc3545;
        }

        /* Tool Section */
        .tool-section {
            display: none;
            animation: fadeIn 0.5s ease;
        }

        .tool-section.show {
            display: block;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .feature-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }

        .feature-card {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            border: 2px solid transparent;
        }

        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .feature-card.active {
            border-color: #667eea;
            background: linear-gradient(135deg, rgba(102,126,234,0.1), rgba(118,75,162,0.1));
        }

        .feature-card i {
            font-size: 40px;
            color: #667eea;
            margin-bottom: 15px;
        }

        .feature-card h4 {
            margin: 10px 0 5px;
            color: #333;
        }

        .feature-card p {
            margin: 0;
            color: #666;
            font-size: 13px;
        }

        .btn-spam {
            background: linear-gradient(135deg, #ff6b6b, #ff8e8e);
            color: white;
            border: none;
            padding: 20px;
            font-size: 20px;
            font-weight: 600;
            border-radius: 15px;
            width: 100%;
            cursor: pointer;
            transition: all 0.3s;
            text-transform: uppercase;
            letter-spacing: 2px;
            box-shadow: 0 10px 30px rgba(255,107,107,0.4);
            margin-top: 30px;
        }

        .btn-spam:hover:not(:disabled) {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(255,107,107,0.6);
        }

        .btn-spam:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        /* Result */
        .result-container {
            margin-top: 30px;
            padding: 20px;
            border-radius: 15px;
            background: #f8f9fa;
            display: none;
        }

        .result-container.show {
            display: block;
            animation: slideUp 0.5s ease;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .stat-box {
            background: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            border-left: 4px solid #667eea;
        }

        /* Loading */
        .loader {
            display: none;
            text-align: center;
            padding: 40px;
        }

        .loader.show {
            display: block;
        }

        .spinner {
            width: 50px;
            height: 50px;
            border: 5px solid #f3f3f3;
            border-top-color: #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Admin Section */
        .admin-section {
            background: white;
            border-radius: 20px;
            padding: 30px;
            margin-top: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .admin-header h3 {
            margin: 0;
            color: #333;
        }

        .key-table {
            width: 100%;
            border-collapse: collapse;
        }

        .key-table th {
            background: #f8f9fa;
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #333;
        }

        .key-table td {
            padding: 15px;
            border-bottom: 1px solid #dee2e6;
        }

        .key-table tr:hover {
            background: #f8f9fa;
        }

        .key-preview {
            font-family: monospace;
            background: #e9ecef;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 14px;
        }

        .copy-btn {
            padding: 5px 15px;
            border: none;
            border-radius: 5px;
            background: #667eea;
            color: white;
            cursor: pointer;
            font-size: 12px;
            transition: all 0.3s;
        }

        .copy-btn:hover {
            background: #5a67d8;
        }

        .badge {
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 12px;
            font-weight: 600;
        }

        .badge-active {
            background: #28a745;
            color: white;
        }

        .badge-inactive {
            background: #dc3545;
            color: white;
        }

        .badge-expired {
            background: #ffc107;
            color: #333;
        }

        .toast {
            position: fixed;
            top: 20px;
            right: 20px;
            background: white;
            border-radius: 10px;
            padding: 15px 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            display: none;
            align-items: center;
            gap: 10px;
            z-index: 1000;
            animation: slideInRight 0.3s ease;
        }

        .toast.show {
            display: flex;
        }

        .toast.success {
            border-left: 4px solid #28a745;
        }

        .toast.error {
            border-left: 4px solid #dc3545;
        }

        .toast.warning {
            border-left: 4px solid #ffc107;
        }

        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        /* Responsive */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 20px;
            }
            
            .stats {
                justify-content: center;
            }
            
            .key-input-group {
                flex-direction: column;
            }
            
            .verify-btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="toast" id="toast">
        <i class="fas" id="toastIcon"></i>
        <span id="toastMessage"></span>
    </div>

    <div class="container">
        <!-- Header -->
        <div class="header d-flex justify-content-between align-items-center">
            <div class="logo">
                <div class="logo-icon">
                    <i class="fas fa-bolt"></i>
                </div>
                <div class="logo-text">
                    <h1>WusTeam SpamSMS</h1>
                    <p><i class="fas fa-shield-alt"></i> Secure API Key Management</p>
                </div>
            </div>
            <div class="stats">
                <div class="stat-item">
                    <div class="stat-value" id="totalKeys">0</div>
                    <div class="stat-label">Tổng Keys</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value" id="activeKeys">0</div>
                    <div class="stat-label">Đang hoạt động</div>
                </div>
            </div>
        </div>

        <!-- Main Card -->
        <div class="main-card">
            <div class="card-header">
                <h2><i class="fas fa-key me-2"></i>Xác thực API Key</h2>
                <p>Nhập API Key của bạn để sử dụng công cụ Spam SMS</p>
            </div>
            <div class="card-body">
                <!-- Authentication Section -->
                <div class="auth-section">
                    <h3><i class="fas fa-lock me-2"></i>Authentication Required</h3>
                    <p>Vui lòng nhập API Key để tiếp tục. Nếu chưa có key, hãy đăng nhập để tạo key mới.</p>
                    
                    <div class="key-input-group">
                        <input type="text" class="key-input" id="apiKey" placeholder="Nhập API Key của bạn..." autocomplete="off">
                        <button class="verify-btn" id="verifyBtn" onclick="verifyKey()">
                            <i class="fas fa-check-circle"></i>
                            <span>Xác thực</span>
                        </button>
                    </div>
                    
                    <div class="key-status" id="keyStatus"></div>
                    
                    <div class="text-center mt-3">
                        <a href="admin/login.php" class="text-white">
                            <i class="fas fa-user-shield me-1"></i>Đăng nhập Admin
                        </a>
                    </div>
                </div>

                <!-- Tool Section (hidden until key verified) -->
                <div class="tool-section" id="toolSection">
                    <h3><i class="fas fa-cogs me-2"></i>Công cụ Spam SMS</h3>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-phone-alt me-2 text-primary"></i>Số điện thoại đích
                                </label>
                                <input type="text" class="form-control" id="sdt" placeholder="Nhập số điện thoại (VD: 0912345678)" maxlength="10">
                                <small class="text-muted">Nhập 10 số, bắt đầu bằng 03,05,07,08,09</small>
                            </div>
                        </div>
                        
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-redo me-2 text-primary"></i>Số lần lặp
                                </label>
                                <select class="form-select" id="loop">
                                    <option value="1">1 lần</option>
                                    <option value="2">2 lần</option>
                                    <option value="3">3 lần</option>
                                    <option value="5">5 lần</option>
                                    <option value="10">10 lần</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label class="form-label fw-bold">
                                    <i class="fas fa-clock me-2 text-primary"></i>Delay (giây)
                                </label>
                                <select class="form-select" id="delay">
                                    <option value="0">Không delay</option>
                                    <option value="1">1 giây</option>
                                    <option value="2">2 giây</option>
                                    <option value="3">3 giây</option>
                                    <option value="5">5 giây</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="feature-grid">
                        <div class="feature-card" onclick="toggleFeature(this, 'rate_limit')">
                            <i class="fas fa-tachometer-alt"></i>
                            <h4>Rate Limit</h4>
                            <p>Giới hạn số lần gửi</p>
                            <input type="checkbox" id="rate_limit" class="d-none" checked>
                        </div>
                        
                        <div class="feature-card" onclick="toggleFeature(this, 'logging')">
                            <i class="fas fa-history"></i>
                            <h4>Logging</h4>
                            <p>Ghi nhật ký hoạt động</p>
                            <input type="checkbox" id="logging" class="d-none" checked>
                        </div>
                        
                        <div class="feature-card" onclick="toggleFeature(this, 'random_ua')">
                            <i class="fas fa-user-secret"></i>
                            <h4>Random UA</h4>
                            <p>User Agent ngẫu nhiên</p>
                            <input type="checkbox" id="random_ua" class="d-none">
                        </div>
                        
                        <div class="feature-card" onclick="toggleFeature(this, 'statistics')">
                            <i class="fas fa-chart-bar"></i>
                            <h4>Thống kê</h4>
                            <p>Xem thống kê chi tiết</p>
                            <input type="checkbox" id="statistics" class="d-none" checked>
                        </div>
                    </div>

                    <button class="btn-spam" id="spamBtn" onclick="startSpam()">
                        <i class="fas fa-rocket me-2"></i>
                        BẮT ĐẦU SPAM
                    </button>

                    <!-- Loader -->
                    <div class="loader" id="loader">
                        <div class="spinner"></div>
                        <p class="text-muted">Đang xử lý... Vui lòng đợi</p>
                    </div>

                    <!-- Result -->
                    <div class="result-container" id="resultContainer">
                        <h4 class="mb-3"><i class="fas fa-chart-line me-2"></i>Kết quả</h4>
                        <div id="resultContent"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        let currentKey = '';
        let isKeyValid = false;

        // Load keys on page load
        window.onload = function() {
            loadStats();
        };

        // Load statistics
        function loadStats() {
    fetch('/spamsms/api/user_api.php?action=stats')
        .then(response => {
            if (!response.ok) {
                throw new Error('HTTP error ' + response.status);
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                document.getElementById('totalKeys').textContent = data.stats?.total_keys || 0;
                document.getElementById('activeKeys').textContent = data.stats?.active_users || 0;
            }
        })
        .catch(error => {
            console.error('Error loading stats:', error);
            // Set default values on error
            document.getElementById('totalKeys').textContent = '0';
            document.getElementById('activeKeys').textContent = '0';
        });
}

        // Verify API Key
        function verifyKey() {
    const key = document.getElementById('apiKey').value.trim();
    const verifyBtn = document.getElementById('verifyBtn');
    const keyInput = document.querySelector('.key-input');
    const keyStatus = document.getElementById('keyStatus');
    
    if (!key) {
        showToast('Vui lòng nhập API Key', 'warning');
        keyInput.classList.add('error');
        setTimeout(() => keyInput.classList.remove('error'), 500);
        return;
    }

    verifyBtn.disabled = true;
    verifyBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang xác thực...';

    // Sử dụng fetch với đầy đủ URL
    fetch('/spamsms/api/keyadmin.php?action=verify&key=' + encodeURIComponent(key))
        .then(response => {
            if (!response.ok) {
                throw new Error('HTTP error ' + response.status);
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 200 && data.valid) {
                keyStatus.className = 'key-status success';
                keyStatus.innerHTML = '<i class="fas fa-check-circle me-2"></i>' + data.message;
                
                showToast('Xác thực thành công!', 'success');
                
                document.getElementById('toolSection').classList.add('show');
                currentKey = key;
                isKeyValid = true;
                
                sessionStorage.setItem('validKey', key);
            } else {
                keyStatus.className = 'key-status error';
                keyStatus.innerHTML = '<i class="fas fa-times-circle me-2"></i>' + (data.message || 'Key không hợp lệ');
                
                showToast(data.message || 'Key không hợp lệ', 'error');
                document.getElementById('toolSection').classList.remove('show');
                isKeyValid = false;
            }
        })
        .catch(error => {
            console.error('Fetch error:', error);
            keyStatus.className = 'key-status error';
            keyStatus.innerHTML = '<i class="fas fa-times-circle me-2"></i>Lỗi kết nối đến server';
            showToast('Lỗi kết nối: ' + error.message, 'error');
        })
        .finally(() => {
            verifyBtn.disabled = false;
            verifyBtn.innerHTML = '<i class="fas fa-check-circle"></i><span>Xác thực</span>';
        });
}

        // Toggle feature
        function toggleFeature(element, featureId) {
            element.classList.toggle('active');
            const checkbox = document.getElementById(featureId);
            checkbox.checked = !checkbox.checked;
        }

        // Start spam
        function startSpam() {
            if (!isKeyValid) {
                showToast('Vui lòng xác thực key trước khi sử dụng!', 'warning');
                return;
            }

            const sdt = document.getElementById('sdt').value.trim();
            if (!sdt) {
                showToast('Vui lòng nhập số điện thoại!', 'warning');
                return;
            }

            if (!/^(09|08|07|03|05)\d{8}$/.test(sdt)) {
                showToast('Số điện thoại không hợp lệ!', 'error');
                return;
            }

            const spamBtn = document.getElementById('spamBtn');
            const loader = document.getElementById('loader');
            const resultContainer = document.getElementById('resultContainer');

            spamBtn.disabled = true;
            loader.classList.add('show');
            resultContainer.classList.remove('show');

            const data = {
                sdt: sdt,
                loop: document.getElementById('loop').value,
                delay: document.getElementById('delay').value,
                features: {
                    rate_limit: document.getElementById('rate_limit').checked,
                    logging: document.getElementById('logging').checked,
                    random_ua: document.getElementById('random_ua').checked,
                    statistics: document.getElementById('statistics').checked
                },
                api_key: currentKey
            };

            fetch('process.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WusTeam': currentKey
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(result => {
                displayResult(result);
                showToast('Gửi thành công!', 'success');
            })
            .catch(error => {
                showToast('Lỗi: ' + error, 'error');
            })
            .finally(() => {
                spamBtn.disabled = false;
                loader.classList.remove('show');
            });
        }

        // Display result
        function displayResult(data) {
            const resultContainer = document.getElementById('resultContainer');
            const resultContent = document.getElementById('resultContent');
            
            const r = data.r || data;
            
            let html = `
                <div class="stat-box">
                    <strong>Số điện thoại:</strong> ${r.phone || document.getElementById('sdt').value}
                </div>
                <div class="stat-box">
                    <strong>Thành công:</strong> ${r.statistics?.total_success || 0}
                </div>
                <div class="stat-box">
                    <strong>Thất bại:</strong> ${r.statistics?.total_failed || 0}
                </div>
                <div class="stat-box">
                    <strong>Tỉ lệ thành công:</strong> ${r.statistics?.success_rate || '0%'}
                </div>
                <div class="stat-box">
                    <strong>Thời gian:</strong> ${r.date || new Date().toLocaleString()}
                </div>
            `;
            
            if (r.results) {
                html += '<hr><h5>Chi tiết các lần gửi:</h5>';
                for (let loop in r.results) {
                    html += `
                        <div class="stat-box">
                            <strong>${loop}:</strong> 
                            Success: ${r.results[loop].success}, 
                            Failed: ${r.results[loop].failed}
                        </div>
                    `;
                }
            }
            
            resultContent.innerHTML = html;
            resultContainer.classList.add('show');
        }

        // Show toast
        function showToast(message, type = 'info') {
            const toast = document.getElementById('toast');
            const icon = document.getElementById('toastIcon');
            const msg = document.getElementById('toastMessage');
            
            let iconClass = 'fa-info-circle';
            if (type === 'success') iconClass = 'fa-check-circle';
            if (type === 'error') iconClass = 'fa-times-circle';
            if (type === 'warning') iconClass = 'fa-exclamation-triangle';
            
            icon.className = 'fas ' + iconClass;
            msg.textContent = message;
            
            toast.className = 'toast show ' + type;
            
            setTimeout(() => {
                toast.classList.remove('show');
            }, 3000);
        }

        // Check for saved key in session
        const savedKey = sessionStorage.getItem('validKey');
        if (savedKey) {
            document.getElementById('apiKey').value = savedKey;
            verifyKey();
        }

        // Enter key to verify
        document.getElementById('apiKey').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                verifyKey();
            }
        });
    </script>
</body>
</html>