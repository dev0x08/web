<?php
// admin/index.php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../includes/Database.php';
require_once __DIR__ . '/../includes/UserManager.php';
require_once __DIR__ . '/../includes/KeyManager.php';
require_once __DIR__ . '/../includes/APIManager.php';
require_once __DIR__ . '/../includes/functions.php';

$userManager = new UserManager();
$keyManager = new KeyManager();
$apiManager = new APIManager();

// Kiểm tra session
$token = $_SESSION['admin_token'] ?? '';
$user = $userManager->validateToken($token);

if (!$user['valid'] || $user['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

// Lấy thống kê
$stats = $userManager->getStats();

// Lấy hoạt động gần đây
$recentActivities = $stats['recent_activities'] ?? [];

// Lấy top users
$topUsers = $stats['top_users'] ?? [];

// Lấy thống kê APIs
$apis = $apiManager->getAllAPIs();
$totalApis = count($apis);
$activeApis = 0;
$totalApiRequests = 0;

foreach ($apis as $api) {
    if ($api->status === 'active') $activeApis++;
    $totalApiRequests += $api->total_requests;
}

// Lấy thống kê keys
$keys = $keyManager->getKeysList();
$totalKeys = count($keys);
$activeKeys = 0;
foreach ($keys as $key) {
    if ($key->status === 'active') $activeKeys++;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - WusTeam Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .dashboard-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        .card-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
            margin-bottom: 15px;
        }
        .card-value {
            font-size: 32px;
            font-weight: 700;
            color: #333;
        }
        .card-label {
            color: #666;
            font-size: 14px;
        }
        .trend-up {
            color: #28a745;
            font-size: 13px;
        }
        .trend-down {
            color: #dc3545;
            font-size: 13px;
        }
        .activity-item {
            padding: 12px;
            border-bottom: 1px solid #eee;
        }
        .activity-item:last-child {
            border-bottom: none;
        }
        .activity-time {
            font-size: 12px;
            color: #999;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h3>WusTeam</h3>
            <p>Admin Panel</p>
        </div>
        <div class="sidebar-menu">
            <a href="index.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="users.php"><i class="fas fa-users"></i> Quản lý Users</a>
            <a href="apis.php"><i class="fas fa-plug"></i> Quản lý APIs</a>
            <a href="keys.php"><i class="fas fa-key"></i> API Keys</a>
            <a href="logs.php"><i class="fas fa-history"></i> Logs</a>
            <a href="settings.php"><i class="fas fa-cog"></i> Cài đặt</a>
            <a href="profile.php"><i class="fas fa-user"></i> Hồ sơ</a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navbar -->
        <div class="top-navbar">
            <button class="navbar-toggle">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="user-info">
                <span>Xin chào, <?php echo htmlspecialchars($user['full_name'] ?: $user['username']); ?></span>
                <div class="user-avatar">
                    <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                </div>
            </div>
        </div>

        <!-- Content -->
        <div class="container-fluid">
            <h2 class="mb-4">Dashboard</h2>
            
            <!-- Stats Cards -->
            <div class="row">
                <div class="col-md-3">
                    <div class="dashboard-card">
                        <div class="card-icon" style="background: linear-gradient(135deg, #667eea, #764ba2);">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="card-value"><?php echo $stats['total_users'] ?? 0; ?></div>
                        <div class="card-label">Tổng Users</div>
                        <div class="trend-up">
                            <i class="fas fa-arrow-up me-1"></i><?php echo $stats['active_users'] ?? 0; ?> active
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="dashboard-card">
                        <div class="card-icon" style="background: linear-gradient(135deg, #28a745, #20c997);">
                            <i class="fas fa-key"></i>
                        </div>
                        <div class="card-value"><?php echo $totalKeys; ?></div>
                        <div class="card-label">API Keys</div>
                        <div class="trend-up">
                            <i class="fas fa-check-circle me-1"></i><?php echo $activeKeys; ?> active
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="dashboard-card">
                        <div class="card-icon" style="background: linear-gradient(135deg, #17a2b8, #6f42c1);">
                            <i class="fas fa-plug"></i>
                        </div>
                        <div class="card-value"><?php echo $totalApis; ?></div>
                        <div class="card-label">APIs</div>
                        <div class="trend-up">
                            <i class="fas fa-check-circle me-1"></i><?php echo $activeApis; ?> active
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="dashboard-card">
                        <div class="card-icon" style="background: linear-gradient(135deg, #ffc107, #fd7e14);">
                            <i class="fas fa-rocket"></i>
                        </div>
                        <div class="card-value"><?php echo number_format($stats['today_spam'] ?? 0); ?></div>
                        <div class="card-label">Spam hôm nay</div>
                        <div class="trend-up">
                            <i class="fas fa-chart-line me-1"></i><?php echo $stats['week_spam'] ?? 0; ?> tuần này
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Second Row Stats -->
            <div class="row">
                <div class="col-md-3">
                    <div class="dashboard-card">
                        <div class="card-icon" style="background: linear-gradient(135deg, #dc3545, #c82333);">
                            <i class="fas fa-chart-bar"></i>
                        </div>
                        <div class="card-value"><?php echo number_format($stats['total_spam'] ?? 0); ?></div>
                        <div class="card-label">Tổng spam</div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="dashboard-card">
                        <div class="card-icon" style="background: linear-gradient(135deg, #6c757d, #495057);">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="card-value"><?php echo $stats['month_spam'] ?? 0; ?></div>
                        <div class="card-label">Spam tháng này</div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="dashboard-card">
                        <div class="card-icon" style="background: linear-gradient(135deg, #20c997, #0ca678);">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="card-value"><?php echo $totalApiRequests; ?></div>
                        <div class="card-label">Tổng API requests</div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="dashboard-card">
                        <div class="card-icon" style="background: linear-gradient(135deg, #e83e8c, #d63384);">
                            <i class="fas fa-database"></i>
                        </div>
                        <div class="card-value">MySQL</div>
                        <div class="card-label">Database</div>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <!-- Recent Activities -->
                <div class="col-md-6">
                    <div class="dashboard-card">
                        <h5 class="mb-3">Hoạt động gần đây</h5>
                        <div class="activity-list">
                            <?php if (empty($recentActivities)): ?>
                                <p class="text-muted text-center py-3">Chưa có hoạt động nào</p>
                            <?php else: ?>
                                <?php foreach ($recentActivities as $activity): 
                                    $activityItem = is_array($activity) ? (object)$activity : $activity;
                                ?>
                                    <div class="activity-item">
                                        <div class="d-flex justify-content-between">
                                            <div>
                                                <strong><?php echo htmlspecialchars($activityItem->username ?? 'System'); ?></strong>
                                                <span class="text-muted"><?php echo htmlspecialchars($activityItem->action); ?></span>
                                            </div>
                                            <span class="activity-time"><?php echo time_ago($activityItem->created_at); ?></span>
                                        </div>
                                        <div class="small text-muted mt-1">
                                            <?php echo htmlspecialchars($activityItem->details ?? ''); ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Top Users -->
                <div class="col-md-6">
                    <div class="dashboard-card">
                        <h5 class="mb-3">Top Users</h5>
                        <div class="activity-list">
                            <?php if (empty($topUsers)): ?>
                                <p class="text-muted text-center py-3">Chưa có dữ liệu</p>
                            <?php else: ?>
                                <?php foreach ($topUsers as $top): 
                                    $topItem = is_array($top) ? (object)$top : $top;
                                ?>
                                    <div class="activity-item">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <strong><?php echo htmlspecialchars($topItem->username); ?></strong>
                                            </div>
                                            <span class="badge bg-primary"><?php echo $topItem->spam_count; ?> lần</span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="row">
                <div class="col-12">
                    <div class="dashboard-card">
                        <h5 class="mb-3">Thao tác nhanh</h5>
                        <div class="row">
                            <div class="col-md-2 col-6 mb-2">
                                <a href="users.php" class="btn btn-outline-primary w-100">
                                    <i class="fas fa-users mb-2"></i><br>
                                    Quản lý Users
                                </a>
                            </div>
                            <div class="col-md-2 col-6 mb-2">
                                <a href="apis.php" class="btn btn-outline-success w-100">
                                    <i class="fas fa-plug mb-2"></i><br>
                                    Quản lý APIs
                                </a>
                            </div>
                            <div class="col-md-2 col-6 mb-2">
                                <a href="keys.php" class="btn btn-outline-warning w-100">
                                    <i class="fas fa-key mb-2"></i><br>
                                    API Keys
                                </a>
                            </div>
                            <div class="col-md-2 col-6 mb-2">
                                <a href="logs.php" class="btn btn-outline-info w-100">
                                    <i class="fas fa-history mb-2"></i><br>
                                    Xem Logs
                                </a>
                            </div>
                            <div class="col-md-2 col-6 mb-2">
                                <a href="../index.php" target="_blank" class="btn btn-outline-danger w-100">
                                    <i class="fas fa-external-link-alt mb-2"></i><br>
                                    Về trang chủ
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Loading -->
    <div class="loading" id="loading">
        <div class="spinner"></div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/admin.js"></script>
</body>
</html>