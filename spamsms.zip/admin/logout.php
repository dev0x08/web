<?php
// admin/logout.php
session_start();

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../includes/Database.php';
require_once __DIR__ . '/../includes/UserManager.php';

$userManager = new UserManager();

if (isset($_SESSION['admin_token'])) {
    $userManager->logout($_SESSION['admin_token']);
}

session_destroy();
header('Location: login.php');
exit;