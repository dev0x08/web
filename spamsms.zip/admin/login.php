<?php
// admin/login.php
session_start();

// Define error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include files with error handling
try {
    require_once __DIR__ . '/../config/database.php';
    require_once __DIR__ . '/../config/constants.php';
    require_once __DIR__ . '/../includes/Database.php';
    require_once __DIR__ . '/../includes/UserManager.php';
    require_once __DIR__ . '/../includes/functions.php';
} catch (Exception $e) {
    die('Lỗi include file: ' . $e->getMessage());
}

$userManager = new UserManager();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    $result = $userManager->authenticate($username, $password);
    
    if ($result['success']) {
        $_SESSION['admin_token'] = $result['token'];
        $_SESSION['admin_user'] = $result['user'];
        header('Location: index.php');
        exit;
    } else {
        $error = $result['message'];
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - WusTeam SpamSMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .login-box {
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 30px 60px rgba(0,0,0,0.3);
            max-width: 400px;
            width: 100%;
        }
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo i {
            font-size: 48px;
            color: #667eea;
        }
        .logo h3 {
            margin-top: 10px;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <div class="logo">
            <i class="fas fa-shield-alt"></i>
            <h3>Admin Login</h3>
            <p class="text-muted">WusTeam SpamSMS</p>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Tên đăng nhập</label>
                <input type="text" name="username" class="form-control" required autofocus>
            </div>
            
            <div class="mb-3">
                <label class="form-label">Mật khẩu</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            
            <button type="submit" class="btn btn-primary w-100">Đăng nhập</button>
            
            <div class="text-center mt-3">
                <a href="../index.php" class="text-muted">Quay lại trang chủ</a>
            </div>
        </form>
    </div>
    
    <script src="https://kit.fontawesome.com/your-kit.js" crossorigin="anonymous"></script>
</body>
</html>