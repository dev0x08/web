<?php
// admin/profile.php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../includes/Database.php';
require_once __DIR__ . '/../includes/UserManager.php';
require_once __DIR__ . '/../includes/KeyManager.php';
require_once __DIR__ . '/../includes/functions.php';

$userManager = new UserManager();

// Kiểm tra session
$token = $_SESSION['admin_token'] ?? '';
$user = $userManager->validateToken($token);

if (!$user['valid']) {
    header('Location: login.php');
    exit;
}

// Khởi tạo KeyManager
$keyManager = new KeyManager();

// Lấy thông tin user chi tiết
$userInfo = $userManager->getUserById($user['user_id']);

// Xử lý cập nhật profile
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_profile') {
        $data = [
            'full_name' => $_POST['full_name'] ?? '',
            'email' => $_POST['email'] ?? ''
        ];
        
        if (!empty($_POST['password'])) {
            $data['password'] = $_POST['password'];
        }
        
        $result = $userManager->updateUser($user['user_id'], $data);
        
        if ($result) {
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Cập nhật thông tin thành công!'];
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Không thể cập nhật thông tin!'];
        }
        header('Location: profile.php');
        exit;
    }
    
    if ($action === 'generate_key') {
        $name = $_POST['key_name'] ?? 'API Key ' . date('Y-m-d');
        $newKey = $keyManager->generateKey($user['user_id'], $name);
        
        if ($newKey) {
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Tạo key thành công!', 'key' => $newKey];
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Không thể tạo key!'];
        }
        header('Location: profile.php');
        exit;
    }
}

// Lấy API keys của user
$allKeys = $keyManager->getKeysList();
$userKeys = array_filter($allKeys, function($k) use ($user) {
    $keyItem = is_array($k) ? (object)$k : $k;
    return isset($keyItem->user_id) && $keyItem->user_id == $user['user_id'];
});

// Lấy lịch sử spam
$spamHistory = $userManager->getSpamHistory($user['user_id'], 20);

$message = $_SESSION['message'] ?? null;
unset($_SESSION['message']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hồ sơ - WusTeam Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        .user-avatar-large {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            font-weight: bold;
            margin: 0 auto 20px;
            border: 4px solid #fff;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        .info-item {
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        .info-item:last-child {
            border-bottom: none;
        }
        .info-label {
            font-weight: 600;
            color: #666;
            width: 120px;
            display: inline-block;
        }
        .info-value {
            color: #333;
        }
        .key-item {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 10px;
            border-left: 3px solid #667eea;
        }
        .key-code {
            font-family: monospace;
            background: #e9ecef;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 13px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h3>WusTeam</h3>
            <p>Admin Panel</p>
        </div>
        <div class="sidebar-menu">
            <a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="users.php"><i class="fas fa-users"></i> Quản lý Users</a>
            <a href="apis.php"><i class="fas fa-plug"></i> Quản lý APIs</a>
            <a href="keys.php"><i class="fas fa-key"></i> API Keys</a>
            <a href="logs.php"><i class="fas fa-history"></i> Logs</a>
            <a href="settings.php"><i class="fas fa-cog"></i> Cài đặt</a>
            <a href="profile.php" class="active"><i class="fas fa-user"></i> Hồ sơ</a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navbar -->
        <div class="top-navbar">
            <button class="navbar-toggle">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="user-info">
                <span>Xin chào, <?php echo htmlspecialchars($user['full_name'] ?: $user['username']); ?></span>
                <div class="user-avatar">
                    <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                </div>
            </div>
        </div>

        <!-- Content -->
        <div class="container-fluid">
            <h2 class="mb-4">Hồ sơ cá nhân</h2>
            
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message['type']; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message['text']; ?>
                    <?php if (isset($message['key'])): ?>
                        <br><strong>Key mới: </strong> 
                        <code class="key-code"><?php echo $message['key']; ?></code>
                        <button class="btn btn-sm btn-outline-primary ms-2" onclick="copyKey('<?php echo $message['key']; ?>')">
                            <i class="fas fa-copy"></i> Copy
                        </button>
                    <?php endif; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <div class="row">
                <!-- Left Column - Profile Info -->
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body text-center">
                            <div class="user-avatar-large">
                                <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                            </div>
                            
                            <h4><?php echo htmlspecialchars($userInfo->full_name ?: $user['username']); ?></h4>
                            <p class="text-muted">@<?php echo htmlspecialchars($user['username']); ?></p>
                            
                            <?php if ($user['role'] === 'admin'): ?>
                                <span class="badge bg-danger mb-3">Administrator</span>
                            <?php else: ?>
                                <span class="badge bg-info mb-3">User</span>
                            <?php endif; ?>
                            
                            <hr>
                            
                            <div class="text-start">
                                <div class="info-item">
                                    <span class="info-label"><i class="fas fa-envelope me-2"></i>Email:</span>
                                    <span class="info-value"><?php echo htmlspecialchars($userInfo->email); ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label"><i class="fas fa-calendar me-2"></i>Tham gia:</span>
                                    <span class="info-value"><?php echo date('d/m/Y', strtotime($userInfo->created_at)); ?></span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label"><i class="fas fa-clock me-2"></i>Last login:</span>
                                    <span class="info-value"><?php echo $userInfo->last_login ? time_ago($userInfo->last_login) : 'Chưa đăng nhập'; ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Stats Card -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Thống kê</h5>
                        </div>
                        <div class="card-body">
                            <div class="row text-center">
                                <div class="col-6">
                                    <h3 class="text-primary"><?php echo count($userKeys); ?></h3>
                                    <small class="text-muted">API Keys</small>
                                </div>
                                <div class="col-6">
                                    <h3 class="text-success"><?php echo count($spamHistory); ?></h3>
                                    <small class="text-muted">Lần spam</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Right Column - Edit Profile -->
                <div class="col-md-8">
                    <!-- Edit Profile Form -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Chỉnh sửa hồ sơ</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="action" value="update_profile">
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label class="form-label">Username</label>
                                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($userInfo->username); ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group mb-3">
                                            <label class="form-label">Họ tên</label>
                                            <input type="text" class="form-control" name="full_name" value="<?php echo htmlspecialchars($userInfo->full_name); ?>">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="form-group mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($userInfo->email); ?>" required>
                                </div>
                                
                                <hr>
                                
                                <div class="form-group mb-3">
                                    <label class="form-label">Mật khẩu mới (để trống nếu không đổi)</label>
                                    <input type="password" class="form-control" name="password" placeholder="Nhập mật khẩu mới">
                                </div>
                                
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save me-2"></i>Cập nhật
                                </button>
                            </form>
                        </div>
                    </div>
                    
                    <!-- API Keys -->
                    <div class="card mb-4">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">API Keys của tôi</h5>
                            <button class="btn btn-sm btn-primary" onclick="showGenerateKeyModal()">
                                <i class="fas fa-plus me-2"></i>Tạo key mới
                            </button>
                        </div>
                        <div class="card-body">
                            <?php if (empty($userKeys)): ?>
                                <div class="text-center py-4">
                                    <i class="fas fa-key fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">Bạn chưa có API Key nào</p>
                                </div>
                            <?php else: ?>
                                <?php foreach ($userKeys as $key): 
                                    $keyItem = is_array($key) ? (object)$key : $key;
                                ?>
                                    <div class="key-item">
                                        <div class="d-flex justify-content-between align-items-start">
                                            <div>
                                                <strong><?php echo htmlspecialchars($keyItem->name ?: 'Không tên'); ?></strong>
                                                <?php if ($keyItem->status === 'active'): ?>
                                                    <span class="badge bg-success ms-2">Active</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary ms-2">Inactive</span>
                                                <?php endif; ?>
                                            </div>
                                            <button class="btn btn-sm btn-outline-primary" onclick="copyKey('<?php echo $keyItem->api_key; ?>')">
                                                <i class="fas fa-copy"></i>
                                            </button>
                                        </div>
                                        <div class="mt-2">
                                            <code class="key-code"><?php echo $keyItem->api_key; ?></code>
                                        </div>
                                        <div class="mt-2 small text-muted">
                                            <i class="fas fa-clock me-1"></i> Hết hạn: 
                                            <?php echo $keyItem->expires_at ? date('d/m/Y', strtotime($keyItem->expires_at)) : 'Không giới hạn'; ?>
                                            | <i class="fas fa-chart-line me-1"></i> Đã dùng: <?php echo $keyItem->usage_count; ?> lần
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Spam History -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Lịch sử spam gần đây</h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($spamHistory)): ?>
                                <div class="text-center py-4">
                                    <i class="fas fa-history fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">Chưa có lịch sử spam</p>
                                </div>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Thời gian</th>
                                                <th>Số điện thoại</th>
                                                <th>Số lần</th>
                                                <th>Thành công</th>
                                                <th>Tỉ lệ</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($spamHistory as $log): 
                                                $logItem = is_array($log) ? (object)$log : $log;
                                            ?>
                                            <tr>
                                                <td><?php echo time_ago($logItem->created_at); ?></td>
                                                <td><?php echo format_phone($logItem->phone_number); ?></td>
                                                <td><?php echo $logItem->total_requests; ?></td>
                                                <td class="text-success"><?php echo $logItem->success_count; ?></td>
                                                <td>
                                                    <div class="progress" style="height: 20px;">
                                                        <div class="progress-bar bg-success" style="width: <?php echo $logItem->success_rate; ?>%">
                                                            <?php echo $logItem->success_rate; ?>%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Generate Key Modal -->
    <div class="modal" id="generateKeyModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title">Tạo API Key mới</h5>
                        <button type="button" class="modal-close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="action" value="generate_key">
                        
                        <div class="form-group">
                            <label class="form-label">Tên key</label>
                            <input type="text" class="form-control" name="key_name" value="API Key <?php echo date('Y-m-d'); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Số ngày hết hạn</label>
                            <input type="number" class="form-control" name="days" value="30" min="1" max="365" required>
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            Key sẽ tự động hết hạn sau số ngày đã chọn
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Tạo</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Loading -->
    <div class="loading" id="loading">
        <div class="spinner"></div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/admin.js"></script>
    <script>
        // Show generate key modal
        function showGenerateKeyModal() {
            new bootstrap.Modal(document.getElementById('generateKeyModal')).show();
        }
        
        // Copy key to clipboard
        function copyKey(key) {
            navigator.clipboard.writeText(key).then(() => {
                showToast('Đã copy key vào clipboard!', 'success');
            }).catch(() => {
                showToast('Không thể copy key', 'error');
            });
        }
        
        // Show toast
        function showToast(message, type = 'info') {
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            toast.innerHTML = `
                <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'times-circle' : 'info-circle'}"></i>
                <span>${message}</span>
            `;
            
            const container = document.querySelector('.toast-container') || (() => {
                const div = document.createElement('div');
                div.className = 'toast-container';
                document.body.appendChild(div);
                return div;
            })();
            
            container.appendChild(toast);
            
            setTimeout(() => {
                toast.remove();
            }, 3000);
        }
        
        // Handle modal close buttons
        document.querySelectorAll('[data-dismiss="modal"]').forEach(btn => {
            btn.addEventListener('click', function() {
                const modal = this.closest('.modal');
                const modalInstance = bootstrap.Modal.getInstance(modal);
                if (modalInstance) {
                    modalInstance.hide();
                }
            });
        });
    </script>
</body>
</html>