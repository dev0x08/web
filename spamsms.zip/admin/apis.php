<?php
// admin/apis.php
session_start();
require_once __DIR__ . '/../includes/UserManager.php';
require_once __DIR__ . '/../includes/APIManager.php';
require_once __DIR__ . '/../includes/functions.php';

$userManager = new UserManager();
$apiManager = new APIManager();

// Kiểm tra session
$token = $_SESSION['admin_token'] ?? '';
$user = $userManager->validateToken($token);

if (!$user['valid'] || $user['role'] !== 'admin') {
    redirect('login.php');
}

// Xử lý actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add') {
        $data = [
            'name' => $_POST['name'],
            'url' => $_POST['url'],
            'method' => $_POST['method'],
            'headers' => $_POST['headers'] ?? '',
            'body' => $_POST['body'] ?? '',
            'body_type' => $_POST['body_type'] ?? 'json',
            'params' => $_POST['params'] ?? '',
            'note' => $_POST['note'] ?? '',
            'status' => isset($_POST['status']) ? 1 : 0
        ];
        
        $result = $apiManager->addAPI($data, $user['user_id']);
        if ($result) {
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Thêm API thành công!'];
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Không thể thêm API!'];
        }
        redirect('apis.php');
    }
    
    if ($action === 'update') {
        $id = $_POST['id'];
        $data = [
            'name' => $_POST['name'],
            'url' => $_POST['url'],
            'method' => $_POST['method'],
            'headers' => $_POST['headers'] ?? '',
            'body' => $_POST['body'] ?? '',
            'body_type' => $_POST['body_type'] ?? 'json',
            'params' => $_POST['params'] ?? '',
            'note' => $_POST['note'] ?? '',
            'status' => isset($_POST['status']) ? 1 : 0
        ];
        
        $result = $apiManager->updateAPI($id, $data);
        if ($result) {
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Cập nhật API thành công!'];
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Không thể cập nhật API!'];
        }
        redirect('apis.php');
    }
    
    if ($action === 'delete') {
        $id = $_POST['id'];
        $result = $apiManager->deleteAPI($id);
        if ($result) {
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Xóa API thành công!'];
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Không thể xóa API!'];
        }
        redirect('apis.php');
    }
    
    if ($action === 'toggle') {
        $id = $_POST['id'];
        $result = $apiManager->toggleAPI($id);
        if ($result) {
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Thay đổi trạng thái thành công!'];
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Không thể thay đổi trạng thái!'];
        }
        redirect('apis.php');
    }
    
    if ($action === 'import') {
        if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
            $count = $apiManager->importAPIs($_FILES['file']['tmp_name'], $user['user_id']);
            if ($count) {
                $_SESSION['message'] = ['type' => 'success', 'text' => "Import $count APIs thành công!"];
            } else {
                $_SESSION['message'] = ['type' => 'error', 'text' => 'Không thể import file!'];
            }
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Vui lòng chọn file!'];
        }
        redirect('apis.php');
    }
}

// Lấy danh sách APIs
$apis = $apiManager->getAllAPIs();

// Thống kê
$totalApis = count($apis);
$activeApis = 0;
$totalRequests = 0;
$avgSuccessRate = 0;

foreach ($apis as $api) {
    if ($api->status === 'active') $activeApis++;
    $totalRequests += $api->total_requests;
    $avgSuccessRate += $api->success_rate;
}

if ($totalApis > 0) {
    $avgSuccessRate = round($avgSuccessRate / $totalApis, 2);
}

$message = $_SESSION['message'] ?? null;
unset($_SESSION['message']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý APIs - WusTeam Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h3>WusTeam</h3>
            <p>Admin Panel</p>
        </div>
        <div class="sidebar-menu">
            <a href="index.php"><i class="fas fa-dashboard"></i> Dashboard</a>
            <a href="users.php"><i class="fas fa-users"></i> Quản lý Users</a>
            <a href="apis.php" class="active"><i class="fas fa-plug"></i> Quản lý APIs</a>
            <a href="keys.php"><i class="fas fa-key"></i> API Keys</a>
            <a href="logs.php"><i class="fas fa-history"></i> Logs</a>
            <a href="settings.php"><i class="fas fa-cog"></i> Cài đặt</a>
            <a href="profile.php"><i class="fas fa-user"></i> Hồ sơ</a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navbar -->
        <div class="top-navbar">
            <button class="navbar-toggle">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="user-info">
                <span>Xin chào, <?php echo htmlspecialchars($user['full_name'] ?: $user['username']); ?></span>
                <div class="user-avatar">
                    <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                </div>
            </div>
        </div>

        <!-- Content -->
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Quản lý APIs</h2>
                <div>
                    <button class="btn btn-success me-2" onclick="showAddModal()">
                        <i class="fas fa-plus me-2"></i>Thêm API
                    </button>
                    <button class="btn btn-warning me-2" onclick="exportAPIs()">
                        <i class="fas fa-download me-2"></i>Export
                    </button>
                    <button class="btn btn-info" onclick="document.getElementById('importFile').click()">
                        <i class="fas fa-upload me-2"></i>Import
                    </button>
                    <form method="POST" enctype="multipart/form-data" style="display: none;">
                        <input type="hidden" name="action" value="import">
                        <input type="file" id="importFile" name="file" accept=".json" onchange="this.form.submit()">
                    </form>
                </div>
            </div>
            
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message['type'] === 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message['text']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Stats Cards -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-icon">
                            <i class="fas fa-plug"></i>
                        </div>
                        <div class="stats-value"><?php echo $totalApis; ?></div>
                        <div class="stats-label">Tổng số APIs</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-icon" style="background: linear-gradient(135deg, #28a745, #20c997);">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="stats-value"><?php echo $activeApis; ?></div>
                        <div class="stats-label">Đang hoạt động</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-icon" style="background: linear-gradient(135deg, #17a2b8, #6f42c1);">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div class="stats-value"><?php echo $avgSuccessRate; ?>%</div>
                        <div class="stats-label">Tỉ lệ thành công TB</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-icon" style="background: linear-gradient(135deg, #ffc107, #fd7e14);">
                            <i class="fas fa-rocket"></i>
                        </div>
                        <div class="stats-value"><?php echo number_format($totalRequests); ?></div>
                        <div class="stats-label">Tổng requests</div>
                    </div>
                </div>
            </div>
            
            <!-- Search -->
            <div class="row mb-3">
                <div class="col-md-6">
                    <input type="text" class="form-control" id="searchInput" placeholder="Tìm kiếm API..." onkeyup="searchTable()">
                </div>
                <div class="col-md-6 text-end">
                    <button class="btn btn-outline-secondary" onclick="exportToCSV()">
                        <i class="fas fa-file-csv me-2"></i>Xuất CSV
                    </button>
                </div>
            </div>
            
            <!-- APIs Table -->
            <div class="data-table">
                <div class="table-responsive">
                    <table class="table" id="apisTable">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Tên API</th>
                                <th>Method</th>
                                <th>URL</th>
                                <th>Trạng thái</th>
                                <th>Tỉ lệ success</th>
                                <th>Requests</th>
                                <th>Lần cuối</th>
                                <th>Ngày tạo</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($apis as $api): ?>
                            <tr>
                                <td><?php echo $api->id; ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($api->name); ?></strong>
                                    <?php if ($api->note): ?>
                                        <br><small class="text-muted"><?php echo htmlspecialchars($api->note); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge bg-info"><?php echo $api->method; ?></span>
                                </td>
                                <td>
                                    <div style="max-width: 200px; overflow: hidden; text-overflow: ellipsis;">
                                        <?php echo htmlspecialchars($api->url); ?>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($api->status === 'active'): ?>
                                        <span class="badge badge-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="progress" style="height: 20px;">
                                        <div class="progress-bar bg-success" style="width: <?php echo $api->success_rate; ?>%">
                                            <?php echo $api->success_rate; ?>%
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo number_format($api->total_requests); ?></td>
                                <td>
                                    <?php 
                                    if ($api->last_check) {
                                        echo time_ago($api->last_check);
                                    } else {
                                        echo 'Chưa kiểm tra';
                                    }
                                    ?>
                                </td>
                                <td><?php echo date('d/m/Y', strtotime($api->created_at)); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-outline-primary" onclick="editAPI(<?php echo $api->id; ?>)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-info" onclick="testAPI(<?php echo $api->id; ?>)">
                                        <i class="fas fa-flask"></i>
                                    </button>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="toggle">
                                        <input type="hidden" name="id" value="<?php echo $api->id; ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-warning">
                                            <i class="fas fa-power-off"></i>
                                        </button>
                                    </form>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Bạn có chắc muốn xóa API này?')">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $api->id; ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            
                            <?php if (empty($apis)): ?>
                            <tr>
                                <td colspan="10" class="text-center py-4">
                                    <i class="fas fa-plug fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">Chưa có API nào. Hãy thêm API mới!</p>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Add/Edit Modal -->
    <div class="modal" id="apiModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" id="apiForm">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalTitle">Thêm API mới</h5>
                        <button type="button" class="modal-close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="action" id="formAction" value="add">
                        <input type="hidden" name="id" id="apiId">
                        
                        <div class="form-group">
                            <label class="form-label">Tên API</label>
                            <input type="text" class="form-control" id="apiName" name="name" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Method</label>
                            <select class="form-control" id="apiMethod" name="method" required>
                                <option value="GET">GET</option>
                                <option value="POST">POST</option>
                                <option value="PUT">PUT</option>
                                <option value="DELETE">DELETE</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">URL</label>
                            <input type="url" class="form-control" id="apiUrl" name="url" required>
                            <small class="text-muted">Sử dụng {{phone}} cho số điện thoại</small>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Headers (mỗi dòng một header)</label>
                            <textarea class="form-control" id="apiHeaders" name="headers" rows="3" placeholder="accept: application/json&#10;content-type: application/json"></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Body Type</label>
                                    <select class="form-control" id="apiBodyType" name="body_type">
                                        <option value="json">JSON</option>
                                        <option value="form">Form Data</option>
                                        <option value="none">None</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Params (cho GET)</label>
                                    <input type="text" class="form-control" id="apiParams" name="params" placeholder="phone={{phone}}">
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Body</label>
                            <textarea class="form-control" id="apiBody" name="body" rows="5" placeholder='{"phone":"{{phone}}"}'>{"phone":"{{phone}}"}</textarea>
                            <small class="text-muted">Hỗ trợ: {{phone}}, {{phone_raw}}, {{time}}, {{random}}</small>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Ghi chú</label>
                            <input type="text" class="form-control" id="apiNote" name="note">
                        </div>
                        
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="apiStatus" name="status" checked>
                            <label class="form-check-label" for="apiStatus">Kích hoạt API</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Lưu</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Test Modal -->
    <div class="modal" id="testModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Test API</h5>
                    <button type="button" class="modal-close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-label">Số điện thoại test</label>
                        <input type="text" class="form-control" id="testPhone" value="0987654321">
                    </div>
                    
                    <div id="testResult" style="display: none;">
                        <hr>
                        <h6>Kết quả:</h6>
                        <pre id="testResultContent" style="background: #f8f9fa; padding: 10px; border-radius: 5px; max-height: 300px; overflow: auto;"></pre>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                    <button type="button" class="btn btn-primary" onclick="runTest()">Test</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Loading -->
    <div class="loading" id="loading">
        <div class="spinner"></div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/admin.js"></script>
    <script>
        let currentApiId = null;
        
        // Show add modal
        function showAddModal() {
            document.getElementById('formAction').value = 'add';
            document.getElementById('modalTitle').textContent = 'Thêm API mới';
            document.getElementById('apiForm').reset();
            document.getElementById('apiId').value = '';
            new bootstrap.Modal(document.getElementById('apiModal')).show();
        }
        
        // Edit API
        function editAPI(id) {
            currentApiId = id;
            window.loading.show();
            
            fetch(`/api/api_manager.php?action=get&id=${id}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        const api = data.api;
                        
                        document.getElementById('formAction').value = 'update';
                        document.getElementById('modalTitle').textContent = 'Cập nhật API';
                        document.getElementById('apiId').value = api.id;
                        document.getElementById('apiName').value = api.name;
                        document.getElementById('apiMethod').value = api.method;
                        document.getElementById('apiUrl').value = api.url;
                        
                        if (api.headers && Array.isArray(api.headers)) {
                            document.getElementById('apiHeaders').value = api.headers.join('\n');
                        }
                        
                        document.getElementById('apiBodyType').value = api.body_type || 'json';
                        document.getElementById('apiParams').value = api.params || '';
                        document.getElementById('apiBody').value = api.body || '';
                        document.getElementById('apiNote').value = api.note || '';
                        document.getElementById('apiStatus').checked = api.status === 'active';
                        
                        new bootstrap.Modal(document.getElementById('apiModal')).show();
                    } else {
                        window.toast.show('Không thể tải thông tin API', 'error');
                    }
                })
                .catch(error => {
                    window.toast.show('Lỗi: ' + error, 'error');
                })
                .finally(() => {
                    window.loading.hide();
                });
        }
        
        // Test API
        function testAPI(id) {
            currentApiId = id;
            document.getElementById('testResult').style.display = 'none';
            new bootstrap.Modal(document.getElementById('testModal')).show();
        }
        
        // Run test
        function runTest() {
            const phone = document.getElementById('testPhone').value.trim();
            
            if (!phone) {
                window.toast.show('Vui lòng nhập số điện thoại', 'warning');
                return;
            }
            
            window.loading.show();
            
            fetch(`/api/api_manager.php?action=test&id=${currentApiId}&phone=${phone}`)
                .then(response => response.json())
                .then(data => {
                    const result = data.result;
                    
                    let resultHtml = '';
                    resultHtml += `Status: ${result.success ? '✅ Success' : '❌ Failed'}\n`;
                    resultHtml += `HTTP Code: ${result.http_code || 'N/A'}\n`;
                    if (result.error) resultHtml += `Error: ${result.error}\n`;
                    resultHtml += `URL: ${result.url}\n`;
                    if (result.body) resultHtml += `Body: ${result.body}\n`;
                    resultHtml += `\nResponse:\n${result.response || 'No response'}`;
                    
                    document.getElementById('testResultContent').textContent = resultHtml;
                    document.getElementById('testResult').style.display = 'block';
                    
                    if (data.status === 'success') {
                        window.toast.show('Test thành công!', 'success');
                    } else {
                        window.toast.show('Test thất bại!', 'error');
                    }
                })
                .catch(error => {
                    window.toast.show('Lỗi: ' + error, 'error');
                })
                .finally(() => {
                    window.loading.hide();
                });
        }
        
        // Export APIs
        function exportAPIs() {
            window.location.href = '/api/api_manager.php?action=export';
        }
        
        // Export to CSV
        function exportToCSV() {
            TableUtils.exportToCSV('apisTable', 'apis_export_' + new Date().toISOString().slice(0,10));
        }
        
        // Search table
        function searchTable() {
            const input = document.getElementById('searchInput');
            TableUtils.search('apisTable', input);
        }
        
        // Handle modal close buttons
        document.querySelectorAll('[data-dismiss="modal"]').forEach(btn => {
            btn.addEventListener('click', function() {
                const modal = this.closest('.modal');
                bootstrap.Modal.getInstance(modal).hide();
            });
        });
    </script>
</body>
</html>