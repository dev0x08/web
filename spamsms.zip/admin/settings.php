<?php
// admin/settings.php
session_start();
require_once __DIR__ . '/../includes/UserManager.php';
require_once __DIR__ . '/../includes/functions.php';

$userManager = new UserManager();

// Kiểm tra session
$token = $_SESSION['admin_token'] ?? '';
$user = $userManager->validateToken($token);

if (!$user['valid'] || $user['role'] !== 'admin') {
    redirect('login.php');
}

// Xử lý lưu cài đặt
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $settings = [
        'site_name' => $_POST['site_name'] ?? 'WusTeam SpamSMS',
        'site_url' => $_POST['site_url'] ?? '',
        'admin_email' => $_POST['admin_email'] ?? '',
        'items_per_page' => (int)($_POST['items_per_page'] ?? 20),
        'session_lifetime' => (int)($_POST['session_lifetime'] ?? 7),
        'key_expiry_days' => (int)($_POST['key_expiry_days'] ?? 30),
        'rate_limit' => (int)($_POST['rate_limit'] ?? 10),
        'rate_limit_window' => (int)($_POST['rate_limit_window'] ?? 3600),
        'curl_timeout' => (int)($_POST['curl_timeout'] ?? 30),
        'max_redirects' => (int)($_POST['max_redirects'] ?? 10),
        'debug_mode' => isset($_POST['debug_mode']) ? 1 : 0,
        'maintenance_mode' => isset($_POST['maintenance_mode']) ? 1 : 0
    ];
    
    // Lưu vào file config
    $configContent = "<?php\n\n";
    $configContent .= "// Auto-generated config file\n";
    $configContent .= "define('SITE_NAME', '" . addslashes($settings['site_name']) . "');\n";
    $configContent .= "define('SITE_URL', '" . addslashes($settings['site_url']) . "');\n";
    $configContent .= "define('ADMIN_EMAIL', '" . addslashes($settings['admin_email']) . "');\n";
    $configContent .= "define('ITEMS_PER_PAGE', " . $settings['items_per_page'] . ");\n";
    $configContent .= "define('SESSION_LIFETIME', " . ($settings['session_lifetime'] * 86400) . ");\n";
    $configContent .= "define('KEY_EXPIRY_DAYS', " . $settings['key_expiry_days'] . ");\n";
    $configContent .= "define('RATE_LIMIT', " . $settings['rate_limit'] . ");\n";
    $configContent .= "define('RATE_LIMIT_WINDOW', " . $settings['rate_limit_window'] . ");\n";
    $configContent .= "define('CURL_TIMEOUT', " . $settings['curl_timeout'] . ");\n";
    $configContent .= "define('MAX_REDIRECTS', " . $settings['max_redirects'] . ");\n";
    $configContent .= "define('DEBUG_MODE', " . ($settings['debug_mode'] ? 'true' : 'false') . ");\n";
    $configContent .= "define('MAINTENANCE_MODE', " . ($settings['maintenance_mode'] ? 'true' : 'false') . ");\n";
    
    file_put_contents(__DIR__ . '/../config/settings.php', $configContent);
    
    $_SESSION['message'] = ['type' => 'success', 'text' => 'Đã lưu cài đặt!'];
    redirect('settings.php');
}

// Đọc cài đặt hiện tại
$settings = [
    'site_name' => defined('SITE_NAME') ? SITE_NAME : 'WusTeam SpamSMS',
    'site_url' => defined('SITE_URL') ? SITE_URL : '',
    'admin_email' => defined('ADMIN_EMAIL') ? ADMIN_EMAIL : '',
    'items_per_page' => defined('ITEMS_PER_PAGE') ? ITEMS_PER_PAGE : 20,
    'session_lifetime' => defined('SESSION_LIFETIME') ? SESSION_LIFETIME / 86400 : 7,
    'key_expiry_days' => defined('KEY_EXPIRY_DAYS') ? KEY_EXPIRY_DAYS : 30,
    'rate_limit' => defined('RATE_LIMIT') ? RATE_LIMIT : 10,
    'rate_limit_window' => defined('RATE_LIMIT_WINDOW') ? RATE_LIMIT_WINDOW : 3600,
    'curl_timeout' => defined('CURL_TIMEOUT') ? CURL_TIMEOUT : 30,
    'max_redirects' => defined('MAX_REDIRECTS') ? MAX_REDIRECTS : 10,
    'debug_mode' => defined('DEBUG_MODE') ? DEBUG_MODE : false,
    'maintenance_mode' => defined('MAINTENANCE_MODE') ? MAINTENANCE_MODE : false
];

$message = $_SESSION['message'] ?? null;
unset($_SESSION['message']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cài đặt - WusTeam Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h3>WusTeam</h3>
            <p>Admin Panel</p>
        </div>
        <div class="sidebar-menu">
            <a href="index.php"><i class="fas fa-dashboard"></i> Dashboard</a>
            <a href="users.php"><i class="fas fa-users"></i> Quản lý Users</a>
            <a href="apis.php"><i class="fas fa-plug"></i> Quản lý APIs</a>
            <a href="keys.php"><i class="fas fa-key"></i> API Keys</a>
            <a href="logs.php"><i class="fas fa-history"></i> Logs</a>
            <a href="settings.php" class="active"><i class="fas fa-cog"></i> Cài đặt</a>
            <a href="profile.php"><i class="fas fa-user"></i> Hồ sơ</a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navbar -->
        <div class="top-navbar">
            <button class="navbar-toggle">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="user-info">
                <span>Xin chào, <?php echo htmlspecialchars($user['full_name'] ?: $user['username']); ?></span>
                <div class="user-avatar">
                    <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                </div>
            </div>
        </div>

        <!-- Content -->
        <div class="container-fluid">
            <h2 class="mb-4">Cài đặt hệ thống</h2>
            
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message['type'] === 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message['text']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <form method="POST">
                <!-- General Settings -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Cài đặt chung</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Tên website</label>
                                    <input type="text" class="form-control" name="site_name" value="<?php echo htmlspecialchars($settings['site_name']); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">URL website</label>
                                    <input type="url" class="form-control" name="site_url" value="<?php echo htmlspecialchars($settings['site_url']); ?>">
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Email admin</label>
                                    <input type="email" class="form-control" name="admin_email" value="<?php echo htmlspecialchars($settings['admin_email']); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Số item mỗi trang</label>
                                    <input type="number" class="form-control" name="items_per_page" value="<?php echo $settings['items_per_page']; ?>" min="5" max="100">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Security Settings -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Cài đặt bảo mật</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label">Session lifetime (ngày)</label>
                                    <input type="number" class="form-control" name="session_lifetime" value="<?php echo $settings['session_lifetime']; ?>" min="1" max="30">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label">Key expiry (ngày)</label>
                                    <input type="number" class="form-control" name="key_expiry_days" value="<?php echo $settings['key_expiry_days']; ?>" min="1" max="365">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label">Rate limit (số lần)</label>
                                    <input type="number" class="form-control" name="rate_limit" value="<?php echo $settings['rate_limit']; ?>" min="1" max="100">
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Rate limit window (giây)</label>
                                    <input type="number" class="form-control" name="rate_limit_window" value="<?php echo $settings['rate_limit_window']; ?>" min="60" max="86400">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-check" style="margin-top: 32px;">
                                    <input type="checkbox" class="form-check-input" name="debug_mode" id="debug_mode" <?php echo $settings['debug_mode'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="debug_mode">Chế độ debug</label>
                                    <small class="d-block text-muted">Hiển thị lỗi chi tiết</small>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" name="maintenance_mode" id="maintenance_mode" <?php echo $settings['maintenance_mode'] ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="maintenance_mode">Chế độ bảo trì</label>
                            <small class="d-block text-muted">Chỉ admin mới có thể truy cập</small>
                        </div>
                    </div>
                </div>
                
                <!-- API Settings -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Cài đặt API</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">CURL Timeout (giây)</label>
                                    <input type="number" class="form-control" name="curl_timeout" value="<?php echo $settings['curl_timeout']; ?>" min="5" max="120">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Max Redirects</label>
                                    <input type="number" class="form-control" name="max_redirects" value="<?php echo $settings['max_redirects']; ?>" min="0" max="20">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- System Info -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Thông tin hệ thống</h5>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <tr>
                                <td>PHP Version</td>
                                <td><?php echo phpversion(); ?></td>
                            </tr>
                            <tr>
                                <td>Server Software</td>
                                <td><?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'; ?></td>
                            </tr>
                            <tr>
                                <td>Database</td>
                                <td>MySQL <?php 
                                    try {
                                        $db = Database::getInstance();
                                        $stmt = $db->query("SELECT VERSION() as version");
                                        $version = $stmt->fetch();
                                        echo $version['version'];
                                    } catch (Exception $e) {
                                        echo 'Not connected';
                                    }
                                ?></td>
                            </tr>
                            <tr>
                                <td>Upload Max Filesize</td>
                                <td><?php echo ini_get('upload_max_filesize'); ?></td>
                            </tr>
                            <tr>
                                <td>Post Max Size</td>
                                <td><?php echo ini_get('post_max_size'); ?></td>
                            </tr>
                            <tr>
                                <td>Max Execution Time</td>
                                <td><?php echo ini_get('max_execution_time'); ?>s</td>
                            </tr>
                            <tr>
                                <td>Memory Limit</td>
                                <td><?php echo ini_get('memory_limit'); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-2"></i>Lưu cài đặt
                </button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/admin.js"></script>
</body>
</html>