<?php
// admin/logs.php
session_start();
require_once __DIR__ . '/../includes/UserManager.php';
require_once __DIR__ . '/../includes/functions.php';

$userManager = new UserManager();

// Kiểm tra session
$token = $_SESSION['admin_token'] ?? '';
$user = $userManager->validateToken($token);

if (!$user['valid'] || $user['role'] !== 'admin') {
    redirect('login.php');
}

// Xử lý xóa logs
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'clear' && isset($_POST['log'])) {
        $logFile = LOGS_PATH . $_POST['log'];
        if (file_exists($logFile)) {
            file_put_contents($logFile, '');
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Đã xóa log!'];
        }
    }
    redirect('logs.php');
}

// Đọc logs
$logFiles = [
    'api_manager.log' => 'API Manager Log',
    'keyadmin.log' => 'Key Admin Log',
    'user_manager.log' => 'User Manager Log',
    'system.log' => 'System Log'
];

$currentLog = $_GET['log'] ?? 'system.log';
if (!array_key_exists($currentLog, $logFiles)) {
    $currentLog = 'system.log';
}

$logPath = LOGS_PATH . $currentLog;
$logContent = '';
$logSize = 0;
$logLines = [];

if (file_exists($logPath)) {
    $logSize = filesize($logPath);
    $logContent = file_get_contents($logPath);
    $logLines = explode("\n", trim($logContent));
    $logLines = array_reverse($logLines);
}

$message = $_SESSION['message'] ?? null;
unset($_SESSION['message']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logs - WusTeam Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h3>WusTeam</h3>
            <p>Admin Panel</p>
        </div>
        <div class="sidebar-menu">
            <a href="index.php"><i class="fas fa-dashboard"></i> Dashboard</a>
            <a href="users.php"><i class="fas fa-users"></i> Quản lý Users</a>
            <a href="apis.php"><i class="fas fa-plug"></i> Quản lý APIs</a>
            <a href="keys.php"><i class="fas fa-key"></i> API Keys</a>
            <a href="logs.php" class="active"><i class="fas fa-history"></i> Logs</a>
            <a href="settings.php"><i class="fas fa-cog"></i> Cài đặt</a>
            <a href="profile.php"><i class="fas fa-user"></i> Hồ sơ</a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navbar -->
        <div class="top-navbar">
            <button class="navbar-toggle">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="user-info">
                <span>Xin chào, <?php echo htmlspecialchars($user['full_name'] ?: $user['username']); ?></span>
                <div class="user-avatar">
                    <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                </div>
            </div>
        </div>

        <!-- Content -->
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Logs</h2>
                <div>
                    <a href="?log=<?php echo $currentLog; ?>" class="btn btn-outline-primary me-2">
                        <i class="fas fa-sync-alt me-2"></i>Làm mới
                    </a>
                    <a href="?log=<?php echo $currentLog; ?>&download=1" class="btn btn-success me-2">
                        <i class="fas fa-download me-2"></i>Tải xuống
                    </a>
                    <form method="POST" style="display: inline;" onsubmit="return confirm('Bạn có chắc muốn xóa log này?')">
                        <input type="hidden" name="action" value="clear">
                        <input type="hidden" name="log" value="<?php echo $currentLog; ?>">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-2"></i>Xóa log
                        </button>
                    </form>
                </div>
            </div>
            
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message['type'] === 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message['text']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Log Selector -->
            <div class="row mb-4">
                <div class="col-md-8">
                    <div class="btn-group" role="group">
                        <?php foreach ($logFiles as $file => $label): ?>
                            <a href="?log=<?php echo $file; ?>" class="btn btn-outline-primary <?php echo $currentLog === $file ? 'active' : ''; ?>">
                                <?php echo $label; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="col-md-4 text-end">
                    <span class="text-muted">
                        Kích thước: <?php echo format_bytes($logSize); ?> | 
                        Số dòng: <?php echo count($logLines); ?>
                    </span>
                </div>
            </div>
            
            <!-- Log Content -->
            <div class="data-table">
                <div class="mb-3">
                    <input type="text" class="form-control" id="searchLog" placeholder="Tìm kiếm trong log..." onkeyup="filterLog()">
                </div>
                
                <div class="log-container" style="background: #1e1e1e; color: #d4d4d4; padding: 20px; border-radius: 5px; font-family: monospace; max-height: 600px; overflow: auto;">
                    <?php if (empty($logLines) || (count($logLines) == 1 && empty($logLines[0]))): ?>
                        <p class="text-center text-muted">Log trống</p>
                    <?php else: ?>
                        <?php foreach ($logLines as $line): ?>
                            <?php if (empty($line)) continue; ?>
                            <div class="log-line" style="margin-bottom: 5px; white-space: pre-wrap;">
                                <?php 
                                $formattedLine = htmlspecialchars($line);
                                
                                // Highlight error
                                if (strpos($line, 'ERROR') !== false) {
                                    echo '<span style="color: #f48771;">' . $formattedLine . '</span>';
                                }
                                // Highlight warning
                                else if (strpos($line, 'WARNING') !== false) {
                                    echo '<span style="color: #ffb86b;">' . $formattedLine . '</span>';
                                }
                                // Highlight success
                                else if (strpos($line, 'SUCCESS') !== false || strpos($line, 'success') !== false) {
                                    echo '<span style="color: #50fa7b;">' . $formattedLine . '</span>';
                                }
                                // Highlight info
                                else if (strpos($line, 'INFO') !== false) {
                                    echo '<span style="color: #8be9fd;">' . $formattedLine . '</span>';
                                }
                                // Default
                                else {
                                    echo $formattedLine;
                                }
                                ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Loading -->
    <div class="loading" id="loading">
        <div class="spinner"></div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/admin.js"></script>
    <script>
        // Filter log
        function filterLog() {
            const input = document.getElementById('searchLog');
            const filter = input.value.toUpperCase();
            const lines = document.querySelectorAll('.log-line');
            
            lines.forEach(line => {
                if (line.textContent.toUpperCase().indexOf(filter) > -1) {
                    line.style.display = '';
                } else {
                    line.style.display = 'none';
                }
            });
        }
        
        // Auto refresh every 30 seconds
        setInterval(() => {
            window.location.reload();
        }, 30000);
    </script>
</body>
</html>