<?php
// admin/keys.php
session_start();
require_once __DIR__ . '/../includes/UserManager.php';
require_once __DIR__ . '/../includes/KeyManager.php';
require_once __DIR__ . '/../includes/functions.php';

$userManager = new UserManager();
$keyManager = new KeyManager();

// Kiểm tra session
$token = $_SESSION['admin_token'] ?? '';
$user = $userManager->validateToken($token);

if (!$user['valid'] || $user['role'] !== 'admin') {
    redirect('login.php');
}

// Xử lý actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'generate') {
        $userId = $_POST['user_id'] ?? $user['user_id'];
        $name = $_POST['name'] ?? 'API Key';
        $days = (int)($_POST['days'] ?? 30);
        
        $key = $keyManager->generateKey($userId, $name, $days);
        if ($key) {
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Tạo key thành công!', 'key' => $key];
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Không thể tạo key!'];
        }
        redirect('keys.php');
    }
    
    if ($action === 'disable') {
        $id = $_POST['id'];
        $result = $keyManager->disableKey($id);
        if ($result) {
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Vô hiệu hóa key thành công!'];
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Không thể vô hiệu hóa key!'];
        }
        redirect('keys.php');
    }
    
    if ($action === 'enable') {
        $id = $_POST['id'];
        $result = $keyManager->enableKey($id);
        if ($result) {
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Kích hoạt key thành công!'];
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Không thể kích hoạt key!'];
        }
        redirect('keys.php');
    }
    
    if ($action === 'delete') {
        $id = $_POST['id'];
        $result = $keyManager->deleteKey($id);
        if ($result) {
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Xóa key thành công!'];
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Không thể xóa key!'];
        }
        redirect('keys.php');
    }
    
    if ($action === 'renew') {
        $id = $_POST['id'];
        $days = (int)($_POST['days'] ?? 30);
        $result = $keyManager->renewKey($id, $days);
        if ($result) {
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Gia hạn key thành công!'];
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Không thể gia hạn key!'];
        }
        redirect('keys.php');
    }
}

// Lấy danh sách keys
$keys = $keyManager->getKeysList();

// Lấy danh sách users cho dropdown
$users = $userManager->getUsers();

$message = $_SESSION['message'] ?? null;
unset($_SESSION['message']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý API Keys - WusTeam Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h3>WusTeam</h3>
            <p>Admin Panel</p>
        </div>
        <div class="sidebar-menu">
            <a href="index.php"><i class="fas fa-dashboard"></i> Dashboard</a>
            <a href="users.php"><i class="fas fa-users"></i> Quản lý Users</a>
            <a href="apis.php"><i class="fas fa-plug"></i> Quản lý APIs</a>
            <a href="keys.php" class="active"><i class="fas fa-key"></i> API Keys</a>
            <a href="logs.php"><i class="fas fa-history"></i> Logs</a>
            <a href="settings.php"><i class="fas fa-cog"></i> Cài đặt</a>
            <a href="profile.php"><i class="fas fa-user"></i> Hồ sơ</a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navbar -->
        <div class="top-navbar">
            <button class="navbar-toggle">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="user-info">
                <span>Xin chào, <?php echo htmlspecialchars($user['full_name'] ?: $user['username']); ?></span>
                <div class="user-avatar">
                    <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                </div>
            </div>
        </div>

        <!-- Content -->
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Quản lý API Keys</h2>
                <button class="btn btn-primary" onclick="showGenerateModal()">
                    <i class="fas fa-plus me-2"></i>Tạo Key Mới
                </button>
            </div>
            
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message['type'] === 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message['text']; ?>
                    <?php if (isset($message['key'])): ?>
                        <br><strong>Key: </strong> <code><?php echo $message['key']; ?></code>
                        <button class="btn btn-sm btn-outline-primary ms-2" onclick="copyKey('<?php echo $message['key']; ?>')">
                            <i class="fas fa-copy"></i> Copy
                        </button>
                    <?php endif; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Search -->
            <div class="row mb-3">
                <div class="col-md-6">
                    <input type="text" class="form-control" id="searchInput" placeholder="Tìm kiếm key..." onkeyup="searchTable()">
                </div>
                <div class="col-md-6 text-end">
                    <button class="btn btn-outline-secondary" onclick="exportToCSV()">
                        <i class="fas fa-file-csv me-2"></i>Xuất CSV
                    </button>
                </div>
            </div>
            
            <!-- Keys Table -->
            <div class="data-table">
                <div class="table-responsive">
                    <table class="table" id="keysTable">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>API Key</th>
                                <th>Tên</th>
                                <th>Chủ sở hữu</th>
                                <th>Trạng thái</th>
                                <th>Số lần dùng</th>
                                <th>Lần cuối</th>
                                <th>Ngày tạo</th>
                                <th>Hết hạn</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($keys as $key): ?>
                            <tr>
                                <td><?php echo $key->id; ?></td>
                                <td>
                                    <code><?php echo substr($key->api_key, 0, 10); ?>...</code>
                                    <button class="btn btn-sm btn-outline-primary ms-1" onclick="copyKey('<?php echo $key->api_key; ?>')">
                                        <i class="fas fa-copy"></i>
                                    </button>
                                </td>
                                <td><?php echo htmlspecialchars($key->name ?: 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($key->owner ?: 'N/A'); ?></td>
                                <td>
                                    <?php if ($key->status === 'active'): ?>
                                        <?php if (strtotime($key->expires_at) < time()): ?>
                                            <span class="badge badge-warning">Hết hạn</span>
                                        <?php else: ?>
                                            <span class="badge badge-success">Active</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo number_format($key->usage_count); ?></td>
                                <td>
                                    <?php 
                                    if ($key->last_used) {
                                        echo time_ago($key->last_used);
                                    } else {
                                        echo 'Chưa dùng';
                                    }
                                    ?>
                                </td>
                                <td><?php echo date('d/m/Y', strtotime($key->created_at)); ?></td>
                                <td>
                                    <?php if ($key->expires_at): ?>
                                        <?php echo date('d/m/Y', strtotime($key->expires_at)); ?>
                                        <br>
                                        <small class="text-muted">
                                            <?php 
                                            $days = floor((strtotime($key->expires_at) - time()) / 86400);
                                            if ($days > 0) {
                                                echo "Còn $days ngày";
                                            } else {
                                                echo "<span class='text-danger'>Hết hạn</span>";
                                            }
                                            ?>
                                        </small>
                                    <?php else: ?>
                                        Không giới hạn
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($key->status === 'active'): ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="action" value="disable">
                                            <input type="hidden" name="id" value="<?php echo $key->id; ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-warning">
                                                <i class="fas fa-ban"></i>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="action" value="enable">
                                            <input type="hidden" name="id" value="<?php echo $key->id; ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-success">
                                                <i class="fas fa-check"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    
                                    <button class="btn btn-sm btn-outline-info" onclick="showRenewModal(<?php echo $key->id; ?>)">
                                        <i class="fas fa-clock"></i>
                                    </button>
                                    
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Bạn có chắc muốn xóa key này?')">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $key->id; ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            
                            <?php if (empty($keys)): ?>
                            <tr>
                                <td colspan="10" class="text-center py-4">
                                    <i class="fas fa-key fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">Chưa có API Key nào. Hãy tạo key mới!</p>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Generate Key Modal -->
    <div class="modal" id="generateModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title">Tạo API Key mới</h5>
                        <button type="button" class="modal-close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="action" value="generate">
                        
                        <div class="form-group">
                            <label class="form-label">Chọn user</label>
                            <select class="form-control" name="user_id" required>
                                <option value="">-- Chọn user --</option>
                                <?php foreach ($users as $u): ?>
                                    <option value="<?php echo $u->id; ?>" <?php echo $u->id == $user['user_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($u->username); ?> (<?php echo $u->email; ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Tên key</label>
                            <input type="text" class="form-control" name="name" value="API Key <?php echo date('Y-m-d'); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Số ngày hết hạn</label>
                            <input type="number" class="form-control" name="days" value="30" min="1" max="365" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Tạo</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Renew Key Modal -->
    <div class="modal" id="renewModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title">Gia hạn API Key</h5>
                        <button type="button" class="modal-close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="action" value="renew">
                        <input type="hidden" name="id" id="renewKeyId">
                        
                        <div class="form-group">
                            <label class="form-label">Số ngày gia hạn</label>
                            <input type="number" class="form-control" name="days" value="30" min="1" max="365" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Gia hạn</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Loading -->
    <div class="loading" id="loading">
        <div class="spinner"></div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/admin.js"></script>
    <script>
        // Show generate modal
        function showGenerateModal() {
            new bootstrap.Modal(document.getElementById('generateModal')).show();
        }
        
        // Show renew modal
        function showRenewModal(id) {
            document.getElementById('renewKeyId').value = id;
            new bootstrap.Modal(document.getElementById('renewModal')).show();
        }
        
        // Copy key to clipboard
        function copyKey(key) {
            navigator.clipboard.writeText(key).then(() => {
                window.toast.show('Đã copy key vào clipboard!', 'success');
            }).catch(() => {
                window.toast.show('Không thể copy key', 'error');
            });
        }
        
        // Export to CSV
        function exportToCSV() {
            TableUtils.exportToCSV('keysTable', 'keys_export_' + new Date().toISOString().slice(0,10));
        }
        
        // Search table
        function searchTable() {
            const input = document.getElementById('searchInput');
            TableUtils.search('keysTable', input);
        }
        
        // Handle modal close buttons
        document.querySelectorAll('[data-dismiss="modal"]').forEach(btn => {
            btn.addEventListener('click', function() {
                const modal = this.closest('.modal');
                bootstrap.Modal.getInstance(modal).hide();
            });
        });
    </script>
</body>
</html>