<?php
// admin/users.php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../includes/Database.php';
require_once __DIR__ . '/../includes/UserManager.php';
require_once __DIR__ . '/../includes/KeyManager.php';
require_once __DIR__ . '/../includes/functions.php';

$userManager = new UserManager();
$keyManager = new KeyManager();

// Kiểm tra session
$token = $_SESSION['admin_token'] ?? '';
$user = $userManager->validateToken($token);

if (!$user['valid'] || $user['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

// Xử lý thêm user
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add') {
        $data = [
            'username' => $_POST['username'],
            'password' => $_POST['password'],
            'email' => $_POST['email'],
            'full_name' => $_POST['full_name'] ?? '',
            'role' => $_POST['role'] ?? 'user'
        ];
        $result = $userManager->createUser($data);
        if ($result['success']) {
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Thêm user thành công!'];
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => $result['message']];
        }
        header('Location: users.php');
        exit;
    }
    
    if ($_POST['action'] === 'delete') {
        $userId = $_POST['user_id'];
        // Không cho xóa chính mình
        if ($userId != $user['user_id']) {
            $result = $userManager->deleteUser($userId);
            if ($result) {
                $_SESSION['message'] = ['type' => 'success', 'text' => 'Xóa user thành công!'];
            } else {
                $_SESSION['message'] = ['type' => 'error', 'text' => 'Không thể xóa user!'];
            }
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Không thể xóa tài khoản đang đăng nhập!'];
        }
        header('Location: users.php');
        exit;
    }
    
    if ($_POST['action'] === 'toggle_status') {
        $userId = $_POST['user_id'];
        $status = $_POST['status'];
        $result = $userManager->updateUser($userId, ['status' => $status]);
        if ($result) {
            $_SESSION['message'] = ['type' => 'success', 'text' => 'Cập nhật trạng thái thành công!'];
        } else {
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Không thể cập nhật trạng thái!'];
        }
        header('Location: users.php');
        exit;
    }
}

// Lấy danh sách users
$users = $userManager->getUsers();

// Lấy thống kê
$stats = $userManager->getStats();

$message = $_SESSION['message'] ?? null;
unset($_SESSION['message']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Users - WusTeam Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        .user-avatar-sm {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 14px;
        }
        .table td {
            vertical-align: middle;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h3>WusTeam</h3>
            <p>Admin Panel</p>
        </div>
        <div class="sidebar-menu">
            <a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="users.php" class="active"><i class="fas fa-users"></i> Quản lý Users</a>
            <a href="apis.php"><i class="fas fa-plug"></i> Quản lý APIs</a>
            <a href="keys.php"><i class="fas fa-key"></i> API Keys</a>
            <a href="logs.php"><i class="fas fa-history"></i> Logs</a>
            <a href="settings.php"><i class="fas fa-cog"></i> Cài đặt</a>
            <a href="profile.php"><i class="fas fa-user"></i> Hồ sơ</a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navbar -->
        <div class="top-navbar">
            <button class="navbar-toggle">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="user-info">
                <span>Xin chào, <?php echo htmlspecialchars($user['full_name'] ?: $user['username']); ?></span>
                <div class="user-avatar">
                    <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                </div>
            </div>
        </div>

        <!-- Content -->
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Quản lý Users</h2>
                <button class="btn btn-primary" onclick="showAddModal()">
                    <i class="fas fa-plus me-2"></i>Thêm User
                </button>
            </div>
            
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message['type']; ?> alert-dismissible fade show" role="alert">
                    <?php echo $message['text']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Stats Cards -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stats-value"><?php echo $stats['total_users'] ?? 0; ?></div>
                        <div class="stats-label">Tổng Users</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-icon" style="background: linear-gradient(135deg, #28a745, #20c997);">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="stats-value"><?php echo $stats['active_users'] ?? 0; ?></div>
                        <div class="stats-label">Đang hoạt động</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-icon" style="background: linear-gradient(135deg, #17a2b8, #6f42c1);">
                            <i class="fas fa-key"></i>
                        </div>
                        <div class="stats-value"><?php echo $stats['total_keys'] ?? 0; ?></div>
                        <div class="stats-label">Tổng Keys</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-icon" style="background: linear-gradient(135deg, #ffc107, #fd7e14);">
                            <i class="fas fa-rocket"></i>
                        </div>
                        <div class="stats-value"><?php echo $stats['today_spam'] ?? 0; ?></div>
                        <div class="stats-label">Spam hôm nay</div>
                    </div>
                </div>
            </div>
            
            <!-- Search -->
            <div class="row mb-3">
                <div class="col-md-6">
                    <input type="text" class="form-control" id="searchInput" placeholder="Tìm kiếm user..." onkeyup="searchTable()">
                </div>
                <div class="col-md-6 text-end">
                    <button class="btn btn-outline-secondary" onclick="exportToCSV()">
                        <i class="fas fa-file-csv me-2"></i>Xuất CSV
                    </button>
                </div>
            </div>
            
            <!-- Users Table -->
            <div class="data-table">
                <div class="table-responsive">
                    <table class="table" id="usersTable">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Email</th>
                                <th>Vai trò</th>
                                <th>Trạng thái</th>
                                <th>API Keys</th>
                                <th>Last Login</th>
                                <th>Ngày tạo</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $u): 
                                // Convert to object if it's array
                                $userItem = is_array($u) ? (object)$u : $u;
                            ?>
                            <tr>
                                <td><?php echo $userItem->id; ?></td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="user-avatar-sm me-2">
                                            <?php echo strtoupper(substr($userItem->username, 0, 1)); ?>
                                        </div>
                                        <div>
                                            <strong><?php echo htmlspecialchars($userItem->username); ?></strong>
                                            <?php if (!empty($userItem->full_name)): ?>
                                                <br><small><?php echo htmlspecialchars($userItem->full_name); ?></small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($userItem->email); ?></td>
                                <td>
                                    <?php if ($userItem->role === 'admin'): ?>
                                        <span class="badge bg-danger">Admin</span>
                                    <?php else: ?>
                                        <span class="badge bg-info">User</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($userItem->status === 'active'): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-primary" onclick="generateKey(<?php echo $userItem->id; ?>, '<?php echo htmlspecialchars($userItem->username); ?>')">
                                        <i class="fas fa-key me-1"></i>Tạo key
                                    </button>
                                </td>
                                <td>
                                    <?php 
                                    if (!empty($userItem->last_login)) {
                                        echo time_ago($userItem->last_login);
                                    } else {
                                        echo 'Chưa đăng nhập';
                                    }
                                    ?>
                                </td>
                                <td><?php echo date('d/m/Y', strtotime($userItem->created_at)); ?></td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <button class="btn btn-sm btn-outline-info" onclick="editUser(<?php echo $userItem->id; ?>)">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        
                                        <?php if ($userItem->status === 'active'): ?>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Vô hiệu hóa user này?')">
                                                <input type="hidden" name="action" value="toggle_status">
                                                <input type="hidden" name="user_id" value="<?php echo $userItem->id; ?>">
                                                <input type="hidden" name="status" value="inactive">
                                                <button type="submit" class="btn btn-sm btn-outline-warning">
                                                    <i class="fas fa-ban"></i>
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Kích hoạt user này?')">
                                                <input type="hidden" name="action" value="toggle_status">
                                                <input type="hidden" name="user_id" value="<?php echo $userItem->id; ?>">
                                                <input type="hidden" name="status" value="active">
                                                <button type="submit" class="btn btn-sm btn-outline-success">
                                                    <i class="fas fa-check"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        
                                        <?php if ($userItem->id != $user['user_id']): ?>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Bạn có chắc muốn xóa user này? Hành động này không thể hoàn tác!')">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="user_id" value="<?php echo $userItem->id; ?>">
                                                <button type="submit" class="btn btn-sm btn-outline-danger">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            
                            <?php if (empty($users)): ?>
                            <tr>
                                <td colspan="9" class="text-center py-4">
                                    <i class="fas fa-users fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">Chưa có user nào</p>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Add User Modal -->
    <div class="modal" id="addUserModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title">Thêm User mới</h5>
                        <button type="button" class="modal-close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        
                        <div class="form-group">
                            <label class="form-label">Username</label>
                            <input type="text" class="form-control" name="username" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Password</label>
                            <input type="password" class="form-control" name="password" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Họ tên</label>
                            <input type="text" class="form-control" name="full_name">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Vai trò</label>
                            <select class="form-control" name="role">
                                <option value="user">User</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Thêm</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Generate Key Modal -->
    <div class="modal" id="generateKeyModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="keys.php">
                    <div class="modal-header">
                        <h5 class="modal-title">Tạo API Key cho <span id="keyUsername"></span></h5>
                        <button type="button" class="modal-close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="action" value="generate">
                        <input type="hidden" name="user_id" id="keyUserId">
                        
                        <div class="form-group">
                            <label class="form-label">Tên key</label>
                            <input type="text" class="form-control" name="name" id="keyName" value="API Key" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Số ngày hết hạn</label>
                            <input type="number" class="form-control" name="days" value="30" min="1" max="365" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Tạo</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Loading -->
    <div class="loading" id="loading">
        <div class="spinner"></div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/admin.js"></script>
    <script>
        // Show add modal
        function showAddModal() {
            new bootstrap.Modal(document.getElementById('addUserModal')).show();
        }
        
        // Generate key
        function generateKey(userId, username) {
            document.getElementById('keyUserId').value = userId;
            document.getElementById('keyUsername').textContent = username;
            document.getElementById('keyName').value = 'API Key for ' + username;
            new bootstrap.Modal(document.getElementById('generateKeyModal')).show();
        }
        
        // Edit user (to be implemented)
        function editUser(userId) {
            window.location.href = 'profile.php?id=' + userId;
        }
        
        // Export to CSV
        function exportToCSV() {
            const table = document.getElementById('usersTable');
            const rows = table.querySelectorAll('tr');
            const csv = [];
            
            for (let i = 0; i < rows.length; i++) {
                const row = [];
                const cols = rows[i].querySelectorAll('td, th');
                
                for (let j = 0; j < cols.length; j++) {
                    // Skip action buttons column
                    if (j === 8) continue;
                    
                    let data = cols[j].innerText.replace(/"/g, '""');
                    row.push('"' + data + '"');
                }
                
                csv.push(row.join(','));
            }
            
            const csvContent = csv.join('\n');
            const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            
            a.href = url;
            a.download = 'users_export_' + new Date().toISOString().slice(0,10) + '.csv';
            a.click();
            
            URL.revokeObjectURL(url);
        }
        
        // Search table
        function searchTable() {
            const input = document.getElementById('searchInput');
            const filter = input.value.toUpperCase();
            const table = document.getElementById('usersTable');
            const tr = table.getElementsByTagName('tr');
            
            for (let i = 1; i < tr.length; i++) {
                const td = tr[i].getElementsByTagName('td');
                let found = false;
                
                for (let j = 0; j < td.length; j++) {
                    if (td[j] && td[j].innerText.toUpperCase().indexOf(filter) > -1) {
                        found = true;
                        break;
                    }
                }
                
                tr[i].style.display = found ? '' : 'none';
            }
        }
        
        // Handle modal close buttons
        document.querySelectorAll('[data-dismiss="modal"]').forEach(btn => {
            btn.addEventListener('click', function() {
                const modal = this.closest('.modal');
                const modalInstance = bootstrap.Modal.getInstance(modal);
                if (modalInstance) {
                    modalInstance.hide();
                }
            });
        });
    </script>
</body>
</html>