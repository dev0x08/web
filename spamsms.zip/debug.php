<?php
// debug.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>System Debug</h1>";

// PHP Info
echo "<h2>PHP Version</h2>";
echo phpversion();

// Check directories
echo "<h2>Directory Structure</h2>";
$base = __DIR__ . '/spamsms';
echo "Base path: " . $base . "<br>";

$dirs = [
    'spamsms',
    'spamsms/config',
    'spamsms/includes',
    'spamsms/api',
    'spamsms/admin',
    'spamsms/logs'
];

foreach ($dirs as $dir) {
    $path = __DIR__ . '/' . $dir;
    if (is_dir($path)) {
        echo "✅ $dir - OK<br>";
    } else {
        echo "❌ $dir - NOT FOUND<br>";
    }
}

// Check files
echo "<h2>Required Files</h2>";
$files = [
    'spamsms/config/database.php',
    'spamsms/config/constants.php',
    'spamsms/includes/Database.php',
    'spamsms/includes/UserManager.php',
    'spamsms/includes/KeyManager.php',
    'spamsms/includes/APIManager.php',
    'spamsms/includes/functions.php',
    'spamsms/api/keyadmin.php',
    'spamsms/api/user_api.php',
    'spamsms/api/api_manager.php'
];

foreach ($files as $file) {
    $path = __DIR__ . '/' . $file;
    if (file_exists($path)) {
        echo "✅ $file - OK<br>";
    } else {
        echo "❌ $file - NOT FOUND<br>";
    }
}

// Test database connection
echo "<h2>Database Connection Test</h2>";
try {
    require_once __DIR__ . '/spamsms/config/database.php';
    $pdo = new PDO("mysql:host=" . DB_HOST, DB_USER, DB_PASS);
    echo "✅ MySQL Connection - OK<br>";
    
    // Check if database exists
    $stmt = $pdo->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '" . DB_NAME . "'");
    if ($stmt->fetch()) {
        echo "✅ Database " . DB_NAME . " - EXISTS<br>";
    } else {
        echo "❌ Database " . DB_NAME . " - NOT FOUND<br>";
    }
} catch (Exception $e) {
    echo "❌ Database Error: " . $e->getMessage() . "<br>";
}