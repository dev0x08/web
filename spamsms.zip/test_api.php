<?php
// test_api.php
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Test API</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .success { color: green; }
        .error { color: red; }
        pre { background: #f4f4f4; padding: 10px; border-radius: 5px; }
    </style>
</head>
<body>
    <h1>Test API Endpoints</h1>
    
    <h2>1. KeyAdmin API</h2>
    <div id="keyadmin-result">Đang kiểm tra...</div>
    
    <h2>2. User API</h2>
    <div id="userapi-result">Đang kiểm tra...</div>
    
    <script>
        // Test KeyAdmin API
        fetch('/api/keyadmin.php?action=stats')
            .then(response => {
                if (!response.ok) throw new Error('HTTP ' + response.status);
                return response.json();
            })
            .then(data => {
                document.getElementById('keyadmin-result').innerHTML = 
                    '<div class="success">✅ Thành công</div><pre>' + 
                    JSON.stringify(data, null, 2) + '</pre>';
            })
            .catch(error => {
                document.getElementById('keyadmin-result').innerHTML = 
                    '<div class="error">❌ Lỗi: ' + error.message + '</div>';
            });
        
        // Test User API
        fetch('/api/user_api.php?action=stats')
            .then(response => {
                if (!response.ok) throw new Error('HTTP ' + response.status);
                return response.json();
            })
            .then(data => {
                document.getElementById('userapi-result').innerHTML = 
                    '<div class="success">✅ Thành công</div><pre>' + 
                    JSON.stringify(data, null, 2) + '</pre>';
            })
            .catch(error => {
                document.getElementById('userapi-result').innerHTML = 
                    '<div class="error">❌ Lỗi: ' + error.message + '</div>';
            });
    </script>
</body>
</html>